# FreightBox - Implementation TODO

> **Generated**: January 10, 2026
>
> **Based on**: Gap Analysis (GAPS.md)
>
> **Total Tasks**: 47 items across 8 categories

---

## Quick Stats

| Priority | Count | Effort |
|----------|-------|--------|
| P0 - Critical | 8 | ~12 hours |
| P1 - High | 12 | ~20 hours |
| P2 - Medium | 15 | ~30 hours |
| P3 - Future | 12 | ~80+ hours |
| **Total** | **47** | **~142+ hours** |

---

## P0 - Critical (Core Functionality Broken)

These must be fixed for the application to work properly.

### Prisma Schema Updates

- [ ] **Add TransportLeg model to Prisma schema**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Fields: id, shipmentId, sequence, mode, status, carrierId, loadLocationId, dischargeLocationId, vesselId, voyageNumber, flightNumber, truckNumber, vehicleId, etd, eta, atd, ata
  - Relations: shipment, carrier, loadLocation, dischargeLocation, vessel, events
  - Enums: TransportMode, LegStatus

- [ ] **Add TransportEvent model to Prisma schema**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Fields: id, legId, eventType, location (JSON), remarks, timestamp
  - Relations: leg (TransportLeg)
  - Enum: TransportEventType

- [ ] **Add ContainerEvent model to Prisma schema**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Fields: id, containerId, eventType, locationId, locationName, remarks, timestamp
  - Relations: container, location
  - Enum: ContainerEventType

- [ ] **Add ShipmentEvent model to Prisma schema**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Fields: id, shipmentId, eventType, eventCode, locationName, location (JSON), remarks, source, timestamp, reportedAt
  - Relations: shipment
  - Enum: ShipmentEventType

- [ ] **Add TitleTransfer model to Prisma schema**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Fields: id, documentId, sequence, transferType, fromPartyId, toPartyId, signature, previousHash, currentHash, remarks, transferredAt
  - Relations: document, fromParty, toParty
  - Enum: TitleTransferType

- [ ] **Add Location model to Prisma schema**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Fields: id, name, unlocode, locationType, address, city, country, lat, lng
  - Relations: containerEvents, loadLegs, dischargeLegs, containersAtLocation

### GraphQL Implementation

- [ ] **Implement dashboardStats query**
  - File: `apps/freightbox/backend/src/main.ts`
  - Return type: `{ recentActivity: [{ id, type, message, timestamp, user, icon }] }`
  - Logic: Aggregate recent shipments, bookings, documents, payments

- [ ] **Implement createBooking mutation**
  - File: `apps/freightbox/backend/src/main.ts`
  - Input: CreateBookingInput (mode, carrierId, pol, pod, commodity, containers, etc.)
  - Logic: Create booking → optionally create shipment → create container requests

---

## P1 - High (Key Workflows Incomplete)

### Container Model Fields

- [ ] **Add VGM fields to Container model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: vgm (Float), vgmMethod (VGMMethod enum), vgmDate (DateTime), vgmWeighingParty (String)

- [ ] **Add hazmat fields to Container model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: hazardous (Boolean), hazClass (String), unNumber (String)

- [ ] **Add location tracking to Container model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: currentLocationId (String), lastUpdate (DateTime)
  - Relation: currentLocation (Location)

- [ ] **Add events relation to Container model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: events (ContainerEvent[])

### Document Model Fields

- [ ] **Add BL-specific fields to Document model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: blType (BLType enum), isToOrder (Boolean), isNegotiable (Boolean), placeOfIssue, freightTerms, clauses (String[])

- [ ] **Add party relations to Document model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: shipperId, consigneeId, notifyPartyId with Party relations

- [ ] **Add blockchain fields to Document model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: blockchainHash, blockchainTxHash, anchoredAt (DateTime)

- [ ] **Add content fields to Document model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: pdfContent (Bytes), qrCode (String), documentData (Json)

- [ ] **Add lifecycle fields to Document model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: surrenderedAt (DateTime), accomplishedAt (DateTime), remarks (String)

- [ ] **Add titleChain relation to Document model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Add: titleChain (TitleTransfer[])

### GraphQL Implementation

- [ ] **Implement validateContainer mutation**
  - File: `apps/freightbox/backend/src/main.ts`
  - Uses: @ankr/twin ContainerOCR for ISO 6346 validation
  - Return: { valid, prefix, number, checkDigit, shippingLine }

- [ ] **Implement documentTemplates query**
  - File: `apps/freightbox/backend/src/main.ts`
  - Return: List of DocumentTemplate with id, name, documentType, version, isDefault

---

## P2 - Medium (Enhanced Features)

### Document Generation System

- [ ] **Create DocumentTemplate model**
  - File: `apps/freightbox/backend/prisma/schema.prisma`
  - Fields: id, name, documentType, version, content (template HTML), isDefault, isActive

- [ ] **Implement generateDocument mutation**
  - File: `apps/freightbox/backend/src/main.ts`
  - Input: shipmentId, documentType, templateId, customData
  - Logic: Fetch data → Render template → Generate PDF → Store → Return

- [ ] **Implement generateBulkDocuments mutation**
  - File: `apps/freightbox/backend/src/main.ts`
  - Input: shipmentIds[], documentTypes[]
  - Logic: Batch process multiple documents

- [ ] **Implement previewDocument query**
  - File: `apps/freightbox/backend/src/main.ts`
  - Input: documentType, data (JSON)
  - Return: HTML preview string

- [ ] **Add PDF generation service**
  - New file: `apps/freightbox/backend/src/services/pdf-generator.ts`
  - Dependencies: Puppeteer or PDFKit
  - Functions: renderTemplate, generatePDF, generateQRCode

### REST API Implementation

- [ ] **Implement /api/docchain/anchor endpoint**
  - File: `apps/freightbox/backend/src/main-standalone.ts` or new route file
  - Input: documentHash, metadata
  - Logic: Connect to blockchain → Submit transaction → Return txHash

- [ ] **Implement /api/docchain/verify endpoint**
  - File: `apps/freightbox/backend/src/main-standalone.ts`
  - Input: hash
  - Return: { verified, anchoredAt, txHash }

- [ ] **Implement /api/docchain/stats endpoint**
  - File: `apps/freightbox/backend/src/main-standalone.ts`
  - Return: { totalDocuments, totalAnchored, lastAnchorTime }

### AIS Integration

- [ ] **Implement /api/ais/vessels endpoint**
  - File: `apps/freightbox/backend/src/routes/ais.ts`
  - Input: imos (comma-separated)
  - Logic: Call Datalastic API → Return positions

- [ ] **Implement /api/ais/vessel/:imo endpoint**
  - File: `apps/freightbox/backend/src/routes/ais.ts`
  - Return: Single vessel with full details

- [ ] **Implement /api/ais/search endpoint**
  - File: `apps/freightbox/backend/src/routes/ais.ts`
  - Input: query (vessel name)
  - Return: Matching vessels

- [ ] **Implement /api/ais/history endpoint**
  - File: `apps/freightbox/backend/src/routes/ais.ts`
  - Input: imo, days
  - Return: Position history array

- [ ] **Create AIS service wrapper**
  - New file: `apps/freightbox/backend/src/services/ais-service.ts`
  - Providers: Datalastic, MarineTraffic (fallback)
  - Functions: getVesselPosition, searchVessels, getHistory

### Organization Queries

- [ ] **Implement organization query**
  - File: `apps/freightbox/backend/src/main.ts`
  - Return: Organization with users

- [ ] **Implement organizations query**
  - File: `apps/freightbox/backend/src/main.ts`
  - Return: List of organizations

- [ ] **Implement organizationUsers query**
  - File: `apps/freightbox/backend/src/main.ts`
  - Input: organizationId
  - Return: Users in organization

---

## P3 - Future (New Modules)

### Marketplace Module

- [ ] **Design Marketplace database schema**
  - Models: MarketplaceRequirement, MarketplaceBid, MarketplaceContract, EscrowTransaction, Vendor
  - Enums: RequirementStatus, BidStatus, ContractStatus, EscrowStatus

- [ ] **Implement Marketplace GraphQL schema**
  - Queries: requirements, requirement, bids, myBids, contracts, vendors
  - Mutations: createRequirement, submitBid, acceptBid, createContract, releaseEscrow

- [ ] **Create Marketplace frontend pages**
  - Already exist but need backend connection

- [ ] **Implement load matching algorithm**
  - Service to match requirements with vendor capabilities
  - Consider: route, capacity, price, rating

### APIBox Integrations

- [ ] **DigiLocker integration**
  - API: developer.digilocker.gov.in
  - Functions: fetchDocument, verifyDocument

- [ ] **GSTN integration**
  - API: developer.gst.gov.in
  - Functions: verifyGSTIN, getGSTReturns

- [ ] **Vahan integration**
  - API: vahan.parivahan.gov.in
  - Functions: verifyVehicle, getVehicleDetails

- [ ] **eWay Bill integration**
  - API: ewaybillgst.gov.in
  - Functions: generateEWayBill, cancelEWayBill, extendValidity

- [ ] **IceGate integration**
  - API: icegate.gov.in
  - Functions: submitBillOfEntry, submitShippingBill, getCustomsStatus

- [ ] **DGFT integration**
  - API: dgft.gov.in
  - Functions: verifyIEC, getLicenseStatus

### Container Tracking Integration

- [ ] **ShipsGo API integration**
  - Service: Container tracking
  - Functions: trackContainer, getContainerHistory

- [ ] **GoComet API integration**
  - Service: Multi-carrier tracking
  - Functions: trackByContainer, trackByBL

---

## Implementation Order

### Week 1: P0 Critical
1. Add all 6 missing Prisma models
2. Run migrations: `npx prisma migrate dev`
3. Implement dashboardStats query
4. Implement createBooking mutation
5. Test core workflows

### Week 2: P1 High - Schema
1. Add Container VGM/hazmat/location fields
2. Add Document BL/party/blockchain fields
3. Run migrations
4. Update GraphQL schema types
5. Update resolvers to use new fields

### Week 3: P1 High - Features
1. Implement validateContainer (use @ankr/twin)
2. Implement documentTemplates query
3. Basic PDF generation setup
4. Test document workflows

### Week 4: P2 Medium - Document Generation
1. Create DocumentTemplate model
2. Implement generateDocument mutation
3. Implement generateBulkDocuments
4. Implement previewDocument
5. Add QR code generation

### Week 5: P2 Medium - AIS Integration
1. Setup Datalastic API account
2. Create AIS service wrapper
3. Implement all /api/ais/* endpoints
4. Connect frontend tracking

### Week 6: P2 Medium - Blockchain
1. Deploy or connect to DocChain contract
2. Implement /api/docchain/* endpoints
3. Connect to useDocChain hook
4. Test anchoring flow

### Future Sprints: P3
- Marketplace module (2-3 weeks)
- APIBox integrations (2-3 weeks per integration)
- Container tracking APIs (1 week)

---

## Testing Checklist

### After P0 Completion
- [ ] Dashboard loads with recent activity
- [ ] Can create new booking
- [ ] Transport legs display in shipment detail
- [ ] Container events show in timeline
- [ ] Shipment events show in timeline
- [ ] eBL title chain displays correctly

### After P1 Completion
- [ ] Container VGM can be recorded
- [ ] Container validation works
- [ ] Document templates load
- [ ] Documents show party information
- [ ] Documents show blockchain status

### After P2 Completion
- [ ] PDF documents generate correctly
- [ ] QR codes scan successfully
- [ ] Vessel tracking shows real positions
- [ ] Document anchoring works
- [ ] Document verification works

---

## Environment Variables Needed

```env
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/freightbox

# AIS Tracking
DATALASTIC_API_KEY=your_key_here
MARINETRAFFIC_API_KEY=optional_backup

# Container Tracking
SHIPSGO_API_KEY=your_key_here
GOCOMET_API_KEY=your_key_here

# Blockchain
BLOCKCHAIN_RPC_URL=https://polygon-rpc.com
DOCCHAIN_CONTRACT_ADDRESS=0x...
DOCCHAIN_WALLET_KEY=0x...

# Government APIs (Future)
DIGILOCKER_CLIENT_ID=
DIGILOCKER_CLIENT_SECRET=
GSTN_API_KEY=
ICEGATE_USER_ID=
ICEGATE_PASSWORD=
```

---

## Commands Reference

```bash
# Navigate to backend
cd apps/freightbox/backend

# Generate Prisma client after schema changes
npx prisma generate

# Create migration
npx prisma migrate dev --name add_transport_models

# Apply migrations to production
npx prisma migrate deploy

# View database
npx prisma studio

# Run backend
pnpm dev
# or
npx nx serve freightbox-backend

# Run frontend
cd ../frontend
pnpm dev
# or
npx nx serve freightbox-frontend
```

---

## Notes

1. **Prisma migrations** should be run in sequence - don't skip adding related models
2. **@ankr/twin** package has ContainerOCR and SeaRoutes - reuse these
3. **BFF pattern** - all data goes through GraphQL, frontend never hits DB directly
4. **Port 4001** is the GraphQL backend, **Port 3000** is Next.js frontend
5. **main-standalone.ts** is REST alternative for simple integrations

---

*Generated by Claude Code Analysis*
*ANKR Labs - FreightBox Project*
