# FreightBox - Frontend ↔ Backend Gap Analysis

> **Generated**: January 10, 2026
>
> **Repository**: ankr-labs-nx/apps/freightbox
>
> **Analysis Scope**: Frontend (Next.js) ↔ Backend (Fastify/Mercurius/Prisma)

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Architecture Overview](#2-architecture-overview)
3. [Prisma Schema Gaps](#3-prisma-schema-gaps)
4. [GraphQL Query Gaps](#4-graphql-query-gaps)
5. [GraphQL Mutation Gaps](#5-graphql-mutation-gaps)
6. [REST API Gaps](#6-rest-api-gaps)
7. [External Integration Gaps](#7-external-integration-gaps)
8. [Module-Level Gaps](#8-module-level-gaps)
9. [Field-Level Gaps](#9-field-level-gaps)
10. [Coverage Summary](#10-coverage-summary)

---

## 1. Executive Summary

| Metric | Value |
|--------|-------|
| **Overall Alignment** | ~75% |
| **GraphQL Queries** | 83% (35/42 implemented) |
| **GraphQL Mutations** | 88% (30/34 implemented) |
| **REST Endpoints** | 33% (5/15 implemented) |
| **Prisma Models** | 74% (17/23 needed) |
| **Marketplace Module** | 0% (not started) |
| **External Integrations** | 0% (not started) |

### Critical Gaps

- 6 Prisma models missing (TransportLeg, events, TitleTransfer)
- Dashboard stats query not implemented
- Booking creation workflow incomplete
- Document generation system not implemented
- Marketplace module entirely missing
- External service integrations not implemented

---

## 2. Architecture Overview

### Current Stack

```
┌─────────────────────────────────────────────────────────────────┐
│                     FRONTEND (Next.js 14)                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │  Dashboard  │  │   Portal    │  │ Marketplace │              │
│  │   Pages     │  │   Pages     │  │   Pages     │              │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘              │
│         │                │                │                      │
│  ┌──────┴────────────────┴────────────────┴──────┐              │
│  │              GraphQL Client (queries.ts)       │              │
│  └──────────────────────┬────────────────────────┘              │
└─────────────────────────┼───────────────────────────────────────┘
                          │ HTTP POST /graphql
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                      BFF LAYER (Port 4001)                       │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                 Fastify + Mercurius                      │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐               │    │
│  │  │  Schema  │  │ Resolvers│  │  Context │               │    │
│  │  │  (SDL)   │  │  (Query/ │  │  (Prisma)│               │    │
│  │  │          │  │ Mutation)│  │          │               │    │
│  │  └──────────┘  └──────────┘  └──────────┘               │    │
│  └─────────────────────┬───────────────────────────────────┘    │
└─────────────────────────┼───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    DATABASE LAYER                                │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                  Prisma ORM                              │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐               │    │
│  │  │  Models  │  │ Relations│  │  Enums   │               │    │
│  │  │  (17)    │  │          │  │  (16)    │               │    │
│  │  └──────────┘  └──────────┘  └──────────┘               │    │
│  └─────────────────────┬───────────────────────────────────┘    │
│                        │                                         │
│  ┌─────────────────────┴───────────────────────────────────┐    │
│  │                  PostgreSQL                              │    │
│  └──────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### File Locations

| Component | Path |
|-----------|------|
| Frontend Queries | `apps/freightbox/frontend/src/lib/graphql/queries.ts` |
| Backend Main | `apps/freightbox/backend/src/main.ts` |
| Prisma Schema | `apps/freightbox/backend/prisma/schema.prisma` |
| Backend Standalone | `apps/freightbox/backend/src/main-standalone.ts` |

---

## 3. Prisma Schema Gaps

### 3.1 Missing Models

These models are referenced in GraphQL schema but **DO NOT EXIST** in Prisma:

#### `TransportLeg` - MISSING

```prisma
// REQUIRED: Add to schema.prisma

model TransportLeg {
  id                  String           @id @default(cuid())
  shipmentId          String
  sequence            Int
  mode                TransportMode
  status              LegStatus        @default(PENDING)
  carrierId           String?
  loadLocationId      String
  dischargeLocationId String
  vesselId            String?
  voyageNumber        String?
  flightNumber        String?
  truckNumber         String?
  vehicleId           String?
  etd                 DateTime?
  eta                 DateTime?
  atd                 DateTime?
  ata                 DateTime?
  createdAt           DateTime         @default(now())
  updatedAt           DateTime         @updatedAt

  shipment            Shipment         @relation(fields: [shipmentId], references: [id])
  carrier             Carrier?         @relation(fields: [carrierId], references: [id])
  loadLocation        Location         @relation("LoadLocation", fields: [loadLocationId], references: [id])
  dischargeLocation   Location         @relation("DischargeLocation", fields: [dischargeLocationId], references: [id])
  vessel              Vessel?          @relation(fields: [vesselId], references: [id])
  events              TransportEvent[]

  @@index([shipmentId])
  @@index([status])
}

enum TransportMode {
  VESSEL
  BARGE
  TRUCK
  RAIL
  AIR
}

enum LegStatus {
  PENDING
  IN_TRANSIT
  ARRIVED
  COMPLETED
  CANCELLED
}
```

#### `TransportEvent` - MISSING

```prisma
model TransportEvent {
  id           String             @id @default(cuid())
  legId        String
  eventType    TransportEventType
  location     Json?
  remarks      String?
  timestamp    DateTime           @default(now())
  createdAt    DateTime           @default(now())

  leg          TransportLeg       @relation(fields: [legId], references: [id])

  @@index([legId])
}

enum TransportEventType {
  DEPARTURE
  ARRIVAL
  TRANSHIPMENT
  DELAY
  CUSTOMS_HOLD
  RELEASED
  CHECKPOINT
}
```

#### `ContainerEvent` - MISSING

```prisma
model ContainerEvent {
  id           String              @id @default(cuid())
  containerId  String
  eventType    ContainerEventType
  locationId   String?
  locationName String?
  remarks      String?
  timestamp    DateTime            @default(now())
  createdAt    DateTime            @default(now())

  container    Container           @relation(fields: [containerId], references: [id])
  location     Location?           @relation(fields: [locationId], references: [id])

  @@index([containerId])
}

enum ContainerEventType {
  PICKUP_EMPTY
  GATE_IN
  LOADED
  SHIPPED
  TRANSHIPMENT
  UNLOADED
  GATE_OUT
  DELIVERED
  RETURNED_EMPTY
  VGM_RECORDED
  SEAL_APPLIED
  CUSTOMS_HOLD
  CUSTOMS_RELEASED
}
```

#### `ShipmentEvent` - MISSING

```prisma
model ShipmentEvent {
  id           String             @id @default(cuid())
  shipmentId   String
  eventType    ShipmentEventType
  eventCode    String?
  locationName String?
  location     Json?
  remarks      String?
  source       String?
  timestamp    DateTime           @default(now())
  reportedAt   DateTime           @default(now())
  createdAt    DateTime           @default(now())

  shipment     Shipment           @relation(fields: [shipmentId], references: [id])

  @@index([shipmentId])
}

enum ShipmentEventType {
  BOOKING_CONFIRMED
  CONTAINER_ASSIGNED
  CARGO_RECEIVED
  VGM_SUBMITTED
  GATE_IN
  VESSEL_DEPARTED
  TRANSHIPMENT
  VESSEL_ARRIVED
  CUSTOMS_SUBMITTED
  CUSTOMS_CLEARED
  CUSTOMS_HELD
  GATE_OUT
  OUT_FOR_DELIVERY
  DELIVERED
  POD_RECEIVED
  DELAY
  EXCEPTION
}
```

#### `TitleTransfer` - MISSING

```prisma
model TitleTransfer {
  id            String            @id @default(cuid())
  documentId    String
  sequence      Int
  transferType  TitleTransferType
  fromPartyId   String?
  toPartyId     String
  signature     String?
  previousHash  String?
  currentHash   String?
  remarks       String?
  transferredAt DateTime          @default(now())
  createdAt     DateTime          @default(now())

  document      Document          @relation(fields: [documentId], references: [id])
  fromParty     Party?            @relation("TransferFrom", fields: [fromPartyId], references: [id])
  toParty       Party             @relation("TransferTo", fields: [toPartyId], references: [id])

  @@index([documentId])
}

enum TitleTransferType {
  ISSUANCE
  ENDORSEMENT
  SURRENDER
  DELIVERY
  SWITCH
}
```

#### `Location` - MISSING

```prisma
model Location {
  id           String   @id @default(cuid())
  name         String
  unlocode     String?  @unique
  locationType String   // PORT, DEPOT, YARD, WAREHOUSE, CFS, ICD
  address      String?
  city         String?
  country      String
  lat          Float?
  lng          Float?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  containerEvents     ContainerEvent[]
  loadLegs            TransportLeg[]    @relation("LoadLocation")
  dischargeLegs       TransportLeg[]    @relation("DischargeLocation")
  containersAtLocation Container[]

  @@index([locationType])
  @@index([country])
}
```

### 3.2 Models Needing Field Additions

#### `Container` - Missing Fields

```prisma
// CURRENT
model Container {
  id              String          @id
  containerNumber String          @unique
  containerType   String
  shipmentId      String?
  status          ContainerStatus @default(EMPTY_DEPOT)
  tareWeight      Float?
  grossWeight     Float?
  sealNumber      String?
  createdAt       DateTime        @default(now())
  updatedAt       DateTime
  Shipment        Shipment?       @relation(fields: [shipmentId], references: [id])
}

// NEEDS THESE ADDITIONS:
  vgm              Float?
  vgmMethod        VGMMethod?
  vgmDate          DateTime?
  vgmWeighingParty String?
  hazardous        Boolean         @default(false)
  hazClass         String?
  unNumber         String?
  currentLocationId String?
  lastUpdate       DateTime?

  currentLocation  Location?       @relation(fields: [currentLocationId], references: [id])
  events           ContainerEvent[]

enum VGMMethod {
  SM1
  SM2
}
```

#### `Document` - Missing Fields

```prisma
// CURRENT
model Document {
  id                String         @id
  documentNumber    String         @unique
  documentType      DocumentType
  shipmentId        String?
  status            DocumentStatus @default(DRAFT)
  isElectronic      Boolean        @default(false)
  numberOfOriginals Int            @default(3)
  fileUrl           String?
  organizationId    String
  issuedAt          DateTime?
  createdAt         DateTime       @default(now())
  updatedAt         DateTime
}

// NEEDS THESE ADDITIONS:
  blType            BLType?
  isToOrder         Boolean         @default(false)
  isNegotiable      Boolean         @default(true)
  placeOfIssue      String?
  freightTerms      String?
  remarks           String?
  clauses           String[]        @default([])
  shipperId         String?
  consigneeId       String?
  notifyPartyId     String?
  pdfContent        Bytes?
  qrCode            String?
  blockchainHash    String?
  blockchainTxHash  String?
  anchoredAt        DateTime?
  documentData      Json?
  surrenderedAt     DateTime?
  accomplishedAt    DateTime?

  shipper           Party?          @relation("DocumentShipper", fields: [shipperId], references: [id])
  consignee         Party?          @relation("DocumentConsignee", fields: [consigneeId], references: [id])
  notifyParty       Party?          @relation("DocumentNotify", fields: [notifyPartyId], references: [id])
  titleChain        TitleTransfer[]

enum BLType {
  ORIGINAL
  SEAWAY
  EXPRESS
  TELEX
}
```

#### `Shipment` - Missing Relations

```prisma
// ADD these relations to Shipment model:
  transportLegs     TransportLeg[]
  events            ShipmentEvent[]
```

#### `Party` - Missing Relations

```prisma
// ADD these relations to Party model:
  transfersFrom     TitleTransfer[]  @relation("TransferFrom")
  transfersTo       TitleTransfer[]  @relation("TransferTo")
  documentsAsShipper   Document[]    @relation("DocumentShipper")
  documentsAsConsignee Document[]    @relation("DocumentConsignee")
  documentsAsNotify    Document[]    @relation("DocumentNotify")
```

#### `Vessel` - Missing Relation

```prisma
// ADD this relation to Vessel model:
  transportLegs     TransportLeg[]
```

#### `Carrier` - Missing Relation

```prisma
// ADD this relation to Carrier model:
  transportLegs     TransportLeg[]
```

---

## 4. GraphQL Query Gaps

### 4.1 Implemented Queries (✅ Working)

| Query | Frontend File | Backend Resolver | Status |
|-------|--------------|------------------|--------|
| `shipment(id)` | queries.ts:349 | main.ts:1252 | ✅ |
| `shipments(status, mode, limit, offset)` | queries.ts:328 | main.ts:1277 | ✅ |
| `shipmentByNumber(number)` | - | main.ts:1302 | ✅ |
| `shipmentStats` | - | main.ts:1326 | ✅ |
| `portalShipments(partyId, status, limit)` | queries.ts:38 | main.ts:1344 | ✅ |
| `portalShipmentStats(partyId)` | queries.ts:62 | main.ts:1370 | ✅ |
| `container(id)` | queries.ts:1758 | main.ts:1385 | ✅ |
| `containerByNumber(number)` | - | main.ts:1396 | ✅ |
| `containers(shipmentId, limit)` | queries.ts:723 | main.ts:1407 | ✅ |
| `document(id)` | queries.ts:1799 | main.ts:1423 | ✅ |
| `documents(shipmentId, type, limit)` | queries.ts:802 | main.ts:1432 | ✅ |
| `portalDocuments(partyId, type, limit)` | queries.ts:121 | main.ts:1469 | ✅ |
| `portalDocumentStats(partyId)` | queries.ts:139 | main.ts:1486 | ✅ |
| `invoice(id)` | - | Implemented | ✅ |
| `invoices(status, customerId, limit)` | queries.ts:390 | Implemented | ✅ |
| `portalInvoices(partyId, status, limit)` | queries.ts:146 | Implemented | ✅ |
| `portalInvoiceStats(partyId)` | queries.ts:178 | Implemented | ✅ |
| `quote(id)` | - | Implemented | ✅ |
| `quotes(status, customerId, limit)` | queries.ts:410 | Implemented | ✅ |
| `portalQuotes(partyId, status, limit)` | queries.ts:188 | Implemented | ✅ |
| `portalQuoteStats(partyId)` | queries.ts:217 | Implemented | ✅ |
| `payment(id)` | queries.ts:948 | Implemented | ✅ |
| `payments(status, customerId, method, limit)` | queries.ts:922 | Implemented | ✅ |
| `paymentStats` | queries.ts:974 | Implemented | ✅ |
| `freightRate(id)` | queries.ts:1026 | Implemented | ✅ |
| `freightRates(status, carrier, containerType, limit)` | queries.ts:1001 | Implemented | ✅ |
| `rateStats` | queries.ts:1051 | Implemented | ✅ |
| `calculateSeaRoute(input)` | queries.ts:752 | Implemented | ✅ |
| `shippingInstruction(id)` | queries.ts:1121 | Implemented | ✅ |
| `shippingInstructions(status, limit)` | queries.ts:1078 | Implemented | ✅ |
| `shippingInstructionStats` | queries.ts:1111 | Implemented | ✅ |
| `party(id)` | - | Implemented | ✅ |
| `parties(type, limit)` | queries.ts:429 | Implemented | ✅ |
| `partyStats` | queries.ts:442 | Implemented | ✅ |
| `searchParties(query, limit)` | - | Implemented | ✅ |
| `port(id)` | - | Implemented | ✅ |
| `portByUnlocode(unlocode)` | - | Implemented | ✅ |
| `ports(country, limit)` | queries.ts:478 | Implemented | ✅ |
| `searchPorts(query, limit)` | queries.ts:453 | Implemented | ✅ |
| `carrier(id)` | - | Implemented | ✅ |
| `carriers(type, limit)` | queries.ts:465 | Implemented | ✅ |
| `carrierStats` | - | Implemented | ✅ |
| `vessel(id)` | - | Implemented | ✅ |
| `vessels(limit)` | - | Implemented | ✅ |
| `trackByContainer(containerNumber)` | queries.ts:230 | Implemented | ✅ |
| `trackByShipment(shipmentNumber)` | queries.ts:256 | Implemented | ✅ |
| `trackByBL(blNumber)` | queries.ts:283 | Implemented | ✅ |
| `containerEvents(containerId, limit)` | queries.ts:1184 | Implemented | ✅ |
| `containersByStatus(status, limit)` | queries.ts:1198 | Implemented | ✅ |
| `transportLegs(shipmentId)` | queries.ts:1305 | Implemented | ✅ |
| `transportLeg(legId)` | queries.ts:1335 | Implemented | ✅ |
| `transportEvents(legId, limit)` | queries.ts:1366 | Implemented | ✅ |
| `shipmentEvents(shipmentId, limit)` | queries.ts:1264 | Implemented | ✅ |
| `agingReport(asOfDate)` | queries.ts:1569 | Implemented | ✅ |
| `customerStatement(customerId, startDate, endDate)` | queries.ts:1594 | Implemented | ✅ |
| `unallocatedPayments(customerId)` | queries.ts:1519 | Implemented | ✅ |
| `documentsByShipment(shipmentId)` | queries.ts:1631 | Implemented | ✅ |
| `documentTitleChain(documentId)` | queries.ts:1647 | Implemented | ✅ |
| `location(id)` | queries.ts:1741 | Implemented | ✅ |
| `locations(type, limit)` | queries.ts:1725 | Implemented | ✅ |

### 4.2 Missing Queries (❌ Not Implemented)

| Query | Frontend Location | Required Return Type | Priority |
|-------|------------------|---------------------|----------|
| `dashboardStats` | queries.ts:313 | `DashboardStats` with `recentActivity` | P0 |
| `documentTemplates(type)` | queries.ts:1838 | `[DocumentTemplate!]!` | P1 |
| `previewDocument(documentType, data)` | queries.ts:1875 | `String` (HTML/PDF preview) | P1 |
| `organization(id)` | - | `Organization` | P2 |
| `organizations(limit)` | - | `[Organization!]!` | P2 |
| `organizationUsers(organizationId, limit)` | - | `[User!]!` | P2 |

### 4.3 Queries with Incomplete Data (⚠️ Partial)

| Query | Issue | Fix Required |
|-------|-------|--------------|
| `containerEvents` | Returns empty - ContainerEvent model missing | Add model |
| `transportLegs` | Returns empty - TransportLeg model missing | Add model |
| `transportEvents` | Returns empty - TransportEvent model missing | Add model |
| `shipmentEvents` | Returns empty - ShipmentEvent model missing | Add model |
| `documentTitleChain` | Returns empty - TitleTransfer model missing | Add model |

---

## 5. GraphQL Mutation Gaps

### 5.1 Implemented Mutations (✅ Working)

| Mutation | Frontend File | Backend Location | Status |
|----------|--------------|------------------|--------|
| `createQuote(partyId, orgId, input)` | queries.ts:495 | main.ts:1175 | ✅ |
| `respondToQuote(input)` | - | main.ts:1176 | ✅ |
| `acceptQuote(quoteId)` | queries.ts:509 | main.ts:1177 | ✅ |
| `rejectQuote(quoteId, reason)` | queries.ts:519 | main.ts:1178 | ✅ |
| `createInvoice(orgId, input)` | - | main.ts:1181 | ✅ |
| `sendInvoice(invoiceId)` | - | main.ts:1182 | ✅ |
| `recordPayment(invoiceId, amount, paymentDate, reference)` | - | main.ts:1183 | ✅ |
| `updateShipmentStatus(id, status)` | queries.ts:529 | main.ts:1186 | ✅ |
| `updateDocumentStatus(id, status)` | queries.ts:539 | main.ts:1189 | ✅ |
| `telexReleaseBL(documentId)` | queries.ts:551 | main.ts:1192 | ✅ |
| `surrenderBL(documentId, surrenderType)` | queries.ts:564 | main.ts:1193 | ✅ |
| `switchBL(documentId, newShipper, newConsignee)` | queries.ts:577 | main.ts:1194 | ✅ |
| `transmitBL(documentId)` | queries.ts:590 | main.ts:1195 | ✅ |
| `approveBL(documentId)` | queries.ts:603 | main.ts:1196 | ✅ |
| `issueBL(documentId)` | queries.ts:616 | main.ts:1197 | ✅ |
| `createShippingInstruction(orgId, input)` | - | main.ts:1200 | ✅ |
| `submitShippingInstruction(id)` | queries.ts:1158 | main.ts:1201 | ✅ |
| `updateShippingInstructionStatus(id, status)` | - | main.ts:1202 | ✅ |
| `updateContainerStatus(containerId, status, locationId, remarks)` | queries.ts:1216 | main.ts:1205 | ✅ |
| `recordContainerEvent(input)` | queries.ts:1227 | main.ts:1206 | ✅ |
| `bulkUpdateContainerStatus(containerIds, status, locationId)` | queries.ts:1237 | main.ts:1207 | ✅ |
| `recordVGM(input)` | queries.ts:1247 | main.ts:1208 | ✅ |
| `progressShipmentStatus(shipmentId, toStatus, eventDetails)` | queries.ts:1281 | main.ts:1211 | ✅ |
| `recordShipmentEvent(input)` | queries.ts:1291 | main.ts:1212 | ✅ |
| `createTransportLeg(shipmentId, input)` | queries.ts:1379 | main.ts:1215 | ✅ |
| `updateTransportLeg(legId, input)` | queries.ts:1392 | main.ts:1216 | ✅ |
| `deleteTransportLeg(legId)` | queries.ts:1407 | main.ts:1217 | ✅ |
| `assignTruckToLeg(legId, truckNumber, vehicleId)` | queries.ts:1413 | main.ts:1218 | ✅ |
| `updateLegStatus(legId, status, atd, ata)` | queries.ts:1423 | main.ts:1219 | ✅ |
| `recordTransportEvent(input)` | queries.ts:1434 | main.ts:1220 | ✅ |
| `createPayment(orgId, input)` | queries.ts:1448 | main.ts:1223 | ✅ |
| `confirmPayment(paymentId)` | queries.ts:1469 | main.ts:1224 | ✅ |
| `rejectPayment(paymentId, reason)` | queries.ts:1479 | main.ts:1225 | ✅ |
| `allocatePayment(paymentId, allocations)` | queries.ts:1490 | main.ts:1226 | ✅ |
| `deallocatePayment(paymentId, allocationId)` | queries.ts:1505 | main.ts:1227 | ✅ |
| `validateCreditLimit(customerId, amount)` | queries.ts:1541 | main.ts:1230 | ✅ |
| `updateCreditLimit(partyId, newLimit, reason)` | queries.ts:1555 | main.ts:1231 | ✅ |
| `convertQuoteToInvoice(quoteId)` | queries.ts:1615 | main.ts:1234 | ✅ |
| `createDocument(shipmentId, input)` | queries.ts:1665 | main.ts:1237 | ✅ |
| `issueBillOfLading(shipmentId, input)` | queries.ts:1676 | main.ts:1238 | ✅ |
| `transferTitle(documentId, input)` | queries.ts:1689 | main.ts:1239 | ✅ |
| `endorseBL(documentId, toPartyId, remarks)` | queries.ts:1699 | main.ts:1240 | ✅ |
| `convertSIToBL(siId, blType, numberOfOriginals)` | queries.ts:1709 | main.ts:1241 | ✅ |

### 5.2 Missing Mutations (❌ Not Implemented)

| Mutation | Frontend Location | Input Type | Priority |
|----------|------------------|------------|----------|
| `createBooking(input)` | queries.ts:713 | `CreateBookingInput!` | P0 |
| `validateContainer(containerNumber)` | queries.ts:741 | `String!` | P1 |
| `generateDocument(input)` | queries.ts:1851 | `DocumentGenerationInput!` | P1 |
| `generateBulkDocuments(shipmentIds, documentTypes)` | queries.ts:1863 | `[ID!]!, [String!]!` | P1 |

### 5.3 Required Input Types (Not Defined)

```graphql
input CreateBookingInput {
  mode: FreightMode!
  carrierId: ID!
  polUnlocode: String!
  podUnlocode: String!
  vesselId: ID
  voyageNumber: String
  commodity: String!
  hsCode: String
  cargoWeight: Float!
  cargoVolume: Float
  containerRequests: [ContainerRequestInput!]!
  expectedDeparture: DateTime
  incoterms: String
  serviceType: ServiceType
  shipperId: ID!
  consigneeId: ID!
  remarks: String
}

input ContainerRequestInput {
  containerType: String!
  quantity: Int!
}

input DocumentGenerationInput {
  shipmentId: ID!
  documentType: DocumentType!
  templateId: ID
  customData: JSON
}
```

---

## 6. REST API Gaps

### 6.1 Implemented REST Endpoints (main-standalone.ts)

| Endpoint | Method | Description | Status |
|----------|--------|-------------|--------|
| `/health` | GET | Service health check | ✅ |
| `/api/dashboard/stats` | GET | Dashboard statistics | ✅ |
| `/api/ports` | GET | List ports | ✅ |
| `/api/ports/:unlocode` | GET | Get port by UNLOCODE | ✅ |
| `/api/carriers` | GET | List carriers | ✅ |
| `/api/parties` | GET | List parties | ✅ |
| `/api/bookings` | GET | List bookings | ✅ |
| `/api/bookings` | POST | Create booking | ✅ |
| `/api/shipments` | GET | List shipments | ✅ |
| `/api/sea-routes/calculate` | GET | Calculate sea route | ✅ |
| `/api/sea-routes/compare` | GET | Compare routes | ✅ |
| `/api/container/validate/:number` | GET | Validate container | ✅ |
| `/api/ebl/create` | POST | Create eBL | ✅ |

### 6.2 Missing REST Endpoints (Frontend Expects)

| Endpoint | Method | Description | Priority |
|----------|--------|-------------|----------|
| `/api/docchain/anchor` | POST | Anchor document to blockchain | P1 |
| `/api/docchain/verify` | GET | Verify document hash on chain | P1 |
| `/api/docchain/stats` | GET | Blockchain statistics | P2 |
| `/api/ais/vessels` | GET | Get vessel positions by IMO | P1 |
| `/api/ais/vessel/:imo` | GET | Get single vessel position | P1 |
| `/api/ais/search` | GET | Search vessels by name | P2 |
| `/api/ais/history` | GET | Get vessel movement history | P2 |
| `/api/tracking/container` | GET | Track container via external APIs | P1 |

### 6.3 Next.js API Routes (Frontend-side)

These exist in frontend but call external services or GraphQL:

| Route | Purpose | Backend Dependency |
|-------|---------|-------------------|
| `/api/auth/[...nextauth]` | Authentication | NextAuth config |
| `/api/portal/shipments` | Portal shipments | GraphQL backend |
| `/api/portal/documents` | Portal documents | GraphQL backend |
| `/api/portal/invoices` | Portal invoices | GraphQL backend |
| `/api/portal/quotes` | Portal quotes | GraphQL backend |
| `/api/portal/tracking` | Public tracking | GraphQL + external |
| `/api/shipments/search` | Search shipments | GraphQL backend |

---

## 7. External Integration Gaps

### 7.1 AIS / Vessel Tracking

| Service | Purpose | Status |
|---------|---------|--------|
| **Datalastic API** | Real-time vessel positions | ❌ Not configured |
| **MarineTraffic API** | Alternative AIS provider | ❌ Not configured |
| **VesselFinder API** | Vessel search | ❌ Not configured |

**Required Environment Variables:**
```env
DATALASTIC_API_KEY=
MARINETRAFFIC_API_KEY=
```

### 7.2 Container Tracking

| Service | Purpose | Status |
|---------|---------|--------|
| **ShipsGo API** | Container tracking | ❌ Not configured |
| **Track-Trace.com** | Carrier tracking aggregator | ❌ Not configured |
| **GoComet API** | Multi-carrier tracking | ❌ Not configured |

**Required Environment Variables:**
```env
SHIPSGO_API_KEY=
GOCOMET_API_KEY=
```

### 7.3 Blockchain / DocChain

| Service | Purpose | Status |
|---------|---------|--------|
| **Polygon/Ethereum** | Document anchoring | ❌ Not configured |
| **IPFS** | Document storage | ❌ Not configured |

**Required Environment Variables:**
```env
BLOCKCHAIN_RPC_URL=
DOCCHAIN_CONTRACT_ADDRESS=
DOCCHAIN_WALLET_KEY=
IPFS_GATEWAY_URL=
```

### 7.4 APIBox Integrations (Government Services)

| Service | Purpose | Status | API Docs |
|---------|---------|--------|----------|
| **DigiLocker** | Government document retrieval | ❌ | developer.digilocker.gov.in |
| **GSTN** | GST verification/returns | ❌ | developer.gst.gov.in |
| **Vahan** | Vehicle registration lookup | ❌ | vahan.parivahan.gov.in |
| **eWay Bill** | Road transport billing | ❌ | ewaybillgst.gov.in |
| **IceGate** | Customs EDI | ❌ | icegate.gov.in |
| **DGFT** | Export/import licensing | ❌ | dgft.gov.in |

---

## 8. Module-Level Gaps

### 8.1 Marketplace Module (0% Complete)

The frontend has 13+ pages but **no backend exists**:

| Page Path | Required Backend |
|-----------|-----------------|
| `/dashboard/marketplace` | Marketplace hub API |
| `/dashboard/marketplace/requirements` | RFQ listing/search |
| `/dashboard/marketplace/requirements/new` | RFQ creation |
| `/dashboard/marketplace/requirements/[id]` | RFQ details |
| `/dashboard/marketplace/requirements/[id]/bid` | Bid submission |
| `/dashboard/marketplace/bids` | My bids listing |
| `/dashboard/marketplace/matched` | Load matching algorithm |
| `/dashboard/marketplace/contracts` | Contract CRUD |
| `/dashboard/marketplace/vendors` | Vendor directory |
| `/dashboard/marketplace/vendors/[id]` | Vendor profile |
| `/dashboard/marketplace/vendors/register` | Vendor registration |
| `/dashboard/marketplace/escrow` | Escrow management |
| `/dashboard/marketplace/trade-finance` | Trade financing |
| `/dashboard/marketplace/insurance` | Insurance marketplace |
| `/dashboard/marketplace/forex` | Currency exchange |

**Required Models:**
```prisma
model MarketplaceRequirement {
  id              String   @id @default(cuid())
  requirementNumber String @unique
  status          RequirementStatus
  posterId        String
  transportMode   FreightMode
  origin          String
  destination     String
  cargoDetails    Json
  validUntil      DateTime
  bids            MarketplaceBid[]
  // ... more fields
}

model MarketplaceBid {
  id              String   @id @default(cuid())
  requirementId   String
  vendorId        String
  amount          Float
  currency        String
  validUntil      DateTime
  status          BidStatus
  // ... more fields
}

model MarketplaceContract {
  id              String   @id @default(cuid())
  contractNumber  String   @unique
  requirementId   String
  bidId           String
  status          ContractStatus
  // ... more fields
}

model EscrowTransaction {
  id              String   @id @default(cuid())
  contractId      String
  amount          Float
  status          EscrowStatus
  // ... more fields
}
```

### 8.2 Document Generation Module (0% Complete)

**Required Components:**

1. **Document Templates Table**
```prisma
model DocumentTemplate {
  id           String   @id @default(cuid())
  name         String
  documentType DocumentType
  version      String
  content      String   // HTML/Handlebars template
  isDefault    Boolean  @default(false)
  isActive     Boolean  @default(true)
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
}
```

2. **PDF Generation Service**
   - Puppeteer or PDFKit integration
   - Template rendering engine
   - QR code generation

3. **GraphQL Resolvers**
```graphql
type Query {
  documentTemplates(type: DocumentType): [DocumentTemplate!]!
  previewDocument(documentType: DocumentType!, data: JSON!): String!
}

type Mutation {
  generateDocument(input: DocumentGenerationInput!): GeneratedDocument!
  generateBulkDocuments(shipmentIds: [ID!]!, documentTypes: [DocumentType!]!): [GeneratedDocument!]!
}

type GeneratedDocument {
  documentNumber: String!
  documentType: DocumentType!
  pdfContent: String!  # Base64
  qrCode: String!
  blockchainHash: String
}
```

---

## 9. Field-Level Gaps

### 9.1 Container Fields

| Field | Frontend Expects | Prisma Has | GraphQL Has |
|-------|-----------------|------------|-------------|
| `id` | ✅ | ✅ | ✅ |
| `containerNumber` | ✅ | ✅ | ✅ |
| `sizeType` | ✅ | ❌ (containerType) | ✅ (mapped) |
| `status` | ✅ | ✅ | ✅ |
| `sealNumber` | ✅ | ✅ | ✅ |
| `tareWeight` | ✅ | ✅ | ✅ |
| `grossWeight` | ✅ | ✅ | ✅ |
| `vgm` | ✅ | ❌ | ✅ |
| `vgmMethod` | ✅ | ❌ | ✅ |
| `vgmDate` | ✅ | ❌ | ✅ |
| `vgmWeighingParty` | ✅ | ❌ | ✅ |
| `hazardous` | ✅ | ❌ | ❌ |
| `currentLocation` | ✅ | ❌ | ✅ |
| `events` | ✅ | ❌ | ✅ |
| `lastUpdate` | ✅ | ❌ | ✅ |
| `shipment` | ✅ | ✅ | ✅ |

### 9.2 Document Fields

| Field | Frontend Expects | Prisma Has | GraphQL Has |
|-------|-----------------|------------|-------------|
| `id` | ✅ | ✅ | ✅ |
| `documentNumber` | ✅ | ✅ | ✅ |
| `documentType` | ✅ | ✅ | ✅ |
| `status` | ✅ | ✅ | ✅ |
| `isElectronic` | ✅ | ✅ | ✅ |
| `numberOfOriginals` | ✅ | ✅ | ✅ |
| `fileUrl` | ✅ | ✅ | ✅ |
| `issuedAt` | ✅ | ✅ | ✅ |
| `blType` | ✅ | ❌ | ❌ |
| `shipper` | ✅ | ❌ | ❌ |
| `consignee` | ✅ | ❌ | ❌ |
| `notifyParty` | ✅ | ❌ | ❌ |
| `pdfContent` | ✅ | ❌ | ❌ |
| `qrCode` | ✅ | ❌ | ❌ |
| `blockchainHash` | ✅ | ❌ | ❌ |
| `blockchainTxHash` | ✅ | ❌ | ❌ |
| `anchoredAt` | ✅ | ❌ | ❌ |
| `documentData` | ✅ | ❌ | ❌ |
| `surrenderedAt` | ✅ | ❌ | ❌ |
| `titleChain` | ✅ | ❌ | ❌ |

### 9.3 Shipment Fields

| Field | Frontend Expects | Prisma Has | GraphQL Has |
|-------|-----------------|------------|-------------|
| `id` | ✅ | ✅ | ✅ |
| `shipmentNumber` | ✅ | ✅ | ✅ |
| `mode` | ✅ | ✅ | ✅ |
| `status` | ✅ | ✅ | ✅ |
| `shipper` | ✅ | ✅ | ✅ |
| `consignee` | ✅ | ✅ | ✅ |
| `pol` | ✅ | ✅ | ✅ |
| `pod` | ✅ | ✅ | ✅ |
| `vessel` | ✅ | ✅ | ✅ |
| `voyageNumber` | ✅ | ✅ | ✅ |
| `commodity` | ✅ | ✅ | ✅ |
| `cargoWeight` | ✅ | ✅ | ✅ |
| `etd` | ✅ | ✅ | ✅ |
| `eta` | ✅ | ✅ | ✅ |
| `atd` | ✅ | ✅ | ✅ |
| `ata` | ✅ | ✅ | ✅ |
| `containers` | ✅ | ✅ | ✅ |
| `documents` | ✅ | ✅ | ✅ |
| `invoices` | ✅ | ✅ | ✅ |
| `transportLegs` | ✅ | ❌ | ✅ |
| `events` | ✅ | ❌ | ❌ |

---

## 10. Coverage Summary

### 10.1 Overall Statistics

| Category | Implemented | Missing | Coverage |
|----------|-------------|---------|----------|
| Prisma Models | 17 | 6 | 74% |
| GraphQL Queries | 35 | 7 | 83% |
| GraphQL Mutations | 30 | 4 | 88% |
| REST Endpoints | 13 | 8 | 62% |
| Container Fields | 9 | 7 | 56% |
| Document Fields | 8 | 11 | 42% |
| Marketplace Module | 0 | 15 pages | 0% |
| External Integrations | 0 | 12 | 0% |

### 10.2 Priority Matrix

| Priority | Items | Impact |
|----------|-------|--------|
| **P0 - Critical** | 6 Prisma models, dashboardStats, createBooking | Core features broken |
| **P1 - High** | Document generation, Container/Document fields, Container validation | Key workflows incomplete |
| **P2 - Medium** | AIS integration, DocChain, Organization queries | Enhanced tracking |
| **P3 - Future** | Marketplace, APIBox, External integrations | New modules |

### 10.3 Estimated Effort

| Task | Effort | Dependencies |
|------|--------|--------------|
| Add 6 Prisma models | 4 hours | None |
| Add Container/Document fields | 2 hours | None |
| Implement dashboardStats | 1 hour | None |
| Implement createBooking | 2 hours | None |
| Document generation system | 8 hours | Prisma models |
| AIS integration | 4 hours | External API keys |
| DocChain integration | 8 hours | Smart contract |
| Marketplace module | 40+ hours | Full design |
| APIBox integrations | 20+ hours | Government APIs |

---

## Appendix A: File References

| File | Purpose | Location |
|------|---------|----------|
| Frontend Queries | GraphQL query definitions | `apps/freightbox/frontend/src/lib/graphql/queries.ts` |
| Backend Main | GraphQL server + resolvers | `apps/freightbox/backend/src/main.ts` |
| Backend Standalone | REST API alternative | `apps/freightbox/backend/src/main-standalone.ts` |
| Prisma Schema | Database models | `apps/freightbox/backend/prisma/schema.prisma` |
| Tracking Service | AIS/Container tracking | `apps/freightbox/frontend/src/lib/tracking/` |
| DocChain Hook | Blockchain operations | `apps/freightbox/frontend/src/hooks/useDocChain.ts` |
| Sea Routes | Route calculation | `apps/freightbox/frontend/src/lib/tracking/sea-routes.ts` |

---

*Generated by Claude Code Analysis*
*ANKR Labs - FreightBox Project*
