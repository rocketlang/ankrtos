// Ever Pure GraphQL API Service
// This connects to the real PostgreSQL backend via GraphQL

const API_URL = 'https://ever-pure.in/graphql';
const BASE_URL = 'https://ever-pure.in';

// Helper to make GraphQL requests
async function graphql<T>(query: string, variables?: Record<string, any>): Promise<T> {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query, variables }),
    });
    
    const result = await response.json();
    
    if (result.errors) {
      console.error('GraphQL Errors:', result.errors);
      throw new Error(result.errors[0]?.message || 'GraphQL Error');
    }
    
    return result.data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

// ============ PRODUCTS ============

export interface Product {
  id: number;
  nameEn: string;
  nameHi?: string;
  price: number;
  mrp: number;
  stock: number;
  category?: string;
  imageUrl?: string;
  badge?: string;
  weight?: string;
  benefits?: string[];
  tags?: string[];
  isActive: boolean;
}

export async function getProducts(category?: string, limit?: number, search?: string): Promise<Product[]> {
  const query = `
    query GetProducts($category: String, $limit: Int, $search: String) {
      products(category: $category, limit: $limit, search: $search) {
        id
        nameEn
        nameHi
        price
        mrp
        stock
        category
        imageUrl
        badge
        weight
        benefits
        tags
        isActive
      }
    }
  `;
  
  const data = await graphql<{ products: Product[] }>(query, { category, limit, search });
  
  // Fix image URLs - prepend base URL for relative paths
  return data.products.map(p => ({
    ...p,
    imageUrl: p.imageUrl?.startsWith('http') ? p.imageUrl : p.imageUrl ? `${BASE_URL}${p.imageUrl}` : undefined
  }));
}

export async function getProduct(id?: number, sku?: string): Promise<Product | null> {
  const query = `
    query GetProduct($id: Int, $sku: String) {
      product(id: $id, sku: $sku) {
        id
        nameEn
        nameHi
        price
        mrp
        stock
        category
        imageUrl
        badge
        weight
        benefits
        tags
        isActive
      }
    }
  `;
  
  const data = await graphql<{ product: Product | null }>(query, { id, sku });
  if (!data.product) return null;
  
  return {
    ...data.product,
    imageUrl: data.product.imageUrl?.startsWith('http') ? data.product.imageUrl : data.product.imageUrl ? `${BASE_URL}${data.product.imageUrl}` : undefined
  };
}

export async function searchProducts(queryStr: string, category?: string, limit?: number): Promise<Product[]> {
  const query = `
    query SearchProducts($query: String!, $category: String, $limit: Int) {
      searchProducts(query: $query, category: $category, limit: $limit) {
        id
        nameEn
        nameHi
        price
        mrp
        stock
        category
        imageUrl
        badge
        weight
      }
    }
  `;
  
  const data = await graphql<{ searchProducts: Product[] }>(query, { query: queryStr, category, limit });
  
  return data.searchProducts.map(p => ({
    ...p,
    imageUrl: p.imageUrl?.startsWith('http') ? p.imageUrl : p.imageUrl ? `${BASE_URL}${p.imageUrl}` : undefined
  }));
}

export async function getCategories(): Promise<string[]> {
  const query = `
    query GetCategories {
      categories
    }
  `;
  
  const data = await graphql<{ categories: string[] }>(query);
  return data.categories;
}

// ============ ORDERS ============

export interface OrderItem {
  productId: number;
  name: string;
  price: number;
  quantity: number;
  total: number;
}

export interface Order {
  id: number;
  orderId: string;
  invoiceNo: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  customerAddress?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryCharge: number;
  discount: number;
  total: number;
  paymentMethod: string;
  paymentStatus: string;
  orderStatus: string;
  trackingId?: string;
  createdAt: string;
}

export interface CreateOrderInput {
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  customerAddress: string;
  items: OrderItem[];
  paymentMethod: string;
}

export async function createOrder(input: CreateOrderInput): Promise<Order> {
  const mutation = `
    mutation CreateOrderFromCart(
      $customerName: String!
      $customerPhone: String!
      $customerEmail: String
      $customerAddress: String!
      $items: JSON!
      $paymentMethod: String!
    ) {
      createOrderFromCart(
        customerName: $customerName
        customerPhone: $customerPhone
        customerEmail: $customerEmail
        customerAddress: $customerAddress
        items: $items
        paymentMethod: $paymentMethod
      ) {
        id
        orderId
        invoiceNo
        customerName
        customerPhone
        customerEmail
        customerAddress
        items
        subtotal
        deliveryCharge
        discount
        total
        paymentMethod
        paymentStatus
        orderStatus
        createdAt
      }
    }
  `;
  
  const data = await graphql<{ createOrderFromCart: Order }>(mutation, {
    customerName: input.customerName,
    customerPhone: input.customerPhone,
    customerEmail: input.customerEmail,
    customerAddress: input.customerAddress,
    items: input.items,
    paymentMethod: input.paymentMethod,
  });
  
  return data.createOrderFromCart;
}

export async function confirmPayment(orderId: string, razorpayPaymentId: string, razorpaySignature: string): Promise<Order> {
  const mutation = `
    mutation ConfirmPayment($orderId: String!, $razorpayPaymentId: String!, $razorpaySignature: String!) {
      confirmPayment(orderId: $orderId, razorpayPaymentId: $razorpayPaymentId, razorpaySignature: $razorpaySignature) {
        id
        orderId
        paymentStatus
        orderStatus
      }
    }
  `;
  
  const data = await graphql<{ confirmPayment: Order }>(mutation, {
    orderId,
    razorpayPaymentId,
    razorpaySignature,
  });
  
  return data.confirmPayment;
}

export async function getCustomerOrders(phone: string): Promise<Order[]> {
  const query = `
    query CustomerOrders($phone: String!) {
      customerOrders(phone: $phone) {
        id
        orderId
        invoiceNo
        customerName
        customerPhone
        customerAddress
        items
        subtotal
        deliveryCharge
        discount
        total
        paymentMethod
        paymentStatus
        orderStatus
        trackingId
        createdAt
      }
    }
  `;
  
  const data = await graphql<{ customerOrders: Order[] }>(query, { phone });
  return data.customerOrders || [];
}

export async function trackOrder(orderId: string, phone: string): Promise<Order | null> {
  const query = `
    query TrackOrder($orderId: String!, $phone: String!) {
      trackOrder(orderId: $orderId, phone: $phone) {
        id
        orderId
        invoiceNo
        customerName
        customerPhone
        customerAddress
        items
        subtotal
        deliveryCharge
        discount
        total
        paymentMethod
        paymentStatus
        orderStatus
        trackingId
        createdAt
      }
    }
  `;
  
  const data = await graphql<{ trackOrder: Order | null }>(query, { orderId, phone });
  return data.trackOrder;
}

// ============ AUTH ============

export interface AuthResponse {
  success: boolean;
  message?: string;
  token?: string;
  customer?: Customer;
}

export interface OTPResponse {
  success: boolean;
  message: string;
}

export interface Customer {
  id: number;
  name?: string;
  phone: string;
  email?: string;
  loyaltyPoints: number;
  totalOrders: number;
  totalSpent: number;
}

export async function sendOTP(phone: string): Promise<OTPResponse> {
  const mutation = `
    mutation SendOTP($phone: String!) {
      sendOTP(phone: $phone) {
        success
        message
      }
    }
  `;
  
  const data = await graphql<{ sendOTP: OTPResponse }>(mutation, { phone });
  return data.sendOTP;
}

export async function verifyOTP(phone: string, otp: string): Promise<AuthResponse> {
  const mutation = `
    mutation VerifyOTP($phone: String!, $otp: String!) {
      verifyOTP(phone: $phone, otp: $otp) {
        success
        message
        token
        customer {
          id
          name
          phone
          email
          loyaltyPoints
          totalOrders
          totalSpent
        }
      }
    }
  `;
  
  const data = await graphql<{ verifyOTP: AuthResponse }>(mutation, { phone, otp });
  return data.verifyOTP;
}

// ============ WISHLIST ============

export async function toggleWishlist(customerId: number, productId: number): Promise<boolean> {
  const mutation = `
    mutation ToggleWishlist($customerId: Int!, $productId: Int!) {
      toggleWishlist(customerId: $customerId, productId: $productId)
    }
  `;
  
  const data = await graphql<{ toggleWishlist: boolean }>(mutation, { customerId, productId });
  return data.toggleWishlist;
}

export async function getWishlist(customerId: number): Promise<Product[]> {
  const query = `
    query MyWishlist($customerId: Int!) {
      myWishlist(customerId: $customerId) {
        id
        nameEn
        price
        mrp
        stock
        imageUrl
      }
    }
  `;
  
  const data = await graphql<{ myWishlist: Product[] }>(query, { customerId });
  return data.myWishlist?.map(p => ({
    ...p,
    imageUrl: p.imageUrl?.startsWith('http') ? p.imageUrl : p.imageUrl ? `${BASE_URL}${p.imageUrl}` : undefined
  })) || [];
}

// ============ REVIEWS ============

export interface ProductReview {
  id: number;
  productId: number;
  customerName: string;
  rating: number;
  title?: string;
  review?: string;
  createdAt: string;
  isApproved: boolean;
}

export async function addReview(
  productId: number,
  customerName: string,
  customerPhone: string,
  rating: number,
  title?: string,
  comment?: string
): Promise<ProductReview> {
  const mutation = `
    mutation AddReview(
      $productId: Int!
      $customerName: String!
      $customerPhone: String!
      $rating: Int!
      $title: String
      $comment: String
    ) {
      addReview(
        productId: $productId
        customerName: $customerName
        customerPhone: $customerPhone
        rating: $rating
        title: $title
        comment: $comment
      ) {
        id
        productId
        rating
        title
      }
    }
  `;
  
  const data = await graphql<{ addReview: ProductReview }>(mutation, {
    productId,
    customerName,
    customerPhone,
    rating,
    title,
    comment,
  });
  
  return data.addReview;
}

export async function getProductReviews(productId: number): Promise<ProductReview[]> {
  const query = `
    query GetProductReviews($productId: Int!) {
      getProductReviews(productId: $productId) {
        id
        productId
        customerName
        rating
        title
        review
        createdAt
        isApproved
      }
    }
  `;
  
  const data = await graphql<{ getProductReviews: ProductReview[] }>(query, { productId });
  return data.getProductReviews || [];
}

// ============ DISCOUNTS ============

export interface Discount {
  id: number;
  code: string;
  discountType: string;
  discountValue: number;
  minOrderValue?: number;
  maxDiscount?: number;
  isActive: boolean;
}

export async function validateDiscount(code: string, cartTotal: number): Promise<Discount | null> {
  const query = `
    query ValidateDiscount($code: String!, $cartTotal: Float!) {
      validateDiscount(code: $code, cartTotal: $cartTotal) {
        id
        code
        discountType
        discountValue
        minOrderValue
        maxDiscount
        isActive
      }
    }
  `;
  
  const data = await graphql<{ validateDiscount: Discount | null }>(query, { code, cartTotal });
  return data.validateDiscount;
}

// ============ UTILS ============

export function getImageUrl(path: string | undefined): string {
  if (!path) return 'https://via.placeholder.com/150?text=No+Image';
  if (path.startsWith('http')) return path;
  return `${BASE_URL}${path}`;
}

export { BASE_URL, API_URL };
