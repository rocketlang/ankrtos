import React, { useState, useEffect } from 'react';
import { 
  View, Text, ScrollView, TouchableOpacity, StyleSheet, 
  RefreshControl, ActivityIndicator 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const API_URL = 'https://ever-pure.in/graphql';

// GraphQL query helper
async function graphql(query: string, variables?: any) {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
  const data = await res.json();
  if (data.errors) throw new Error(data.errors[0]?.message);
  return data.data;
}

interface DashboardStats {
  totalProducts: number;
  totalOrders: number;
  totalCustomers: number;
  totalVendors: number;
  totalRevenue: number;
  todayRevenue: number;
  todayOrders: number;
  pendingOrders: number;
  activeAlerts: number;
}

interface RecentOrder {
  id: number;
  orderId: string;
  customerName: string;
  total: number;
  orderStatus: string;
  createdAt: string;
}

interface LowStockProduct {
  id: number;
  sku: string;
  nameEn: string;
  stock: number;
  minStock: number;
}

export default function AdminDashboard({ navigation }: any) {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);
  const [lowStock, setLowStock] = useState<LowStockProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      setLoading(true);
      
      // Fetch dashboard stats
      const statsData = await graphql(`query { dashboardStats }`);
      setStats(statsData.dashboardStats || {});
      
      // Fetch recent orders
      const ordersData = await graphql(`
        query { orders(limit: 5) { id orderId customerName total orderStatus createdAt } }
      `);
      setRecentOrders(ordersData.orders || []);
      
      // Fetch products for low stock check
      const productsData = await graphql(`
        query { products(limit: 50) { id sku nameEn stock } }
      `);
      const products = productsData.products || [];
      setLowStock(products.filter((p: any) => p.stock <= 10));
      
    } catch (e) {
      console.error('Dashboard load error:', e);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboard();
    setRefreshing(false);
  };

  const getStatusStyle = (status: string) => {
    switch (status?.toUpperCase()) {
      case 'DELIVERED': return { bg: '#D1FAE5', text: '#059669' };
      case 'CONFIRMED': return { bg: '#DBEAFE', text: '#3B82F6' };
      case 'PROCESSING': return { bg: '#FEF3C7', text: '#F59E0B' };
      case 'SHIPPED': return { bg: '#E9D5FF', text: '#9333EA' };
      case 'CANCELLED': return { bg: '#FEE2E2', text: '#EF4444' };
      default: return { bg: '#F3F4F6', text: '#6B7280' };
    }
  };

  if (loading) {
    return (
      <View style={s.loadingContainer}>
        <ActivityIndicator size="large" color="#059669" />
        <Text style={s.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  const statCards = [
    { label: 'Total Products', value: stats?.totalProducts || 0, icon: 'cube', color: '#3B82F6', trend: '+12%' },
    { label: 'Total Orders', value: stats?.totalOrders || 0, icon: 'cart', color: '#059669', trend: '+8%' },
    { label: 'Customers', value: stats?.totalCustomers || 0, icon: 'people', color: '#9333EA', trend: '+15%' },
    { label: 'Vendors', value: stats?.totalVendors || 0, icon: 'business', color: '#F59E0B', trend: '0%' },
    { label: 'Today Revenue', value: `₹${(stats?.todayRevenue || 0).toLocaleString()}`, icon: 'trending-up', color: '#059669', trend: '+25%' },
    { label: 'Stock Alerts', value: lowStock.length, icon: 'warning', color: '#EF4444', trend: '-5%' },
  ];

  return (
    <ScrollView 
      style={s.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#059669']} />}
    >
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.greeting}>Admin Dashboard</Text>
          <Text style={s.subtitle}>Ever Pure Management</Text>
        </View>
        <TouchableOpacity style={s.notifBtn}>
          <Ionicons name="notifications-outline" size={24} color="#374151" />
          <View style={s.notifBadge} />
        </TouchableOpacity>
      </View>

      {/* Stats Grid */}
      <View style={s.statsGrid}>
        {statCards.map((card, i) => (
          <TouchableOpacity key={i} style={s.statCard}>
            <View style={s.statHeader}>
              <View style={[s.statIcon, { backgroundColor: card.color + '20' }]}>
                <Ionicons name={card.icon as any} size={20} color={card.color} />
              </View>
              <View style={[s.trendBadge, { backgroundColor: card.trend.startsWith('+') ? '#D1FAE5' : '#FEE2E2' }]}>
                <Ionicons 
                  name={card.trend.startsWith('+') ? 'arrow-up' : 'arrow-down'} 
                  size={10} 
                  color={card.trend.startsWith('+') ? '#059669' : '#EF4444'} 
                />
                <Text style={[s.trendText, { color: card.trend.startsWith('+') ? '#059669' : '#EF4444' }]}>
                  {card.trend}
                </Text>
              </View>
            </View>
            <Text style={s.statLabel}>{card.label}</Text>
            <Text style={s.statValue}>{card.value}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Revenue Summary */}
      <View style={s.section}>
        <View style={s.sectionHeader}>
          <Ionicons name="trending-up" size={20} color="#059669" />
          <Text style={s.sectionTitle}>Revenue Summary</Text>
        </View>
        <View style={s.revenueCard}>
          <View style={[s.revenueRow, { backgroundColor: '#F0FDF4' }]}>
            <Text style={s.revenueLabel}>Total Revenue</Text>
            <Text style={[s.revenueValue, { color: '#059669' }]}>
              ₹{(stats?.totalRevenue || 0).toLocaleString()}
            </Text>
          </View>
          <View style={[s.revenueRow, { backgroundColor: '#EFF6FF' }]}>
            <Text style={s.revenueLabel}>Today's Revenue</Text>
            <Text style={[s.revenueValue, { color: '#3B82F6' }]}>
              ₹{(stats?.todayRevenue || 0).toLocaleString()}
            </Text>
          </View>
          <View style={[s.revenueRow, { backgroundColor: '#FFF7ED' }]}>
            <Text style={s.revenueLabel}>Pending Orders</Text>
            <Text style={[s.revenueValue, { color: '#F59E0B' }]}>{stats?.pendingOrders || 0}</Text>
          </View>
          <View style={[s.revenueRow, { backgroundColor: '#FAF5FF' }]}>
            <Text style={s.revenueLabel}>Today's Orders</Text>
            <Text style={[s.revenueValue, { color: '#9333EA' }]}>{stats?.todayOrders || 0}</Text>
          </View>
        </View>
      </View>

      {/* Low Stock Alerts */}
      <View style={s.section}>
        <View style={s.sectionHeader}>
          <Ionicons name="warning" size={20} color="#EF4444" />
          <Text style={s.sectionTitle}>Low Stock Alerts</Text>
          {lowStock.length > 0 && (
            <View style={s.alertBadge}>
              <Text style={s.alertBadgeText}>{lowStock.length} items</Text>
            </View>
          )}
        </View>
        
        {lowStock.length === 0 ? (
          <View style={s.emptyAlert}>
            <Ionicons name="checkmark-circle" size={40} color="#059669" />
            <Text style={s.emptyAlertText}>All products are well stocked!</Text>
          </View>
        ) : (
          <View style={s.stockList}>
            {lowStock.slice(0, 5).map(product => (
              <View key={product.id} style={s.stockItem}>
                <View style={s.stockInfo}>
                  <Text style={s.stockName}>{product.nameEn}</Text>
                  <Text style={s.stockSku}>SKU: {product.sku}</Text>
                </View>
                <View style={s.stockCount}>
                  <Text style={s.stockValue}>{product.stock} left</Text>
                </View>
              </View>
            ))}
          </View>
        )}
      </View>

      {/* Recent Orders */}
      <View style={s.section}>
        <View style={s.sectionHeader}>
          <Ionicons name="cart" size={20} color="#3B82F6" />
          <Text style={s.sectionTitle}>Recent Orders</Text>
          <TouchableOpacity onPress={() => navigation.navigate('AdminOrders')}>
            <Text style={s.viewAll}>View All</Text>
          </TouchableOpacity>
        </View>
        
        {recentOrders.length === 0 ? (
          <View style={s.emptyOrders}>
            <Text style={s.emptyOrdersText}>No orders yet</Text>
          </View>
        ) : (
          <View style={s.ordersList}>
            {recentOrders.map(order => {
              const statusStyle = getStatusStyle(order.orderStatus);
              return (
                <TouchableOpacity key={order.id} style={s.orderItem}>
                  <View style={s.orderInfo}>
                    <Text style={s.orderId}>{order.orderId}</Text>
                    <Text style={s.orderCustomer}>{order.customerName || 'Guest'}</Text>
                  </View>
                  <View style={s.orderRight}>
                    <Text style={s.orderTotal}>₹{order.total}</Text>
                    <View style={[s.statusBadge, { backgroundColor: statusStyle.bg }]}>
                      <Text style={[s.statusText, { color: statusStyle.text }]}>{order.orderStatus}</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </View>

      {/* Quick Actions */}
      <View style={s.section}>
        <Text style={s.sectionTitle}>Quick Actions</Text>
        <View style={s.actionsGrid}>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#D1FAE5' }]} onPress={() => navigation.navigate('AdminOrders')}>
            <Ionicons name="cart" size={24} color="#059669" />
            <Text style={[s.actionText, { color: '#059669' }]}>Orders</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#DBEAFE' }]} onPress={() => navigation.navigate('AdminProducts')}>
            <Ionicons name="cube" size={24} color="#3B82F6" />
            <Text style={[s.actionText, { color: '#3B82F6' }]}>Products</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#FAF5FF' }]} onPress={() => navigation.navigate('AdminVendors')}>
            <Ionicons name="people" size={24} color="#9333EA" />
            <Text style={[s.actionText, { color: '#9333EA' }]}>Vendors</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#FFF7ED' }]} onPress={() => navigation.navigate('AdminDispatch')}>
            <Ionicons name="car" size={24} color="#F59E0B" />
            <Text style={[s.actionText, { color: '#F59E0B' }]}>Dispatch</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ height: 100 }} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F3F4F6' },
  loadingText: { marginTop: 12, fontSize: 16, color: '#6B7280' },
  
  header: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    padding: 20, 
    paddingTop: 50,
    backgroundColor: '#fff',
  },
  greeting: { fontSize: 24, fontWeight: 'bold', color: '#111827' },
  subtitle: { fontSize: 14, color: '#6B7280', marginTop: 2 },
  notifBtn: { padding: 8, position: 'relative' },
  notifBadge: { 
    position: 'absolute', 
    top: 8, 
    right: 8, 
    width: 8, 
    height: 8, 
    borderRadius: 4, 
    backgroundColor: '#EF4444' 
  },

  statsGrid: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    padding: 12, 
    gap: 12,
  },
  statCard: { 
    width: '47%', 
    backgroundColor: '#fff', 
    borderRadius: 16, 
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  statIcon: { width: 40, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  trendBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10, gap: 2 },
  trendText: { fontSize: 10, fontWeight: '600' },
  statLabel: { fontSize: 12, color: '#6B7280', marginBottom: 4 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#111827' },

  section: { backgroundColor: '#fff', margin: 12, marginTop: 0, borderRadius: 16, padding: 16 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 8 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#111827', flex: 1 },
  viewAll: { fontSize: 14, color: '#059669', fontWeight: '600' },

  revenueCard: { gap: 10 },
  revenueRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, borderRadius: 12 },
  revenueLabel: { fontSize: 14, color: '#374151' },
  revenueValue: { fontSize: 18, fontWeight: 'bold' },

  alertBadge: { backgroundColor: '#FEE2E2', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  alertBadgeText: { fontSize: 12, color: '#EF4444', fontWeight: '600' },
  emptyAlert: { alignItems: 'center', paddingVertical: 24 },
  emptyAlertText: { marginTop: 8, fontSize: 14, color: '#059669' },
  stockList: { gap: 8 },
  stockItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, backgroundColor: '#FEF2F2', borderRadius: 10 },
  stockInfo: { flex: 1 },
  stockName: { fontSize: 14, fontWeight: '600', color: '#111827' },
  stockSku: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  stockCount: { alignItems: 'flex-end' },
  stockValue: { fontSize: 16, fontWeight: 'bold', color: '#EF4444' },

  emptyOrders: { paddingVertical: 24, alignItems: 'center' },
  emptyOrdersText: { fontSize: 14, color: '#6B7280' },
  ordersList: { gap: 10 },
  orderItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10 },
  orderInfo: { flex: 1 },
  orderId: { fontSize: 14, fontWeight: '600', color: '#059669', fontFamily: 'monospace' },
  orderCustomer: { fontSize: 13, color: '#6B7280', marginTop: 2 },
  orderRight: { alignItems: 'flex-end' },
  orderTotal: { fontSize: 16, fontWeight: 'bold', color: '#111827' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, marginTop: 4 },
  statusText: { fontSize: 10, fontWeight: '600', textTransform: 'uppercase' },

  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  actionBtn: { 
    width: '47%', 
    paddingVertical: 20, 
    borderRadius: 12, 
    alignItems: 'center', 
    gap: 8 
  },
  actionText: { fontSize: 14, fontWeight: '600' },
});
