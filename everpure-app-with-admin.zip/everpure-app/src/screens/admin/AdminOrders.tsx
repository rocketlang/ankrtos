import React, { useState, useEffect } from 'react';
import { 
  View, Text, ScrollView, TouchableOpacity, StyleSheet, 
  RefreshControl, ActivityIndicator, Alert, TextInput 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const API_URL = 'https://ever-pure.in/graphql';

async function graphql(query: string, variables?: any) {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
  const data = await res.json();
  if (data.errors) throw new Error(data.errors[0]?.message);
  return data.data;
}

interface Order {
  id: number;
  orderId: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  total: number;
  subtotal: number;
  deliveryCharge: number;
  orderStatus: string;
  paymentStatus: string;
  paymentMethod: string;
  items: any;
  createdAt: string;
  trackingId?: string;
}

const STATUS_OPTIONS = ['PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];

export default function AdminOrders({ navigation }: any) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    loadOrders();
  }, [statusFilter]);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const data = await graphql(`
        query GetOrders($status: String, $limit: Int) {
          allOrders(status: $status, limit: $limit) {
            id orderId customerName customerPhone customerAddress
            total subtotal deliveryCharge orderStatus paymentStatus paymentMethod
            items createdAt trackingId
          }
        }
      `, { status: statusFilter || undefined, limit: 50 });
      
      setOrders(data.allOrders || []);
    } catch (e: any) {
      console.error('Load orders error:', e);
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrders();
    setRefreshing(false);
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      await graphql(`
        mutation UpdateOrderStatus($orderId: String!, $status: String!) {
          updateOrderStatus(orderId: $orderId, status: $status) { id orderStatus }
        }
      `, { orderId, status: newStatus });
      
      Alert.alert('Success', `Order status updated to ${newStatus}`);
      loadOrders();
      setSelectedOrder(null);
    } catch (e: any) {
      Alert.alert('Error', e.message);
    }
  };

  const getStatusStyle = (status: string) => {
    switch (status?.toUpperCase()) {
      case 'DELIVERED': return { bg: '#D1FAE5', text: '#059669', icon: 'checkmark-done-circle' };
      case 'CONFIRMED': return { bg: '#DBEAFE', text: '#3B82F6', icon: 'checkmark-circle' };
      case 'PROCESSING': return { bg: '#FEF3C7', text: '#F59E0B', icon: 'time' };
      case 'SHIPPED': return { bg: '#E9D5FF', text: '#9333EA', icon: 'airplane' };
      case 'CANCELLED': return { bg: '#FEE2E2', text: '#EF4444', icon: 'close-circle' };
      default: return { bg: '#F3F4F6', text: '#6B7280', icon: 'time' };
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-IN', { 
      day: 'numeric', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  const filteredOrders = searchQuery 
    ? orders.filter(o => 
        o.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        o.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        o.customerPhone?.includes(searchQuery)
      )
    : orders;

  if (loading && orders.length === 0) {
    return (
      <View style={s.loadingContainer}>
        <ActivityIndicator size="large" color="#059669" />
      </View>
    );
  }

  return (
    <View style={s.container}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#111" />
        </TouchableOpacity>
        <Text style={s.title}>Orders Management</Text>
        <TouchableOpacity onPress={onRefresh}>
          <Ionicons name="refresh" size={24} color="#059669" />
        </TouchableOpacity>
      </View>

      {/* Search & Filter */}
      <View style={s.filterBar}>
        <View style={s.searchBox}>
          <Ionicons name="search" size={18} color="#9CA3AF" />
          <TextInput
            style={s.searchInput}
            placeholder="Search orders..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#9CA3AF"
          />
        </View>
      </View>

      {/* Status Filter Chips */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.filterScroll}>
        <TouchableOpacity 
          style={[s.filterChip, !statusFilter && s.filterChipActive]}
          onPress={() => setStatusFilter('')}
        >
          <Text style={[s.filterChipText, !statusFilter && s.filterChipTextActive]}>All</Text>
        </TouchableOpacity>
        {STATUS_OPTIONS.map(status => (
          <TouchableOpacity 
            key={status}
            style={[s.filterChip, statusFilter === status && s.filterChipActive]}
            onPress={() => setStatusFilter(status)}
          >
            <Text style={[s.filterChipText, statusFilter === status && s.filterChipTextActive]}>
              {status}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Orders List */}
      <ScrollView 
        style={s.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#059669']} />}
      >
        {filteredOrders.length === 0 ? (
          <View style={s.emptyContainer}>
            <Ionicons name="receipt-outline" size={64} color="#D1D5DB" />
            <Text style={s.emptyText}>No orders found</Text>
          </View>
        ) : (
          filteredOrders.map(order => {
            const statusStyle = getStatusStyle(order.orderStatus);
            const items = typeof order.items === 'string' ? JSON.parse(order.items) : order.items;
            
            return (
              <TouchableOpacity 
                key={order.id} 
                style={s.orderCard}
                onPress={() => setSelectedOrder(order)}
              >
                <View style={s.orderHeader}>
                  <View>
                    <Text style={s.orderId}>{order.orderId}</Text>
                    <Text style={s.orderDate}>{formatDate(order.createdAt)}</Text>
                  </View>
                  <View style={[s.statusBadge, { backgroundColor: statusStyle.bg }]}>
                    <Ionicons name={statusStyle.icon as any} size={12} color={statusStyle.text} />
                    <Text style={[s.statusText, { color: statusStyle.text }]}>{order.orderStatus}</Text>
                  </View>
                </View>

                <View style={s.divider} />

                <View style={s.customerInfo}>
                  <View style={s.customerRow}>
                    <Ionicons name="person" size={16} color="#6B7280" />
                    <Text style={s.customerName}>{order.customerName || 'Guest'}</Text>
                  </View>
                  <View style={s.customerRow}>
                    <Ionicons name="call" size={16} color="#6B7280" />
                    <Text style={s.customerPhone}>{order.customerPhone}</Text>
                  </View>
                </View>

                <View style={s.itemsPreview}>
                  {Array.isArray(items) && items.slice(0, 2).map((item: any, idx: number) => (
                    <Text key={idx} style={s.itemText}>• {item.name} x{item.quantity}</Text>
                  ))}
                  {Array.isArray(items) && items.length > 2 && (
                    <Text style={s.moreItems}>+{items.length - 2} more items</Text>
                  )}
                </View>

                <View style={s.orderFooter}>
                  <View>
                    <Text style={s.paymentMethod}>
                      {order.paymentMethod === 'COD' ? '💵 COD' : '💳 Online'}
                    </Text>
                    <Text style={[s.paymentStatus, { color: order.paymentStatus === 'paid' ? '#059669' : '#F59E0B' }]}>
                      {order.paymentStatus === 'paid' ? '✓ Paid' : 'Pending'}
                    </Text>
                  </View>
                  <Text style={s.orderTotal}>₹{order.total}</Text>
                </View>
              </TouchableOpacity>
            );
          })
        )}
        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <View style={s.modalOverlay}>
          <View style={s.modal}>
            <View style={s.modalHeader}>
              <Text style={s.modalTitle}>Order {selectedOrder.orderId}</Text>
              <TouchableOpacity onPress={() => setSelectedOrder(null)}>
                <Ionicons name="close" size={24} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <ScrollView style={s.modalContent}>
              {/* Customer Details */}
              <View style={s.modalSection}>
                <Text style={s.modalSectionTitle}>Customer Details</Text>
                <Text style={s.modalText}>{selectedOrder.customerName}</Text>
                <Text style={s.modalText}>{selectedOrder.customerPhone}</Text>
                <Text style={s.modalText}>{selectedOrder.customerAddress}</Text>
              </View>

              {/* Items */}
              <View style={s.modalSection}>
                <Text style={s.modalSectionTitle}>Order Items</Text>
                {(() => {
                  const items = typeof selectedOrder.items === 'string' 
                    ? JSON.parse(selectedOrder.items) 
                    : selectedOrder.items;
                  return Array.isArray(items) && items.map((item: any, idx: number) => (
                    <View key={idx} style={s.modalItem}>
                      <Text style={s.modalItemName}>{item.name} x{item.quantity}</Text>
                      <Text style={s.modalItemPrice}>₹{item.total || item.price * item.quantity}</Text>
                    </View>
                  ));
                })()}
              </View>

              {/* Totals */}
              <View style={s.modalSection}>
                <View style={s.modalRow}>
                  <Text>Subtotal</Text>
                  <Text>₹{selectedOrder.subtotal}</Text>
                </View>
                <View style={s.modalRow}>
                  <Text>Delivery</Text>
                  <Text>{selectedOrder.deliveryCharge === 0 ? 'FREE' : `₹${selectedOrder.deliveryCharge}`}</Text>
                </View>
                <View style={[s.modalRow, { marginTop: 8 }]}>
                  <Text style={s.modalTotalLabel}>Total</Text>
                  <Text style={s.modalTotalValue}>₹{selectedOrder.total}</Text>
                </View>
              </View>

              {/* Update Status */}
              <View style={s.modalSection}>
                <Text style={s.modalSectionTitle}>Update Status</Text>
                <View style={s.statusGrid}>
                  {STATUS_OPTIONS.map(status => {
                    const style = getStatusStyle(status);
                    const isActive = selectedOrder.orderStatus === status;
                    return (
                      <TouchableOpacity 
                        key={status}
                        style={[s.statusOption, { backgroundColor: isActive ? style.bg : '#F3F4F6' }]}
                        onPress={() => !isActive && updateOrderStatus(selectedOrder.orderId, status)}
                      >
                        <Ionicons name={style.icon as any} size={16} color={isActive ? style.text : '#9CA3AF'} />
                        <Text style={[s.statusOptionText, { color: isActive ? style.text : '#6B7280' }]}>
                          {status}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  
  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between',
    padding: 16, 
    paddingTop: 50, 
    backgroundColor: '#fff',
  },
  title: { fontSize: 18, fontWeight: 'bold', color: '#111' },

  filterBar: { backgroundColor: '#fff', paddingHorizontal: 16, paddingBottom: 12 },
  searchBox: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#F3F4F6', 
    borderRadius: 10, 
    paddingHorizontal: 12,
    gap: 8,
  },
  searchInput: { flex: 1, paddingVertical: 10, fontSize: 15, color: '#111' },

  filterScroll: { backgroundColor: '#fff', paddingHorizontal: 12, paddingBottom: 12, maxHeight: 50 },
  filterChip: { 
    paddingHorizontal: 14, 
    paddingVertical: 6, 
    backgroundColor: '#F3F4F6', 
    borderRadius: 20,
    marginRight: 8,
  },
  filterChipActive: { backgroundColor: '#059669' },
  filterChipText: { fontSize: 13, color: '#6B7280', fontWeight: '500' },
  filterChipTextActive: { color: '#fff' },

  content: { flex: 1, padding: 12 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 60 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#6B7280' },

  orderCard: { 
    backgroundColor: '#fff', 
    borderRadius: 12, 
    padding: 16, 
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  orderId: { fontSize: 16, fontWeight: 'bold', color: '#059669', fontFamily: 'monospace' },
  orderDate: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  statusBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, gap: 4 },
  statusText: { fontSize: 11, fontWeight: '600' },

  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 12 },

  customerInfo: { gap: 6 },
  customerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  customerName: { fontSize: 14, fontWeight: '600', color: '#111' },
  customerPhone: { fontSize: 14, color: '#6B7280' },

  itemsPreview: { marginTop: 12, gap: 4 },
  itemText: { fontSize: 13, color: '#374151' },
  moreItems: { fontSize: 12, color: '#6B7280', fontStyle: 'italic' },

  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  paymentMethod: { fontSize: 14, color: '#374151' },
  paymentStatus: { fontSize: 12, marginTop: 2 },
  orderTotal: { fontSize: 20, fontWeight: 'bold', color: '#059669' },

  // Modal
  modalOverlay: { 
    position: 'absolute', 
    top: 0, left: 0, right: 0, bottom: 0, 
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modal: { 
    backgroundColor: '#fff', 
    borderTopLeftRadius: 20, 
    borderTopRightRadius: 20, 
    maxHeight: '85%',
  },
  modalHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    padding: 16, 
    borderBottomWidth: 1, 
    borderBottomColor: '#E5E7EB' 
  },
  modalTitle: { fontSize: 18, fontWeight: 'bold', color: '#111' },
  modalContent: { padding: 16 },
  modalSection: { marginBottom: 20 },
  modalSectionTitle: { fontSize: 14, fontWeight: '600', color: '#6B7280', marginBottom: 8 },
  modalText: { fontSize: 15, color: '#111', marginBottom: 4 },
  modalItem: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  modalItemName: { fontSize: 14, color: '#111' },
  modalItemPrice: { fontSize: 14, fontWeight: '600', color: '#111' },
  modalRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  modalTotalLabel: { fontSize: 16, fontWeight: 'bold', color: '#111' },
  modalTotalValue: { fontSize: 20, fontWeight: 'bold', color: '#059669' },

  statusGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  statusOption: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    paddingHorizontal: 12, 
    paddingVertical: 8, 
    borderRadius: 8,
    gap: 6,
  },
  statusOptionText: { fontSize: 12, fontWeight: '600' },
});
