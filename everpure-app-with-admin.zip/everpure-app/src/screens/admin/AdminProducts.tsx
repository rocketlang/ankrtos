import React, { useState, useEffect } from 'react';
import { 
  View, Text, ScrollView, TouchableOpacity, StyleSheet, 
  RefreshControl, ActivityIndicator, TextInput, Image, Alert 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const API_URL = 'https://ever-pure.in/graphql';
const BASE_URL = 'https://ever-pure.in';

async function graphql(query: string, variables?: any) {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
  const data = await res.json();
  if (data.errors) throw new Error(data.errors[0]?.message);
  return data.data;
}

interface Product {
  id: number;
  sku: string;
  nameEn: string;
  nameHi?: string;
  price: number;
  mrp: number;
  stock: number;
  category?: string;
  imageUrl?: string;
  isActive: boolean;
  badge?: string;
}

export default function AdminProducts({ navigation }: any) {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      const [productsData, categoriesData] = await Promise.all([
        graphql(`query { products(limit: 200) { id sku nameEn nameHi price mrp stock category imageUrl isActive badge } }`),
        graphql(`query { categories }`),
      ]);
      
      setProducts(productsData.products || []);
      setCategories(categoriesData.categories || []);
    } catch (e: any) {
      console.error('Load products error:', e);
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const getImageUrl = (path?: string) => {
    if (!path) return 'https://via.placeholder.com/80?text=No+Image';
    if (path.startsWith('http')) return path;
    return `${BASE_URL}${path}`;
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = !searchQuery || 
      p.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (loading && products.length === 0) {
    return (
      <View style={s.loadingContainer}>
        <ActivityIndicator size="large" color="#059669" />
      </View>
    );
  }

  return (
    <View style={s.container}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#111" />
        </TouchableOpacity>
        <Text style={s.title}>Products</Text>
        <TouchableOpacity style={s.addBtn}>
          <Ionicons name="add" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={s.searchBar}>
        <View style={s.searchBox}>
          <Ionicons name="search" size={18} color="#9CA3AF" />
          <TextInput
            style={s.searchInput}
            placeholder="Search products..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#9CA3AF"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={18} color="#9CA3AF" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Category Filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.filterScroll}>
        <TouchableOpacity 
          style={[s.filterChip, !selectedCategory && s.filterChipActive]}
          onPress={() => setSelectedCategory('')}
        >
          <Text style={[s.filterChipText, !selectedCategory && s.filterChipTextActive]}>
            All ({products.length})
          </Text>
        </TouchableOpacity>
        {categories.map(cat => {
          const count = products.filter(p => p.category === cat).length;
          return (
            <TouchableOpacity 
              key={cat}
              style={[s.filterChip, selectedCategory === cat && s.filterChipActive]}
              onPress={() => setSelectedCategory(cat)}
            >
              <Text style={[s.filterChipText, selectedCategory === cat && s.filterChipTextActive]}>
                {cat} ({count})
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Products List */}
      <ScrollView 
        style={s.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#059669']} />}
      >
        {filteredProducts.length === 0 ? (
          <View style={s.emptyContainer}>
            <Ionicons name="cube-outline" size={64} color="#D1D5DB" />
            <Text style={s.emptyText}>No products found</Text>
          </View>
        ) : (
          filteredProducts.map(product => (
            <TouchableOpacity key={product.id} style={s.productCard}>
              <Image 
                source={{ uri: getImageUrl(product.imageUrl) }} 
                style={s.productImage}
                resizeMode="contain"
              />
              
              <View style={s.productInfo}>
                <View style={s.productHeader}>
                  <Text style={s.productSku}>{product.sku}</Text>
                  {product.badge && (
                    <View style={[s.badge, product.badge === 'coming_soon' && s.badgeOrange]}>
                      <Text style={s.badgeText}>
                        {product.badge === 'coming_soon' ? 'Coming Soon' : product.badge}
                      </Text>
                    </View>
                  )}
                </View>
                
                <Text style={s.productName} numberOfLines={2}>{product.nameEn}</Text>
                
                {product.category && (
                  <View style={s.categoryBadge}>
                    <Text style={s.categoryText}>{product.category}</Text>
                  </View>
                )}
                
                <View style={s.productFooter}>
                  <View style={s.priceContainer}>
                    <Text style={s.price}>₹{product.price}</Text>
                    {product.mrp > product.price && (
                      <Text style={s.mrp}>₹{product.mrp}</Text>
                    )}
                  </View>
                  
                  <View style={[s.stockContainer, product.stock <= 10 && s.stockLow]}>
                    <Text style={[s.stockText, product.stock <= 10 && s.stockTextLow]}>
                      {product.stock} in stock
                    </Text>
                  </View>
                </View>
              </View>

              <TouchableOpacity style={s.editBtn}>
                <Ionicons name="create-outline" size={20} color="#6B7280" />
              </TouchableOpacity>
            </TouchableOpacity>
          ))
        )}
        
        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Stats Footer */}
      <View style={s.footer}>
        <View style={s.stat}>
          <Text style={s.statValue}>{products.length}</Text>
          <Text style={s.statLabel}>Total</Text>
        </View>
        <View style={s.statDivider} />
        <View style={s.stat}>
          <Text style={s.statValue}>{products.filter(p => p.isActive).length}</Text>
          <Text style={s.statLabel}>Active</Text>
        </View>
        <View style={s.statDivider} />
        <View style={s.stat}>
          <Text style={[s.statValue, { color: '#EF4444' }]}>{products.filter(p => p.stock <= 10).length}</Text>
          <Text style={s.statLabel}>Low Stock</Text>
        </View>
        <View style={s.statDivider} />
        <View style={s.stat}>
          <Text style={s.statValue}>{products.filter(p => p.stock === 0).length}</Text>
          <Text style={s.statLabel}>Out</Text>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between',
    padding: 16, 
    paddingTop: 50, 
    backgroundColor: '#fff',
  },
  title: { fontSize: 18, fontWeight: 'bold', color: '#111' },
  addBtn: { 
    backgroundColor: '#059669', 
    width: 36, 
    height: 36, 
    borderRadius: 18, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },

  searchBar: { backgroundColor: '#fff', paddingHorizontal: 16, paddingBottom: 12 },
  searchBox: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#F3F4F6', 
    borderRadius: 10, 
    paddingHorizontal: 12,
    gap: 8,
  },
  searchInput: { flex: 1, paddingVertical: 10, fontSize: 15, color: '#111' },

  filterScroll: { backgroundColor: '#fff', paddingHorizontal: 12, paddingBottom: 12, maxHeight: 50 },
  filterChip: { 
    paddingHorizontal: 14, 
    paddingVertical: 6, 
    backgroundColor: '#F3F4F6', 
    borderRadius: 20,
    marginRight: 8,
  },
  filterChipActive: { backgroundColor: '#059669' },
  filterChipText: { fontSize: 13, color: '#6B7280', fontWeight: '500' },
  filterChipTextActive: { color: '#fff' },

  content: { flex: 1, padding: 12 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 60 },
  emptyText: { marginTop: 12, fontSize: 16, color: '#6B7280' },

  productCard: { 
    flexDirection: 'row',
    backgroundColor: '#fff', 
    borderRadius: 12, 
    padding: 12, 
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  productImage: { 
    width: 70, 
    height: 70, 
    borderRadius: 8, 
    backgroundColor: '#F9FAFB',
  },
  productInfo: { flex: 1, marginLeft: 12 },
  productHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  productSku: { fontSize: 11, color: '#6B7280', fontFamily: 'monospace' },
  badge: { backgroundColor: '#EF4444', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  badgeOrange: { backgroundColor: '#F59E0B' },
  badgeText: { fontSize: 9, color: '#fff', fontWeight: '600' },
  productName: { fontSize: 14, fontWeight: '600', color: '#111', marginTop: 4, lineHeight: 18 },
  categoryBadge: { 
    alignSelf: 'flex-start', 
    backgroundColor: '#F3F4F6', 
    paddingHorizontal: 8, 
    paddingVertical: 2, 
    borderRadius: 4, 
    marginTop: 6 
  },
  categoryText: { fontSize: 11, color: '#6B7280', textTransform: 'capitalize' },
  productFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  priceContainer: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  price: { fontSize: 16, fontWeight: 'bold', color: '#059669' },
  mrp: { fontSize: 12, color: '#9CA3AF', textDecorationLine: 'line-through' },
  stockContainer: { backgroundColor: '#F0FDF4', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  stockLow: { backgroundColor: '#FEF2F2' },
  stockText: { fontSize: 11, color: '#059669', fontWeight: '600' },
  stockTextLow: { color: '#EF4444' },
  editBtn: { padding: 8 },

  footer: { 
    flexDirection: 'row', 
    backgroundColor: '#fff', 
    paddingVertical: 12, 
    paddingHorizontal: 20,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  stat: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 18, fontWeight: 'bold', color: '#059669' },
  statLabel: { fontSize: 11, color: '#6B7280', marginTop: 2 },
  statDivider: { width: 1, backgroundColor: '#E5E7EB' },
});
