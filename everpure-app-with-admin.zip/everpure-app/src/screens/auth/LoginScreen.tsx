import React, { useState, useRef } from 'react';
import { 
  View, Text, TextInput, TouchableOpacity, StyleSheet, 
  Alert, ActivityIndicator, KeyboardAvoidingView, Platform 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';

export default function LoginScreen({ navigation }: any) {
  const { sendOTP, verifyOTP } = useAuth();
  
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [loading, setLoading] = useState(false);
  
  const otpInputRef = useRef<TextInput>(null);

  const handleSendOTP = async () => {
    const cleanPhone = phone.replace(/\D/g, '');
    
    if (cleanPhone.length !== 10) {
      Alert.alert('Invalid Phone', 'Please enter a valid 10-digit phone number');
      return;
    }
    
    setLoading(true);
    
    try {
      const result = await sendOTP(cleanPhone);
      
      if (result.success) {
        setStep('otp');
        Alert.alert('OTP Sent', `A verification code has been sent to +91 ${cleanPhone}`);
        setTimeout(() => otpInputRef.current?.focus(), 100);
      } else {
        Alert.alert('Error', result.message || 'Failed to send OTP');
      }
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) {
      Alert.alert('Invalid OTP', 'Please enter the 6-digit OTP');
      return;
    }
    
    setLoading(true);
    
    try {
      const result = await verifyOTP(phone, otp);
      
      if (result.success) {
        Alert.alert('Welcome!', 'You are now logged in', [
          { text: 'OK', onPress: () => navigation.goBack() }
        ]);
      } else {
        Alert.alert('Invalid OTP', result.message || 'Please check the OTP and try again');
      }
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Verification failed');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async () => {
    setLoading(true);
    try {
      const result = await sendOTP(phone);
      if (result.success) {
        Alert.alert('OTP Resent', 'A new OTP has been sent to your phone');
      } else {
        Alert.alert('Error', result.message);
      }
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#111" />
        </TouchableOpacity>
        <Text style={styles.title}>Login</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.content}>
        {/* Logo / Icon */}
        <View style={styles.iconContainer}>
          <View style={styles.iconCircle}>
            <Ionicons name="leaf" size={48} color="#059669" />
          </View>
          <Text style={styles.brandName}>Ever Pure</Text>
          <Text style={styles.brandTagline}>Pure & Organic Groceries</Text>
        </View>

        {step === 'phone' ? (
          <>
            <Text style={styles.inputLabel}>Enter your phone number</Text>
            <View style={styles.phoneInputContainer}>
              <Text style={styles.countryCode}>+91</Text>
              <TextInput
                style={styles.phoneInput}
                placeholder="10 digit mobile number"
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                maxLength={10}
                placeholderTextColor="#9CA3AF"
                autoFocus
              />
            </View>
            
            <TouchableOpacity 
              style={[styles.btn, loading && styles.btnDisabled]} 
              onPress={handleSendOTP}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.btnText}>Send OTP</Text>
              )}
            </TouchableOpacity>
            
            <Text style={styles.hint}>
              We'll send you a one-time verification code
            </Text>
          </>
        ) : (
          <>
            <Text style={styles.inputLabel}>Enter verification code</Text>
            <Text style={styles.phoneDisplay}>Sent to +91 {phone}</Text>
            
            <TextInput
              ref={otpInputRef}
              style={styles.otpInput}
              placeholder="Enter 6-digit OTP"
              value={otp}
              onChangeText={setOtp}
              keyboardType="number-pad"
              maxLength={6}
              placeholderTextColor="#9CA3AF"
            />
            
            <TouchableOpacity 
              style={[styles.btn, loading && styles.btnDisabled]} 
              onPress={handleVerifyOTP}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.btnText}>Verify & Login</Text>
              )}
            </TouchableOpacity>
            
            <View style={styles.resendRow}>
              <Text style={styles.resendText}>Didn't receive code? </Text>
              <TouchableOpacity onPress={handleResendOTP} disabled={loading}>
                <Text style={styles.resendLink}>Resend OTP</Text>
              </TouchableOpacity>
            </View>
            
            <TouchableOpacity 
              style={styles.changePhoneBtn}
              onPress={() => { setStep('phone'); setOtp(''); }}
            >
              <Ionicons name="arrow-back" size={16} color="#6B7280" />
              <Text style={styles.changePhoneText}>Change phone number</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    padding: 16, 
    paddingTop: 50,
    borderBottomWidth: 1, 
    borderBottomColor: '#E5E7EB' 
  },
  title: { fontSize: 18, fontWeight: 'bold', color: '#111' },
  content: { flex: 1, padding: 24 },
  iconContainer: { alignItems: 'center', marginVertical: 40 },
  iconCircle: { 
    width: 100, 
    height: 100, 
    borderRadius: 50, 
    backgroundColor: '#F0FDF4', 
    justifyContent: 'center', 
    alignItems: 'center',
    marginBottom: 16,
  },
  brandName: { fontSize: 28, fontWeight: 'bold', color: '#059669' },
  brandTagline: { fontSize: 14, color: '#6B7280', marginTop: 4 },
  inputLabel: { fontSize: 16, fontWeight: '600', color: '#111', marginBottom: 8 },
  phoneInputContainer: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    borderWidth: 1, 
    borderColor: '#E5E7EB', 
    borderRadius: 12,
    overflow: 'hidden',
  },
  countryCode: { 
    fontSize: 18, 
    fontWeight: '600', 
    color: '#111', 
    paddingHorizontal: 16,
    paddingVertical: 14,
    backgroundColor: '#F9FAFB',
    borderRightWidth: 1,
    borderRightColor: '#E5E7EB',
  },
  phoneInput: { 
    flex: 1, 
    fontSize: 18, 
    padding: 14, 
    color: '#111',
    letterSpacing: 1,
  },
  phoneDisplay: { fontSize: 14, color: '#6B7280', marginBottom: 16 },
  otpInput: { 
    borderWidth: 1, 
    borderColor: '#E5E7EB', 
    borderRadius: 12, 
    padding: 16, 
    fontSize: 24, 
    textAlign: 'center',
    letterSpacing: 8,
    color: '#111',
    marginBottom: 16,
  },
  btn: { 
    backgroundColor: '#059669', 
    paddingVertical: 16, 
    borderRadius: 12, 
    alignItems: 'center',
    marginTop: 16,
  },
  btnDisabled: { opacity: 0.6 },
  btnText: { color: '#fff', fontSize: 18, fontWeight: '600' },
  hint: { fontSize: 13, color: '#6B7280', textAlign: 'center', marginTop: 16 },
  resendRow: { 
    flexDirection: 'row', 
    justifyContent: 'center', 
    marginTop: 20 
  },
  resendText: { fontSize: 14, color: '#6B7280' },
  resendLink: { fontSize: 14, color: '#059669', fontWeight: '600' },
  changePhoneBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    marginTop: 30,
    gap: 4,
  },
  changePhoneText: { fontSize: 14, color: '#6B7280' },
});
