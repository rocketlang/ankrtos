/**
 * @ankr/ai-gateway/server
 * 
 * Fastify Server for AI Gateway
 * Exposes REST API for all ANKR products
 * 
 * © Powerp Box IT Solutions Pvt Ltd
 */

import Fastify, { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import cors from '@fastify/cors';
import { AIGateway, createGateway, Product, GatewayRequest } from './index';

// ============================================================================
// TYPES
// ============================================================================

interface ChatBody {
  query: string;
  product: Product;
  userId?: string;
  sessionId?: string;
  language?: string;
  skills?: string[];
  autoDetectSkills?: boolean;
  provider?: string;
  maxCost?: number;
  history?: Array<{ role: string; content: string }>;
}

interface VoiceBody {
  text: string;
  language?: string;
  driverId?: string;
  userId?: string;
}

interface CodegenBody {
  description: string;
  product?: Product;
  language?: string;
}

interface SearchBody {
  query: string;
  product?: Product;
}

// ============================================================================
// SERVER FACTORY
// ============================================================================

export async function createServer(gateway?: AIGateway): Promise<FastifyInstance> {
  const fastify = Fastify({
    logger: true,
  });

  const ai = gateway || createGateway();

  // Register CORS
  await fastify.register(cors, {
    origin: true,
  });

  // -------------------------------------------------------------------------
  // HEALTH CHECK
  // -------------------------------------------------------------------------

  fastify.get('/health', async (request, reply) => {
    return {
      status: 'ok',
      gateway: 'ankr-ai-gateway',
      version: '1.0.0',
      skills: ai.listSkills(),
      timestamp: new Date().toISOString(),
    };
  });

  // -------------------------------------------------------------------------
  // MAIN CHAT ENDPOINT
  // -------------------------------------------------------------------------

  fastify.post<{ Body: ChatBody }>('/v1/chat', async (request, reply) => {
    const body = request.body;

    if (!body.query) {
      return reply.status(400).send({ error: 'query is required' });
    }
    if (!body.product) {
      return reply.status(400).send({ error: 'product is required' });
    }

    try {
      const response = await ai.chat(body);
      return response;
    } catch (error: any) {
      request.log.error(error);
      return reply.status(500).send({ error: error.message });
    }
  });

  // -------------------------------------------------------------------------
  // STREAMING CHAT (SSE)
  // -------------------------------------------------------------------------

  fastify.post<{ Body: ChatBody }>('/v1/chat/stream', async (request, reply) => {
    const body = request.body;

    if (!body.query || !body.product) {
      return reply.status(400).send({ error: 'query and product are required' });
    }

    reply.raw.setHeader('Content-Type', 'text/event-stream');
    reply.raw.setHeader('Cache-Control', 'no-cache');
    reply.raw.setHeader('Connection', 'keep-alive');

    try {
      const stream = ai.chatStream(body);

      for await (const chunk of stream) {
        reply.raw.write(`data: ${JSON.stringify({ text: chunk })}\n\n`);
      }

      reply.raw.write('data: [DONE]\n\n');
      reply.raw.end();
    } catch (error: any) {
      reply.raw.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
      reply.raw.end();
    }
  });

  // -------------------------------------------------------------------------
  // PRODUCT-SPECIFIC ENDPOINTS
  // -------------------------------------------------------------------------

  // SWAYAM
  fastify.post<{ Body: { query: string; language?: string } }>(
    '/v1/swayam/query',
    async (request) => {
      const { query, language } = request.body;
      return ai.chat({
        query,
        product: 'swayam',
        language,
        autoDetectSkills: true,
      });
    }
  );

  // WowTruck
  fastify.post<{ Body: { query: string; language?: string; userId?: string } }>(
    '/v1/wowtruck/query',
    async (request) => {
      const { query, language, userId } = request.body;
      return ai.chat({
        query,
        product: 'wowtruck',
        language: language || 'hi',
        userId,
        autoDetectSkills: true,
      });
    }
  );

  // WowTruck Driver Voice
  fastify.post<{ Body: VoiceBody }>(
    '/v1/wowtruck/voice',
    async (request) => {
      const { text, language, driverId } = request.body;
      return ai.chat({
        query: text,
        product: 'wowtruck',
        language: language || 'hi',
        userId: driverId,
        skills: ['ankr-voice-hindi', 'ankr-tms-dev'],
      });
    }
  );

  // CompliMtrx
  fastify.post<{ Body: { query: string } }>(
    '/v1/complimtrx/query',
    async (request) => {
      const { query } = request.body;
      return ai.chat({
        query,
        product: 'complimtrx',
        autoDetectSkills: true,
      });
    }
  );

  // Saathi
  fastify.post<{ Body: { query: string; language?: string; userId?: string } }>(
    '/v1/saathi/query',
    async (request) => {
      const { query, language, userId } = request.body;
      return ai.chat({
        query,
        product: 'saathi',
        language,
        userId,
        skills: ['ankr-voice-hindi', 'ankr-eon-memory'],
      });
    }
  );

  // Baniai.io
  fastify.post<{ Body: { query: string } }>(
    '/v1/baniai/query',
    async (request) => {
      const { query } = request.body;
      return ai.chat({
        query,
        product: 'baniai',
        autoDetectSkills: true,
      });
    }
  );

  // -------------------------------------------------------------------------
  // CODE GENERATION
  // -------------------------------------------------------------------------

  fastify.post<{ Body: CodegenBody }>(
    '/v1/codegen',
    async (request) => {
      const { description, product, language } = request.body;
      const response = await ai.chat({
        query: description,
        product: product || 'ankr-internal',
        skills: ['ankr-tms-dev'],
        provider: 'deepseek', // Best for code
      });
      return { code: response.content, ...response };
    }
  );

  // -------------------------------------------------------------------------
  // RAG / SEARCH
  // -------------------------------------------------------------------------

  fastify.post<{ Body: SearchBody }>(
    '/v1/search',
    async (request) => {
      const { query, product } = request.body;
      return ai.chat({
        query,
        product: product || 'ankr-internal',
        skills: ['ankr-logistics-rag'],
      });
    }
  );

  // -------------------------------------------------------------------------
  // STATS & MONITORING
  // -------------------------------------------------------------------------

  fastify.get('/v1/stats', async () => {
    const stats = ai.getStats();
    return Object.fromEntries(stats);
  });

  fastify.get<{ Params: { product: string } }>(
    '/v1/stats/:product',
    async (request) => {
      const product = request.params.product as Product;
      return ai.getStats(product);
    }
  );

  // -------------------------------------------------------------------------
  // SKILL MANAGEMENT
  // -------------------------------------------------------------------------

  fastify.get('/v1/skills', async () => {
    return {
      available: ai.listSkills(),
      byProduct: {
        swayam: ai.getProductSkills('swayam'),
        wowtruck: ai.getProductSkills('wowtruck'),
        complimtrx: ai.getProductSkills('complimtrx'),
        saathi: ai.getProductSkills('saathi'),
        baniai: ai.getProductSkills('baniai'),
      },
    };
  });

  // -------------------------------------------------------------------------
  // DECORATE FASTIFY INSTANCE
  // -------------------------------------------------------------------------

  fastify.decorate('aiGateway', ai);

  return fastify;
}

// ============================================================================
// STANDALONE SERVER
// ============================================================================

export async function startServer(port: number = 3000, gateway?: AIGateway): Promise<FastifyInstance> {
  const fastify = await createServer(gateway);

  try {
    await fastify.listen({ port, host: '0.0.0.0' });

    console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                   ANKR AI GATEWAY                             ║
║                                                               ║
║  © Powerp Box IT Solutions Pvt Ltd                           ║
║                                                               ║
║  Products: SWAYAM, WowTruck, CompliMtrx, Saathi, Baniai.io   ║
║  Providers: 17 (Free-tier priority)                          ║
║  Skills: 5 ANKR skills auto-injected                         ║
║                                                               ║
║  Server running on http://0.0.0.0:${port}                       ║
╚═══════════════════════════════════════════════════════════════╝
    `);

    return fastify;
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
}

// ============================================================================
// FASTIFY PLUGIN (for embedding in existing app)
// ============================================================================

export async function aiGatewayPlugin(
  fastify: FastifyInstance,
  options: { gateway?: AIGateway; prefix?: string }
) {
  const ai = options.gateway || createGateway();
  const prefix = options.prefix || '/ai';

  // Decorate
  fastify.decorate('aiGateway', ai);

  // Register routes under prefix
  fastify.register(
    async (instance) => {
      // Health
      instance.get('/health', async () => ({
        status: 'ok',
        skills: ai.listSkills(),
      }));

      // Chat
      instance.post<{ Body: ChatBody }>('/chat', async (request, reply) => {
        const body = request.body;
        if (!body.query || !body.product) {
          return reply.status(400).send({ error: 'query and product required' });
        }
        return ai.chat(body);
      });

      // Product endpoints
      instance.post<{ Body: VoiceBody }>('/wowtruck/voice', async (request) => {
        const { text, language, driverId } = request.body;
        return ai.chat({
          query: text,
          product: 'wowtruck',
          language: language || 'hi',
          userId: driverId,
          skills: ['ankr-voice-hindi', 'ankr-tms-dev'],
        });
      });

      // Stats
      instance.get('/stats', async () => Object.fromEntries(ai.getStats()));

      // Skills
      instance.get('/skills', async () => ({
        available: ai.listSkills(),
      }));
    },
    { prefix }
  );
}

// ============================================================================
// RUN IF CALLED DIRECTLY
// ============================================================================

// Check if this file is being run directly
const isMainModule = require.main === module || process.argv[1]?.includes('server');

if (isMainModule) {
  const port = parseInt(process.env.PORT || '3000', 10);
  startServer(port);
}

// ============================================================================
// EXPORTS
// ============================================================================

export { AIGateway, createGateway } from './index';
