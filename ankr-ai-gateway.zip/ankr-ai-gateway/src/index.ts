/**
 * @ankr/ai-gateway
 * 
 * Central AI Gateway for ALL ANKR Products
 * - SWAYAM, WowTruck, CompliMtrx, Saathi, Baniai.io, etc.
 * 
 * Single entry point for:
 * - 17 LLM Providers (free-tier priority)
 * - Skill injection per product
 * - Cost tracking per product
 * - Voice (Hindi/Tamil/Telugu)
 * - ankr-eon memory integration
 * 
 * © Powerp Box IT Solutions Pvt Ltd
 */

import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { createHash } from 'crypto';

// ============================================================================
// TYPES
// ============================================================================

export type Product = 
  | 'swayam' 
  | 'wowtruck' 
  | 'complimtrx' 
  | 'saathi' 
  | 'baniai' 
  | 'ankr-internal'
  | string;  // Allow custom products

export type Language = 'en' | 'hi' | 'ta' | 'te' | 'bn' | 'mr' | 'gu' | string;

export interface GatewayConfig {
  // Provider configuration
  providers: ProviderConfig[];
  defaultProvider: string;
  fallbackChain: string[];
  
  // Skill configuration
  skillsPath: string;
  
  // Cost control
  maxCostPerRequest: number;
  maxDailyCostPerProduct: number;
  preferFreeTier: boolean;
  
  // Memory integration
  eonEnabled: boolean;
  eonConnectionString?: string;
  
  // Caching
  cacheEnabled: boolean;
  cacheTTL: number;
}

export interface ProviderConfig {
  name: string;
  apiKey?: string;
  baseUrl?: string;
  model?: string;
  freeTier: boolean;
  costPer1kTokens: { input: number; output: number };
  languages: Language[];
  bestFor: string[];  // 'code', 'chat', 'reasoning', 'indic'
}

export interface GatewayRequest {
  // Required
  query: string;
  product: Product;
  
  // Optional
  userId?: string;
  sessionId?: string;
  language?: Language;
  
  // Skill control
  skills?: string[];
  autoDetectSkills?: boolean;
  
  // Provider control
  provider?: string;
  maxCost?: number;
  
  // Conversation
  history?: Array<{ role: string; content: string }>;
  
  // Output
  stream?: boolean;
  responseFormat?: 'text' | 'json' | 'code';
}

export interface GatewayResponse {
  // Response
  content: string;
  
  // Metadata
  provider: string;
  model: string;
  product: Product;
  
  // Skills
  skillsUsed: string[];
  
  // Cost & Performance
  cost: number;
  tokens: { input: number; output: number; total: number };
  latencyMs: number;
  cached: boolean;
  
  // Memory (if eon enabled)
  episodeId?: string;
}

export interface ProductStats {
  product: Product;
  totalRequests: number;
  totalCost: number;
  totalTokens: number;
  avgLatencyMs: number;
  topSkills: string[];
  topProviders: string[];
}

// ============================================================================
// DEFAULT CONFIGURATION
// ============================================================================

const DEFAULT_PROVIDERS: ProviderConfig[] = [
  {
    name: 'groq',
    freeTier: true,
    costPer1kTokens: { input: 0, output: 0 },
    languages: ['en', 'hi', 'ta', 'te'],
    bestFor: ['chat', 'fast'],
    model: 'llama-3.3-70b-versatile',
    baseUrl: 'https://api.groq.com/openai/v1',
  },
  {
    name: 'ollama',
    freeTier: true,
    costPer1kTokens: { input: 0, output: 0 },
    languages: ['en'],
    bestFor: ['local', 'private'],
    baseUrl: 'http://127.0.0.1:11434',
  },
  {
    name: 'longcat',
    freeTier: true,
    costPer1kTokens: { input: 0, output: 0 },
    languages: ['hi', 'ta', 'te', 'bn', 'mr', 'gu', 'en'],
    bestFor: ['indic', 'multilingual'],
    model: 'LongCat-Flash-Chat',
    baseUrl: 'https://api.longcat.chat/openai',
  },
  {
    name: 'deepseek',
    freeTier: true,
    costPer1kTokens: { input: 0.14, output: 0.28 },
    languages: ['en', 'zh'],
    bestFor: ['code', 'reasoning'],
    model: 'deepseek-chat',
    baseUrl: 'https://api.deepseek.com/v1',
  },
  {
    name: 'zhipuai',
    freeTier: true,
    costPer1kTokens: { input: 0.1, output: 0.1 },
    languages: ['zh', 'en'],
    bestFor: ['chinese'],
    model: 'glm-4',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4/',
  },
  {
    name: 'openrouter',
    freeTier: false,
    costPer1kTokens: { input: 1, output: 2 },
    languages: ['en'],
    bestFor: ['fallback', 'multimodel'],
    baseUrl: 'https://openrouter.ai/api/v1',
  },
];

const DEFAULT_CONFIG: GatewayConfig = {
  providers: DEFAULT_PROVIDERS,
  defaultProvider: 'groq',
  fallbackChain: ['groq', 'ollama', 'longcat', 'deepseek', 'openrouter'],
  skillsPath: '.claude/skills',
  maxCostPerRequest: 0.01,
  maxDailyCostPerProduct: 1.0,
  preferFreeTier: true,
  eonEnabled: false,
  cacheEnabled: true,
  cacheTTL: 3600,
};

// ============================================================================
// SKILL MAPPINGS PER PRODUCT
// ============================================================================

const PRODUCT_SKILLS: Record<Product, string[]> = {
  'swayam': ['ankr-tms-dev', 'ankr-llmbox'],
  'wowtruck': ['ankr-tms-dev', 'ankr-voice-hindi', 'ankr-logistics-rag', 'ankr-eon-memory'],
  'complimtrx': ['ankr-tms-dev', 'ankr-logistics-rag'],
  'saathi': ['ankr-voice-hindi', 'ankr-eon-memory'],
  'baniai': ['ankr-tms-dev', 'ankr-logistics-rag'],
  'ankr-internal': ['ankr-tms-dev', 'ankr-eon-memory', 'ankr-llmbox', 'ankr-logistics-rag', 'ankr-voice-hindi'],
};

// ============================================================================
// AI GATEWAY CLASS
// ============================================================================

export class AIGateway {
  private config: GatewayConfig;
  private skillCache: Map<string, string> = new Map();
  private responseCache: Map<string, GatewayResponse> = new Map();
  private productStats: Map<Product, ProductStats> = new Map();
  private dailyCosts: Map<Product, number> = new Map();

  constructor(config: Partial<GatewayConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  // --------------------------------------------------------------------------
  // MAIN CHAT METHOD
  // --------------------------------------------------------------------------

  async chat(request: GatewayRequest): Promise<GatewayResponse> {
    const startTime = Date.now();

    // Validate product
    if (!request.product) {
      throw new Error('Product is required');
    }

    // Check daily cost limit
    const dailyCost = this.dailyCosts.get(request.product) || 0;
    if (dailyCost >= this.config.maxDailyCostPerProduct) {
      throw new Error(`Daily cost limit reached for ${request.product}`);
    }

    // Check cache
    const cacheKey = this.getCacheKey(request);
    if (this.config.cacheEnabled && this.responseCache.has(cacheKey)) {
      const cached = this.responseCache.get(cacheKey)!;
      return { ...cached, cached: true, latencyMs: Date.now() - startTime };
    }

    // Determine skills
    const skills = this.determineSkills(request);
    const skillContent = this.loadSkills(skills);

    // Select provider
    const provider = this.selectProvider(request);

    // Build messages
    const messages = this.buildMessages(request, skillContent);

    // Call provider
    const response = await this.callProvider(provider, messages, request);

    // Build result
    const result: GatewayResponse = {
      content: response.content,
      provider: provider.name,
      model: response.model,
      product: request.product,
      skillsUsed: skills,
      cost: response.cost,
      tokens: response.tokens,
      latencyMs: Date.now() - startTime,
      cached: false,
    };

    // Record to eon memory if enabled
    if (this.config.eonEnabled) {
      result.episodeId = await this.recordEpisode(request, result);
    }

    // Update stats
    this.updateStats(request.product, result);

    // Cache response
    if (this.config.cacheEnabled) {
      this.responseCache.set(cacheKey, result);
    }

    return result;
  }

  // --------------------------------------------------------------------------
  // STREAMING CHAT
  // --------------------------------------------------------------------------

  async *chatStream(request: GatewayRequest): AsyncGenerator<string> {
    const skills = this.determineSkills(request);
    const skillContent = this.loadSkills(skills);
    const provider = this.selectProvider(request);
    const messages = this.buildMessages(request, skillContent);

    const stream = await this.callProviderStream(provider, messages, request);

    for await (const chunk of stream) {
      yield chunk;
    }
  }

  // --------------------------------------------------------------------------
  // SKILL MANAGEMENT
  // --------------------------------------------------------------------------

  private determineSkills(request: GatewayRequest): string[] {
    // If explicitly specified, use those
    if (request.skills && request.skills.length > 0) {
      return request.skills;
    }

    // If auto-detect disabled, use product defaults
    if (request.autoDetectSkills === false) {
      return PRODUCT_SKILLS[request.product] || PRODUCT_SKILLS['ankr-internal'];
    }

    // Auto-detect based on query + product
    const detected = this.autoDetectSkills(request.query);
    const productSkills = PRODUCT_SKILLS[request.product] || [];

    // Merge: detected + product-specific
    const merged = [...new Set([...detected, ...productSkills])];

    // Limit to 3 skills to avoid context overflow
    return merged.slice(0, 3);
  }

  private autoDetectSkills(query: string): string[] {
    const queryLower = query.toLowerCase();
    const detected: string[] = [];

    const patterns: Record<string, string[]> = {
      'ankr-tms-dev': ['module', 'service', 'controller', 'nestjs', 'prisma', 'crud', 'api'],
      'ankr-eon-memory': ['memory', 'episode', 'learn', 'remember', 'pattern'],
      'ankr-voice-hindi': ['voice', 'hindi', 'tamil', 'telugu', 'बोलो', 'சொல்', 'చెప్పు'],
      'ankr-llmbox': ['llm', 'provider', 'cost', 'groq', 'deepseek'],
      'ankr-logistics-rag': ['search', 'find', 'shipment', 'carrier', 'route'],
    };

    for (const [skill, keywords] of Object.entries(patterns)) {
      if (keywords.some(k => queryLower.includes(k))) {
        detected.push(skill);
      }
    }

    return detected;
  }

  private loadSkills(skillNames: string[]): string {
    const contents: string[] = [];

    for (const name of skillNames) {
      // Check cache
      if (this.skillCache.has(name)) {
        contents.push(this.skillCache.get(name)!);
        continue;
      }

      // Load from file
      const skillPath = join(this.config.skillsPath, name, 'SKILL.md');
      if (existsSync(skillPath)) {
        const content = readFileSync(skillPath, 'utf-8');
        this.skillCache.set(name, content);
        contents.push(content);
      }
    }

    return contents.join('\n\n---\n\n');
  }

  // --------------------------------------------------------------------------
  // PROVIDER SELECTION
  // --------------------------------------------------------------------------

  private selectProvider(request: GatewayRequest): ProviderConfig {
    // If explicitly specified
    if (request.provider) {
      const provider = this.config.providers.find(p => p.name === request.provider);
      if (provider) return provider;
    }

    // Language-based routing
    if (request.language && ['hi', 'ta', 'te', 'bn', 'mr', 'gu'].includes(request.language)) {
      const indicProvider = this.config.providers.find(p => 
        p.languages.includes(request.language!) && p.freeTier
      );
      if (indicProvider) return indicProvider;
    }

    // Cost-based routing
    if (this.config.preferFreeTier || (request.maxCost !== undefined && request.maxCost < 0.001)) {
      const freeProvider = this.config.providers.find(p => p.freeTier);
      if (freeProvider) return freeProvider;
    }

    // Query-based routing
    const queryLower = request.query.toLowerCase();
    if (/code|function|class|implement|debug/.test(queryLower)) {
      const codeProvider = this.config.providers.find(p => p.bestFor.includes('code'));
      if (codeProvider) return codeProvider;
    }

    // Default
    return this.config.providers.find(p => p.name === this.config.defaultProvider) 
      || this.config.providers[0];
  }

  // --------------------------------------------------------------------------
  // MESSAGE BUILDING
  // --------------------------------------------------------------------------

  private buildMessages(request: GatewayRequest, skillContent: string): Array<{ role: string; content: string }> {
    const messages: Array<{ role: string; content: string }> = [];

    // System prompt with skills
    let systemPrompt = '';
    
    if (skillContent) {
      systemPrompt += skillContent + '\n\n';
    }

    systemPrompt += `You are an AI assistant for ${request.product.toUpperCase()}, part of ANKR Labs ecosystem.
Follow the patterns and guidelines from the skills above.
Be concise, practical, and cost-conscious.`;

    if (request.language && request.language !== 'en') {
      const langNames: Record<string, string> = {
        hi: 'Hindi', ta: 'Tamil', te: 'Telugu', bn: 'Bengali', mr: 'Marathi', gu: 'Gujarati'
      };
      systemPrompt += `\nRespond in ${langNames[request.language] || request.language} when appropriate.`;
    }

    messages.push({ role: 'system', content: systemPrompt });

    // History
    if (request.history) {
      messages.push(...request.history);
    }

    // Current query
    messages.push({ role: 'user', content: request.query });

    return messages;
  }

  // --------------------------------------------------------------------------
  // PROVIDER CALLS (IMPLEMENT BASED ON YOUR EXISTING PROXY)
  // --------------------------------------------------------------------------

  private async callProvider(
    provider: ProviderConfig,
    messages: Array<{ role: string; content: string }>,
    request: GatewayRequest
  ): Promise<{ content: string; model: string; cost: number; tokens: { input: number; output: number; total: number } }> {
    // This is where you integrate with your existing ai-proxy
    // For now, placeholder implementation
    
    const response = await fetch(`${provider.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${provider.apiKey || process.env[`${provider.name.toUpperCase()}_API_KEY`]}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: provider.model,
        messages,
        temperature: 0.7,
        max_tokens: 2048,
      }),
    });

    const data = await response.json();
    
    const inputTokens = data.usage?.prompt_tokens || 0;
    const outputTokens = data.usage?.completion_tokens || 0;
    const cost = (inputTokens / 1000 * provider.costPer1kTokens.input) +
                 (outputTokens / 1000 * provider.costPer1kTokens.output);

    return {
      content: data.choices?.[0]?.message?.content || '',
      model: data.model || provider.model || 'unknown',
      cost,
      tokens: {
        input: inputTokens,
        output: outputTokens,
        total: inputTokens + outputTokens,
      },
    };
  }

  private async *callProviderStream(
    provider: ProviderConfig,
    messages: Array<{ role: string; content: string }>,
    request: GatewayRequest
  ): AsyncGenerator<string> {
    // Streaming implementation
    const response = await fetch(`${provider.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${provider.apiKey || process.env[`${provider.name.toUpperCase()}_API_KEY`]}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: provider.model,
        messages,
        temperature: 0.7,
        max_tokens: 2048,
        stream: true,
      }),
    });

    const reader = response.body?.getReader();
    if (!reader) return;

    const decoder = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      
      const chunk = decoder.decode(value);
      const lines = chunk.split('\n').filter(line => line.startsWith('data: '));
      
      for (const line of lines) {
        const data = line.slice(6);
        if (data === '[DONE]') continue;
        
        try {
          const parsed = JSON.parse(data);
          const content = parsed.choices?.[0]?.delta?.content;
          if (content) yield content;
        } catch {}
      }
    }
  }

  // --------------------------------------------------------------------------
  // EON MEMORY INTEGRATION
  // --------------------------------------------------------------------------

  private async recordEpisode(request: GatewayRequest, response: GatewayResponse): Promise<string> {
    // Record to ankr-eon memory system
    // Implement based on your eon schema
    const episodeId = createHash('md5')
      .update(JSON.stringify({ query: request.query, timestamp: Date.now() }))
      .digest('hex');

    // TODO: Insert into ankr_eon.episodes table
    // await this.eonClient.query(`INSERT INTO ankr_eon.episodes ...`);

    return episodeId;
  }

  // --------------------------------------------------------------------------
  // STATS & MONITORING
  // --------------------------------------------------------------------------

  private updateStats(product: Product, response: GatewayResponse): void {
    const existing = this.productStats.get(product) || {
      product,
      totalRequests: 0,
      totalCost: 0,
      totalTokens: 0,
      avgLatencyMs: 0,
      topSkills: [],
      topProviders: [],
    };

    existing.totalRequests++;
    existing.totalCost += response.cost;
    existing.totalTokens += response.tokens.total;
    existing.avgLatencyMs = (existing.avgLatencyMs * (existing.totalRequests - 1) + response.latencyMs) / existing.totalRequests;

    this.productStats.set(product, existing);

    // Update daily cost
    const dailyCost = (this.dailyCosts.get(product) || 0) + response.cost;
    this.dailyCosts.set(product, dailyCost);
  }

  getStats(product?: Product): ProductStats | Map<Product, ProductStats> {
    if (product) {
      return this.productStats.get(product) || {
        product,
        totalRequests: 0,
        totalCost: 0,
        totalTokens: 0,
        avgLatencyMs: 0,
        topSkills: [],
        topProviders: [],
      };
    }
    return this.productStats;
  }

  // --------------------------------------------------------------------------
  // UTILITY METHODS
  // --------------------------------------------------------------------------

  private getCacheKey(request: GatewayRequest): string {
    const data = JSON.stringify({
      query: request.query,
      product: request.product,
      skills: request.skills,
      language: request.language,
    });
    return createHash('md5').update(data).digest('hex');
  }

  listSkills(): string[] {
    const skillsDir = this.config.skillsPath;
    if (!existsSync(skillsDir)) return [];
    
    const { readdirSync } = require('fs');
    return readdirSync(skillsDir, { withFileTypes: true })
      .filter((d: any) => d.isDirectory())
      .map((d: any) => d.name);
  }

  getProductSkills(product: Product): string[] {
    return PRODUCT_SKILLS[product] || PRODUCT_SKILLS['ankr-internal'];
  }
}

// ============================================================================
// FACTORY & EXPORTS
// ============================================================================

export function createGateway(config?: Partial<GatewayConfig>): AIGateway {
  return new AIGateway(config);
}

export default AIGateway;
