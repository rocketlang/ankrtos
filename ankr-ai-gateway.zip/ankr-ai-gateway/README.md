# @ankr/ai-gateway

**Central AI Gateway for ALL ANKR Products**

Single entry point for AI across SWAYAM, WowTruck, CompliMtrx, Saathi, Baniai.io, and more.

© Powerp Box IT Solutions Pvt Ltd

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                      ANKR AI GATEWAY                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│  │  SWAYAM  │ │ WowTruck │ │CompliMtrx│ │  Saathi  │ │Baniai.io │ │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ │
│       │            │            │            │            │        │
│       └────────────┴─────┬──────┴────────────┴────────────┘        │
│                          │                                          │
│                          ▼                                          │
│              ┌───────────────────────┐                             │
│              │   @ankr/ai-gateway    │                             │
│              │                       │                             │
│              │  • Skill Injection    │                             │
│              │  • Provider Routing   │                             │
│              │  • Cost Optimization  │                             │
│              │  • ankr-eon Memory    │                             │
│              │  • Voice Support      │                             │
│              └───────────┬───────────┘                             │
│                          │                                          │
│         ┌────────────────┼────────────────┐                        │
│         ▼                ▼                ▼                        │
│    ┌─────────┐     ┌─────────┐     ┌─────────┐                    │
│    │  Groq   │     │LongCat  │     │DeepSeek │                    │
│    │  FREE   │     │  FREE   │     │  CHEAP  │                    │
│    │ (fast)  │     │ (indic) │     │ (code)  │                    │
│    └─────────┘     └─────────┘     └─────────┘                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Quick Start

### Installation

```bash
cd ~/ankr-labs-nx
pnpm add hono --filter @ankr/ai-gateway
```

### Run Server

```bash
# With Bun (recommended)
cd packages/@ankr/ai-gateway
bun run src/server.ts

# With Node
npx tsx src/server.ts
```

### Test It

```bash
# Health check
curl http://localhost:3000/health

# Chat (specify product)
curl -X POST http://localhost:3000/v1/chat \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Create a shipment tracking module",
    "product": "wowtruck"
  }'

# Hindi voice query
curl -X POST http://localhost:3000/v1/wowtruck/voice \
  -H "Content-Type: application/json" \
  -d '{
    "text": "मेरा शिपमेंट कहां है?",
    "language": "hi",
    "driverId": "DRV123"
  }'
```

---

## API Endpoints

### Core

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/v1/chat` | POST | Main chat endpoint |
| `/v1/chat/stream` | POST | Streaming chat |
| `/v1/codegen` | POST | Code generation |
| `/v1/search` | POST | RAG search |

### Product-Specific

| Endpoint | Product | Default Skills |
|----------|---------|----------------|
| `/v1/swayam/query` | SWAYAM | ankr-tms-dev, ankr-llmbox |
| `/v1/wowtruck/query` | WowTruck | ankr-tms-dev, ankr-voice-hindi, ankr-logistics-rag |
| `/v1/wowtruck/voice` | WowTruck | ankr-voice-hindi, ankr-tms-dev |
| `/v1/complimtrx/query` | CompliMtrx | ankr-tms-dev, ankr-logistics-rag |
| `/v1/saathi/query` | Saathi | ankr-voice-hindi, ankr-eon-memory |
| `/v1/baniai/query` | Baniai.io | ankr-tms-dev, ankr-logistics-rag |

### Stats

| Endpoint | Description |
|----------|-------------|
| `/v1/stats` | Stats for all products |
| `/v1/stats/:product` | Stats for specific product |
| `/v1/skills` | List available skills |

---

## Usage in Code

### Basic Usage

```typescript
import { createGateway } from '@ankr/ai-gateway';

const gateway = createGateway();

const response = await gateway.chat({
  query: 'Create a carrier rating service',
  product: 'wowtruck',
});

console.log(response.content);    // Generated code
console.log(response.provider);   // 'groq'
console.log(response.cost);       // 0 (free tier)
console.log(response.skillsUsed); // ['ankr-tms-dev']
```

### With Language

```typescript
const response = await gateway.chat({
  query: 'शिपमेंट की स्थिति बताओ',
  product: 'wowtruck',
  language: 'hi',
});
// Routes to LongCat (best for Hindi)
```

### Streaming

```typescript
const stream = gateway.chatStream({
  query: 'Write a long explanation of TMS',
  product: 'swayam',
});

for await (const chunk of stream) {
  process.stdout.write(chunk);
}
```

### Force Provider

```typescript
const response = await gateway.chat({
  query: 'Debug this complex algorithm',
  product: 'ankr-internal',
  provider: 'deepseek',  // Best for code
});
```

---

## Provider Routing

| Condition | Provider | Cost |
|-----------|----------|------|
| Hindi/Tamil/Telugu | LongCat | FREE |
| Default (fast) | Groq | FREE |
| Code generation | DeepSeek | ~$0.001 |
| Fallback | OpenRouter | ~$0.01 |

---

## Skills per Product

```typescript
const PRODUCT_SKILLS = {
  'swayam': ['ankr-tms-dev', 'ankr-llmbox'],
  'wowtruck': ['ankr-tms-dev', 'ankr-voice-hindi', 'ankr-logistics-rag', 'ankr-eon-memory'],
  'complimtrx': ['ankr-tms-dev', 'ankr-logistics-rag'],
  'saathi': ['ankr-voice-hindi', 'ankr-eon-memory'],
  'baniai': ['ankr-tms-dev', 'ankr-logistics-rag'],
};
```

---

## Environment Variables

```bash
# Provider API Keys
GROQ_API_KEY=gsk_xxx
LONGCAT_API_KEY=ak_xxx
DEEPSEEK_API_KEY=sk-xxx
OPENROUTER_API_KEY=sk-or-xxx

# Optional
OLLAMA_BASE_URL=http://127.0.0.1:11434
EON_CONNECTION_STRING=postgresql://...
```

---

## Cost Optimization

The gateway automatically:

1. **Prefers free-tier providers** (Groq, LongCat, Ollama)
2. **Routes by language** (Hindi → LongCat)
3. **Routes by task** (Code → DeepSeek)
4. **Caches responses** (same query = instant)
5. **Tracks per-product costs**

**Monthly estimate:**
- Light usage: $0 (all free tier)
- Heavy usage: $5-20
- Enterprise: $50-100

---

## Integration with Existing Proxy

If you have an existing AI proxy, integrate like this:

```typescript
import { AIGateway } from '@ankr/ai-gateway';

// Your existing proxy
import { MyAIProxy } from './my-ai-proxy';

// Override the provider call method
class CustomGateway extends AIGateway {
  private myProxy: MyAIProxy;

  constructor(proxy: MyAIProxy) {
    super();
    this.myProxy = proxy;
  }

  protected async callProvider(provider, messages, request) {
    // Use your existing proxy
    return this.myProxy.chat({
      messages,
      provider: provider.name,
    });
  }
}

const gateway = new CustomGateway(myExistingProxy);
```

---

## License

PROPRIETARY - Powerp Box IT Solutions Pvt Ltd

---

Jai Guru Ji 🙏
