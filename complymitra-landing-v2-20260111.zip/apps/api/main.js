"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// apps/api/src/main.ts
var import_fastify = __toESM(require("fastify"));
var import_cors = __toESM(require("@fastify/cors"));
var import_mercurius = __toESM(require("mercurius"));

// apps/api/src/app/graphql/builder.ts
var import_core = __toESM(require("@pothos/core"));
var import_plugin_simple_objects = __toESM(require("@pothos/plugin-simple-objects"));
var builder = new import_core.default({
  plugins: [import_plugin_simple_objects.default]
});
builder.scalarType("DateTime", {
  serialize: (value) => value.toISOString(),
  parseValue: (value) => {
    if (typeof value === "string" || typeof value === "number") {
      return new Date(value);
    }
    throw new Error("Invalid DateTime value");
  }
});
builder.scalarType("Decimal", {
  serialize: (value) => Number(value),
  parseValue: (value) => {
    if (typeof value === "number")
      return value;
    if (typeof value === "string")
      return parseFloat(value);
    throw new Error("Invalid Decimal value");
  }
});
builder.queryType({});
builder.mutationType({});

// libs/database/src/index.ts
var import_client = require("@prisma/client");
var globalForPrisma = globalThis;
var prisma = globalForPrisma.prisma ?? new import_client.PrismaClient({
  log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"]
});
if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}

// apps/api/src/app/graphql/types/company.ts
builder.enumType("EntityType", {
  values: [
    "PROPRIETORSHIP",
    "PARTNERSHIP",
    "LLP",
    "PRIVATE_LIMITED",
    "PUBLIC_LIMITED",
    "OPC",
    "SECTION_8",
    "TRUST",
    "SOCIETY",
    "HUF"
  ]
});
builder.enumType("CompanyStatus", {
  values: ["ACTIVE", "INACTIVE", "SUSPENDED", "PENDING_VERIFICATION"]
});
var CompanyObject = builder.simpleObject("Company", {
  fields: (t) => ({
    id: t.string(),
    legalName: t.string(),
    tradeName: t.string({ nullable: true }),
    entityType: t.string(),
    dateOfIncorporation: t.field({ type: "DateTime", nullable: true }),
    cin: t.string({ nullable: true }),
    llpin: t.string({ nullable: true }),
    pan: t.string(),
    tan: t.string({ nullable: true }),
    primaryNicCode: t.string({ nullable: true }),
    industrySector: t.string({ nullable: true }),
    financialYearEnd: t.string(),
    totalEmployees: t.int(),
    permanentEmployees: t.int(),
    contractEmployees: t.int(),
    isMsme: t.boolean(),
    msmeCategory: t.string({ nullable: true }),
    udyamRegistration: t.string({ nullable: true }),
    email: t.string({ nullable: true }),
    phone: t.string({ nullable: true }),
    website: t.string({ nullable: true }),
    status: t.string(),
    onboardingCompleted: t.boolean(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});

// apps/api/src/app/graphql/types/address.ts
var INDIAN_STATES = {
  "AN": "Andaman and Nicobar Islands",
  "AP": "Andhra Pradesh",
  "AR": "Arunachal Pradesh",
  "AS": "Assam",
  "BR": "Bihar",
  "CH": "Chandigarh",
  "CT": "Chhattisgarh",
  "DD": "Daman and Diu",
  "DL": "Delhi",
  "GA": "Goa",
  "GJ": "Gujarat",
  "HP": "Himachal Pradesh",
  "HR": "Haryana",
  "JH": "Jharkhand",
  "JK": "Jammu and Kashmir",
  "KA": "Karnataka",
  "KL": "Kerala",
  "LA": "Ladakh",
  "LD": "Lakshadweep",
  "MH": "Maharashtra",
  "ML": "Meghalaya",
  "MN": "Manipur",
  "MP": "Madhya Pradesh",
  "MZ": "Mizoram",
  "NL": "Nagaland",
  "OD": "Odisha",
  "PB": "Punjab",
  "PY": "Puducherry",
  "RJ": "Rajasthan",
  "SK": "Sikkim",
  "TG": "Telangana",
  "TN": "Tamil Nadu",
  "TR": "Tripura",
  "UK": "Uttarakhand",
  "UP": "Uttar Pradesh",
  "WB": "West Bengal"
};
var CompanyAddressObject = builder.simpleObject("CompanyAddress", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    addressType: t.string(),
    addressLine1: t.string(),
    addressLine2: t.string({ nullable: true }),
    landmark: t.string({ nullable: true }),
    city: t.string(),
    district: t.string({ nullable: true }),
    stateCode: t.string(),
    stateName: t.string(),
    // Computed from stateCode
    pincode: t.string(),
    isPrimary: t.boolean(),
    contactPerson: t.string({ nullable: true }),
    contactPhone: t.string({ nullable: true }),
    contactEmail: t.string({ nullable: true }),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
function withStateName(address) {
  if (!address)
    return null;
  return {
    ...address,
    stateName: INDIAN_STATES[address.stateCode] || address.stateCode
  };
}
function withStateNameList(addresses) {
  return addresses.map(withStateName);
}
builder.queryFields((t) => ({
  // Get addresses for a company
  companyAddresses: t.field({
    type: [CompanyAddressObject],
    args: {
      companyId: t.arg.string({ required: true })
    },
    resolve: async (_, { companyId }) => {
      const addresses = await prisma.companyAddress.findMany({
        where: { companyId },
        orderBy: { isPrimary: "desc" }
      });
      return withStateNameList(addresses);
    }
  }),
  // Get single address
  companyAddress: t.field({
    type: CompanyAddressObject,
    nullable: true,
    args: {
      id: t.arg.string({ required: true })
    },
    resolve: async (_, { id }) => {
      const address = await prisma.companyAddress.findUnique({ where: { id } });
      return withStateName(address);
    }
  }),
  // List Indian states
  indianStates: t.field({
    type: ["String"],
    resolve: () => Object.entries(INDIAN_STATES).map(([code, name]) => `${code}: ${name}`)
  })
}));
builder.mutationFields((t) => ({
  // Add address to company
  addCompanyAddress: t.field({
    type: CompanyAddressObject,
    args: {
      companyId: t.arg.string({ required: true }),
      addressType: t.arg.string({ required: true }),
      addressLine1: t.arg.string({ required: true }),
      addressLine2: t.arg.string(),
      landmark: t.arg.string(),
      city: t.arg.string({ required: true }),
      district: t.arg.string(),
      stateCode: t.arg.string({ required: true }),
      pincode: t.arg.string({ required: true }),
      isPrimary: t.arg.boolean({ defaultValue: false }),
      contactPerson: t.arg.string(),
      contactPhone: t.arg.string(),
      contactEmail: t.arg.string()
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      const stateCode = args.stateCode.toUpperCase();
      if (!INDIAN_STATES[stateCode]) {
        throw new Error(`Invalid state code: ${stateCode}`);
      }
      if (!/^\d{6}$/.test(args.pincode)) {
        throw new Error("Invalid pincode. Must be 6 digits");
      }
      if (args.isPrimary) {
        await prisma.companyAddress.updateMany({
          where: { companyId: args.companyId, isPrimary: true },
          data: { isPrimary: false }
        });
      }
      const address = await prisma.companyAddress.create({
        data: {
          companyId: args.companyId,
          addressType: args.addressType,
          addressLine1: args.addressLine1,
          addressLine2: args.addressLine2,
          landmark: args.landmark,
          city: args.city,
          district: args.district,
          stateCode,
          pincode: args.pincode,
          isPrimary: args.isPrimary ?? false,
          contactPerson: args.contactPerson,
          contactPhone: args.contactPhone,
          contactEmail: args.contactEmail
        }
      });
      return withStateName(address);
    }
  }),
  // Update address
  updateCompanyAddress: t.field({
    type: CompanyAddressObject,
    args: {
      id: t.arg.string({ required: true }),
      addressType: t.arg.string(),
      addressLine1: t.arg.string(),
      addressLine2: t.arg.string(),
      landmark: t.arg.string(),
      city: t.arg.string(),
      district: t.arg.string(),
      stateCode: t.arg.string(),
      pincode: t.arg.string(),
      isPrimary: t.arg.boolean(),
      contactPerson: t.arg.string(),
      contactPhone: t.arg.string(),
      contactEmail: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const existing = await prisma.companyAddress.findUnique({ where: { id } });
      if (!existing)
        throw new Error("Address not found");
      const data = {};
      if (args.addressType !== void 0)
        data.addressType = args.addressType;
      if (args.addressLine1 !== void 0)
        data.addressLine1 = args.addressLine1;
      if (args.addressLine2 !== void 0)
        data.addressLine2 = args.addressLine2;
      if (args.landmark !== void 0)
        data.landmark = args.landmark;
      if (args.city !== void 0)
        data.city = args.city;
      if (args.district !== void 0)
        data.district = args.district;
      if (args.contactPerson !== void 0)
        data.contactPerson = args.contactPerson;
      if (args.contactPhone !== void 0)
        data.contactPhone = args.contactPhone;
      if (args.contactEmail !== void 0)
        data.contactEmail = args.contactEmail;
      if (args.pincode !== void 0 && args.pincode !== null) {
        if (!/^\d{6}$/.test(args.pincode)) {
          throw new Error("Invalid pincode. Must be 6 digits");
        }
        data.pincode = args.pincode;
      }
      if (args.stateCode !== void 0 && args.stateCode !== null) {
        const stateCode = args.stateCode.toUpperCase();
        if (!INDIAN_STATES[stateCode]) {
          throw new Error(`Invalid state code: ${stateCode}`);
        }
        data.stateCode = stateCode;
      }
      if (args.isPrimary === true) {
        await prisma.companyAddress.updateMany({
          where: { companyId: existing.companyId, isPrimary: true, id: { not: id } },
          data: { isPrimary: false }
        });
        data.isPrimary = true;
      } else if (args.isPrimary === false) {
        data.isPrimary = false;
      }
      const address = await prisma.companyAddress.update({ where: { id }, data });
      return withStateName(address);
    }
  }),
  // Delete address
  deleteCompanyAddress: t.field({
    type: "Boolean",
    args: {
      id: t.arg.string({ required: true })
    },
    resolve: async (_, { id }) => {
      const existing = await prisma.companyAddress.findUnique({ where: { id } });
      if (!existing)
        throw new Error("Address not found");
      await prisma.companyAddress.delete({ where: { id } });
      return true;
    }
  })
}));

// apps/api/src/app/graphql/types/gst.ts
var GST_STATE_CODES = {
  "01": "JK",
  "02": "HP",
  "03": "PB",
  "04": "CH",
  "05": "UK",
  "06": "HR",
  "07": "DL",
  "08": "RJ",
  "09": "UP",
  "10": "BR",
  "11": "SK",
  "12": "AR",
  "13": "NL",
  "14": "MN",
  "15": "MZ",
  "16": "TR",
  "17": "ML",
  "18": "AS",
  "19": "WB",
  "20": "JH",
  "21": "OD",
  "22": "CT",
  "23": "MP",
  "24": "GJ",
  "26": "DD",
  "27": "MH",
  "28": "AP",
  "29": "KA",
  "30": "GA",
  "31": "LD",
  "32": "KL",
  "33": "TN",
  "34": "PY",
  "35": "AN",
  "36": "TG",
  "37": "AP",
  "38": "LA"
};
function validateGSTIN(gstin) {
  const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
  if (!gstinRegex.test(gstin)) {
    return { valid: false, error: "Invalid GSTIN format. Expected: 27AAAAA0000A1Z5" };
  }
  const gstStateCode = gstin.substring(0, 2);
  const stateCode = GST_STATE_CODES[gstStateCode];
  if (!stateCode) {
    return { valid: false, error: `Invalid GST state code: ${gstStateCode}` };
  }
  return { valid: true, stateCode };
}
var GstRegistrationObject = builder.simpleObject("GstRegistration", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    gstin: t.string(),
    stateCode: t.string(),
    stateName: t.string(),
    tradeName: t.string({ nullable: true }),
    registrationType: t.string(),
    registrationDate: t.field({ type: "DateTime", nullable: true }),
    filingFrequency: t.string(),
    isEinvoiceApplicable: t.boolean(),
    einvoiceFromDate: t.field({ type: "DateTime", nullable: true }),
    username: t.string({ nullable: true }),
    isPrimary: t.boolean(),
    status: t.string(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
function withStateName2(gst) {
  if (!gst)
    return null;
  return {
    ...gst,
    stateName: INDIAN_STATES[gst.stateCode] || gst.stateCode
  };
}
function withStateNameList2(registrations) {
  return registrations.map(withStateName2);
}
builder.queryFields((t) => ({
  // Get GST registrations for a company
  gstRegistrations: t.field({
    type: [GstRegistrationObject],
    args: {
      companyId: t.arg.string({ required: true })
    },
    resolve: async (_, { companyId }) => {
      const registrations = await prisma.gstRegistration.findMany({
        where: { companyId },
        orderBy: { isPrimary: "desc" }
      });
      return withStateNameList2(registrations);
    }
  }),
  // Get single GST registration
  gstRegistration: t.field({
    type: GstRegistrationObject,
    nullable: true,
    args: {
      id: t.arg.string({ required: true })
    },
    resolve: async (_, { id }) => {
      const registration = await prisma.gstRegistration.findUnique({ where: { id } });
      return withStateName2(registration);
    }
  }),
  // Get GST by GSTIN
  gstByGstin: t.field({
    type: GstRegistrationObject,
    nullable: true,
    args: {
      gstin: t.arg.string({ required: true })
    },
    resolve: async (_, { gstin }) => {
      const registration = await prisma.gstRegistration.findUnique({
        where: { gstin: gstin.toUpperCase() }
      });
      return withStateName2(registration);
    }
  })
}));
builder.mutationFields((t) => ({
  // Add GST registration
  addGstRegistration: t.field({
    type: GstRegistrationObject,
    args: {
      companyId: t.arg.string({ required: true }),
      gstin: t.arg.string({ required: true }),
      tradeName: t.arg.string(),
      registrationType: t.arg.string({ required: true }),
      registrationDate: t.arg.string(),
      filingFrequency: t.arg.string({ defaultValue: "MONTHLY" }),
      isEinvoiceApplicable: t.arg.boolean({ defaultValue: false }),
      einvoiceFromDate: t.arg.string(),
      username: t.arg.string(),
      isPrimary: t.arg.boolean({ defaultValue: false })
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      const gstinUpper = args.gstin.toUpperCase();
      const validation = validateGSTIN(gstinUpper);
      if (!validation.valid) {
        throw new Error(validation.error);
      }
      const gstinPan = gstinUpper.substring(2, 12);
      if (gstinPan !== company.pan) {
        throw new Error(`GSTIN PAN (${gstinPan}) does not match company PAN (${company.pan})`);
      }
      const existing = await prisma.gstRegistration.findUnique({ where: { gstin: gstinUpper } });
      if (existing) {
        throw new Error("This GSTIN is already registered");
      }
      if (args.isPrimary) {
        await prisma.gstRegistration.updateMany({
          where: { companyId: args.companyId, isPrimary: true },
          data: { isPrimary: false }
        });
      }
      const registration = await prisma.gstRegistration.create({
        data: {
          companyId: args.companyId,
          gstin: gstinUpper,
          stateCode: validation.stateCode,
          tradeName: args.tradeName,
          registrationType: args.registrationType,
          registrationDate: args.registrationDate ? new Date(args.registrationDate) : null,
          filingFrequency: args.filingFrequency || "MONTHLY",
          isEinvoiceApplicable: args.isEinvoiceApplicable ?? false,
          einvoiceFromDate: args.einvoiceFromDate ? new Date(args.einvoiceFromDate) : null,
          username: args.username,
          isPrimary: args.isPrimary ?? false,
          status: "ACTIVE"
        }
      });
      return withStateName2(registration);
    }
  }),
  // Update GST registration
  updateGstRegistration: t.field({
    type: GstRegistrationObject,
    args: {
      id: t.arg.string({ required: true }),
      tradeName: t.arg.string(),
      filingFrequency: t.arg.string(),
      isEinvoiceApplicable: t.arg.boolean(),
      einvoiceFromDate: t.arg.string(),
      username: t.arg.string(),
      isPrimary: t.arg.boolean(),
      status: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const existing = await prisma.gstRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("GST Registration not found");
      const data = {};
      if (args.tradeName !== void 0)
        data.tradeName = args.tradeName;
      if (args.filingFrequency !== void 0)
        data.filingFrequency = args.filingFrequency;
      if (args.isEinvoiceApplicable !== void 0)
        data.isEinvoiceApplicable = args.isEinvoiceApplicable;
      if (args.einvoiceFromDate !== void 0) {
        data.einvoiceFromDate = args.einvoiceFromDate ? new Date(args.einvoiceFromDate) : null;
      }
      if (args.username !== void 0)
        data.username = args.username;
      if (args.status !== void 0)
        data.status = args.status;
      if (args.isPrimary === true) {
        await prisma.gstRegistration.updateMany({
          where: { companyId: existing.companyId, isPrimary: true, id: { not: id } },
          data: { isPrimary: false }
        });
        data.isPrimary = true;
      } else if (args.isPrimary === false) {
        data.isPrimary = false;
      }
      const registration = await prisma.gstRegistration.update({ where: { id }, data });
      return withStateName2(registration);
    }
  }),
  // Delete GST registration
  deleteGstRegistration: t.field({
    type: "Boolean",
    args: {
      id: t.arg.string({ required: true })
    },
    resolve: async (_, { id }) => {
      const existing = await prisma.gstRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("GST Registration not found");
      await prisma.gstRegistration.delete({ where: { id } });
      return true;
    }
  })
}));

// apps/api/src/app/graphql/types/epf-esi.ts
var EpfRegistrationObject = builder.simpleObject("EpfRegistration", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    establishmentCode: t.string(),
    establishmentName: t.string({ nullable: true }),
    registrationDate: t.field({ type: "DateTime", nullable: true }),
    coveredEmployees: t.int(),
    isExempted: t.boolean(),
    exemptionCategory: t.string({ nullable: true }),
    wageLimit: t.field({ type: "Decimal" }),
    employerContributionRate: t.field({ type: "Decimal" }),
    employeeContributionRate: t.field({ type: "Decimal" }),
    adminChargesRate: t.field({ type: "Decimal" }),
    isEdliApplicable: t.boolean(),
    username: t.string({ nullable: true }),
    status: t.string(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
var EsiRegistrationObject = builder.simpleObject("EsiRegistration", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    esiCode: t.string(),
    stateCode: t.string(),
    stateName: t.string(),
    registrationDate: t.field({ type: "DateTime", nullable: true }),
    coveredEmployees: t.int(),
    wageLimit: t.field({ type: "Decimal" }),
    employerContributionRate: t.field({ type: "Decimal" }),
    employeeContributionRate: t.field({ type: "Decimal" }),
    dispensaryName: t.string({ nullable: true }),
    dispensaryAddress: t.string({ nullable: true }),
    dispensaryCode: t.string({ nullable: true }),
    username: t.string({ nullable: true }),
    status: t.string(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
function withStateName3(esi) {
  if (!esi)
    return null;
  return {
    ...esi,
    stateName: INDIAN_STATES[esi.stateCode] || esi.stateCode
  };
}
builder.queryFields((t) => ({
  epfRegistrations: t.field({
    type: [EpfRegistrationObject],
    args: { companyId: t.arg.string({ required: true }) },
    resolve: async (_, { companyId }) => {
      const registrations = await prisma.epfRegistration.findMany({
        where: { companyId },
        orderBy: { createdAt: "desc" }
      });
      return registrations;
    }
  }),
  epfRegistration: t.field({
    type: EpfRegistrationObject,
    nullable: true,
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const registration = await prisma.epfRegistration.findUnique({ where: { id } });
      return registration;
    }
  }),
  esiRegistrations: t.field({
    type: [EsiRegistrationObject],
    args: { companyId: t.arg.string({ required: true }) },
    resolve: async (_, { companyId }) => {
      const registrations = await prisma.esiRegistration.findMany({
        where: { companyId },
        orderBy: { createdAt: "desc" }
      });
      return registrations.map(withStateName3);
    }
  }),
  esiRegistration: t.field({
    type: EsiRegistrationObject,
    nullable: true,
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const registration = await prisma.esiRegistration.findUnique({ where: { id } });
      return withStateName3(registration);
    }
  })
}));
builder.mutationFields((t) => ({
  addEpfRegistration: t.field({
    type: EpfRegistrationObject,
    args: {
      companyId: t.arg.string({ required: true }),
      establishmentCode: t.arg.string({ required: true }),
      establishmentName: t.arg.string(),
      registrationDate: t.arg.string(),
      coveredEmployees: t.arg.int({ defaultValue: 0 }),
      isExempted: t.arg.boolean({ defaultValue: false }),
      username: t.arg.string()
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      const codeUpper = args.establishmentCode.toUpperCase();
      if (codeUpper.length < 10 || codeUpper.length > 25) {
        throw new Error("EPF establishment code must be 10-25 characters");
      }
      const existing = await prisma.epfRegistration.findUnique({
        where: { establishmentCode: codeUpper }
      });
      if (existing)
        throw new Error("This EPF code is already registered");
      const registration = await prisma.epfRegistration.create({
        data: {
          companyId: args.companyId,
          establishmentCode: codeUpper,
          establishmentName: args.establishmentName,
          registrationDate: args.registrationDate ? new Date(args.registrationDate) : null,
          coveredEmployees: args.coveredEmployees ?? 0,
          isExempted: args.isExempted ?? false,
          username: args.username,
          status: "ACTIVE"
        }
      });
      return registration;
    }
  }),
  updateEpfRegistration: t.field({
    type: EpfRegistrationObject,
    args: {
      id: t.arg.string({ required: true }),
      establishmentName: t.arg.string(),
      coveredEmployees: t.arg.int(),
      isExempted: t.arg.boolean(),
      username: t.arg.string(),
      status: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const existing = await prisma.epfRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("EPF Registration not found");
      const data = {};
      if (args.establishmentName !== void 0)
        data.establishmentName = args.establishmentName;
      if (args.coveredEmployees !== void 0)
        data.coveredEmployees = args.coveredEmployees;
      if (args.isExempted !== void 0)
        data.isExempted = args.isExempted;
      if (args.username !== void 0)
        data.username = args.username;
      if (args.status !== void 0)
        data.status = args.status;
      const registration = await prisma.epfRegistration.update({ where: { id }, data });
      return registration;
    }
  }),
  deleteEpfRegistration: t.field({
    type: "Boolean",
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const existing = await prisma.epfRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("EPF Registration not found");
      await prisma.epfRegistration.delete({ where: { id } });
      return true;
    }
  }),
  addEsiRegistration: t.field({
    type: EsiRegistrationObject,
    args: {
      companyId: t.arg.string({ required: true }),
      esiCode: t.arg.string({ required: true }),
      stateCode: t.arg.string({ required: true }),
      registrationDate: t.arg.string(),
      coveredEmployees: t.arg.int({ defaultValue: 0 }),
      dispensaryName: t.arg.string(),
      username: t.arg.string()
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      const stateCode = args.stateCode.toUpperCase();
      if (!INDIAN_STATES[stateCode]) {
        throw new Error(`Invalid state code: ${stateCode}`);
      }
      if (!/^[0-9]{17}$/.test(args.esiCode)) {
        throw new Error("Invalid ESI code format. Must be 17 digits");
      }
      const existing = await prisma.esiRegistration.findUnique({
        where: { esiCode: args.esiCode }
      });
      if (existing)
        throw new Error("This ESI code is already registered");
      const registration = await prisma.esiRegistration.create({
        data: {
          companyId: args.companyId,
          esiCode: args.esiCode,
          stateCode,
          registrationDate: args.registrationDate ? new Date(args.registrationDate) : null,
          coveredEmployees: args.coveredEmployees ?? 0,
          dispensaryName: args.dispensaryName,
          username: args.username,
          status: "ACTIVE"
        }
      });
      return withStateName3(registration);
    }
  }),
  updateEsiRegistration: t.field({
    type: EsiRegistrationObject,
    args: {
      id: t.arg.string({ required: true }),
      coveredEmployees: t.arg.int(),
      dispensaryName: t.arg.string(),
      username: t.arg.string(),
      status: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const existing = await prisma.esiRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("ESI Registration not found");
      const data = {};
      if (args.coveredEmployees !== void 0)
        data.coveredEmployees = args.coveredEmployees;
      if (args.dispensaryName !== void 0)
        data.dispensaryName = args.dispensaryName;
      if (args.username !== void 0)
        data.username = args.username;
      if (args.status !== void 0)
        data.status = args.status;
      const registration = await prisma.esiRegistration.update({ where: { id }, data });
      return withStateName3(registration);
    }
  }),
  deleteEsiRegistration: t.field({
    type: "Boolean",
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const existing = await prisma.esiRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("ESI Registration not found");
      await prisma.esiRegistration.delete({ where: { id } });
      return true;
    }
  })
}));

// apps/api/src/app/graphql/types/pt-lwf.ts
var PtRegistrationObject = builder.simpleObject("PtRegistration", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    stateCode: t.string(),
    stateName: t.string(),
    ptecNumber: t.string({ nullable: true }),
    ptrcNumber: t.string({ nullable: true }),
    registrationDate: t.field({ type: "DateTime", nullable: true }),
    filingFrequency: t.string(),
    taxSlabApplicable: t.string({ nullable: true }),
    enrolledEmployees: t.int(),
    username: t.string({ nullable: true }),
    status: t.string(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
var LwfRegistrationObject = builder.simpleObject("LwfRegistration", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    stateCode: t.string(),
    stateName: t.string(),
    registrationNumber: t.string({ nullable: true }),
    registrationDate: t.field({ type: "DateTime", nullable: true }),
    filingFrequency: t.string(),
    employerContribution: t.field({ type: "Decimal", nullable: true }),
    employeeContribution: t.field({ type: "Decimal", nullable: true }),
    username: t.string({ nullable: true }),
    status: t.string(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
function withStateName4(record) {
  if (!record)
    return null;
  return {
    ...record,
    stateName: INDIAN_STATES[record.stateCode] || record.stateCode
  };
}
builder.queryFields((t) => ({
  ptRegistrations: t.field({
    type: [PtRegistrationObject],
    args: { companyId: t.arg.string({ required: true }) },
    resolve: async (_, { companyId }) => {
      const registrations = await prisma.ptRegistration.findMany({
        where: { companyId },
        orderBy: { stateCode: "asc" }
      });
      return registrations.map(withStateName4);
    }
  }),
  ptRegistration: t.field({
    type: PtRegistrationObject,
    nullable: true,
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const registration = await prisma.ptRegistration.findUnique({ where: { id } });
      return withStateName4(registration);
    }
  }),
  lwfRegistrations: t.field({
    type: [LwfRegistrationObject],
    args: { companyId: t.arg.string({ required: true }) },
    resolve: async (_, { companyId }) => {
      const registrations = await prisma.lwfRegistration.findMany({
        where: { companyId },
        orderBy: { stateCode: "asc" }
      });
      return registrations.map(withStateName4);
    }
  }),
  lwfRegistration: t.field({
    type: LwfRegistrationObject,
    nullable: true,
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const registration = await prisma.lwfRegistration.findUnique({ where: { id } });
      return withStateName4(registration);
    }
  })
}));
builder.mutationFields((t) => ({
  addPtRegistration: t.field({
    type: PtRegistrationObject,
    args: {
      companyId: t.arg.string({ required: true }),
      stateCode: t.arg.string({ required: true }),
      ptecNumber: t.arg.string(),
      ptrcNumber: t.arg.string(),
      registrationDate: t.arg.string(),
      filingFrequency: t.arg.string({ defaultValue: "MONTHLY" }),
      enrolledEmployees: t.arg.int({ defaultValue: 0 }),
      username: t.arg.string()
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      const stateCode = args.stateCode.toUpperCase();
      if (!INDIAN_STATES[stateCode]) {
        throw new Error(`Invalid state code: ${stateCode}`);
      }
      const existing = await prisma.ptRegistration.findFirst({
        where: { companyId: args.companyId, stateCode }
      });
      if (existing) {
        throw new Error(`PT Registration already exists for ${INDIAN_STATES[stateCode]}`);
      }
      const registration = await prisma.ptRegistration.create({
        data: {
          companyId: args.companyId,
          stateCode,
          ptecNumber: args.ptecNumber,
          ptrcNumber: args.ptrcNumber,
          registrationDate: args.registrationDate ? new Date(args.registrationDate) : null,
          filingFrequency: args.filingFrequency || "MONTHLY",
          enrolledEmployees: args.enrolledEmployees ?? 0,
          username: args.username,
          status: "ACTIVE"
        }
      });
      return withStateName4(registration);
    }
  }),
  updatePtRegistration: t.field({
    type: PtRegistrationObject,
    args: {
      id: t.arg.string({ required: true }),
      ptecNumber: t.arg.string(),
      ptrcNumber: t.arg.string(),
      filingFrequency: t.arg.string(),
      enrolledEmployees: t.arg.int(),
      username: t.arg.string(),
      status: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const existing = await prisma.ptRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("PT Registration not found");
      const data = {};
      if (args.ptecNumber !== void 0)
        data.ptecNumber = args.ptecNumber;
      if (args.ptrcNumber !== void 0)
        data.ptrcNumber = args.ptrcNumber;
      if (args.filingFrequency !== void 0)
        data.filingFrequency = args.filingFrequency;
      if (args.enrolledEmployees !== void 0)
        data.enrolledEmployees = args.enrolledEmployees;
      if (args.username !== void 0)
        data.username = args.username;
      if (args.status !== void 0)
        data.status = args.status;
      const registration = await prisma.ptRegistration.update({ where: { id }, data });
      return withStateName4(registration);
    }
  }),
  deletePtRegistration: t.field({
    type: "Boolean",
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const existing = await prisma.ptRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("PT Registration not found");
      await prisma.ptRegistration.delete({ where: { id } });
      return true;
    }
  }),
  addLwfRegistration: t.field({
    type: LwfRegistrationObject,
    args: {
      companyId: t.arg.string({ required: true }),
      stateCode: t.arg.string({ required: true }),
      registrationNumber: t.arg.string(),
      registrationDate: t.arg.string(),
      filingFrequency: t.arg.string({ defaultValue: "HALF_YEARLY" }),
      employerContribution: t.arg.float(),
      employeeContribution: t.arg.float(),
      username: t.arg.string()
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      const stateCode = args.stateCode.toUpperCase();
      if (!INDIAN_STATES[stateCode]) {
        throw new Error(`Invalid state code: ${stateCode}`);
      }
      const existing = await prisma.lwfRegistration.findFirst({
        where: { companyId: args.companyId, stateCode }
      });
      if (existing) {
        throw new Error(`LWF Registration already exists for ${INDIAN_STATES[stateCode]}`);
      }
      const registration = await prisma.lwfRegistration.create({
        data: {
          companyId: args.companyId,
          stateCode,
          registrationNumber: args.registrationNumber,
          registrationDate: args.registrationDate ? new Date(args.registrationDate) : null,
          filingFrequency: args.filingFrequency || "HALF_YEARLY",
          employerContribution: args.employerContribution,
          employeeContribution: args.employeeContribution,
          username: args.username,
          status: "ACTIVE"
        }
      });
      return withStateName4(registration);
    }
  }),
  updateLwfRegistration: t.field({
    type: LwfRegistrationObject,
    args: {
      id: t.arg.string({ required: true }),
      registrationNumber: t.arg.string(),
      filingFrequency: t.arg.string(),
      employerContribution: t.arg.float(),
      employeeContribution: t.arg.float(),
      username: t.arg.string(),
      status: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const existing = await prisma.lwfRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("LWF Registration not found");
      const data = {};
      if (args.registrationNumber !== void 0)
        data.registrationNumber = args.registrationNumber;
      if (args.filingFrequency !== void 0)
        data.filingFrequency = args.filingFrequency;
      if (args.employerContribution !== void 0)
        data.employerContribution = args.employerContribution;
      if (args.employeeContribution !== void 0)
        data.employeeContribution = args.employeeContribution;
      if (args.username !== void 0)
        data.username = args.username;
      if (args.status !== void 0)
        data.status = args.status;
      const registration = await prisma.lwfRegistration.update({ where: { id }, data });
      return withStateName4(registration);
    }
  }),
  deleteLwfRegistration: t.field({
    type: "Boolean",
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const existing = await prisma.lwfRegistration.findUnique({ where: { id } });
      if (!existing)
        throw new Error("LWF Registration not found");
      await prisma.lwfRegistration.delete({ where: { id } });
      return true;
    }
  })
}));

// apps/api/src/app/graphql/types/personnel.ts
var CompanyPersonnelObject = builder.simpleObject("CompanyPersonnel", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    personType: t.string(),
    designation: t.string({ nullable: true }),
    din: t.string({ nullable: true }),
    dpin: t.string({ nullable: true }),
    pan: t.string({ nullable: true }),
    firstName: t.string(),
    lastName: t.string({ nullable: true }),
    fullName: t.string(),
    email: t.string({ nullable: true }),
    mobile: t.string({ nullable: true }),
    dateOfAppointment: t.field({ type: "DateTime", nullable: true }),
    dateOfCessation: t.field({ type: "DateTime", nullable: true }),
    hasDsc: t.boolean(),
    dscExpiryDate: t.field({ type: "DateTime", nullable: true }),
    isAuthorizedSignatory: t.boolean(),
    status: t.string(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
function withFullName(person) {
  if (!person)
    return null;
  return {
    ...person,
    fullName: person.lastName ? `${person.firstName} ${person.lastName}` : person.firstName
  };
}
builder.queryFields((t) => ({
  companyPersonnel: t.field({
    type: [CompanyPersonnelObject],
    args: {
      companyId: t.arg.string({ required: true }),
      personType: t.arg.string(),
      status: t.arg.string()
    },
    resolve: async (_, { companyId, personType, status }) => {
      const where = { companyId };
      if (personType)
        where.personType = personType;
      if (status)
        where.status = status;
      const personnel = await prisma.companyPersonnel.findMany({
        where,
        orderBy: [{ personType: "asc" }, { firstName: "asc" }]
      });
      return personnel.map(withFullName);
    }
  }),
  person: t.field({
    type: CompanyPersonnelObject,
    nullable: true,
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const person = await prisma.companyPersonnel.findUnique({ where: { id } });
      return withFullName(person);
    }
  }),
  // Get directors by DIN
  personByDin: t.field({
    type: CompanyPersonnelObject,
    nullable: true,
    args: { din: t.arg.string({ required: true }) },
    resolve: async (_, { din }) => {
      const person = await prisma.companyPersonnel.findFirst({
        where: { din: din.toUpperCase() }
      });
      return withFullName(person);
    }
  })
}));
builder.mutationFields((t) => ({
  addPersonnel: t.field({
    type: CompanyPersonnelObject,
    args: {
      companyId: t.arg.string({ required: true }),
      personType: t.arg.string({ required: true }),
      designation: t.arg.string(),
      din: t.arg.string(),
      dpin: t.arg.string(),
      pan: t.arg.string(),
      firstName: t.arg.string({ required: true }),
      lastName: t.arg.string(),
      email: t.arg.string(),
      mobile: t.arg.string(),
      dateOfAppointment: t.arg.string(),
      hasDsc: t.arg.boolean({ defaultValue: false }),
      dscExpiryDate: t.arg.string(),
      isAuthorizedSignatory: t.arg.boolean({ defaultValue: false })
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      if (args.din) {
        const dinUpper = args.din.toUpperCase();
        if (!/^[0-9]{8}$/.test(dinUpper)) {
          throw new Error("Invalid DIN format. Must be 8 digits");
        }
      }
      if (args.pan) {
        const panUpper = args.pan.toUpperCase();
        if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(panUpper)) {
          throw new Error("Invalid PAN format");
        }
      }
      const person = await prisma.companyPersonnel.create({
        data: {
          companyId: args.companyId,
          personType: args.personType,
          designation: args.designation,
          din: args.din?.toUpperCase(),
          dpin: args.dpin?.toUpperCase(),
          pan: args.pan?.toUpperCase(),
          firstName: args.firstName,
          lastName: args.lastName,
          email: args.email?.toLowerCase(),
          mobile: args.mobile,
          dateOfAppointment: args.dateOfAppointment ? new Date(args.dateOfAppointment) : null,
          hasDsc: args.hasDsc ?? false,
          dscExpiryDate: args.dscExpiryDate ? new Date(args.dscExpiryDate) : null,
          isAuthorizedSignatory: args.isAuthorizedSignatory ?? false,
          status: "ACTIVE"
        }
      });
      return withFullName(person);
    }
  }),
  updatePersonnel: t.field({
    type: CompanyPersonnelObject,
    args: {
      id: t.arg.string({ required: true }),
      designation: t.arg.string(),
      email: t.arg.string(),
      mobile: t.arg.string(),
      hasDsc: t.arg.boolean(),
      dscExpiryDate: t.arg.string(),
      isAuthorizedSignatory: t.arg.boolean(),
      dateOfCessation: t.arg.string(),
      status: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const existing = await prisma.companyPersonnel.findUnique({ where: { id } });
      if (!existing)
        throw new Error("Personnel not found");
      const data = {};
      if (args.designation !== void 0)
        data.designation = args.designation;
      if (args.email !== void 0)
        data.email = args.email?.toLowerCase();
      if (args.mobile !== void 0)
        data.mobile = args.mobile;
      if (args.hasDsc !== void 0)
        data.hasDsc = args.hasDsc;
      if (args.dscExpiryDate !== void 0) {
        data.dscExpiryDate = args.dscExpiryDate ? new Date(args.dscExpiryDate) : null;
      }
      if (args.isAuthorizedSignatory !== void 0)
        data.isAuthorizedSignatory = args.isAuthorizedSignatory;
      if (args.dateOfCessation !== void 0) {
        data.dateOfCessation = args.dateOfCessation ? new Date(args.dateOfCessation) : null;
        if (args.dateOfCessation)
          data.status = "CEASED";
      }
      if (args.status !== void 0)
        data.status = args.status;
      const person = await prisma.companyPersonnel.update({ where: { id }, data });
      return withFullName(person);
    }
  }),
  deletePersonnel: t.field({
    type: "Boolean",
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const existing = await prisma.companyPersonnel.findUnique({ where: { id } });
      if (!existing)
        throw new Error("Personnel not found");
      await prisma.companyPersonnel.delete({ where: { id } });
      return true;
    }
  })
}));

// apps/api/src/app/graphql/types/turnover.ts
var CompanyTurnoverObject = builder.simpleObject("CompanyTurnover", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    financialYear: t.string(),
    turnoverAmount: t.field({ type: "Decimal" }),
    isAudited: t.boolean(),
    isEstimated: t.boolean(),
    createdAt: t.field({ type: "DateTime" }),
    updatedAt: t.field({ type: "DateTime" })
  })
});
var CompanyStateEmployeesObject = builder.simpleObject("CompanyStateEmployees", {
  fields: (t) => ({
    id: t.string(),
    companyId: t.string(),
    stateCode: t.string(),
    stateName: t.string(),
    employeeCount: t.int(),
    asOfDate: t.field({ type: "DateTime" }),
    createdAt: t.field({ type: "DateTime" })
  })
});
function withStateName5(record) {
  if (!record)
    return null;
  return {
    ...record,
    stateName: INDIAN_STATES[record.stateCode] || record.stateCode
  };
}
builder.queryFields((t) => ({
  companyTurnovers: t.field({
    type: [CompanyTurnoverObject],
    args: { companyId: t.arg.string({ required: true }) },
    resolve: async (_, { companyId }) => {
      const turnovers = await prisma.companyTurnover.findMany({
        where: { companyId },
        orderBy: { financialYear: "desc" }
      });
      return turnovers;
    }
  }),
  companyStateEmployees: t.field({
    type: [CompanyStateEmployeesObject],
    args: { companyId: t.arg.string({ required: true }) },
    resolve: async (_, { companyId }) => {
      const records = await prisma.companyStateEmployees.findMany({
        where: { companyId },
        orderBy: { stateCode: "asc" }
      });
      return records.map(withStateName5);
    }
  })
}));
builder.mutationFields((t) => ({
  addCompanyTurnover: t.field({
    type: CompanyTurnoverObject,
    args: {
      companyId: t.arg.string({ required: true }),
      financialYear: t.arg.string({ required: true }),
      turnoverAmount: t.arg.float({ required: true }),
      isAudited: t.arg.boolean({ defaultValue: false }),
      isEstimated: t.arg.boolean({ defaultValue: false })
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      if (!/^[0-9]{4}-[0-9]{2}$/.test(args.financialYear)) {
        throw new Error("Invalid FY format. Use: 2024-25");
      }
      const turnover = await prisma.companyTurnover.upsert({
        where: {
          companyId_financialYear: {
            companyId: args.companyId,
            financialYear: args.financialYear
          }
        },
        update: {
          turnoverAmount: args.turnoverAmount,
          isAudited: args.isAudited ?? false,
          isEstimated: args.isEstimated ?? false
        },
        create: {
          companyId: args.companyId,
          financialYear: args.financialYear,
          turnoverAmount: args.turnoverAmount,
          isAudited: args.isAudited ?? false,
          isEstimated: args.isEstimated ?? false
        }
      });
      return turnover;
    }
  }),
  deleteCompanyTurnover: t.field({
    type: "Boolean",
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      await prisma.companyTurnover.delete({ where: { id } });
      return true;
    }
  }),
  updateStateEmployees: t.field({
    type: CompanyStateEmployeesObject,
    args: {
      companyId: t.arg.string({ required: true }),
      stateCode: t.arg.string({ required: true }),
      employeeCount: t.arg.int({ required: true })
    },
    resolve: async (_, args) => {
      const company = await prisma.company.findUnique({ where: { id: args.companyId } });
      if (!company)
        throw new Error("Company not found");
      const stateCode = args.stateCode.toUpperCase();
      if (!INDIAN_STATES[stateCode]) {
        throw new Error(`Invalid state code: ${stateCode}`);
      }
      const asOfDate = /* @__PURE__ */ new Date();
      const record = await prisma.companyStateEmployees.create({
        data: {
          companyId: args.companyId,
          stateCode,
          employeeCount: args.employeeCount,
          asOfDate
        }
      });
      return withStateName5(record);
    }
  })
}));

// apps/api/src/app/graphql/schema.ts
builder.queryFields((t) => ({
  health: t.string({ resolve: () => "OK" }),
  version: t.string({ resolve: () => "0.0.1" }),
  company: t.field({
    type: CompanyObject,
    nullable: true,
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const company = await prisma.company.findUnique({ where: { id } });
      return company;
    }
  }),
  companyByPan: t.field({
    type: CompanyObject,
    nullable: true,
    args: { pan: t.arg.string({ required: true }) },
    resolve: async (_, { pan }) => {
      const company = await prisma.company.findUnique({ where: { pan: pan.toUpperCase() } });
      return company;
    }
  }),
  companies: t.field({
    type: [CompanyObject],
    args: {
      skip: t.arg.int({ defaultValue: 0 }),
      take: t.arg.int({ defaultValue: 20 }),
      status: t.arg.string(),
      search: t.arg.string()
    },
    resolve: async (_, { skip, take, status, search }) => {
      const where = {};
      if (status)
        where.status = status;
      if (search) {
        where.OR = [
          { legalName: { contains: search, mode: "insensitive" } },
          { tradeName: { contains: search, mode: "insensitive" } },
          { pan: { contains: search.toUpperCase() } }
        ];
      }
      const companies = await prisma.company.findMany({
        where,
        skip: skip ?? 0,
        take: Math.min(take ?? 20, 100),
        orderBy: { createdAt: "desc" }
      });
      return companies;
    }
  }),
  companiesCount: t.int({
    args: { status: t.arg.string() },
    resolve: async (_, { status }) => {
      const where = {};
      if (status)
        where.status = status;
      return prisma.company.count({ where });
    }
  })
}));
builder.mutationFields((t) => ({
  createCompany: t.field({
    type: CompanyObject,
    args: {
      legalName: t.arg.string({ required: true }),
      tradeName: t.arg.string(),
      entityType: t.arg.string({ required: true }),
      pan: t.arg.string({ required: true }),
      cin: t.arg.string(),
      llpin: t.arg.string(),
      tan: t.arg.string(),
      dateOfIncorporation: t.arg.string(),
      totalEmployees: t.arg.int({ defaultValue: 0 }),
      isMsme: t.arg.boolean({ defaultValue: false }),
      msmeCategory: t.arg.string(),
      email: t.arg.string(),
      phone: t.arg.string()
    },
    resolve: async (_, args, ctx) => {
      const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
      if (!panRegex.test(args.pan.toUpperCase())) {
        throw new Error("Invalid PAN format");
      }
      const exists = await prisma.company.findUnique({ where: { pan: args.pan.toUpperCase() } });
      if (exists)
        throw new Error("Company with this PAN already exists");
      const company = await prisma.company.create({
        data: {
          legalName: args.legalName,
          tradeName: args.tradeName,
          entityType: args.entityType,
          pan: args.pan.toUpperCase(),
          cin: args.cin?.toUpperCase(),
          llpin: args.llpin?.toUpperCase(),
          tan: args.tan?.toUpperCase(),
          dateOfIncorporation: args.dateOfIncorporation ? new Date(args.dateOfIncorporation) : null,
          totalEmployees: args.totalEmployees ?? 0,
          permanentEmployees: 0,
          contractEmployees: 0,
          isMsme: args.isMsme ?? false,
          msmeCategory: args.msmeCategory,
          email: args.email,
          phone: args.phone,
          status: "ACTIVE",
          createdBy: ctx.user?.id ?? "system"
        }
      });
      return company;
    }
  }),
  updateCompany: t.field({
    type: CompanyObject,
    args: {
      id: t.arg.string({ required: true }),
      legalName: t.arg.string(),
      tradeName: t.arg.string(),
      totalEmployees: t.arg.int(),
      email: t.arg.string(),
      phone: t.arg.string(),
      status: t.arg.string()
    },
    resolve: async (_, { id, ...args }) => {
      const exists = await prisma.company.findUnique({ where: { id } });
      if (!exists)
        throw new Error("Company not found");
      const data = {};
      if (args.legalName !== void 0)
        data.legalName = args.legalName;
      if (args.tradeName !== void 0)
        data.tradeName = args.tradeName;
      if (args.totalEmployees !== void 0)
        data.totalEmployees = args.totalEmployees;
      if (args.email !== void 0)
        data.email = args.email;
      if (args.phone !== void 0)
        data.phone = args.phone;
      if (args.status !== void 0)
        data.status = args.status;
      const company = await prisma.company.update({ where: { id }, data });
      return company;
    }
  }),
  deleteCompany: t.field({
    type: "Boolean",
    args: { id: t.arg.string({ required: true }) },
    resolve: async (_, { id }) => {
      const exists = await prisma.company.findUnique({ where: { id } });
      if (!exists)
        throw new Error("Company not found");
      await prisma.company.delete({ where: { id } });
      return true;
    }
  })
}));
var schema = builder.toSchema();

// apps/api/src/app/graphql/context.ts
async function buildContext(request, reply) {
  const user = process.env.NODE_ENV === "development" ? {
    id: "dev-user-id",
    email: "dev@ankr.in",
    roles: ["admin"]
  } : null;
  return {
    request,
    reply,
    prisma,
    user
  };
}

// apps/api/src/app/graphql/error-handler.ts
var ErrorCodes = {
  VALIDATION_ERROR: "VALIDATION_ERROR",
  NOT_FOUND: "NOT_FOUND",
  DUPLICATE: "DUPLICATE_ENTRY",
  UNAUTHORIZED: "UNAUTHORIZED",
  FORBIDDEN: "FORBIDDEN",
  INTERNAL_ERROR: "INTERNAL_ERROR"
};
function formatError(error) {
  const message = error.message;
  let code = ErrorCodes.INTERNAL_ERROR;
  if (message.includes("not found") || message.includes("Not found")) {
    code = ErrorCodes.NOT_FOUND;
  } else if (message.includes("already exists") || message.includes("already registered")) {
    code = ErrorCodes.DUPLICATE;
  } else if (message.includes("Invalid") || message.includes("Must be")) {
    code = ErrorCodes.VALIDATION_ERROR;
  } else if (message.includes("unauthorized")) {
    code = ErrorCodes.UNAUTHORIZED;
  } else if (message.includes("forbidden")) {
    code = ErrorCodes.FORBIDDEN;
  }
  return { message, code, path: error.path };
}

// apps/api/src/main.ts
var PORT = parseInt(process.env.PORT || "4000");
var HOST = process.env.HOST || "0.0.0.0";
async function bootstrap() {
  const app = (0, import_fastify.default)({ logger: true });
  await app.register(import_cors.default, {
    origin: true,
    credentials: true
  });
  await app.register(import_mercurius.default, {
    schema,
    context: buildContext,
    graphiql: true,
    errorFormatter: (result, _ctx) => {
      const errors = result.errors?.map((err) => ({
        ...formatError(err),
        locations: err.locations
      }));
      return {
        statusCode: 200,
        response: { data: result.data, errors }
      };
    }
  });
  app.get("/health", async () => ({ status: "OK", timestamp: (/* @__PURE__ */ new Date()).toISOString() }));
  app.get("/", async () => ({
    name: "Ankr Compliance API",
    version: "0.0.1",
    graphql: "/graphql"
  }));
  await app.listen({ port: PORT, host: HOST });
  console.log(`
    \u{1F680} Server ready at http://${HOST}:${PORT}
    \u{1F4CA} GraphQL: http://${HOST}:${PORT}/graphql
    Jai GuruJi! \u{1F64F}
  `);
}
bootstrap().catch(console.error);
//# sourceMappingURL=main.js.map
