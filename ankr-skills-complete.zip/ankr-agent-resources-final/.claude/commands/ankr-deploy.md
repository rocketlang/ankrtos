---
name: ankr-deploy
description: "Deploy ANKR modules to staging or production. Usage: /ankr-deploy [module] [environment]"
---

# ANKR Deploy Command

Deploy ANKR Labs modules with proper checks and procedures.

## Usage

```
/ankr-deploy <module> <environment>
```

**Examples:**
- `/ankr-deploy tms staging`
- `/ankr-deploy wms production`
- `/ankr-deploy @ankr/oauth staging`

## Pre-deployment Checklist

Before deploying, verify:

1. **Build passes**
   ```bash
   NX_DAEMON=false npx nx build <module>
   ```

2. **Tests pass**
   ```bash
   npx nx test <module>
   ```

3. **Prisma migrations applied**
   ```bash
   npx prisma migrate deploy --schema=apps/wowtruck/backend/prisma/schema.prisma
   ```

4. **Environment variables set**
   - Check `.env.staging` or `.env.production`
   - Verify all required secrets are in place

## Deployment Steps

### Staging

```bash
# 1. Build
NX_DAEMON=false npx nx build <module>

# 2. Run tests
npx nx test <module>

# 3. Deploy (example with Docker)
docker build -t ankr/<module>:staging .
docker push ankr/<module>:staging

# 4. Update staging
kubectl set image deployment/<module> <module>=ankr/<module>:staging -n staging
```

### Production

```bash
# 1. Create release tag
git tag -a v<version> -m "Release <module> v<version>"
git push origin v<version>

# 2. Build production
NODE_ENV=production NX_DAEMON=false npx nx build <module>

# 3. Run full test suite
npx nx test <module> --coverage

# 4. Deploy with rollback plan
docker build -t ankr/<module>:v<version> .
docker push ankr/<module>:v<version>

# 5. Blue-green deployment
kubectl set image deployment/<module> <module>=ankr/<module>:v<version> -n production
```

## Module-Specific Notes

### @ankr/oauth
- Clear session cache after deploy
- Verify OAuth redirects work

### TMS Backend
- Run database migrations first
- Check WebSocket connections

### WMS
- Verify inventory sync status
- Check warehouse integrations

## Rollback

```bash
# Quick rollback to previous version
kubectl rollout undo deployment/<module> -n <environment>

# Rollback to specific version
kubectl rollout undo deployment/<module> --to-revision=<revision> -n <environment>
```

## Post-deployment

1. Check health endpoints
2. Monitor error rates for 15 minutes
3. Run smoke tests
4. Update deployment log
