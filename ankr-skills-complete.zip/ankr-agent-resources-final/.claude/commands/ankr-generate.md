---
name: ankr-generate
description: "Generate ANKR module boilerplate. Usage: /ankr-generate <type> <name>"
---

# ANKR Generate Command

Scaffold new modules, services, and components following ANKR patterns.

## Usage

```
/ankr-generate <type> <name>
```

## Types

### module
Generate a complete NestJS module with controller, service, DTOs.

```
/ankr-generate module shipment-tracking
```

Creates:
```
modules/shipment-tracking/
├── shipment-tracking.module.ts
├── shipment-tracking.controller.ts
├── shipment-tracking.service.ts
├── shipment-tracking.resolver.ts
└── dto/
    ├── create-shipment-tracking.dto.ts
    └── update-shipment-tracking.dto.ts
```

### service
Generate a standalone service.

```
/ankr-generate service rate-calculator
```

### dto
Generate DTO with Zod validation.

```
/ankr-generate dto carrier-rate
```

### resolver
Generate GraphQL resolver.

```
/ankr-generate resolver route-optimization
```

### package
Generate new @ankr/* package in monorepo.

```
/ankr-generate package notifications
```

Creates:
```
packages/@ankr/notifications/
├── src/
│   └── index.ts
├── package.json
├── tsconfig.json
└── README.md
```

## Templates

### Module Template

```typescript
// [name].module.ts
import { Module } from '@nestjs/common';
import { ${PascalName}Controller } from './${name}.controller';
import { ${PascalName}Service } from './${name}.service';

@Module({
  controllers: [${PascalName}Controller],
  providers: [${PascalName}Service],
  exports: [${PascalName}Service],
})
export class ${PascalName}Module {}
```

### Service Template

```typescript
// [name].service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@ankr/prisma';

@Injectable()
export class ${PascalName}Service {
  constructor(private readonly prisma: PrismaService) {}

  async findAll() {
    return this.prisma.${camelName}.findMany();
  }

  async findOne(id: string) {
    return this.prisma.${camelName}.findUnique({ where: { id } });
  }

  async create(dto: Create${PascalName}Dto) {
    return this.prisma.${camelName}.create({ data: dto });
  }

  async update(id: string, dto: Update${PascalName}Dto) {
    return this.prisma.${camelName}.update({
      where: { id },
      data: dto,
    });
  }

  async remove(id: string) {
    return this.prisma.${camelName}.delete({ where: { id } });
  }
}
```

### DTO Template

```typescript
// create-[name].dto.ts
import { z } from 'zod';
import { createZodDto } from 'nestjs-zod';

export const Create${PascalName}Schema = z.object({
  // Add fields here
  name: z.string().min(1),
});

export class Create${PascalName}Dto extends createZodDto(Create${PascalName}Schema) {}
```

## Options

- `--dry-run`: Preview files without creating
- `--skip-tests`: Don't generate test files
- `--graphql`: Include GraphQL resolver
- `--rest-only`: Skip GraphQL, REST only
