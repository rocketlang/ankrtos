---
name: ankr-eon-memory
description: "Self-evolving memory system for ANKR agents. Use when: (1) Implementing episodic/semantic/procedural memory, (2) Working with pgvector embeddings, (3) Building memory consolidation pipelines, (4) Cross-module learning patterns"
---

# ANKR-EON Memory System Skill

## Overview

ankr-eon is ANKR's self-evolving AI memory system. It provides episodic, semantic, and procedural memory layers that learn and improve automatically.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        ANKR-EON                                 │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │  Episodic   │  │  Semantic   │  │ Procedural  │             │
│  │   Memory    │→→│   Memory    │→→│   Memory    │             │
│  │ (Episodes)  │  │ (Patterns)  │  │  (Skills)   │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│         ↓                ↓                ↓                     │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │            PostgreSQL + pgvector                         │   │
│  │  Schema: ankr_eon.*                                      │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Database Schema

```sql
-- Create dedicated schema (isolated from public)
CREATE SCHEMA IF NOT EXISTS ankr_eon;

-- Enable pgvector
CREATE EXTENSION IF NOT EXISTS vector;

-- Episodic Memory: State → Action → Outcome
CREATE TABLE ankr_eon.episodes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module VARCHAR(50) NOT NULL,           -- 'tms', 'wms', 'oms'
  session_id UUID NOT NULL,
  
  -- State before action
  state_context JSONB NOT NULL,
  state_embedding vector(1536),
  
  -- Action taken
  action_type VARCHAR(100) NOT NULL,
  action_params JSONB,
  
  -- Outcome
  outcome_success BOOLEAN NOT NULL,
  outcome_data JSONB,
  outcome_feedback REAL,                 -- -1 to 1
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  tags TEXT[]
);

-- Index for similarity search
CREATE INDEX ON ankr_eon.episodes 
  USING ivfflat (state_embedding vector_cosine_ops)
  WITH (lists = 100);

-- Semantic Memory: Learned patterns
CREATE TABLE ankr_eon.semantic_patterns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module VARCHAR(50) NOT NULL,
  
  -- Pattern definition
  pattern_name VARCHAR(200) NOT NULL,
  pattern_description TEXT NOT NULL,
  pattern_embedding vector(1536),
  
  -- Learning stats
  episode_count INTEGER DEFAULT 1,
  success_rate REAL DEFAULT 0.5,
  confidence REAL DEFAULT 0.5,
  
  -- Lifecycle
  status VARCHAR(20) DEFAULT 'active',   -- active, archived, superseded
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_used_at TIMESTAMPTZ DEFAULT NOW(),
  last_validated_at TIMESTAMPTZ
);

-- Procedural Memory: Skills and workflows
CREATE TABLE ankr_eon.procedures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module VARCHAR(50) NOT NULL,
  
  -- Procedure definition
  name VARCHAR(200) NOT NULL,
  description TEXT,
  steps JSONB NOT NULL,                  -- Ordered steps
  
  -- Parameters learned
  default_params JSONB,
  optimized_params JSONB,
  
  -- Performance
  avg_execution_time_ms INTEGER,
  success_rate REAL DEFAULT 0.5,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Cross-module insights
CREATE TABLE ankr_eon.cross_module_insights (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  source_module VARCHAR(50) NOT NULL,
  target_module VARCHAR(50) NOT NULL,
  
  insight_type VARCHAR(100) NOT NULL,
  insight_description TEXT NOT NULL,
  
  correlation_strength REAL,             -- 0 to 1
  episode_ids UUID[],                    -- Source episodes
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  validated BOOLEAN DEFAULT FALSE
);
```

## TypeScript Interface

```typescript
// packages/@ankr/eon/src/types.ts

export interface Episode {
  id: string;
  module: 'tms' | 'wms' | 'oms';
  sessionId: string;
  
  stateContext: Record<string, unknown>;
  stateEmbedding?: number[];
  
  actionType: string;
  actionParams?: Record<string, unknown>;
  
  outcomeSuccess: boolean;
  outcomeData?: Record<string, unknown>;
  outcomeFeedback?: number;
  
  createdAt: Date;
  tags?: string[];
}

export interface SemanticPattern {
  id: string;
  module: string;
  patternName: string;
  patternDescription: string;
  patternEmbedding?: number[];
  episodeCount: number;
  successRate: number;
  confidence: number;
  status: 'active' | 'archived' | 'superseded';
}

export interface MemoryQuery {
  module?: string;
  query: string;
  limit?: number;
  minConfidence?: number;
  includeArchived?: boolean;
}
```

## Core Operations

### 1. Recording Episodes

```typescript
import { EonService } from '@ankr/eon';

class ShipmentService {
  constructor(private eon: EonService) {}

  async createShipment(dto: CreateShipmentDto, userId: string) {
    // Capture state before action
    const state = {
      origin: dto.origin,
      destination: dto.destination,
      vehicleType: dto.vehicleType,
      time: new Date().toISOString(),
      userId,
    };

    try {
      const result = await this.prisma.shipment.create({ data: dto });
      
      // Record successful episode
      await this.eon.recordEpisode({
        module: 'tms',
        stateContext: state,
        actionType: 'create_shipment',
        actionParams: dto,
        outcomeSuccess: true,
        outcomeData: { shipmentId: result.id },
        outcomeFeedback: 1.0,
      });

      return result;
    } catch (error) {
      // Record failed episode
      await this.eon.recordEpisode({
        module: 'tms',
        stateContext: state,
        actionType: 'create_shipment',
        actionParams: dto,
        outcomeSuccess: false,
        outcomeData: { error: error.message },
        outcomeFeedback: -1.0,
      });
      
      throw error;
    }
  }
}
```

### 2. Querying Similar Situations

```typescript
// Find similar past situations
const similar = await eon.findSimilarEpisodes({
  module: 'tms',
  stateContext: currentState,
  limit: 5,
  minSimilarity: 0.8,
});

// Get success patterns
const patterns = await eon.getPatterns({
  module: 'tms',
  actionType: 'route_optimization',
  minSuccessRate: 0.7,
});
```

### 3. Memory Consolidation (Automatic)

```typescript
// Runs nightly via cron job
class MemoryConsolidationJob {
  async run() {
    // 1. Deduplicate episodes (>95% similarity)
    await this.deduplicateEpisodes();
    
    // 2. Extract patterns from clusters
    await this.extractPatterns();
    
    // 3. Decay unused patterns
    await this.decayPatterns();
    
    // 4. Find cross-module insights
    await this.findCrossModuleInsights();
  }

  private async extractPatterns() {
    // Cluster similar episodes
    const clusters = await this.prisma.$queryRaw`
      SELECT 
        action_type,
        array_agg(id) as episode_ids,
        avg(outcome_feedback) as avg_feedback,
        count(*) as count
      FROM ankr_eon.episodes
      WHERE created_at > NOW() - INTERVAL '7 days'
      GROUP BY action_type, 
        (state_embedding <-> (
          SELECT avg(state_embedding) 
          FROM ankr_eon.episodes e2 
          WHERE e2.action_type = episodes.action_type
        )) < 0.2
      HAVING count(*) >= 5
    `;

    // Generate patterns via LLM
    for (const cluster of clusters) {
      if (cluster.avg_feedback > 0.7) {
        const pattern = await this.generatePattern(cluster);
        await this.savePattern(pattern);
      }
    }
  }
}
```

## Embedding Providers (Cost Cascade)

```typescript
// Multi-provider embedding with fallback
class EmbeddingService {
  private providers = [
    { name: 'local', model: 'all-MiniLM-L6-v2', cost: 0 },
    { name: 'jina', model: 'jina-embeddings-v2', cost: 0.0001 },
    { name: 'voyage', model: 'voyage-2', cost: 0.0002 },
    { name: 'openai', model: 'text-embedding-3-small', cost: 0.0004 },
  ];

  async embed(text: string): Promise<number[]> {
    for (const provider of this.providers) {
      try {
        return await this.callProvider(provider, text);
      } catch (e) {
        console.warn(`${provider.name} failed, trying next...`);
      }
    }
    throw new Error('All embedding providers failed');
  }
}
```

## Cross-Module Learning

```typescript
// TMS learns from WMS patterns
const insight = await eon.findCrossModuleInsight({
  sourceModule: 'wms',
  targetModule: 'tms',
  pattern: 'delhi_warehouse_delays',
});

// Returns:
// {
//   insight: "Delhi warehouse capacity issues affect route planning",
//   correlationStrength: 0.85,
//   recommendation: "Add 2-hour buffer for Delhi pickups"
// }
```

## Best Practices

1. **Always capture state BEFORE action** - Enables causal learning
2. **Use specific action types** - `create_shipment` not `create`
3. **Include user context** - Personalizes learning
4. **Tag episodes** - Enables filtered queries
5. **Set outcome feedback** - Drives pattern quality

## Integration Points

- **ankr-tms**: Shipment, route, carrier decisions
- **ankr-wms**: Inventory, warehouse, fulfillment patterns
- **ankr-oms**: Order, customer, pricing patterns
- **SUNOKAHOBOLO**: Voice command patterns per language
