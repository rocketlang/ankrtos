---
name: ankr-logistics-rag
description: "RAG system for logistics data retrieval. Use when: (1) Querying shipment/route/carrier data, (2) Building semantic search over logistics docs, (3) Implementing hybrid search (vector + keyword), (4) Answering logistics questions with context"
---

# ANKR Logistics RAG Skill

## Overview

This skill implements Retrieval-Augmented Generation (RAG) for ANKR's logistics domain, combining pgvector semantic search with domain-specific knowledge.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      ANKR RAG Pipeline                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Query: "Shipments delayed in Mumbai last week"                  │
│           ↓                                                      │
│  ┌─────────────────┐                                            │
│  │  Query Parser   │ → Extract: location=Mumbai, time=last_week │
│  └────────┬────────┘                                            │
│           ↓                                                      │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │  Vector Search  │ +  │ Keyword Search  │  = Hybrid          │
│  │   (pgvector)    │    │ (PostgreSQL FTS)│                    │
│  └────────┬────────┘    └────────┬────────┘                    │
│           └──────────┬───────────┘                              │
│                      ↓                                          │
│  ┌─────────────────────────────────────────┐                   │
│  │           Reranker (Optional)            │                   │
│  │    Cross-encoder for precision           │                   │
│  └────────────────────┬────────────────────┘                   │
│                       ↓                                         │
│  ┌─────────────────────────────────────────┐                   │
│  │              LLM (via LLMBox)            │                   │
│  │   Generate answer with retrieved context │                   │
│  └────────────────────┬────────────────────┘                   │
│                       ↓                                         │
│  Answer: "Found 12 delayed shipments in Mumbai..."              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Database Schema

```sql
-- Documents table for RAG
CREATE TABLE ankr_rag.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Source info
  source_type VARCHAR(50) NOT NULL,    -- 'shipment', 'policy', 'sop', 'faq'
  source_id VARCHAR(100),
  
  -- Content
  title VARCHAR(500),
  content TEXT NOT NULL,
  content_embedding vector(1536),
  
  -- Metadata
  metadata JSONB DEFAULT '{}',
  
  -- Chunking
  chunk_index INTEGER DEFAULT 0,
  parent_id UUID,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX ON ankr_rag.documents 
  USING ivfflat (content_embedding vector_cosine_ops)
  WITH (lists = 100);

CREATE INDEX ON ankr_rag.documents 
  USING gin (to_tsvector('english', content));

CREATE INDEX ON ankr_rag.documents (source_type);
CREATE INDEX ON ankr_rag.documents USING gin (metadata);
```

## TypeScript Interfaces

```typescript
interface Document {
  id: string;
  sourceType: 'shipment' | 'policy' | 'sop' | 'faq' | 'carrier';
  sourceId?: string;
  title?: string;
  content: string;
  contentEmbedding?: number[];
  metadata: Record<string, unknown>;
  chunkIndex: number;
  parentId?: string;
}

interface RAGQuery {
  query: string;
  filters?: {
    sourceType?: string[];
    dateRange?: { start: Date; end: Date };
    metadata?: Record<string, unknown>;
  };
  limit?: number;
  hybridWeight?: number;  // 0 = pure vector, 1 = pure keyword
  rerank?: boolean;
}

interface RAGResponse {
  answer: string;
  sources: Document[];
  confidence: number;
  queryTime: number;
}
```

## Implementation

### 1. Document Ingestion

```typescript
class RAGIngestion {
  constructor(
    private prisma: PrismaService,
    private embedder: EmbeddingService,
  ) {}

  async ingestShipment(shipment: Shipment): Promise<void> {
    // Convert shipment to text
    const content = this.shipmentToText(shipment);
    
    // Generate embedding
    const embedding = await this.embedder.embed(content);
    
    // Store
    await this.prisma.$executeRaw`
      INSERT INTO ankr_rag.documents 
        (source_type, source_id, title, content, content_embedding, metadata)
      VALUES (
        'shipment',
        ${shipment.id},
        ${`Shipment ${shipment.trackingNumber}`},
        ${content},
        ${embedding}::vector,
        ${JSON.stringify({
          origin: shipment.origin,
          destination: shipment.destination,
          status: shipment.status,
          carrier: shipment.carrier,
        })}
      )
    `;
  }

  private shipmentToText(s: Shipment): string {
    return `
      Shipment ${s.trackingNumber} from ${s.origin} to ${s.destination}.
      Carrier: ${s.carrier}. Vehicle: ${s.vehicleType}.
      Status: ${s.status}. Weight: ${s.weight}kg.
      Scheduled: ${s.scheduledDate}. 
      ${s.notes ? `Notes: ${s.notes}` : ''}
    `.trim();
  }
}
```

### 2. Hybrid Search

```typescript
class RAGSearch {
  async hybridSearch(query: RAGQuery): Promise<Document[]> {
    const queryEmbedding = await this.embedder.embed(query.query);
    const weight = query.hybridWeight ?? 0.5;

    // Hybrid search: combine vector and keyword
    const results = await this.prisma.$queryRaw<Document[]>`
      WITH vector_search AS (
        SELECT 
          id,
          1 - (content_embedding <=> ${queryEmbedding}::vector) as vector_score
        FROM ankr_rag.documents
        WHERE source_type = ANY(${query.filters?.sourceType || ['shipment', 'policy', 'sop']})
        ORDER BY content_embedding <=> ${queryEmbedding}::vector
        LIMIT 20
      ),
      keyword_search AS (
        SELECT 
          id,
          ts_rank(to_tsvector('english', content), plainto_tsquery('english', ${query.query})) as keyword_score
        FROM ankr_rag.documents
        WHERE to_tsvector('english', content) @@ plainto_tsquery('english', ${query.query})
        LIMIT 20
      )
      SELECT 
        d.*,
        COALESCE(v.vector_score, 0) * ${1 - weight} + 
        COALESCE(k.keyword_score, 0) * ${weight} as combined_score
      FROM ankr_rag.documents d
      LEFT JOIN vector_search v ON d.id = v.id
      LEFT JOIN keyword_search k ON d.id = k.id
      WHERE v.id IS NOT NULL OR k.id IS NOT NULL
      ORDER BY combined_score DESC
      LIMIT ${query.limit || 5}
    `;

    return results;
  }
}
```

### 3. Query with RAG

```typescript
class RAGService {
  constructor(
    private search: RAGSearch,
    private llmbox: LLMBox,
  ) {}

  async query(query: RAGQuery): Promise<RAGResponse> {
    const startTime = Date.now();

    // 1. Retrieve relevant documents
    const docs = await this.search.hybridSearch(query);

    // 2. Build context
    const context = docs.map(d => 
      `[${d.sourceType.toUpperCase()}] ${d.title}\n${d.content}`
    ).join('\n\n---\n\n');

    // 3. Generate answer
    const response = await this.llmbox.chat({
      messages: [
        {
          role: 'system',
          content: `You are a logistics assistant for ANKR TMS. 
Answer questions based on the provided context.
Always cite your sources using [SOURCE_TYPE: ID] format.
If the answer isn't in the context, say so.`
        },
        {
          role: 'user',
          content: `Context:\n${context}\n\nQuestion: ${query.query}`
        }
      ],
      maxCost: 0.01,
      preferFreeTier: true,
    });

    return {
      answer: response.content,
      sources: docs,
      confidence: this.calculateConfidence(docs),
      queryTime: Date.now() - startTime,
    };
  }

  private calculateConfidence(docs: Document[]): number {
    if (docs.length === 0) return 0;
    // Average of top-k similarity scores
    const avgScore = docs.reduce((sum, d) => sum + (d.combinedScore || 0), 0) / docs.length;
    return Math.min(avgScore * 100, 100);
  }
}
```

### 4. Specialized Logistics Queries

```typescript
class LogisticsRAG {
  // Shipment tracking
  async trackShipment(trackingNumber: string): Promise<RAGResponse> {
    return this.rag.query({
      query: `Current status of shipment ${trackingNumber}`,
      filters: {
        sourceType: ['shipment'],
        metadata: { trackingNumber },
      },
    });
  }

  // Route suggestions
  async suggestRoute(origin: string, dest: string): Promise<RAGResponse> {
    return this.rag.query({
      query: `Best route from ${origin} to ${dest} based on past shipments`,
      filters: {
        sourceType: ['shipment', 'sop'],
        metadata: { 
          $or: [
            { origin: { $contains: origin } },
            { destination: { $contains: dest } },
          ]
        },
      },
    });
  }

  // Policy lookup
  async findPolicy(topic: string): Promise<RAGResponse> {
    return this.rag.query({
      query: topic,
      filters: { sourceType: ['policy', 'sop', 'faq'] },
      hybridWeight: 0.7,  // More keyword for policies
    });
  }

  // Carrier performance
  async carrierAnalysis(carrierName: string): Promise<RAGResponse> {
    return this.rag.query({
      query: `Performance and issues with carrier ${carrierName}`,
      filters: {
        sourceType: ['shipment'],
        metadata: { carrier: carrierName },
      },
    });
  }
}
```

## Chunking Strategies

```typescript
class DocumentChunker {
  // For long documents (SOPs, policies)
  chunkDocument(content: string, options: ChunkOptions): string[] {
    const { maxChunkSize = 500, overlap = 50 } = options;
    
    // Split by paragraphs first
    const paragraphs = content.split(/\n\n+/);
    const chunks: string[] = [];
    let currentChunk = '';

    for (const para of paragraphs) {
      if ((currentChunk + para).length > maxChunkSize) {
        if (currentChunk) {
          chunks.push(currentChunk.trim());
        }
        currentChunk = para;
      } else {
        currentChunk += '\n\n' + para;
      }
    }

    if (currentChunk) {
      chunks.push(currentChunk.trim());
    }

    return chunks;
  }

  // For structured data (shipments)
  chunkShipment(shipment: Shipment): string[] {
    // Single chunk per shipment - already structured
    return [this.shipmentToText(shipment)];
  }
}
```

## Voice Integration

```typescript
// Voice query → RAG → Voice response
class VoiceRAG {
  async handleVoiceQuery(audio: Buffer, language: string): Promise<Buffer> {
    // 1. Transcribe
    const text = await this.stt.transcribe(audio, language);
    
    // 2. RAG query
    const response = await this.rag.query({ query: text });
    
    // 3. Translate response if needed
    const localizedAnswer = language !== 'en' 
      ? await this.translate(response.answer, language)
      : response.answer;
    
    // 4. Text to speech
    return this.tts.synthesize(localizedAnswer, language);
  }
}

// Example: Driver asks in Hindi
// "मुंबई में कितने शिपमेंट अटके हैं?"
// → RAG finds delayed Mumbai shipments
// → Answers in Hindi with count and details
```

## Best Practices

1. **Index frequently queried fields** - sourceType, status, dates
2. **Chunk long documents** - 500 tokens max per chunk
3. **Use metadata filters** - Reduce search space before vector search
4. **Cache common queries** - Reduce LLM calls
5. **Monitor retrieval quality** - Track if answers match retrieved docs

## Integration with ankr-eon

```typescript
// RAG learns from successful retrievals
class RAGWithMemory {
  async query(query: RAGQuery): Promise<RAGResponse> {
    const response = await this.rag.query(query);
    
    // Record episode in ankr-eon
    await this.eon.recordEpisode({
      module: 'rag',
      stateContext: { query: query.query, filters: query.filters },
      actionType: 'rag_query',
      outcomeSuccess: response.confidence > 0.7,
      outcomeData: {
        answerLength: response.answer.length,
        sourcesCount: response.sources.length,
        confidence: response.confidence,
      },
    });

    return response;
  }
}
```
