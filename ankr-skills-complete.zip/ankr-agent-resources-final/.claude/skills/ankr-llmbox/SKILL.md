---
name: ankr-llmbox
description: "Multi-provider LLM router with free-tier priority. Use when: (1) Making LLM calls with cost optimization, (2) Routing by language (Hindi → LongCat), (3) Implementing fallback cascades, (4) Tracking API costs"
---

# ANKR LLMBox Skill

## Overview

LLMBox is ANKR's universal LLM router that democratizes AI access by prioritizing free-tier providers while maintaining quality through intelligent fallback.

## Provider Priority (Free First)

| Priority | Provider | Free Tier | Speed | Best For |
|----------|----------|-----------|-------|----------|
| 1 | Groq | ✅ Generous | ⚡ Ultra | English, fast inference |
| 2 | Ollama | ✅ Local | ⚡ Fast | Offline, privacy |
| 3 | LongCat | ✅ Yes | 🚀 Fast | Hindi, Tamil, Telugu |
| 4 | DeepSeek | ✅ Limited | 🚀 Fast | Coding, reasoning |
| 5 | ZhipuAI | ✅ Limited | 🚀 Fast | Chinese |
| 6 | OpenRouter | 💳 Paid | ⚡ Fast | Multi-model access |

## Configuration

```bash
# .env
DEFAULT_PROVIDER=groq
FALLBACK_PROVIDERS=groq,ollama,longcat,deepseek,openrouter
PREFER_FREE_TIER=true
MAX_COST_PER_REQUEST=0.01

# Language routing
LLMBOX_LANG_MODE=auto
LLMBOX_PROVIDER_HI=longcat
LLMBOX_PROVIDER_TA=longcat
LLMBOX_PROVIDER_TE=longcat
LLMBOX_PROVIDER_EN=groq

# API Keys
GROQ_API_KEY=gsk_xxx
LONGCAT_API_KEY=ak_xxx
DEEPSEEK_API_KEY=sk-xxx
OLLAMA_BASE_URL=http://127.0.0.1:11434
```

## TypeScript Interface

```typescript
interface LLMBoxConfig {
  defaultProvider: string;
  fallbackProviders: string[];
  preferFreeTier: boolean;
  maxCostPerRequest: number;
  timeout: number;
  enableCaching: boolean;
}

interface ChatRequest {
  messages: Message[];
  provider?: string;           // Force specific provider
  model?: string;
  temperature?: number;
  maxTokens?: number;
  language?: string;           // For auto-routing
  maxCost?: number;
  stream?: boolean;
}

interface ChatResponse {
  content: string;
  role: 'assistant';
  provider: string;
  model: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  cost: number;
  cached: boolean;
  latencyMs: number;
}
```

## Usage Patterns

### 1. Basic Chat (Auto-routing)

```typescript
import { LLMBox } from '@ankr/llmbox';

// Auto-detects language and routes to best free provider
const response = await LLMBox.chat({
  messages: [
    { role: 'user', content: 'नमस्ते, मुझे AI के बारे में बताओ' }
  ],
});
// Routes to: LongCat (Free, Hindi-optimized)

const response2 = await LLMBox.chat({
  messages: [
    { role: 'user', content: 'Hello, tell me about AI' }
  ],
});
// Routes to: Groq (Free, Fast)
```

### 2. Force Provider

```typescript
const response = await LLMBox.chat({
  messages: [{ role: 'user', content: 'Explain quantum computing' }],
  provider: 'deepseek',  // Force DeepSeek
  maxTokens: 2048,
});
```

### 3. Cost-Controlled Request

```typescript
const response = await LLMBox.chat({
  messages: [{ role: 'user', content: 'Write a poem' }],
  maxCost: 0.001,  // Max $0.001 for this request
  preferFreeTier: true,
});

if (response.cost > 0) {
  console.log(`Cost: $${response.cost.toFixed(6)}`);
}
```

### 4. Conversation with Cost Tracking

```typescript
const conversation = LLMBox.conversation();

await conversation.add('What is machine learning?');
await conversation.add('Give me an example');
await conversation.add('How is it used in logistics?');

console.log(`Total cost: $${conversation.totalCost}`);
console.log(`Total tokens: ${conversation.totalTokens}`);
// Typical: $0.00 (all on free tier!)
```

### 5. Streaming Response

```typescript
const stream = await LLMBox.chat({
  messages: [{ role: 'user', content: 'Write a long story' }],
  stream: true,
});

for await (const chunk of stream) {
  process.stdout.write(chunk.content);
}
```

## Provider Implementation

```typescript
// packages/@ankr/llmbox/src/providers/groq.ts

export class GroqProvider implements LLMProvider {
  name = 'groq';
  baseUrl = 'https://api.groq.com/openai/v1';
  freeQuota = { requestsPerMinute: 30, tokensPerDay: 500000 };
  
  async chat(request: ChatRequest): Promise<ChatResponse> {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: request.model || 'llama-3.3-70b-versatile',
        messages: request.messages,
        temperature: request.temperature || 0.7,
        max_tokens: request.maxTokens || 2048,
        stream: request.stream,
      }),
    });
    
    const data = await response.json();
    
    return {
      content: data.choices[0].message.content,
      role: 'assistant',
      provider: 'groq',
      model: data.model,
      usage: {
        promptTokens: data.usage.prompt_tokens,
        completionTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens,
      },
      cost: 0,  // Free tier
      cached: false,
      latencyMs: Date.now() - startTime,
    };
  }
}
```

## Language Detection & Routing

```typescript
class LanguageRouter {
  private languageProviders = {
    hi: 'longcat',   // Hindi
    ta: 'longcat',   // Tamil
    te: 'longcat',   // Telugu
    bn: 'longcat',   // Bengali
    en: 'groq',      // English
    zh: 'zhipuai',   // Chinese
  };

  async route(text: string): Promise<string> {
    const lang = await this.detectLanguage(text);
    return this.languageProviders[lang] || 'groq';
  }

  private async detectLanguage(text: string): Promise<string> {
    // Fast detection using character ranges
    if (/[\u0900-\u097F]/.test(text)) return 'hi';  // Devanagari
    if (/[\u0B80-\u0BFF]/.test(text)) return 'ta';  // Tamil
    if (/[\u0C00-\u0C7F]/.test(text)) return 'te';  // Telugu
    if (/[\u0980-\u09FF]/.test(text)) return 'bn';  // Bengali
    if (/[\u4E00-\u9FFF]/.test(text)) return 'zh';  // Chinese
    return 'en';
  }
}
```

## Caching Layer

```typescript
class LLMCache {
  constructor(private redis: Redis) {}

  async get(request: ChatRequest): Promise<ChatResponse | null> {
    const key = this.getCacheKey(request);
    const cached = await this.redis.get(key);
    
    if (cached) {
      const response = JSON.parse(cached);
      response.cached = true;
      return response;
    }
    
    return null;
  }

  async set(request: ChatRequest, response: ChatResponse): Promise<void> {
    const key = this.getCacheKey(request);
    await this.redis.setex(key, 3600, JSON.stringify(response));
  }

  private getCacheKey(request: ChatRequest): string {
    const hash = crypto.createHash('md5')
      .update(JSON.stringify(request.messages))
      .digest('hex');
    return `llmbox:${hash}`;
  }
}
```

## Cost Tracking

```typescript
const COST_PER_1M_TOKENS = {
  'groq': { input: 0, output: 0 },           // Free
  'ollama': { input: 0, output: 0 },         // Local
  'longcat': { input: 0, output: 0 },        // Free
  'deepseek': { input: 0.14, output: 0.28 }, // Very cheap
  'openai': { input: 3, output: 15 },        // Expensive
};

class CostTracker {
  private dailyCost = 0;
  private maxDailyCost = 1.0;  // $1/day limit

  async checkBudget(estimatedCost: number): Promise<boolean> {
    return (this.dailyCost + estimatedCost) <= this.maxDailyCost;
  }

  async recordCost(cost: number): Promise<void> {
    this.dailyCost += cost;
    await this.persistCost(cost);
  }
}
```

## Fallback Strategy

```typescript
class FallbackHandler {
  private providers = ['groq', 'ollama', 'longcat', 'deepseek'];

  async executeWithFallback(request: ChatRequest): Promise<ChatResponse> {
    for (const provider of this.providers) {
      try {
        return await this.callProvider(provider, request);
      } catch (error) {
        console.warn(`${provider} failed: ${error.message}`);
        
        // Check if we should continue
        if (this.isRateLimitError(error)) {
          continue;  // Try next provider
        }
        if (this.isAuthError(error)) {
          continue;  // Skip misconfigured provider
        }
        throw error;  // Don't catch other errors
      }
    }
    
    throw new Error('All LLM providers failed');
  }
}
```

## Best Practices

1. **Always set maxCost** - Prevents runaway spending
2. **Use caching for repeated queries** - Huge cost savings
3. **Prefer streaming for long responses** - Better UX
4. **Track costs daily** - Set alerts at thresholds
5. **Test with Ollama first** - Free local testing

## Integration with ANKR Stack

```typescript
// In TMS service
class ShipmentOptimizer {
  constructor(private llmbox: LLMBox) {}

  async suggestRoute(origin: string, dest: string): Promise<string> {
    const response = await this.llmbox.chat({
      messages: [
        { role: 'system', content: 'You are a logistics route optimizer.' },
        { role: 'user', content: `Suggest optimal route: ${origin} → ${dest}` },
      ],
      maxCost: 0.001,
      preferFreeTier: true,
    });
    
    return response.content;
  }
}
```
