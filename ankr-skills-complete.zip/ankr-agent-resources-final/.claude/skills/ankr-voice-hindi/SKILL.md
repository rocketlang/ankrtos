---
name: ankr-voice-hindi
description: "Multilingual voice AI skill for SUNOKAHOBOLO. Use when: (1) Building voice interfaces in Hindi, Tamil, Telugu, (2) Voice-to-action for truck drivers, (3) Speech-to-text/text-to-speech integration, (4) Voice-first logistics workflows"
---

# ANKR Voice Hindi Skill (SUNOKAHOBOLO)

## Overview

SUNOKAHOBOLO is ANKR's multilingual voice AI gateway. It enables voice-first interfaces for logistics workers who prefer native languages over English.

## Supported Languages

| Language | Code | STT | TTS | LLM Routing |
|----------|------|-----|-----|-------------|
| Hindi | hi | ✅ | ✅ | LongCat |
| Tamil | ta | ✅ | ✅ | LongCat |
| Telugu | te | ✅ | ✅ | LongCat |
| Bengali | bn | ✅ | ✅ | LongCat |
| English | en | ✅ | ✅ | Groq |
| Marathi | mr | ✅ | ✅ | LongCat |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     SUNOKAHOBOLO Gateway                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Audio Input                                                     │
│       ↓                                                          │
│  ┌─────────────┐                                                │
│  │     STT     │  Whisper / Google STT / Azure                  │
│  │  (100+ lang)│                                                │
│  └──────┬──────┘                                                │
│         ↓                                                        │
│  ┌─────────────┐                                                │
│  │  Language   │  Auto-detect + dialect identification          │
│  │  Detection  │                                                │
│  └──────┬──────┘                                                │
│         ↓                                                        │
│  ┌─────────────┐                                                │
│  │   LLMBox    │  Route to best provider per language           │
│  │   Router    │  Hindi → LongCat, English → Groq               │
│  └──────┬──────┘                                                │
│         ↓                                                        │
│  ┌─────────────┐                                                │
│  │    TTS      │  Chatterbox / ElevenLabs / Piper               │
│  │   Output    │                                                │
│  └─────────────┘                                                │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Voice Request Interface

```typescript
interface VoiceRequest {
  // Audio input
  audio: Buffer | ReadableStream;
  audioFormat: 'wav' | 'mp3' | 'webm' | 'ogg';
  sampleRate?: number;
  
  // Context
  userId: string;
  sessionId: string;
  module: 'tms' | 'wms' | 'oms' | 'care';
  
  // Preferences
  preferredLanguage?: string;
  responseFormat?: 'text' | 'audio' | 'both';
  voiceId?: string;  // For TTS voice cloning
}

interface VoiceResponse {
  // Transcription
  originalText: string;        // In detected language
  detectedLanguage: string;
  confidence: number;
  dialect?: string;            // Chennai Tamil vs Madurai Tamil
  
  // Translation (if needed)
  translatedText?: string;     // English version
  
  // LLM Response
  responseText: string;        // In user's language
  responseEnglish?: string;    // English version
  
  // Audio output
  audioBuffer?: Buffer;
  audioDuration?: number;
  
  // Metadata
  processingTime: number;
  providers: {
    stt: string;
    llm: string;
    tts: string;
  };
}
```

## Implementation Patterns

### 1. Basic Voice Handler

```typescript
import { SunokahaboloGateway } from '@ankr/voice';

@Controller('voice')
export class VoiceController {
  constructor(
    private voice: SunokahaboloGateway,
    private tms: TmsService,
  ) {}

  @Post('command')
  async handleVoice(@Body() req: VoiceRequest): Promise<VoiceResponse> {
    // Process voice → text
    const transcription = await this.voice.transcribe(req.audio, {
      format: req.audioFormat,
      language: req.preferredLanguage,
    });

    // Route to appropriate handler based on intent
    const intent = await this.voice.classifyIntent(transcription.text);
    
    let response: string;
    switch (intent.action) {
      case 'check_shipment':
        const shipment = await this.tms.getShipment(intent.params.id);
        response = this.formatShipmentResponse(shipment, transcription.language);
        break;
        
      case 'get_route':
        const route = await this.tms.getOptimalRoute(intent.params);
        response = this.formatRouteResponse(route, transcription.language);
        break;
        
      default:
        response = this.getDefaultResponse(transcription.language);
    }

    // Convert response to audio
    const audio = await this.voice.synthesize(response, {
      language: transcription.language,
      voiceId: req.voiceId,
    });

    return {
      originalText: transcription.text,
      detectedLanguage: transcription.language,
      confidence: transcription.confidence,
      responseText: response,
      audioBuffer: audio.buffer,
      audioDuration: audio.duration,
      processingTime: Date.now() - startTime,
      providers: {
        stt: transcription.provider,
        llm: 'llmbox',
        tts: audio.provider,
      },
    };
  }
}
```

### 2. Driver Voice Commands (Hindi)

```typescript
// Voice commands for truck drivers

const DRIVER_COMMANDS = {
  // Route queries
  'आज का रूट': 'get_today_route',
  'अगला स्टॉप': 'get_next_stop',
  'कितनी दूर है': 'get_distance',
  
  // Status updates
  'पहुंच गया': 'mark_arrived',
  'निकल रहा हूं': 'mark_departed',
  'देरी हो रही है': 'report_delay',
  
  // Emergency
  'मदद चाहिए': 'request_help',
  'गाड़ी खराब': 'report_breakdown',
  'एक्सीडेंट': 'report_accident',
};

class DriverVoiceHandler {
  async handleHindiCommand(text: string, driverId: string) {
    // Fuzzy match against known commands
    const command = this.matchCommand(text, DRIVER_COMMANDS);
    
    switch (command) {
      case 'get_today_route':
        const route = await this.getDriverRoute(driverId);
        return this.formatHindi(`
          आज का रूट: ${route.origin} से ${route.destination}
          कुल दूरी: ${route.distanceKm} किलोमीटर
          अनुमानित समय: ${route.estimatedHours} घंटे
        `);
        
      case 'mark_arrived':
        await this.updateDeliveryStatus(driverId, 'ARRIVED');
        return 'ठीक है, आपकी पहुंच दर्ज हो गई।';
        
      case 'report_delay':
        await this.createDelayAlert(driverId);
        return 'देरी की सूचना भेज दी गई है। कृपया अनुमानित समय बताएं।';
        
      case 'report_accident':
        await this.triggerEmergencySOS(driverId);
        return 'आपातकालीन सहायता भेजी जा रही है। कृपया सुरक्षित रहें।';
    }
  }
}
```

### 3. Tamil Warehouse Commands

```typescript
const WAREHOUSE_COMMANDS_TAMIL = {
  // Inventory
  'ஸ்டாக் எவ்வளவு': 'check_stock',
  'இடம் இருக்கா': 'check_space',
  
  // Operations
  'அனுப்பு': 'dispatch',
  'ஏற்று': 'load',
  'இறக்கு': 'unload',
};

class WarehouseVoiceHandler {
  async handleTamilCommand(text: string, warehouseId: string) {
    const command = this.matchCommand(text, WAREHOUSE_COMMANDS_TAMIL);
    
    switch (command) {
      case 'check_stock':
        const stock = await this.getWarehouseStock(warehouseId);
        return `இப்போது ${stock.totalUnits} யூனிட் இருக்கு. ${stock.availableSpace} சதுர அடி காலி.`;
    }
  }
}
```

## TTS Providers (Cost Cascade)

```typescript
const TTS_PROVIDERS = [
  {
    name: 'piper',
    languages: ['hi', 'en'],
    cost: 0,  // Local
    quality: 'good',
  },
  {
    name: 'chatterbox',
    languages: ['hi', 'en'],
    cost: 0,  // Self-hosted
    quality: 'excellent',
    supportsCloning: true,
  },
  {
    name: 'elevenlabs',
    languages: ['hi', 'ta', 'te', 'bn', 'en'],
    cost: 0.30,  // Per 1K chars
    quality: 'premium',
    supportsCloning: true,
  },
];
```

## Voice Data Collection

```typescript
// Anonymized data for training (with consent)
interface VoiceDataPoint {
  audioHash: string;           // Not actual audio
  transcription: string;
  language: string;
  dialect?: string;
  domain: 'logistics' | 'coding' | 'support';
  intent: string;
  success: boolean;
  correctedTranscription?: string;
  userRating?: number;
}

// Value: Multilingual logistics voice dataset
// - First Hindi/Tamil/Telugu logistics commands
// - Real driver/warehouse worker speech patterns
// - Dialect variations across India
```

## Best Practices

1. **Always confirm critical actions** - "क्या आप पक्का चाहते हैं?"
2. **Keep responses short** - Drivers can't read long text
3. **Support interruption** - Let users cut off TTS
4. **Graceful fallback** - If STT fails, offer text input
5. **Cache common responses** - Reduce TTS costs

## Integration with TMS

```typescript
// Voice-enabled shipment tracking
@Controller('voice/tms')
export class VoiceTmsController {
  @Post('track')
  async trackByVoice(@Body() req: VoiceRequest) {
    // "मेरा शिपमेंट कहां है" → Get shipment status
    // "Order number 12345" → Lookup and respond
    // "Chennai se Bangalore kitna time" → Route estimate
  }
}
```

## Error Responses (Multilingual)

```typescript
const ERROR_RESPONSES = {
  hi: {
    NOT_UNDERSTOOD: 'माफ कीजिए, मुझे समझ नहीं आया। कृपया दोबारा बोलें।',
    NO_SHIPMENT: 'यह शिपमेंट नहीं मिला। कृपया नंबर जांचें।',
    SYSTEM_ERROR: 'कुछ गड़बड़ हो गई। कृपया बाद में कोशिश करें।',
  },
  ta: {
    NOT_UNDERSTOOD: 'மன்னிக்கவும், புரியவில்லை. மீண்டும் சொல்லுங்கள்.',
    NO_SHIPMENT: 'இந்த ஷிப்மென்ட் இல்லை. நம்பரை சரிபார்க்கவும்.',
    SYSTEM_ERROR: 'ஏதோ தவறு நடந்தது. பின்னர் முயற்சிக்கவும்.',
  },
  te: {
    NOT_UNDERSTOOD: 'క్షమించండి, అర్థం కాలేదు. మళ్ళీ చెప్పండి.',
    NO_SHIPMENT: 'ఈ షిప్మెంట్ కనుగొనలేదు. నంబర్ చెక్ చేయండి.',
    SYSTEM_ERROR: 'ఏదో తప్పు జరిగింది. తర్వాత ప్రయత్నించండి.',
  },
};
```
