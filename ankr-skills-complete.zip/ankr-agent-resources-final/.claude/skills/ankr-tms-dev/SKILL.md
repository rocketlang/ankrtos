---
name: ankr-tms-dev
description: "Development skill for ANKR Labs TMS/WMS/OMS modules. Use when: (1) Creating NestJS modules in ankr-labs-nx monorepo, (2) Working with Prisma + PostgreSQL + pgvector, (3) Building logistics APIs, (4) Following ANKR's mobile-first, cost-conscious patterns"
---

# ANKR TMS Development Skill

## Overview

ANKR Labs builds AI-first logistics software (TMS, WMS, OMS) using a mobile-first approach. This skill teaches Claude to generate code following ANKR's established patterns.

## Tech Stack

| Layer | Technology |
|-------|------------|
| Monorepo | Nx with pnpm |
| Backend | NestJS + Fastify |
| ORM | Prisma |
| Database | PostgreSQL + pgvector (TimescaleDB) |
| API | GraphQL (Mercurius) + REST |
| Validation | Zod |
| Testing | Jest |
| Real-time | Socket.io / WebSocket |

## Project Structure

```
ankr-labs-nx/
├── apps/
│   └── wowtruck/
│       ├── backend/
│       │   ├── src/
│       │   │   ├── index.ts
│       │   │   ├── schema.ts
│       │   │   ├── resolvers/
│       │   │   ├── services/
│       │   │   └── modules/
│       │   └── prisma/
│       │       └── schema.prisma
│       └── frontend/
├── packages/
│   ├── @ankr/oauth/          # OAuth (9 providers)
│   ├── @ankr/iam/            # RBAC/ABAC
│   ├── @ankr/security/       # WAF, Encryption
│   ├── @ankr/entity/         # Base entity patterns
│   ├── @ankr/alerts/         # SOS, Broadcasts
│   └── @ankr/wire/           # Event bus (Redis/MQTT)
└── tsconfig.base.json
```

## When Creating a New Module

### 1. Module Structure
```
modules/
└── [module-name]/
    ├── [module].controller.ts
    ├── [module].service.ts
    ├── [module].module.ts
    ├── [module].resolver.ts      # If GraphQL
    └── dto/
        ├── create-[module].dto.ts
        └── update-[module].dto.ts
```

### 2. Service Pattern
```typescript
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@ankr/prisma';
import { CreateShipmentDto } from './dto/create-shipment.dto';

@Injectable()
export class ShipmentService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateShipmentDto, userId: string) {
    return this.prisma.shipment.create({
      data: {
        ...dto,
        createdBy: userId,
        status: 'PENDING',
      },
    });
  }

  async findByLocation(lat: number, lng: number, radiusKm: number) {
    // Use pgvector for geo queries
    return this.prisma.$queryRaw`
      SELECT *, 
        earth_distance(
          ll_to_earth(${lat}, ${lng}),
          ll_to_earth(latitude, longitude)
        ) / 1000 as distance_km
      FROM shipments
      WHERE earth_distance(
        ll_to_earth(${lat}, ${lng}),
        ll_to_earth(latitude, longitude)
      ) < ${radiusKm * 1000}
      ORDER BY distance_km
    `;
  }
}
```

### 3. DTO with Zod
```typescript
import { z } from 'zod';
import { createZodDto } from 'nestjs-zod';

export const CreateShipmentSchema = z.object({
  origin: z.string().min(1),
  destination: z.string().min(1),
  weight: z.number().positive(),
  vehicleType: z.enum(['TRUCK', 'TRAILER', 'CONTAINER']),
  scheduledDate: z.coerce.date(),
});

export class CreateShipmentDto extends createZodDto(CreateShipmentSchema) {}
```

### 4. Controller with Swagger
```typescript
import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '@ankr/oauth';
import { CreateShipmentDto } from './dto/create-shipment.dto';
import { ShipmentService } from './shipment.service';

@ApiTags('Shipments')
@Controller('shipments')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class ShipmentController {
  constructor(private readonly service: ShipmentService) {}

  @Post()
  @ApiOperation({ summary: 'Create new shipment' })
  async create(@Body() dto: CreateShipmentDto, @CurrentUser() user: User) {
    return this.service.create(dto, user.id);
  }
}
```

## Prisma Schema Patterns

### Adding pgvector
```prisma
generator client {
  provider        = "prisma-client-js"
  previewFeatures = ["postgresqlExtensions"]
}

datasource db {
  provider   = "postgresql"
  url        = env("DATABASE_URL")
  extensions = [vector, postgis]
}

model Shipment {
  id          String   @id @default(cuid())
  embedding   Unsupported("vector(1536)")?
  latitude    Float?
  longitude   Float?
  // ... other fields
}
```

## Build Commands

```bash
# Build single package
NX_DAEMON=false npx nx build @ankr/oauth

# Generate Prisma client
npx prisma generate --schema=apps/wowtruck/backend/prisma/schema.prisma

# Run migrations
npx prisma migrate dev --schema=apps/wowtruck/backend/prisma/schema.prisma

# Add dependency to package
pnpm add lodash --filter @ankr/oauth
```

## Cost-Conscious Patterns

### 1. LLMBox Integration
```typescript
// Use free-tier providers first
import { LLMBox } from '@ankr/llmbox';

const response = await LLMBox.chat({
  messages: [{ role: 'user', content: query }],
  preferFreeTier: true,  // Groq → Ollama → DeepSeek
  maxCost: 0.01,
});
```

### 2. Caching Strategy
```typescript
// Cache expensive operations
import { CacheService } from '@ankr/cache';

@Injectable()
export class RateService {
  constructor(private cache: CacheService) {}

  async getRate(origin: string, dest: string) {
    const key = `rate:${origin}:${dest}`;
    
    return this.cache.wrap(key, async () => {
      // Expensive calculation
      return this.calculateRate(origin, dest);
    }, { ttl: 3600 });
  }
}
```

## Mobile-First Guidelines

1. **Termux-Compatible**: Code must work in Termux environment
2. **Offline-First**: Design for intermittent connectivity
3. **Low Bandwidth**: Minimize payload sizes
4. **Battery Efficient**: Reduce background processing

## Common Mistakes to Avoid

1. ❌ Using `www.` in API URLs
2. ❌ Hardcoding API keys (use env vars)
3. ❌ Ignoring tsconfig.base.json path mappings
4. ❌ Using `npm` instead of `pnpm`
5. ❌ Forgetting to run `prisma generate` after schema changes

## Related Packages

- `@ankr/oauth` - Authentication (9 providers, OTP, Magic Links)
- `@ankr/iam` - Authorization (RBAC, ABAC)
- `@ankr/security` - WAF, Encryption, Rate Limiting
- `@ankr/entity` - Base entity patterns
- `@ankr/alerts` - SOS, Recalls, Broadcasts
