/**
 * Wallet Service Tests
 * Test coverage for wallet operations: credit, debit, instant pay, advances
 *
 * 🙏 Jai Guru Ji | © 2026 ANKR Labs
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

// ─────────────────────────────────────────────────────────────────────────────
// Mock Setup
// ─────────────────────────────────────────────────────────────────────────────

const mockWallet = {
  id: 'wallet-internal-001',
  walletId: 'FR8W-ABC123',
  ownerType: 'DRIVER',
  ownerId: 'driver-001',
  ownerName: 'Rajesh Kumar',
  availableBalance: 10000,
  pendingBalance: 0,
  heldBalance: 0,
  totalEarnings: 50000,
  totalWithdrawals: 40000,
  currency: 'INR',
  instantPayEnabled: true,
  instantPayLimit: 50000,
  instantPayUsed: 0,
  instantPayReset: new Date(),
  advanceEnabled: true,
  advanceLimit: 20000,
  outstandingAdv: 0,
  advanceRecoveryPct: 25,
  bankAccountNumber: '1234567890',
  bankIfsc: 'HDFC0001234',
  bankName: 'HDFC Bank',
  bankVerified: true,
  upiId: 'rajesh@upi',
  upiVerified: true,
  status: 'ACTIVE',
  kycVerified: true,
  organizationId: 'org-001',
  createdAt: new Date(),
  updatedAt: new Date(),
  transactions: [],
  advances: [],
};

const mockTransaction = {
  id: 'txn-internal-001',
  transactionId: 'TXN-ABC123',
  walletId: 'wallet-internal-001',
  type: 'TRIP_EARNING',
  amount: 5000,
  balanceBefore: 10000,
  balanceAfter: 15000,
  status: 'COMPLETED',
  sourceType: 'SHIPMENT',
  sourceId: 'shipment-001',
  description: 'Trip earning for shipment',
  descriptionHi: 'शिपमेंट के लिए यात्रा आय',
  paymentMethod: null,
  utrNumber: null,
  platformFee: 0,
  processingFee: 0,
  tax: 0,
  netAmount: 5000,
  isInstantPay: false,
  podVerified: false,
  createdAt: new Date(),
  processedAt: new Date(),
  failedAt: null,
  failureReason: null,
};

const mockAdvance = {
  id: 'adv-internal-001',
  advanceId: 'ADV-ABC123',
  walletId: 'wallet-internal-001',
  type: 'FUEL',
  amount: 5000,
  pendingAmount: 5000,
  recoveredAmount: 0,
  status: 'ACTIVE',
  shipmentId: 'shipment-001',
  tripId: null,
  reason: 'Fuel advance for trip',
  approvedBy: 'admin-001',
  recoveryPct: 25,
  disbursedAt: new Date(),
  recoveredAt: null,
  wallet: mockWallet,
};

// Mock Prisma client
const mockPrismaFr8xWallet = {
  findUnique: vi.fn(),
  findMany: vi.fn(),
  create: vi.fn(),
  update: vi.fn(),
};

const mockPrismaFr8xWalletTransaction = {
  create: vi.fn(),
  findMany: vi.fn(),
  count: vi.fn(),
  aggregate: vi.fn(),
  update: vi.fn(),
};

const mockPrismaFr8xAdvance = {
  create: vi.fn(),
  findUnique: vi.fn(),
  findMany: vi.fn(),
  update: vi.fn(),
};

const mockPrismaTransaction = vi.fn().mockImplementation(async (operations) => {
  const results = [];
  for (const op of operations) {
    results.push(await op);
  }
  return results;
});

const mockPrisma = {
  fr8xWallet: mockPrismaFr8xWallet,
  fr8xWalletTransaction: mockPrismaFr8xWalletTransaction,
  fr8xAdvance: mockPrismaFr8xAdvance,
  $transaction: mockPrismaTransaction,
} as any;

// ─────────────────────────────────────────────────────────────────────────────
// Error Classes
// ─────────────────────────────────────────────────────────────────────────────

class Fr8XServiceError extends Error {
  constructor(public code: string, message: string) {
    super(message);
    this.name = 'Fr8XServiceError';
  }
}

const ErrorCodes = {
  RESOURCE_NOT_FOUND: 'RESOURCE_NOT_FOUND',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  INVALID_STATE_TRANSITION: 'INVALID_STATE_TRANSITION',
  PLAN_LIMIT_EXCEEDED: 'PLAN_LIMIT_EXCEEDED',
  FORBIDDEN: 'FORBIDDEN',
};

// ─────────────────────────────────────────────────────────────────────────────
// Service Factory (simplified for testing)
// ─────────────────────────────────────────────────────────────────────────────

function createTestWalletService(prisma: any) {
  const INSTANT_PAY_FEE_PCT = 1.5;
  const PROCESSING_FEE_FLAT = 10;
  const TAX_RATE = 18;

  return {
    async createWallet(input: any) {
      const existing = await prisma.fr8xWallet.findUnique({
        where: {
          ownerType_ownerId: {
            ownerType: input.ownerType,
            ownerId: input.ownerId,
          },
        },
      });

      if (existing) {
        throw new Fr8XServiceError(
          ErrorCodes.VALIDATION_ERROR,
          `Wallet already exists for ${input.ownerType} ${input.ownerId}`
        );
      }

      return prisma.fr8xWallet.create({
        data: {
          walletId: `FR8W-${Date.now()}`,
          ownerType: input.ownerType,
          ownerId: input.ownerId,
          ownerName: input.ownerName,
          organizationId: input.organizationId,
          instantPayLimit: 50000,
          advanceLimit: 20000,
          advanceRecoveryPct: 25,
        },
      });
    },

    async getWallet(walletId: string) {
      const wallet = await prisma.fr8xWallet.findUnique({
        where: { walletId },
        include: {
          transactions: { take: 10, orderBy: { createdAt: 'desc' } },
          advances: { where: { status: 'ACTIVE' } },
        },
      });

      if (!wallet) {
        throw new Fr8XServiceError(ErrorCodes.RESOURCE_NOT_FOUND, 'Wallet not found');
      }

      return wallet;
    },

    async credit(input: any) {
      const wallet = await prisma.fr8xWallet.findUnique({
        where: { walletId: input.walletId },
      });

      if (!wallet) {
        throw new Fr8XServiceError(ErrorCodes.RESOURCE_NOT_FOUND, 'Wallet not found');
      }

      if (wallet.status !== 'ACTIVE') {
        throw new Fr8XServiceError(
          ErrorCodes.INVALID_STATE_TRANSITION,
          `Wallet is ${wallet.status}`
        );
      }

      let platformFee = 0;
      let processingFee = 0;
      let tax = 0;
      let netAmount = input.amount;

      if (input.isInstantPay) {
        const instantPayUsed = Number(wallet.instantPayUsed);
        const instantPayLimit = Number(wallet.instantPayLimit);

        if (instantPayUsed + input.amount > instantPayLimit) {
          throw new Fr8XServiceError(
            ErrorCodes.PLAN_LIMIT_EXCEEDED,
            `Daily instant pay limit exceeded. Used: ₹${instantPayUsed}, Limit: ₹${instantPayLimit}`
          );
        }

        platformFee = (input.amount * INSTANT_PAY_FEE_PCT) / 100;
        processingFee = PROCESSING_FEE_FLAT;
        tax = ((platformFee + processingFee) * TAX_RATE) / 100;
        netAmount = input.amount - platformFee - processingFee - tax;
      }

      const transaction = await prisma.fr8xWalletTransaction.create({
        data: {
          transactionId: `TXN-${Date.now()}`,
          walletId: wallet.id,
          type: input.type,
          amount: input.amount,
          balanceBefore: Number(wallet.availableBalance),
          balanceAfter: Number(wallet.availableBalance) + netAmount,
          status: input.isInstantPay ? 'COMPLETED' : 'PENDING',
          description: input.description,
          isInstantPay: input.isInstantPay ?? false,
          platformFee,
          processingFee,
          tax,
          netAmount,
        },
      });

      await prisma.fr8xWallet.update({
        where: { id: wallet.id },
        data: {
          availableBalance: Number(wallet.availableBalance) + netAmount,
          totalEarnings: Number(wallet.totalEarnings) + input.amount,
        },
      });

      return transaction;
    },

    async debit(input: any) {
      const wallet = await prisma.fr8xWallet.findUnique({
        where: { walletId: input.walletId },
      });

      if (!wallet) {
        throw new Fr8XServiceError(ErrorCodes.RESOURCE_NOT_FOUND, 'Wallet not found');
      }

      if (wallet.status !== 'ACTIVE') {
        throw new Fr8XServiceError(
          ErrorCodes.INVALID_STATE_TRANSITION,
          `Wallet is ${wallet.status}`
        );
      }

      const availableBalance = Number(wallet.availableBalance);

      if (availableBalance < input.amount) {
        throw new Fr8XServiceError(
          ErrorCodes.VALIDATION_ERROR,
          `Insufficient balance. Available: ₹${availableBalance}, Requested: ₹${input.amount}`
        );
      }

      const transaction = await prisma.fr8xWalletTransaction.create({
        data: {
          transactionId: `TXN-${Date.now()}`,
          walletId: wallet.id,
          type: input.type,
          amount: -input.amount,
          balanceBefore: availableBalance,
          balanceAfter: availableBalance - input.amount,
          status: 'PROCESSING',
          description: input.description,
          paymentMethod: input.paymentMethod,
        },
      });

      await prisma.fr8xWallet.update({
        where: { id: wallet.id },
        data: {
          availableBalance: availableBalance - input.amount,
          totalWithdrawals: Number(wallet.totalWithdrawals) + input.amount,
        },
      });

      return transaction;
    },

    async withdrawToBank(walletId: string, amount: number) {
      const wallet = await prisma.fr8xWallet.findUnique({
        where: { walletId },
      });

      if (!wallet?.bankAccountNumber || !wallet?.bankVerified) {
        throw new Fr8XServiceError(
          ErrorCodes.VALIDATION_ERROR,
          'No verified bank account linked'
        );
      }

      return this.debit({
        walletId,
        type: 'CASH_OUT',
        amount,
        paymentMethod: 'BANK_TRANSFER',
        description: `Withdrawal to ${wallet.bankName}`,
      });
    },

    async withdrawToUpi(walletId: string, amount: number) {
      const wallet = await prisma.fr8xWallet.findUnique({
        where: { walletId },
      });

      if (!wallet?.upiId || !wallet?.upiVerified) {
        throw new Fr8XServiceError(
          ErrorCodes.VALIDATION_ERROR,
          'No verified UPI ID linked'
        );
      }

      return this.debit({
        walletId,
        type: 'UPI_TRANSFER',
        amount,
        paymentMethod: 'UPI',
        description: `UPI transfer to ${wallet.upiId}`,
      });
    },

    async disburseAdvance(input: any) {
      const wallet = await prisma.fr8xWallet.findUnique({
        where: { walletId: input.walletId },
        include: { advances: { where: { status: 'ACTIVE' } } },
      });

      if (!wallet) {
        throw new Fr8XServiceError(ErrorCodes.RESOURCE_NOT_FOUND, 'Wallet not found');
      }

      if (!wallet.advanceEnabled) {
        throw new Fr8XServiceError(
          ErrorCodes.FORBIDDEN,
          'Advances are disabled for this wallet'
        );
      }

      const currentOutstanding = Number(wallet.outstandingAdv);
      const advanceLimit = Number(wallet.advanceLimit);

      if (currentOutstanding + input.amount > advanceLimit) {
        throw new Fr8XServiceError(
          ErrorCodes.PLAN_LIMIT_EXCEEDED,
          `Advance limit exceeded. Outstanding: ₹${currentOutstanding}, Limit: ₹${advanceLimit}`
        );
      }

      const advance = await prisma.fr8xAdvance.create({
        data: {
          advanceId: `ADV-${Date.now()}`,
          walletId: wallet.id,
          type: input.type,
          amount: input.amount,
          pendingAmount: input.amount,
          approvedBy: input.approvedBy,
          recoveryPct: input.recoveryPct ?? Number(wallet.advanceRecoveryPct),
        },
      });

      await prisma.fr8xWallet.update({
        where: { id: wallet.id },
        data: {
          outstandingAdv: currentOutstanding + input.amount,
        },
      });

      return advance;
    },

    async getTransactions(walletId: string, options: any = {}) {
      const wallet = await prisma.fr8xWallet.findUnique({
        where: { walletId },
      });

      if (!wallet) {
        throw new Fr8XServiceError(ErrorCodes.RESOURCE_NOT_FOUND, 'Wallet not found');
      }

      const where: any = { walletId: wallet.id };
      if (options.type) where.type = options.type;

      const [transactions, total] = await Promise.all([
        prisma.fr8xWalletTransaction.findMany({
          where,
          take: options.limit ?? 20,
          skip: options.offset ?? 0,
          orderBy: { createdAt: 'desc' },
        }),
        prisma.fr8xWalletTransaction.count({ where }),
      ]);

      return { transactions, total };
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

describe('Wallet Service', () => {
  let walletService: ReturnType<typeof createTestWalletService>;

  beforeEach(() => {
    vi.clearAllMocks();
    walletService = createTestWalletService(mockPrisma);
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  describe('createWallet', () => {
    it('should create a new wallet successfully', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(null);
      mockPrismaFr8xWallet.create.mockResolvedValue(mockWallet);

      const result = await walletService.createWallet({
        ownerType: 'DRIVER',
        ownerId: 'driver-001',
        ownerName: 'Rajesh Kumar',
      });

      expect(result.walletId).toBe('FR8W-ABC123');
      expect(mockPrismaFr8xWallet.create).toHaveBeenCalled();
    });

    it('should throw error if wallet already exists', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);

      await expect(
        walletService.createWallet({
          ownerType: 'DRIVER',
          ownerId: 'driver-001',
          ownerName: 'Rajesh Kumar',
        })
      ).rejects.toThrow('Wallet already exists');
    });
  });

  describe('getWallet', () => {
    it('should return wallet with transactions and advances', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        transactions: [mockTransaction],
        advances: [mockAdvance],
      });

      const result = await walletService.getWallet('FR8W-ABC123');

      expect(result.walletId).toBe('FR8W-ABC123');
      expect(result.transactions).toHaveLength(1);
      expect(result.advances).toHaveLength(1);
    });

    it('should throw error for non-existent wallet', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(null);

      await expect(walletService.getWallet('non-existent')).rejects.toThrow('Wallet not found');
    });
  });

  describe('credit', () => {
    it('should credit wallet successfully', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);
      mockPrismaFr8xWalletTransaction.create.mockResolvedValue(mockTransaction);
      mockPrismaFr8xWallet.update.mockResolvedValue({
        ...mockWallet,
        availableBalance: 15000,
      });

      const result = await walletService.credit({
        walletId: 'FR8W-ABC123',
        type: 'TRIP_EARNING',
        amount: 5000,
        description: 'Trip earning',
      });

      expect(result.amount).toBe(5000);
      expect(mockPrismaFr8xWalletTransaction.create).toHaveBeenCalled();
      expect(mockPrismaFr8xWallet.update).toHaveBeenCalled();
    });

    it('should throw error for non-existent wallet', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(null);

      await expect(
        walletService.credit({
          walletId: 'non-existent',
          type: 'TRIP_EARNING',
          amount: 5000,
          description: 'Test',
        })
      ).rejects.toThrow('Wallet not found');
    });

    it('should throw error for suspended wallet', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        status: 'SUSPENDED',
      });

      await expect(
        walletService.credit({
          walletId: 'FR8W-ABC123',
          type: 'TRIP_EARNING',
          amount: 5000,
          description: 'Test',
        })
      ).rejects.toThrow('Wallet is SUSPENDED');
    });

    it('should apply instant pay fees correctly', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);
      mockPrismaFr8xWalletTransaction.create.mockResolvedValue({
        ...mockTransaction,
        isInstantPay: true,
        platformFee: 75, // 1.5% of 5000
        processingFee: 10,
        tax: 15.3, // 18% of (75 + 10)
      });
      mockPrismaFr8xWallet.update.mockResolvedValue(mockWallet);

      const result = await walletService.credit({
        walletId: 'FR8W-ABC123',
        type: 'INSTANT_POD',
        amount: 5000,
        description: 'Instant POD payment',
        isInstantPay: true,
      });

      expect(result.isInstantPay).toBe(true);
    });

    it('should throw error when instant pay limit exceeded', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        instantPayUsed: 45000,
        instantPayLimit: 50000,
      });

      await expect(
        walletService.credit({
          walletId: 'FR8W-ABC123',
          type: 'INSTANT_POD',
          amount: 10000,
          description: 'Test',
          isInstantPay: true,
        })
      ).rejects.toThrow('Daily instant pay limit exceeded');
    });
  });

  describe('debit', () => {
    it('should debit wallet successfully', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);
      mockPrismaFr8xWalletTransaction.create.mockResolvedValue({
        ...mockTransaction,
        type: 'CASH_OUT',
        amount: -2000,
      });
      mockPrismaFr8xWallet.update.mockResolvedValue({
        ...mockWallet,
        availableBalance: 8000,
      });

      const result = await walletService.debit({
        walletId: 'FR8W-ABC123',
        type: 'CASH_OUT',
        amount: 2000,
        paymentMethod: 'BANK_TRANSFER',
        description: 'Withdrawal',
      });

      expect(result.amount).toBe(-2000);
    });

    it('should throw error for insufficient balance', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        availableBalance: 1000,
      });

      await expect(
        walletService.debit({
          walletId: 'FR8W-ABC123',
          type: 'CASH_OUT',
          amount: 5000,
          paymentMethod: 'BANK_TRANSFER',
          description: 'Withdrawal',
        })
      ).rejects.toThrow('Insufficient balance');
    });

    it('should throw error for suspended wallet', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        status: 'SUSPENDED',
      });

      await expect(
        walletService.debit({
          walletId: 'FR8W-ABC123',
          type: 'CASH_OUT',
          amount: 1000,
          paymentMethod: 'BANK_TRANSFER',
          description: 'Withdrawal',
        })
      ).rejects.toThrow('Wallet is SUSPENDED');
    });
  });

  describe('withdrawToBank', () => {
    it('should withdraw to verified bank account', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);
      mockPrismaFr8xWalletTransaction.create.mockResolvedValue({
        ...mockTransaction,
        type: 'CASH_OUT',
        paymentMethod: 'BANK_TRANSFER',
      });
      mockPrismaFr8xWallet.update.mockResolvedValue(mockWallet);

      const result = await walletService.withdrawToBank('FR8W-ABC123', 5000);

      expect(result.paymentMethod).toBe('BANK_TRANSFER');
    });

    it('should throw error for unverified bank account', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        bankVerified: false,
      });

      await expect(walletService.withdrawToBank('FR8W-ABC123', 5000)).rejects.toThrow(
        'No verified bank account linked'
      );
    });

    it('should throw error when no bank account linked', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        bankAccountNumber: null,
      });

      await expect(walletService.withdrawToBank('FR8W-ABC123', 5000)).rejects.toThrow(
        'No verified bank account linked'
      );
    });
  });

  describe('withdrawToUpi', () => {
    it('should withdraw to verified UPI ID', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);
      mockPrismaFr8xWalletTransaction.create.mockResolvedValue({
        ...mockTransaction,
        type: 'UPI_TRANSFER',
        paymentMethod: 'UPI',
      });
      mockPrismaFr8xWallet.update.mockResolvedValue(mockWallet);

      const result = await walletService.withdrawToUpi('FR8W-ABC123', 2000);

      expect(result.paymentMethod).toBe('UPI');
    });

    it('should throw error for unverified UPI ID', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        upiVerified: false,
      });

      await expect(walletService.withdrawToUpi('FR8W-ABC123', 2000)).rejects.toThrow(
        'No verified UPI ID linked'
      );
    });
  });

  describe('disburseAdvance', () => {
    it('should disburse advance successfully', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        advances: [],
      });
      mockPrismaFr8xAdvance.create.mockResolvedValue(mockAdvance);
      mockPrismaFr8xWallet.update.mockResolvedValue({
        ...mockWallet,
        outstandingAdv: 5000,
      });

      const result = await walletService.disburseAdvance({
        walletId: 'FR8W-ABC123',
        type: 'FUEL',
        amount: 5000,
        approvedBy: 'admin-001',
      });

      expect(result.type).toBe('FUEL');
      expect(result.amount).toBe(5000);
    });

    it('should throw error when advances disabled', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        advanceEnabled: false,
        advances: [],
      });

      await expect(
        walletService.disburseAdvance({
          walletId: 'FR8W-ABC123',
          type: 'FUEL',
          amount: 5000,
          approvedBy: 'admin-001',
        })
      ).rejects.toThrow('Advances are disabled');
    });

    it('should throw error when advance limit exceeded', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        outstandingAdv: 18000,
        advanceLimit: 20000,
        advances: [],
      });

      await expect(
        walletService.disburseAdvance({
          walletId: 'FR8W-ABC123',
          type: 'FUEL',
          amount: 5000,
          approvedBy: 'admin-001',
        })
      ).rejects.toThrow('Advance limit exceeded');
    });
  });

  describe('getTransactions', () => {
    it('should return paginated transactions', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);
      mockPrismaFr8xWalletTransaction.findMany.mockResolvedValue([mockTransaction]);
      mockPrismaFr8xWalletTransaction.count.mockResolvedValue(1);

      const result = await walletService.getTransactions('FR8W-ABC123', {
        limit: 10,
        offset: 0,
      });

      expect(result.transactions).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should filter by transaction type', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(mockWallet);
      mockPrismaFr8xWalletTransaction.findMany.mockResolvedValue([mockTransaction]);
      mockPrismaFr8xWalletTransaction.count.mockResolvedValue(1);

      await walletService.getTransactions('FR8W-ABC123', {
        type: 'TRIP_EARNING',
      });

      expect(mockPrismaFr8xWalletTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ type: 'TRIP_EARNING' }),
        })
      );
    });

    it('should throw error for non-existent wallet', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue(null);

      await expect(walletService.getTransactions('non-existent')).rejects.toThrow(
        'Wallet not found'
      );
    });
  });

  describe('Edge Cases', () => {
    it('should handle zero balance correctly', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        availableBalance: 0,
      });

      await expect(
        walletService.debit({
          walletId: 'FR8W-ABC123',
          type: 'CASH_OUT',
          amount: 100,
          paymentMethod: 'UPI',
          description: 'Test',
        })
      ).rejects.toThrow('Insufficient balance');
    });

    it('should handle large transaction amounts', async () => {
      mockPrismaFr8xWallet.findUnique.mockResolvedValue({
        ...mockWallet,
        availableBalance: 1000000,
      });
      mockPrismaFr8xWalletTransaction.create.mockResolvedValue({
        ...mockTransaction,
        amount: 500000,
      });
      mockPrismaFr8xWallet.update.mockResolvedValue(mockWallet);

      const result = await walletService.credit({
        walletId: 'FR8W-ABC123',
        type: 'TRIP_EARNING',
        amount: 500000,
        description: 'Large payment',
      });

      expect(result.amount).toBe(500000);
    });
  });
});
