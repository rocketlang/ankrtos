/**
 * Fr8X Freight Exchange - Main Server
 * World-class freight marketplace API
 */

import { randomUUID } from 'crypto';
import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import cookie from '@fastify/cookie';
import mercurius from 'mercurius';
import { PrismaClient } from '../generated/prisma/index.js';
import { schema } from './schema/index.js';
import { createContext } from './context.js';
import { logger, fastifyLoggerPlugin } from './lib/index.js';

// Initialize Prisma with structured logging
const prisma = new PrismaClient({
  log: [
    { level: 'query', emit: 'event' },
    { level: 'error', emit: 'event' },
    { level: 'warn', emit: 'event' },
  ],
});

// Log Prisma queries in development
if (process.env.NODE_ENV === 'development') {
  prisma.$on('query', (e) => {
    logger.db('query', 'prisma', e.duration, {
      query: e.query,
      params: e.params,
    });
  });
}

prisma.$on('error', (e) => {
  logger.error('Prisma error', new Error(e.message), { target: e.target });
});

prisma.$on('warn', (e) => {
  logger.warn(`Prisma warning: ${e.message}`, { target: e.target });
});

// Initialize Fastify with structured logging
const app = Fastify({
  logger: false, // We use our custom logger
  requestIdHeader: 'x-request-id',
  genReqId: () => randomUUID(),
});

// Register plugins
await app.register(fastifyLoggerPlugin);

await app.register(cors, {
  origin: true,
  credentials: true,
});

await app.register(cookie);

await app.register(jwt, {
  secret: process.env.JWT_SECRET || 'fr8x-secret',
});

// Register Mercurius GraphQL
await app.register(mercurius, {
  schema,
  context: (request, reply) => createContext({ request, reply, prisma }),
  graphiql: process.env.NODE_ENV === 'development',
  path: '/graphql',
  subscription: true,
});

// Health check endpoint
app.get('/health', async (request) => {
  const correlationId = request.correlationId || request.id;
  return {
    status: 'ok',
    service: 'fr8x-backend',
    timestamp: new Date().toISOString(),
    correlationId,
  };
});

// API Info endpoint
app.get('/', async () => {
  return {
    name: 'Fr8X Freight Exchange API',
    version: '1.0.0',
    description: 'World-class freight marketplace - Any Size. Any Mode. Anywhere.',
    graphql: '/graphql',
    graphiql: process.env.NODE_ENV === 'development' ? '/graphiql' : null,
    docs: 'https://freightbox.org/downloads',
  };
});

// Graceful shutdown
const shutdown = async () => {
  logger.info('Shutting down Fr8X server...');
  await prisma.$disconnect();
  await app.close();
  process.exit(0);
};

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
const start = async () => {
  try {
    const port = parseInt(process.env.PORT || '4050');
    const host = process.env.HOST || '0.0.0.0';

    await app.listen({ port, host });

    logger.info('Fr8X server started', {
      port,
      host,
      environment: process.env.NODE_ENV || 'development',
      graphql: `http://${host}:${port}/graphql`,
    });

    console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ███████╗██████╗  █████╗ ██╗  ██╗                           ║
║   ██╔════╝██╔══██╗██╔══██╗╚██╗██╔╝                           ║
║   █████╗  ██████╔╝╚█████╔╝ ╚███╔╝                            ║
║   ██╔══╝  ██╔══██╗██╔══██╗ ██╔██╗                            ║
║   ██║     ██║  ██║╚█████╔╝██╔╝ ██╗                           ║
║   ╚═╝     ╚═╝  ╚═╝ ╚════╝ ╚═╝  ╚═╝                           ║
║                                                               ║
║   Freight Exchange - Any Size. Any Mode. Anywhere.           ║
║                                                               ║
╠═══════════════════════════════════════════════════════════════╣
║   Server:    http://${host}:${port}                              ║
║   GraphQL:   http://${host}:${port}/graphql                      ║
║   GraphiQL:  http://${host}:${port}/graphiql                     ║
║   Health:    http://${host}:${port}/health                       ║
╚═══════════════════════════════════════════════════════════════╝
    `);
  } catch (err) {
    logger.fatal('Failed to start Fr8X server', err as Error);
    process.exit(1);
  }
};

start();

export { app, prisma };
