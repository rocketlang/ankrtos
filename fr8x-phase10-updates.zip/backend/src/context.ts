/**
 * Fr8X GraphQL Context
 */

import type { FastifyRequest, FastifyReply } from 'fastify';
import type { PrismaClient } from '../generated/prisma/index.js';
import { logger, type StructuredLogger, createGraphQLLogger } from './lib/index.js';

export interface Context {
  prisma: PrismaClient;
  request: FastifyRequest;
  reply: FastifyReply;
  user: {
    id: string;
    email: string;
    role: string;
    organizationId: string | null;
  } | null;
  log: StructuredLogger;
  correlationId: string;
  gqlLog: ReturnType<typeof createGraphQLLogger>;
}

interface CreateContextParams {
  request: FastifyRequest;
  reply: FastifyReply;
  prisma: PrismaClient;
}

export async function createContext({ request, reply, prisma }: CreateContextParams): Promise<Context> {
  let user = null;

  // Get or generate correlation ID
  const correlationId =
    (request.headers['x-correlation-id'] as string) ||
    (request.headers['x-request-id'] as string) ||
    request.id;

  // Extract user from JWT if present
  try {
    const token = request.headers.authorization?.replace('Bearer ', '');
    if (token) {
      const decoded = await request.jwtVerify<{
        id: string;
        email: string;
        role: string;
        organizationId: string | null;
      }>();
      user = decoded;
    }
  } catch {
    // Token invalid or expired - continue as unauthenticated
  }

  // Create request-scoped logger
  const log = logger.child({
    correlationId,
    requestId: request.id,
    userId: user?.id,
    organizationId: user?.organizationId || undefined,
  });

  // Create GraphQL-specific logger
  const gqlLog = createGraphQLLogger({
    reply,
    log,
    correlationId,
  } as any);

  return {
    prisma,
    request,
    reply,
    user,
    log,
    correlationId,
    gqlLog,
  };
}
