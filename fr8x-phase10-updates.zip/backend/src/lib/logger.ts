/**
 * Fr8X Structured Logger
 * Provides correlation IDs, structured logging, and context propagation
 */
import pino, { type Logger, type LoggerOptions } from 'pino';
import { AsyncLocalStorage } from 'async_hooks';
import { randomUUID } from 'crypto';

// ═══════════════════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════════════════

export interface LogContext {
  correlationId: string;
  requestId?: string;
  userId?: string;
  organizationId?: string;
  sessionId?: string;
  operation?: string;
  traceId?: string;
  spanId?: string;
}

export interface StructuredLog {
  level: string;
  message: string;
  context: LogContext;
  data?: Record<string, unknown>;
  error?: {
    name: string;
    message: string;
    stack?: string;
    code?: string;
  };
  duration?: number;
  timestamp: string;
  service: string;
  environment: string;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Async Context Storage
// ═══════════════════════════════════════════════════════════════════════════════

const asyncLocalStorage = new AsyncLocalStorage<LogContext>();

/**
 * Get current logging context from async local storage
 */
export function getLogContext(): LogContext | undefined {
  return asyncLocalStorage.getStore();
}

/**
 * Run a function with a specific logging context
 */
export function runWithContext<T>(context: Partial<LogContext>, fn: () => T): T {
  const currentContext = getLogContext();
  const newContext: LogContext = {
    correlationId: context.correlationId || currentContext?.correlationId || randomUUID(),
    requestId: context.requestId || currentContext?.requestId,
    userId: context.userId || currentContext?.userId,
    organizationId: context.organizationId || currentContext?.organizationId,
    sessionId: context.sessionId || currentContext?.sessionId,
    operation: context.operation || currentContext?.operation,
    traceId: context.traceId || currentContext?.traceId,
    spanId: context.spanId || currentContext?.spanId,
  };
  return asyncLocalStorage.run(newContext, fn);
}

/**
 * Create a child context with additional properties
 */
export function withContext(context: Partial<LogContext>): LogContext {
  const current = getLogContext() || { correlationId: randomUUID() };
  return { ...current, ...context };
}

// ═══════════════════════════════════════════════════════════════════════════════
// Logger Configuration
// ═══════════════════════════════════════════════════════════════════════════════

const SERVICE_NAME = 'fr8x-backend';
const ENVIRONMENT = process.env.NODE_ENV || 'development';
const LOG_LEVEL = process.env.LOG_LEVEL || (ENVIRONMENT === 'production' ? 'info' : 'debug');

const loggerOptions: LoggerOptions = {
  level: LOG_LEVEL,
  base: {
    service: SERVICE_NAME,
    environment: ENVIRONMENT,
    pid: process.pid,
    hostname: process.env.HOSTNAME || 'localhost',
  },
  timestamp: pino.stdTimeFunctions.isoTime,
  formatters: {
    level: (label) => ({ level: label }),
    bindings: (bindings) => ({
      pid: bindings.pid,
      hostname: bindings.hostname,
      service: bindings.service,
      environment: bindings.environment,
    }),
  },
  redact: {
    paths: [
      'password',
      'passwordHash',
      'token',
      'accessToken',
      'refreshToken',
      'apiKey',
      'secret',
      'authorization',
      'cookie',
      '*.password',
      '*.passwordHash',
      '*.token',
      '*.accessToken',
      '*.refreshToken',
      '*.apiKey',
      '*.secret',
    ],
    censor: '[REDACTED]',
  },
  transport:
    ENVIRONMENT === 'development'
      ? {
          target: 'pino-pretty',
          options: {
            colorize: true,
            translateTime: 'SYS:standard',
            ignore: 'pid,hostname',
          },
        }
      : undefined,
};

// Base pino logger
const baseLogger = pino(loggerOptions);

// ═══════════════════════════════════════════════════════════════════════════════
// Structured Logger Class
// ═══════════════════════════════════════════════════════════════════════════════

export class StructuredLogger {
  private logger: Logger;
  private defaultContext: Partial<LogContext>;

  constructor(options?: { context?: Partial<LogContext>; logger?: Logger }) {
    this.logger = options?.logger || baseLogger;
    this.defaultContext = options?.context || {};
  }

  private getContext(): LogContext {
    const asyncContext = getLogContext();
    return {
      correlationId: asyncContext?.correlationId || this.defaultContext.correlationId || randomUUID(),
      requestId: asyncContext?.requestId || this.defaultContext.requestId,
      userId: asyncContext?.userId || this.defaultContext.userId,
      organizationId: asyncContext?.organizationId || this.defaultContext.organizationId,
      sessionId: asyncContext?.sessionId || this.defaultContext.sessionId,
      operation: asyncContext?.operation || this.defaultContext.operation,
      traceId: asyncContext?.traceId || this.defaultContext.traceId,
      spanId: asyncContext?.spanId || this.defaultContext.spanId,
    };
  }

  private formatError(error: Error): StructuredLog['error'] {
    return {
      name: error.name,
      message: error.message,
      stack: error.stack,
      code: (error as any).code,
    };
  }

  /**
   * Create a child logger with additional context
   */
  child(context: Partial<LogContext>): StructuredLogger {
    return new StructuredLogger({
      context: { ...this.defaultContext, ...context },
      logger: this.logger,
    });
  }

  /**
   * Log at debug level
   */
  debug(message: string, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.debug({ ...context, ...data }, message);
  }

  /**
   * Log at info level
   */
  info(message: string, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.info({ ...context, ...data }, message);
  }

  /**
   * Log at warn level
   */
  warn(message: string, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.warn({ ...context, ...data }, message);
  }

  /**
   * Log at error level
   */
  error(message: string, error?: Error | unknown, data?: Record<string, unknown>): void {
    const context = this.getContext();
    const errorData = error instanceof Error ? this.formatError(error) : { error };
    this.logger.error({ ...context, error: errorData, ...data }, message);
  }

  /**
   * Log at fatal level
   */
  fatal(message: string, error?: Error | unknown, data?: Record<string, unknown>): void {
    const context = this.getContext();
    const errorData = error instanceof Error ? this.formatError(error) : { error };
    this.logger.fatal({ ...context, error: errorData, ...data }, message);
  }

  /**
   * Log an operation with timing
   */
  async time<T>(operation: string, fn: () => Promise<T>, data?: Record<string, unknown>): Promise<T> {
    const start = Date.now();
    const context = this.getContext();

    this.logger.debug({ ...context, operation, ...data }, `${operation} started`);

    try {
      const result = await fn();
      const duration = Date.now() - start;
      this.logger.info({ ...context, operation, duration, ...data }, `${operation} completed`);
      return result;
    } catch (error) {
      const duration = Date.now() - start;
      const errorData = error instanceof Error ? this.formatError(error) : { error };
      this.logger.error(
        { ...context, operation, duration, error: errorData, ...data },
        `${operation} failed`
      );
      throw error;
    }
  }

  /**
   * Log HTTP request
   */
  request(method: string, path: string, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.info(
      {
        ...context,
        http: { method, path },
        ...data,
      },
      `${method} ${path}`
    );
  }

  /**
   * Log HTTP response
   */
  response(method: string, path: string, statusCode: number, duration: number, data?: Record<string, unknown>): void {
    const context = this.getContext();
    const level = statusCode >= 500 ? 'error' : statusCode >= 400 ? 'warn' : 'info';
    this.logger[level](
      {
        ...context,
        http: { method, path, statusCode },
        duration,
        ...data,
      },
      `${method} ${path} ${statusCode} - ${duration}ms`
    );
  }

  /**
   * Log GraphQL operation
   */
  graphql(operationType: string, operationName: string, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.info(
      {
        ...context,
        graphql: { operationType, operationName },
        ...data,
      },
      `GraphQL ${operationType}: ${operationName}`
    );
  }

  /**
   * Log database query
   */
  db(operation: string, model: string, duration?: number, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.debug(
      {
        ...context,
        db: { operation, model, duration },
        ...data,
      },
      `DB ${operation} ${model}${duration ? ` - ${duration}ms` : ''}`
    );
  }

  /**
   * Log business event
   */
  event(eventName: string, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.info(
      {
        ...context,
        event: eventName,
        ...data,
      },
      `Event: ${eventName}`
    );
  }

  /**
   * Log audit event
   */
  audit(action: string, resource: string, resourceId: string, data?: Record<string, unknown>): void {
    const context = this.getContext();
    this.logger.info(
      {
        ...context,
        audit: { action, resource, resourceId },
        ...data,
      },
      `Audit: ${action} ${resource}:${resourceId}`
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Default Logger Instance
// ═══════════════════════════════════════════════════════════════════════════════

export const logger = new StructuredLogger();

// ═══════════════════════════════════════════════════════════════════════════════
// Fastify Plugin
// ═══════════════════════════════════════════════════════════════════════════════

import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import fp from 'fastify-plugin';

declare module 'fastify' {
  interface FastifyRequest {
    correlationId: string;
    log: StructuredLogger;
  }
}

async function loggerPlugin(fastify: FastifyInstance): Promise<void> {
  // Add correlation ID header
  const CORRELATION_ID_HEADER = 'x-correlation-id';
  const REQUEST_ID_HEADER = 'x-request-id';

  fastify.decorateRequest('correlationId', '');
  fastify.decorateRequest('log', null);

  // Pre-handler to set up logging context
  fastify.addHook('onRequest', async (request: FastifyRequest, reply: FastifyReply) => {
    const correlationId =
      (request.headers[CORRELATION_ID_HEADER] as string) ||
      (request.headers[REQUEST_ID_HEADER] as string) ||
      randomUUID();

    request.correlationId = correlationId;
    reply.header(CORRELATION_ID_HEADER, correlationId);

    // Extract user info from JWT if available
    let userId: string | undefined;
    let organizationId: string | undefined;

    try {
      const decoded = await request.jwtVerify<{ userId?: string; organizationId?: string }>().catch(() => null);
      if (decoded) {
        userId = decoded.userId;
        organizationId = decoded.organizationId;
      }
    } catch {
      // Ignore JWT errors for unauthenticated routes
    }

    // Create request-scoped logger
    request.log = logger.child({
      correlationId,
      requestId: request.id,
      userId,
      organizationId,
    });

    // Log incoming request
    request.log.request(request.method, request.url, {
      userAgent: request.headers['user-agent'],
      ip: request.ip,
    });
  });

  // Post-handler to log response
  fastify.addHook('onResponse', async (request: FastifyRequest, reply: FastifyReply) => {
    const duration = reply.elapsedTime;
    request.log.response(request.method, request.url, reply.statusCode, Math.round(duration));
  });

  // Error handler
  fastify.addHook('onError', async (request: FastifyRequest, reply: FastifyReply, error: Error) => {
    request.log.error(`Request error: ${error.message}`, error, {
      url: request.url,
      method: request.method,
    });
  });
}

export const fastifyLoggerPlugin = fp(loggerPlugin, {
  name: 'fr8x-logger',
  fastify: '4.x',
});

// ═══════════════════════════════════════════════════════════════════════════════
// GraphQL Logger Extension
// ═══════════════════════════════════════════════════════════════════════════════

export interface GraphQLLogContext {
  operationType: 'query' | 'mutation' | 'subscription';
  operationName: string;
  variables?: Record<string, unknown>;
  userId?: string;
  organizationId?: string;
  correlationId: string;
}

export function logGraphQLOperation(ctx: GraphQLLogContext, startTime: number): void {
  const duration = Date.now() - startTime;
  const reqLogger = logger.child({
    correlationId: ctx.correlationId,
    userId: ctx.userId,
    organizationId: ctx.organizationId,
  });

  reqLogger.graphql(ctx.operationType, ctx.operationName, {
    duration,
    variables: ctx.variables,
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// Export Utilities
// ═══════════════════════════════════════════════════════════════════════════════

export function generateCorrelationId(): string {
  return randomUUID();
}

export function generateTraceId(): string {
  return randomUUID().replace(/-/g, '');
}

export function generateSpanId(): string {
  return randomUUID().substring(0, 16).replace(/-/g, '');
}

export default logger;
