/**
 * Fr8X Backend Library Exports
 */
export {
  logger,
  StructuredLogger,
  fastifyLoggerPlugin,
  getLogContext,
  runWithContext,
  withContext,
  generateCorrelationId,
  generateTraceId,
  generateSpanId,
  logGraphQLOperation,
  type LogContext,
  type StructuredLog,
  type GraphQLLogContext,
} from './logger.js';

export {
  createGraphQLLogger,
  withResolverLogging,
  withBatchLogging,
  graphqlLoggingHooks,
} from './graphql-logger.js';
