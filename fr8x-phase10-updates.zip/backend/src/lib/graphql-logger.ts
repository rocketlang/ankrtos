/**
 * Fr8X GraphQL Logger Plugin
 * Logs GraphQL operations with timing and context
 */
import type { MercuriusContext, MercuriusLoggingHook } from 'mercurius';
import { logger, type StructuredLogger } from './logger.js';

interface GraphQLContext extends MercuriusContext {
  log?: StructuredLogger;
  correlationId?: string;
}

/**
 * Mercurius logging hooks for structured logging
 */
export const graphqlLoggingHooks: MercuriusLoggingHook[] = [
  {
    /**
     * Called before GraphQL operation execution
     */
    logMessage: (message) => {
      const parsed = typeof message === 'string' ? { message } : message;
      return parsed;
    },
  },
];

/**
 * GraphQL operation logger
 * Wraps resolvers with timing and logging
 */
export function createGraphQLLogger(context: GraphQLContext) {
  const correlationId = context.correlationId || context.reply?.request?.correlationId || '';
  const reqLogger = context.log || logger.child({ correlationId });

  return {
    logQuery: (operationName: string, variables?: Record<string, unknown>) => {
      reqLogger.graphql('query', operationName, { variables });
    },

    logMutation: (operationName: string, variables?: Record<string, unknown>) => {
      reqLogger.graphql('mutation', operationName, { variables });
    },

    logSubscription: (operationName: string, variables?: Record<string, unknown>) => {
      reqLogger.graphql('subscription', operationName, { variables });
    },

    logResolver: async <T>(
      resolverName: string,
      fn: () => Promise<T>,
      meta?: Record<string, unknown>
    ): Promise<T> => {
      return reqLogger.time(`Resolver:${resolverName}`, fn, meta);
    },

    logError: (operationName: string, error: Error, variables?: Record<string, unknown>) => {
      reqLogger.error(`GraphQL operation failed: ${operationName}`, error, { variables });
    },
  };
}

/**
 * Resolver timing wrapper
 * Use to wrap resolver functions for automatic timing
 */
export function withResolverLogging<TArgs, TResult>(
  resolverName: string,
  resolver: (args: TArgs, context: GraphQLContext) => Promise<TResult>
) {
  return async (args: TArgs, context: GraphQLContext): Promise<TResult> => {
    const gqlLogger = createGraphQLLogger(context);
    return gqlLogger.logResolver(resolverName, () => resolver(args, context));
  };
}

/**
 * Batch resolver logging
 * For DataLoader-style batch resolvers
 */
export function withBatchLogging<TKey, TResult>(
  loaderName: string,
  batchFn: (keys: readonly TKey[]) => Promise<TResult[]>,
  context: GraphQLContext
) {
  return async (keys: readonly TKey[]): Promise<TResult[]> => {
    const gqlLogger = createGraphQLLogger(context);
    return gqlLogger.logResolver(`Batch:${loaderName}`, () => batchFn(keys), {
      batchSize: keys.length,
    });
  };
}

export default createGraphQLLogger;
