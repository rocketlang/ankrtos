/**
 * Fr8X Comprehensive Seed Script
 * Seeds complete test data: Users, Carriers, Shipments, Bids, Wallets, Transactions
 * Run after seed.ts: npx tsx prisma/seed-comprehensive.ts
 */
import { PrismaClient } from '../generated/prisma/index.js';
import bcrypt from 'bcryptjs';
const { hash } = bcrypt;

const prisma = new PrismaClient();

// Helper to generate random date within range
function randomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

// Helper to generate random amount within range
function randomAmount(min: number, max: number): number {
  return Math.round((min + Math.random() * (max - min)) * 100) / 100;
}

// Indian city coordinates for realistic locations
const indianCities = [
  { city: 'Mumbai', state: 'Maharashtra', lat: 19.076, lng: 72.8777 },
  { city: 'Delhi', state: 'Delhi', lat: 28.7041, lng: 77.1025 },
  { city: 'Bangalore', state: 'Karnataka', lat: 12.9716, lng: 77.5946 },
  { city: 'Chennai', state: 'Tamil Nadu', lat: 13.0827, lng: 80.2707 },
  { city: 'Kolkata', state: 'West Bengal', lat: 22.5726, lng: 88.3639 },
  { city: 'Hyderabad', state: 'Telangana', lat: 17.385, lng: 78.4867 },
  { city: 'Ahmedabad', state: 'Gujarat', lat: 23.0225, lng: 72.5714 },
  { city: 'Pune', state: 'Maharashtra', lat: 18.5204, lng: 73.8567 },
  { city: 'Jaipur', state: 'Rajasthan', lat: 26.9124, lng: 75.7873 },
  { city: 'Lucknow', state: 'Uttar Pradesh', lat: 26.8467, lng: 80.9462 },
  { city: 'Surat', state: 'Gujarat', lat: 21.1702, lng: 72.8311 },
  { city: 'Nagpur', state: 'Maharashtra', lat: 21.1458, lng: 79.0882 },
  { city: 'Indore', state: 'Madhya Pradesh', lat: 22.7196, lng: 75.8577 },
  { city: 'Coimbatore', state: 'Tamil Nadu', lat: 11.0168, lng: 76.9558 },
  { city: 'Visakhapatnam', state: 'Andhra Pradesh', lat: 17.6868, lng: 83.2185 },
];

// Cargo types for shipments
const cargoTypes = ['GENERAL', 'FMCG', 'TEXTILES', 'ELECTRONICS', 'MACHINERY', 'CHEMICALS', 'PHARMA', 'AGRICULTURE'];

// Vehicle types
const vehicleTypes = ['TATA_407', 'EICHER_14FT', 'EICHER_17FT', 'EICHER_19FT', 'CONTAINER_20FT', 'CONTAINER_40FT', 'TRAILER_40FT'];

async function main() {
  console.log('🚀 Starting Fr8X Comprehensive Seed...\n');

  // ═══════════════════════════════════════════════════════════════════════════════
  // SHIPPER ORGANIZATIONS & USERS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('🏢 Creating shipper organizations...');

  const shipperOrgs = [
    { code: 'FR8X-SHIP-001', name: 'TechCorp Industries', gstin: '27AABCT1234A1ZB', city: 'Mumbai', state: 'Maharashtra' },
    { code: 'FR8X-SHIP-002', name: 'Reliance FMCG', gstin: '27AABCR1234A1ZB', city: 'Mumbai', state: 'Maharashtra' },
    { code: 'FR8X-SHIP-003', name: 'Tata Steel Ltd', gstin: '24AABCT1234A1ZB', city: 'Jamshedpur', state: 'Jharkhand' },
    { code: 'FR8X-SHIP-004', name: 'Mahindra Logistics', gstin: '27AABCM1234A1ZB', city: 'Pune', state: 'Maharashtra' },
    { code: 'FR8X-SHIP-005', name: 'ITC Limited', gstin: '19AABCI1234A1ZB', city: 'Kolkata', state: 'West Bengal' },
  ];

  const createdShipperOrgs: any[] = [];
  for (const org of shipperOrgs) {
    const created = await prisma.organization.upsert({
      where: { code: org.code },
      update: {},
      create: {
        code: org.code,
        name: org.name,
        type: 'SHIPPER',
        gstin: org.gstin,
        panNumber: org.gstin.substring(2, 12),
        email: `contact@${org.name.toLowerCase().replace(/\s+/g, '')}.in`,
        phone: `+9198${Math.floor(10000000 + Math.random() * 89999999)}`,
        addressLine1: `${Math.floor(100 + Math.random() * 900)} Business Park`,
        city: org.city,
        state: org.state,
        postalCode: `${Math.floor(100000 + Math.random() * 899999)}`,
        verificationStatus: 'VERIFIED',
        trustScore: Math.floor(70 + Math.random() * 30),
      },
    });
    createdShipperOrgs.push(created);
  }
  console.log(`   ✓ ${shipperOrgs.length} shipper organizations created`);

  // Create users for shipper organizations
  console.log('👤 Creating shipper users...');
  const hashedPassword = await hash('User@123', 12);

  const shipperUsers = [];
  for (let i = 0; i < createdShipperOrgs.length; i++) {
    const org = createdShipperOrgs[i];
    const user = await prisma.user.upsert({
      where: { email: `shipper${i + 1}@fr8x.in` },
      update: {},
      create: {
        email: `shipper${i + 1}@fr8x.in`,
        phone: `+9199${String(i + 1).padStart(8, '0')}`,
        passwordHash: hashedPassword,
        firstName: ['Amit', 'Priya', 'Rahul', 'Sneha', 'Vikram'][i],
        lastName: ['Patel', 'Sharma', 'Kumar', 'Singh', 'Verma'][i],
        role: 'SHIPPER_ADMIN',
        emailVerified: true,
        phoneVerified: true,
        organizationId: org.id,
      },
    });
    shipperUsers.push(user);
  }
  console.log(`   ✓ ${shipperUsers.length} shipper users created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // CARRIER ORGANIZATIONS & CARRIERS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('🚚 Creating carrier organizations...');

  const carrierOrgs = [
    { code: 'FR8X-CARR-001', name: 'SpeedLink Transport', type: 'FLEET_OWNER', city: 'Delhi', vehicles: 50 },
    { code: 'FR8X-CARR-002', name: 'Gati Express', type: 'THREE_PL', city: 'Mumbai', vehicles: 120 },
    { code: 'FR8X-CARR-003', name: 'SafeShip Logistics', type: 'FREIGHT_FORWARDER', city: 'Chennai', vehicles: 35 },
    { code: 'FR8X-CARR-004', name: 'BlueGold Carriers', type: 'FLEET_OWNER', city: 'Bangalore', vehicles: 75 },
    { code: 'FR8X-CARR-005', name: 'RapidMove Express', type: 'COURIER', city: 'Hyderabad', vehicles: 40 },
    { code: 'FR8X-CARR-006', name: 'Northern Star Transport', type: 'FLEET_OWNER', city: 'Ludhiana', vehicles: 60 },
    { code: 'FR8X-CARR-007', name: 'Coastal Freight Services', type: 'NVOCC', city: 'Kochi', vehicles: 25 },
    { code: 'FR8X-CARR-008', name: 'Green Fleet Logistics', type: 'THREE_PL', city: 'Ahmedabad', vehicles: 90 },
  ];

  const createdCarriers: any[] = [];
  for (const org of carrierOrgs) {
    const carrierOrg = await prisma.organization.upsert({
      where: { code: org.code },
      update: {},
      create: {
        code: org.code,
        name: org.name,
        type: 'CARRIER',
        gstin: `${Math.floor(10 + Math.random() * 27)}AABC${org.code.substring(9)}A1ZB`,
        panNumber: `AABC${org.code.substring(9)}A`,
        email: `ops@${org.name.toLowerCase().replace(/\s+/g, '')}.in`,
        phone: `+9197${Math.floor(10000000 + Math.random() * 89999999)}`,
        addressLine1: `${Math.floor(1 + Math.random() * 999)} Industrial Area`,
        city: org.city,
        state: indianCities.find(c => c.city === org.city)?.state || 'Maharashtra',
        postalCode: `${Math.floor(100000 + Math.random() * 899999)}`,
        verificationStatus: 'VERIFIED',
        trustScore: Math.floor(60 + Math.random() * 40),
      },
    });

    const carrier = await prisma.carrier.upsert({
      where: { organizationId: carrierOrg.id },
      update: {},
      create: {
        code: `CARR-${org.code.substring(10)}`,
        organizationId: carrierOrg.id,
        type: org.type as any,
        status: 'ACTIVE',
        transportModes: ['ROAD'],
        vehicleTypes: vehicleTypes.slice(0, 4 + Math.floor(Math.random() * 3)) as any,
        cargoTypes: cargoTypes.slice(0, 4 + Math.floor(Math.random() * 4)),
        serviceCities: indianCities.slice(0, 5 + Math.floor(Math.random() * 10)).map(c => c.city),
        serviceStates: [...new Set(indianCities.slice(0, 10).map(c => c.state))],
        totalVehicles: org.vehicles,
        activeVehicles: Math.floor(org.vehicles * 0.8),
        totalDrivers: Math.floor(org.vehicles * 1.2),
        activeDrivers: Math.floor(org.vehicles * 0.9),
        totalTrips: Math.floor(100 + Math.random() * 500),
        completedTrips: Math.floor(95 + Math.random() * 480),
        onTimeDeliveryRate: 85 + Math.random() * 15,
        averageRating: 3.5 + Math.random() * 1.5,
        totalRatings: Math.floor(50 + Math.random() * 200),
        overallTrustScore: Math.floor(60 + Math.random() * 40),
      },
    });
    createdCarriers.push({ org: carrierOrg, carrier });
  }
  console.log(`   ✓ ${carrierOrgs.length} carriers created`);

  // Create carrier users
  console.log('👤 Creating carrier users...');
  const carrierUsers = [];
  for (let i = 0; i < createdCarriers.length; i++) {
    const { org } = createdCarriers[i];
    const user = await prisma.user.upsert({
      where: { email: `carrier${i + 1}@fr8x.in` },
      update: {},
      create: {
        email: `carrier${i + 1}@fr8x.in`,
        phone: `+9196${String(i + 1).padStart(8, '0')}`,
        passwordHash: hashedPassword,
        firstName: ['Rajesh', 'Suresh', 'Mohan', 'Kishore', 'Arun', 'Deepak', 'Sanjay', 'Prakash'][i],
        lastName: ['Yadav', 'Gupta', 'Sharma', 'Singh', 'Patel', 'Kumar', 'Verma', 'Joshi'][i],
        role: 'CARRIER_ADMIN',
        emailVerified: true,
        phoneVerified: true,
        organizationId: org.id,
      },
    });
    carrierUsers.push(user);
  }
  console.log(`   ✓ ${carrierUsers.length} carrier users created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // WALLETS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('💰 Creating wallets...');

  const allOrgs = [...createdShipperOrgs, ...createdCarriers.map(c => c.org)];
  const wallets: any[] = [];

  for (const org of allOrgs) {
    const wallet = await prisma.wallet.upsert({
      where: { organizationId: org.id },
      update: {},
      create: {
        code: `WLT-${org.code}`,
        organizationId: org.id,
        currency: 'INR',
        balance: randomAmount(50000, 500000),
        pendingCredits: randomAmount(0, 50000),
        pendingDebits: randomAmount(0, 30000),
        lifetimeCredits: randomAmount(500000, 5000000),
        lifetimeDebits: randomAmount(400000, 4500000),
        instantPayEnabled: Math.random() > 0.3,
        instantPayLimit: randomAmount(100000, 500000),
        dailyWithdrawalLimit: randomAmount(50000, 200000),
        status: 'ACTIVE',
      },
    });
    wallets.push(wallet);
  }
  console.log(`   ✓ ${wallets.length} wallets created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // ADDRESSES
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('📍 Creating addresses...');

  const addresses: any[] = [];
  for (let i = 0; i < 30; i++) {
    const cityData = indianCities[i % indianCities.length];
    const address = await prisma.address.create({
      data: {
        addressLine1: `${Math.floor(1 + Math.random() * 999)} ${['Industrial', 'Commercial', 'Business', 'Trade'][i % 4]} Complex`,
        addressLine2: `Sector ${Math.floor(1 + Math.random() * 50)}`,
        city: cityData.city,
        state: cityData.state,
        postalCode: `${Math.floor(100000 + Math.random() * 899999)}`,
        country: 'IN',
        latitude: cityData.lat + (Math.random() * 0.1 - 0.05),
        longitude: cityData.lng + (Math.random() * 0.1 - 0.05),
        geoHash: `geo${i}`,
        isVerified: Math.random() > 0.2,
        type: ['WAREHOUSE', 'FACTORY', 'PORT', 'TERMINAL'][i % 4] as any,
      },
    });
    addresses.push(address);
  }
  console.log(`   ✓ ${addresses.length} addresses created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // SPOT MARKET LOADS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('📦 Creating spot market loads...');

  const spotLoads: any[] = [];
  const now = new Date();
  const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const twoWeeksLater = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);

  for (let i = 0; i < 50; i++) {
    const originIdx = Math.floor(Math.random() * indianCities.length);
    let destIdx = Math.floor(Math.random() * indianCities.length);
    while (destIdx === originIdx) destIdx = Math.floor(Math.random() * indianCities.length);

    const origin = indianCities[originIdx];
    const dest = indianCities[destIdx];
    const shipperOrg = createdShipperOrgs[i % createdShipperOrgs.length];
    const vehicleType = vehicleTypes[Math.floor(Math.random() * vehicleTypes.length)];
    const cargoType = cargoTypes[Math.floor(Math.random() * cargoTypes.length)];

    const weight = Math.floor(5000 + Math.random() * 25000);
    const distance = Math.floor(200 + Math.random() * 1500);
    const baseRate = distance * 45; // Rs 45/km

    const statuses = ['OPEN', 'OPEN', 'OPEN', 'BIDDING', 'BIDDING', 'ASSIGNED', 'IN_TRANSIT', 'COMPLETED'];
    const status = statuses[Math.floor(Math.random() * statuses.length)];

    const load = await prisma.spotMarketLoad.create({
      data: {
        loadNumber: `SPOT${String(i + 1).padStart(6, '0')}`,
        shipperOrgId: shipperOrg.id,
        originCity: origin.city,
        originState: origin.state,
        originLatitude: origin.lat,
        originLongitude: origin.lng,
        destinationCity: dest.city,
        destinationState: dest.state,
        destinationLatitude: dest.lat,
        destinationLongitude: dest.lng,
        distanceKm: distance,
        vehicleType: vehicleType as any,
        vehicleCount: Math.floor(1 + Math.random() * 3),
        cargoType,
        cargoDescription: `${cargoType} goods - Load ${i + 1}`,
        weight,
        volume: Math.floor(weight / 300),
        isHazardous: cargoType === 'CHEMICALS',
        isTemperatureControlled: cargoType === 'PHARMA',
        targetRate: baseRate,
        maxRate: baseRate * 1.2,
        lowestBid: status !== 'OPEN' ? baseRate * (0.85 + Math.random() * 0.15) : null,
        bidCount: status !== 'OPEN' ? Math.floor(1 + Math.random() * 8) : 0,
        pickupDateFrom: randomDate(now, twoWeeksLater),
        pickupDateTo: randomDate(now, twoWeeksLater),
        deliveryDateFrom: randomDate(now, twoWeeksLater),
        deliveryDateTo: randomDate(now, twoWeeksLater),
        status: status as any,
        expiresAt: new Date(now.getTime() + (24 + Math.random() * 72) * 60 * 60 * 1000),
        isUrgent: Math.random() > 0.8,
        priority: Math.floor(1 + Math.random() * 5),
      },
    });
    spotLoads.push(load);
  }
  console.log(`   ✓ ${spotLoads.length} spot market loads created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // BIDS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('🏷️  Creating bids...');

  let bidCount = 0;
  for (const load of spotLoads) {
    if (load.status === 'OPEN') continue;

    const numBids = Math.floor(2 + Math.random() * 6);
    for (let b = 0; b < numBids; b++) {
      const carrier = createdCarriers[Math.floor(Math.random() * createdCarriers.length)];
      const bidAmount = load.targetRate * (0.8 + Math.random() * 0.25);

      const bidStatuses = ['PENDING', 'ACCEPTED', 'REJECTED', 'COUNTERED', 'WITHDRAWN'];
      const bidStatus = b === 0 && load.status !== 'BIDDING' ? 'ACCEPTED' : bidStatuses[Math.floor(Math.random() * bidStatuses.length)];

      await prisma.bid.create({
        data: {
          bidNumber: `BID${load.loadNumber}-${String(b + 1).padStart(3, '0')}`,
          spotMarketLoadId: load.id,
          carrierId: carrier.carrier.id,
          amount: bidAmount,
          currency: 'INR',
          transitDays: Math.floor(1 + Math.random() * 5),
          vehiclesOffered: Math.floor(1 + Math.random() * 3),
          validUntil: new Date(now.getTime() + 24 * 60 * 60 * 1000),
          notes: `Bid from ${carrier.org.name}`,
          status: bidStatus as any,
          submittedAt: randomDate(oneWeekAgo, now),
        },
      });
      bidCount++;
    }
  }
  console.log(`   ✓ ${bidCount} bids created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // SHIPMENTS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('📦 Creating shipments...');

  const shipments: any[] = [];
  const shipmentStatuses = ['BOOKED', 'CONFIRMED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED', 'COMPLETED'];

  for (let i = 0; i < 30; i++) {
    const originAddr = addresses[i % addresses.length];
    const destAddr = addresses[(i + 5) % addresses.length];
    const shipperOrg = createdShipperOrgs[i % createdShipperOrgs.length];
    const carrier = createdCarriers[i % createdCarriers.length];
    const status = shipmentStatuses[Math.floor(Math.random() * shipmentStatuses.length)];
    const amount = randomAmount(20000, 150000);

    const shipment = await prisma.shipment.create({
      data: {
        code: `SHP${String(i + 1).padStart(8, '0')}`,
        type: ['FTL', 'LTL', 'FCL'][Math.floor(Math.random() * 3)] as any,
        status: status as any,
        priority: ['STANDARD', 'EXPRESS', 'PRIORITY'][Math.floor(Math.random() * 3)] as any,
        originAddressId: originAddr.id,
        destinationAddressId: destAddr.id,
        shipperOrgId: shipperOrg.id,
        carrierId: carrier.carrier.id,
        pickupDateFrom: randomDate(oneWeekAgo, now),
        pickupDateTo: randomDate(now, twoWeeksLater),
        deliveryDateFrom: randomDate(now, twoWeeksLater),
        deliveryDateTo: randomDate(now, twoWeeksLater),
        weight: Math.floor(1000 + Math.random() * 25000),
        volume: Math.floor(5 + Math.random() * 50),
        cargoDescription: `${cargoTypes[i % cargoTypes.length]} shipment`,
        cargoValue: randomAmount(100000, 1000000),
        declaredValue: randomAmount(100000, 1000000),
        baseAmount: amount,
        taxAmount: amount * 0.18,
        totalAmount: amount * 1.18,
        currency: 'INR',
        paymentStatus: status === 'COMPLETED' ? 'PAID' : 'PENDING' as any,
        paymentTerms: ['PREPAID', 'COD', 'CREDIT'][Math.floor(Math.random() * 3)] as any,
        currentCity: indianCities[Math.floor(Math.random() * indianCities.length)].city,
        currentState: indianCities[Math.floor(Math.random() * indianCities.length)].state,
        trackingEnabled: true,
        podRequired: true,
      },
    });
    shipments.push(shipment);
  }
  console.log(`   ✓ ${shipments.length} shipments created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // WALLET TRANSACTIONS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('💳 Creating wallet transactions...');

  let txnCount = 0;
  for (const wallet of wallets) {
    const numTxns = 10 + Math.floor(Math.random() * 20);
    for (let t = 0; t < numTxns; t++) {
      const isCredit = Math.random() > 0.4;
      const txnTypes = isCredit
        ? ['FREIGHT_PAYMENT', 'REFUND', 'CREDIT_LINE', 'INSTANT_PAY']
        : ['PAYOUT', 'DEDUCTION', 'COMMISSION', 'PENALTY'];
      const type = txnTypes[Math.floor(Math.random() * txnTypes.length)];
      const amount = randomAmount(5000, 100000);

      await prisma.walletTransaction.create({
        data: {
          walletId: wallet.id,
          type: type as any,
          amount,
          currency: 'INR',
          direction: isCredit ? 'CREDIT' : 'DEBIT',
          status: 'COMPLETED',
          reference: `TXN${Date.now()}${t}`,
          description: `${type.replace(/_/g, ' ')} - Transaction ${t + 1}`,
          processedAt: randomDate(oneWeekAgo, now),
          balanceBefore: wallet.balance + (isCredit ? -amount : amount),
          balanceAfter: wallet.balance,
        },
      });
      txnCount++;
    }
  }
  console.log(`   ✓ ${txnCount} wallet transactions created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // NOTIFICATIONS
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('🔔 Creating notifications...');

  const allUsers = [...shipperUsers, ...carrierUsers];
  let notifCount = 0;

  for (const user of allUsers) {
    const numNotifs = 5 + Math.floor(Math.random() * 10);
    for (let n = 0; n < numNotifs; n++) {
      const notifTypes = ['SHIPMENT_UPDATE', 'BID_RECEIVED', 'BID_ACCEPTED', 'PAYMENT_RECEIVED', 'DOCUMENT_REQUIRED', 'SYSTEM'];
      const type = notifTypes[Math.floor(Math.random() * notifTypes.length)];

      await prisma.notification.create({
        data: {
          userId: user.id,
          type: type as any,
          title: `${type.replace(/_/g, ' ')} - Notification`,
          message: `This is a ${type.toLowerCase().replace(/_/g, ' ')} notification for testing.`,
          priority: ['LOW', 'MEDIUM', 'HIGH'][Math.floor(Math.random() * 3)] as any,
          isRead: Math.random() > 0.5,
          isArchived: Math.random() > 0.9,
          channel: ['IN_APP', 'EMAIL', 'SMS', 'PUSH'][Math.floor(Math.random() * 4)] as any,
        },
      });
      notifCount++;
    }
  }
  console.log(`   ✓ ${notifCount} notifications created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // POOL RESOURCES (Available Vehicles)
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('🚛 Creating pool resources...');

  let poolCount = 0;
  for (const { carrier, org } of createdCarriers) {
    const numResources = 5 + Math.floor(Math.random() * 10);
    for (let r = 0; r < numResources; r++) {
      const cityData = indianCities[Math.floor(Math.random() * indianCities.length)];
      const destCity = indianCities[Math.floor(Math.random() * indianCities.length)];

      await prisma.poolResource.create({
        data: {
          carrierId: carrier.id,
          vehicleType: vehicleTypes[Math.floor(Math.random() * vehicleTypes.length)] as any,
          currentCity: cityData.city,
          currentState: cityData.state,
          currentLatitude: cityData.lat,
          currentLongitude: cityData.lng,
          availableFrom: randomDate(now, twoWeeksLater),
          availableTo: randomDate(twoWeeksLater, new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)),
          destinationPreferences: [destCity.city],
          capacityWeight: Math.floor(10000 + Math.random() * 20000),
          capacityVolume: Math.floor(20 + Math.random() * 60),
          expectedRate: randomAmount(15000, 60000),
          status: 'AVAILABLE' as any,
          notes: `Available vehicle from ${org.name}`,
        },
      });
      poolCount++;
    }
  }
  console.log(`   ✓ ${poolCount} pool resources created`);

  // ═══════════════════════════════════════════════════════════════════════════════
  // SUMMARY
  // ═══════════════════════════════════════════════════════════════════════════════
  console.log('\n✅ Fr8X Comprehensive Seed completed successfully!\n');
  console.log('Summary:');
  console.log(`   - ${shipperOrgs.length} shipper organizations`);
  console.log(`   - ${shipperUsers.length} shipper users`);
  console.log(`   - ${carrierOrgs.length} carrier organizations`);
  console.log(`   - ${carrierUsers.length} carrier users`);
  console.log(`   - ${wallets.length} wallets`);
  console.log(`   - ${addresses.length} addresses`);
  console.log(`   - ${spotLoads.length} spot market loads`);
  console.log(`   - ${bidCount} bids`);
  console.log(`   - ${shipments.length} shipments`);
  console.log(`   - ${txnCount} wallet transactions`);
  console.log(`   - ${notifCount} notifications`);
  console.log(`   - ${poolCount} pool resources`);
  console.log('\nTest Credentials:');
  console.log('   Admin:     admin@fr8x.in / Admin@123');
  console.log('   Shippers:  shipper[1-5]@fr8x.in / User@123');
  console.log('   Carriers:  carrier[1-8]@fr8x.in / User@123\n');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
