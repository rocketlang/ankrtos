import { test, expect } from '@playwright/test';

/**
 * Post Load E2E Tests
 * Tests for the load posting wizard flow
 */

test.describe('Post Load Wizard', () => {
  // Helper to login
  const login = async (page: any) => {
    await page.goto('/exchange/login');
    await page.getByPlaceholder(/email/i).fill('admin@fr8x.in');
    await page.getByPlaceholder(/password/i).fill('Admin@123');
    await page.getByRole('button', { name: /login|sign in/i }).click();
    await page.waitForURL(/\/exchange\/?$/, { timeout: 15000 });
  };

  test.beforeEach(async ({ page }) => {
    await login(page);
  });

  test.describe('Post Load Page', () => {
    test('should display post load page', async ({ page }) => {
      await page.goto('/exchange/board/post');

      await expect(page).toHaveURL(/\/exchange\/board\/post/);
      await expect(page.getByText(/post.*load|new.*load|create.*shipment/i).first()).toBeVisible({ timeout: 10000 });
    });

    test('should display origin section', async ({ page }) => {
      await page.goto('/exchange/board/post');

      await expect(
        page.getByText(/origin|pickup|from/i).first()
      ).toBeVisible({ timeout: 10000 });
    });

    test('should display destination section', async ({ page }) => {
      await page.goto('/exchange/board/post');

      await expect(
        page.getByText(/destination|delivery|to/i).first()
      ).toBeVisible({ timeout: 10000 });
    });
  });

  test.describe('Location Selection', () => {
    test('should enter origin city', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const originInput = page.getByPlaceholder(/origin|pickup.*city|from/i).or(page.getByLabel(/origin/i));
      if (await originInput.isVisible({ timeout: 5000 })) {
        await originInput.fill('Mumbai');

        // Should show autocomplete or accept input
        await page.waitForTimeout(500);
      }
    });

    test('should enter destination city', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const destInput = page.getByPlaceholder(/destination|delivery.*city/i).or(page.getByLabel(/destination/i));
      if (await destInput.isVisible({ timeout: 5000 })) {
        await destInput.fill('Delhi');
        await page.waitForTimeout(500);
      }
    });

    test('should select state for origin', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const stateSelect = page.getByLabel(/origin.*state/i).or(page.getByPlaceholder(/state/i).first());
      if (await stateSelect.isVisible({ timeout: 5000 })) {
        await stateSelect.click();

        // Select Maharashtra
        const option = page.getByRole('option', { name: /maharashtra/i });
        if (await option.isVisible({ timeout: 3000 })) {
          await option.click();
        }
      }
    });
  });

  test.describe('Cargo Details', () => {
    test('should enter cargo description', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const cargoInput = page.getByPlaceholder(/cargo|goods|description/i).or(page.getByLabel(/cargo/i));
      if (await cargoInput.isVisible({ timeout: 5000 })) {
        await cargoInput.fill('Electronics - Laptops and Monitors');
      }
    });

    test('should enter weight', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const weightInput = page.getByPlaceholder(/weight/i).or(page.getByLabel(/weight/i));
      if (await weightInput.isVisible({ timeout: 5000 })) {
        await weightInput.fill('5000');
      }
    });

    test('should select vehicle type', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const vehicleSelect = page.getByRole('combobox', { name: /vehicle/i }).or(page.getByLabel(/vehicle.*type/i));
      if (await vehicleSelect.isVisible({ timeout: 5000 })) {
        await vehicleSelect.click();

        const option = page.getByRole('option').first();
        if (await option.isVisible({ timeout: 3000 })) {
          await option.click();
        }
      }
    });

    test('should toggle hazardous materials', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const hazmatToggle = page.getByRole('switch', { name: /hazardous/i }).or(page.getByLabel(/hazardous/i));
      if (await hazmatToggle.isVisible({ timeout: 5000 })) {
        await hazmatToggle.click();
      }
    });
  });

  test.describe('Pricing & Schedule', () => {
    test('should enter budget/rate', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const budgetInput = page.getByPlaceholder(/budget|rate|price/i).or(page.getByLabel(/budget/i));
      if (await budgetInput.isVisible({ timeout: 5000 })) {
        await budgetInput.fill('50000');
      }
    });

    test('should select pickup date', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const dateInput = page.getByLabel(/pickup.*date/i).or(page.getByPlaceholder(/date/i));
      if (await dateInput.isVisible({ timeout: 5000 })) {
        await dateInput.click();

        // Select a future date
        const nextWeek = page.getByRole('gridcell', { name: /[2-3][0-9]/ }).first();
        if (await nextWeek.isVisible({ timeout: 3000 })) {
          await nextWeek.click();
        }
      }
    });
  });

  test.describe('Form Validation', () => {
    test('should show validation errors for empty form', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const submitBtn = page.getByRole('button', { name: /post|submit|create/i });
      if (await submitBtn.isVisible({ timeout: 5000 })) {
        await submitBtn.click();

        // Should show validation errors
        await expect(
          page.getByText(/required|fill|enter/i).first()
        ).toBeVisible({ timeout: 5000 });
      }
    });

    test('should validate weight is positive', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const weightInput = page.getByPlaceholder(/weight/i).or(page.getByLabel(/weight/i));
      if (await weightInput.isVisible({ timeout: 5000 })) {
        await weightInput.fill('-100');

        const submitBtn = page.getByRole('button', { name: /post|submit|create/i });
        await submitBtn.click();

        // Should show validation error
        await expect(
          page.getByText(/positive|invalid|must be/i)
        ).toBeVisible({ timeout: 5000 });
      }
    });

    test('should validate pickup date is in future', async ({ page }) => {
      await page.goto('/exchange/board/post');

      // Fill some required fields
      const originInput = page.getByPlaceholder(/origin/i).first();
      if (await originInput.isVisible({ timeout: 5000 })) {
        await originInput.fill('Mumbai');
      }

      // Try to submit
      const submitBtn = page.getByRole('button', { name: /post|submit|create/i });
      if (await submitBtn.isVisible({ timeout: 5000 })) {
        await submitBtn.click();

        // Should show date validation or other required field errors
        await expect(
          page.getByText(/required|date|pickup/i).first()
        ).toBeVisible({ timeout: 5000 });
      }
    });
  });

  test.describe('Successful Submission', () => {
    test('should fill complete form and submit', async ({ page }) => {
      await page.goto('/exchange/board/post');

      // Fill origin
      const originInput = page.getByPlaceholder(/origin.*city/i).or(page.getByLabel(/origin/i).first());
      if (await originInput.isVisible({ timeout: 5000 })) {
        await originInput.fill('Mumbai');
      }

      // Fill destination
      const destInput = page.getByPlaceholder(/destination/i).or(page.getByLabel(/destination/i).first());
      if (await destInput.isVisible({ timeout: 5000 })) {
        await destInput.fill('Delhi');
      }

      // Fill cargo
      const cargoInput = page.getByPlaceholder(/cargo|goods/i).or(page.getByLabel(/cargo/i));
      if (await cargoInput.isVisible({ timeout: 5000 })) {
        await cargoInput.fill('General Cargo');
      }

      // Fill weight
      const weightInput = page.getByPlaceholder(/weight/i).or(page.getByLabel(/weight/i));
      if (await weightInput.isVisible({ timeout: 5000 })) {
        await weightInput.fill('5000');
      }

      // Check for form completion indicator
      const formProgress = page.locator('[data-testid="form-progress"]').or(page.getByRole('progressbar'));
      if (await formProgress.isVisible({ timeout: 3000 })) {
        // Form has progress indicator
      }
    });
  });

  test.describe('Cancel Flow', () => {
    test('should navigate back on cancel', async ({ page }) => {
      await page.goto('/exchange/board/post');

      const cancelBtn = page.getByRole('button', { name: /cancel|back/i });
      if (await cancelBtn.isVisible({ timeout: 5000 })) {
        await cancelBtn.click();

        // Should go back to board or show confirmation
        await expect(
          page.getByText(/load board|discard|are you sure/i)
        ).toBeVisible({ timeout: 5000 });
      }
    });
  });
});
