import { test, expect } from '@playwright/test';

/**
 * Authentication E2E Tests
 * Tests for login, register, and protected routes
 */

test.describe('Authentication', () => {
  test.beforeEach(async ({ page }) => {
    // Clear any existing auth state
    await page.context().clearCookies();
    await page.evaluate(() => localStorage.clear());
  });

  test.describe('Login Flow', () => {
    test('should display login page correctly', async ({ page }) => {
      await page.goto('/exchange/login');

      await expect(page.getByRole('heading', { name: /login|sign in/i })).toBeVisible();
      await expect(page.getByPlaceholder(/email/i)).toBeVisible();
      await expect(page.getByPlaceholder(/password/i)).toBeVisible();
      await expect(page.getByRole('button', { name: /login|sign in/i })).toBeVisible();
    });

    test('should show validation errors for empty form', async ({ page }) => {
      await page.goto('/exchange/login');

      await page.getByRole('button', { name: /login|sign in/i }).click();

      // Should show validation messages
      await expect(page.getByText(/email.*required|please enter/i)).toBeVisible();
    });

    test('should show error for invalid credentials', async ({ page }) => {
      await page.goto('/exchange/login');

      await page.getByPlaceholder(/email/i).fill('invalid@test.com');
      await page.getByPlaceholder(/password/i).fill('wrongpassword');
      await page.getByRole('button', { name: /login|sign in/i }).click();

      // Should show error message
      await expect(page.getByText(/invalid|incorrect|failed/i)).toBeVisible({ timeout: 10000 });
    });

    test('should login successfully with valid credentials', async ({ page }) => {
      await page.goto('/exchange/login');

      await page.getByPlaceholder(/email/i).fill('admin@fr8x.in');
      await page.getByPlaceholder(/password/i).fill('Admin@123');
      await page.getByRole('button', { name: /login|sign in/i }).click();

      // Should redirect to dashboard
      await expect(page).toHaveURL(/\/exchange\/?$/, { timeout: 15000 });
    });

    test('should navigate to register page', async ({ page }) => {
      await page.goto('/exchange/login');

      await page.getByRole('link', { name: /register|sign up|create account/i }).click();

      await expect(page).toHaveURL(/\/exchange\/register/);
    });
  });

  test.describe('Register Flow', () => {
    test('should display register page correctly', async ({ page }) => {
      await page.goto('/exchange/register');

      await expect(page.getByRole('heading', { name: /register|sign up|create/i })).toBeVisible();
      await expect(page.getByPlaceholder(/email/i)).toBeVisible();
      await expect(page.getByPlaceholder(/password/i).first()).toBeVisible();
    });

    test('should show validation errors for invalid email', async ({ page }) => {
      await page.goto('/exchange/register');

      await page.getByPlaceholder(/email/i).fill('notanemail');
      await page.getByPlaceholder(/password/i).first().fill('Test@123');

      await page.getByRole('button', { name: /register|sign up|create/i }).click();

      await expect(page.getByText(/valid email|invalid email/i)).toBeVisible();
    });

    test('should navigate to login page', async ({ page }) => {
      await page.goto('/exchange/register');

      await page.getByRole('link', { name: /login|sign in|already have/i }).click();

      await expect(page).toHaveURL(/\/exchange\/login/);
    });
  });

  test.describe('Protected Routes', () => {
    test('should redirect to login when accessing protected route', async ({ page }) => {
      await page.goto('/exchange/board');

      // Should redirect to login or show login prompt
      await expect(page).toHaveURL(/\/(login|exchange\/login)|exchange\/board/);
    });

    test('should access protected route after login', async ({ page }) => {
      // Login first
      await page.goto('/exchange/login');
      await page.getByPlaceholder(/email/i).fill('admin@fr8x.in');
      await page.getByPlaceholder(/password/i).fill('Admin@123');
      await page.getByRole('button', { name: /login|sign in/i }).click();

      // Wait for navigation
      await page.waitForURL(/\/exchange\/?$/, { timeout: 15000 });

      // Now access protected route
      await page.goto('/exchange/board');

      await expect(page).toHaveURL(/\/exchange\/board/);
      await expect(page.getByText(/load board|available loads/i)).toBeVisible({ timeout: 10000 });
    });
  });

  test.describe('Logout', () => {
    test('should logout successfully', async ({ page }) => {
      // Login first
      await page.goto('/exchange/login');
      await page.getByPlaceholder(/email/i).fill('admin@fr8x.in');
      await page.getByPlaceholder(/password/i).fill('Admin@123');
      await page.getByRole('button', { name: /login|sign in/i }).click();

      await page.waitForURL(/\/exchange\/?$/, { timeout: 15000 });

      // Find and click logout
      const userMenu = page.getByRole('button', { name: /menu|user|profile/i }).or(page.locator('[data-testid="user-menu"]'));
      if (await userMenu.isVisible()) {
        await userMenu.click();
        await page.getByRole('button', { name: /logout|sign out/i }).click();
      }

      // Should be logged out - check for login button or redirect
      await expect(page.getByRole('link', { name: /login/i }).or(page.getByRole('button', { name: /login/i }))).toBeVisible({ timeout: 10000 });
    });
  });
});
