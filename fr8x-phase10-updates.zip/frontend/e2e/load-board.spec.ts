import { test, expect } from '@playwright/test';

/**
 * Load Board E2E Tests
 * Tests for browsing loads, viewing details, and placing bids
 */

test.describe('Load Board', () => {
  // Helper to login before tests
  const login = async (page: any) => {
    await page.goto('/exchange/login');
    await page.getByPlaceholder(/email/i).fill('admin@fr8x.in');
    await page.getByPlaceholder(/password/i).fill('Admin@123');
    await page.getByRole('button', { name: /login|sign in/i }).click();
    await page.waitForURL(/\/exchange\/?$/, { timeout: 15000 });
  };

  test.describe('Load Board Page', () => {
    test.beforeEach(async ({ page }) => {
      await login(page);
    });

    test('should display load board with available loads', async ({ page }) => {
      await page.goto('/exchange/board');

      await expect(page).toHaveURL(/\/exchange\/board/);
      // Should show load board header or load cards
      await expect(
        page.getByText(/load board|available loads|spot market/i).or(page.locator('[data-testid="load-card"]').first())
      ).toBeVisible({ timeout: 10000 });
    });

    test('should display load cards with key information', async ({ page }) => {
      await page.goto('/exchange/board');

      // Wait for loads to load
      await page.waitForTimeout(2000);

      // Check for load information (may be in cards or list)
      const loadContainer = page.locator('[data-testid="load-card"]').or(page.locator('.load-card')).or(page.getByRole('article'));

      if (await loadContainer.first().isVisible()) {
        // Should show route information
        await expect(page.getByText(/→|to|from/i).first()).toBeVisible();
      }
    });

    test('should filter loads by origin city', async ({ page }) => {
      await page.goto('/exchange/board');

      // Look for filter input
      const originFilter = page.getByPlaceholder(/origin|from/i).or(page.getByLabel(/origin/i));
      if (await originFilter.isVisible()) {
        await originFilter.fill('Mumbai');

        // Wait for filter to apply
        await page.waitForTimeout(1000);

        // Results should update
        await expect(page.getByText(/mumbai/i)).toBeVisible();
      }
    });

    test('should filter loads by destination city', async ({ page }) => {
      await page.goto('/exchange/board');

      const destFilter = page.getByPlaceholder(/destination|to/i).or(page.getByLabel(/destination/i));
      if (await destFilter.isVisible()) {
        await destFilter.fill('Delhi');
        await page.waitForTimeout(1000);
      }
    });

    test('should filter loads by vehicle type', async ({ page }) => {
      await page.goto('/exchange/board');

      const vehicleFilter = page.getByRole('combobox', { name: /vehicle/i }).or(page.getByLabel(/vehicle type/i));
      if (await vehicleFilter.isVisible()) {
        await vehicleFilter.click();
        // Select a vehicle type
        const option = page.getByRole('option').first();
        if (await option.isVisible()) {
          await option.click();
        }
      }
    });
  });

  test.describe('Load Detail Page', () => {
    test.beforeEach(async ({ page }) => {
      await login(page);
    });

    test('should navigate to load detail page', async ({ page }) => {
      await page.goto('/exchange/board');

      // Wait for loads
      await page.waitForTimeout(2000);

      // Click on a load card
      const loadCard = page.locator('[data-testid="load-card"]').or(page.locator('.load-card')).or(page.getByRole('article'));
      if (await loadCard.first().isVisible()) {
        await loadCard.first().click();

        // Should navigate to detail page
        await expect(page).toHaveURL(/\/exchange\/board\/[a-zA-Z0-9-]+/);
      }
    });

    test('should display load details', async ({ page }) => {
      // Go directly to a load detail if we know one exists
      await page.goto('/exchange/board');
      await page.waitForTimeout(2000);

      const loadCard = page.locator('[data-testid="load-card"]').or(page.locator('.load-card')).first();
      if (await loadCard.isVisible()) {
        await loadCard.click();
        await page.waitForURL(/\/exchange\/board\/[a-zA-Z0-9-]+/, { timeout: 5000 });

        // Should show detailed information
        await expect(
          page.getByText(/details|origin|destination|weight|cargo/i).first()
        ).toBeVisible({ timeout: 5000 });
      }
    });

    test('should display bid section', async ({ page }) => {
      await page.goto('/exchange/board');
      await page.waitForTimeout(2000);

      const loadCard = page.locator('[data-testid="load-card"]').first();
      if (await loadCard.isVisible()) {
        await loadCard.click();
        await page.waitForURL(/\/exchange\/board\/[a-zA-Z0-9-]+/, { timeout: 5000 });

        // Should show bid section
        await expect(
          page.getByText(/bid|place bid|current bids/i).first()
        ).toBeVisible({ timeout: 5000 });
      }
    });
  });

  test.describe('Place Bid Flow', () => {
    test.beforeEach(async ({ page }) => {
      await login(page);
    });

    test('should open bid modal when clicking place bid', async ({ page }) => {
      await page.goto('/exchange/board');
      await page.waitForTimeout(2000);

      // Find and click place bid button
      const placeBidBtn = page.getByRole('button', { name: /place bid|bid now/i }).first();
      if (await placeBidBtn.isVisible()) {
        await placeBidBtn.click();

        // Should show bid modal/form
        await expect(
          page.getByRole('dialog').or(page.locator('[data-testid="bid-modal"]')).or(page.getByPlaceholder(/amount|bid/i))
        ).toBeVisible({ timeout: 5000 });
      }
    });

    test('should validate bid amount', async ({ page }) => {
      await page.goto('/exchange/board');
      await page.waitForTimeout(2000);

      const placeBidBtn = page.getByRole('button', { name: /place bid|bid now/i }).first();
      if (await placeBidBtn.isVisible()) {
        await placeBidBtn.click();

        // Enter invalid bid (0 or negative)
        const bidInput = page.getByPlaceholder(/amount/i).or(page.getByLabel(/bid amount/i));
        if (await bidInput.isVisible()) {
          await bidInput.fill('0');
          await page.getByRole('button', { name: /submit|confirm|place/i }).click();

          // Should show validation error
          await expect(page.getByText(/invalid|minimum|must be/i)).toBeVisible({ timeout: 5000 });
        }
      }
    });

    test('should submit bid successfully', async ({ page }) => {
      await page.goto('/exchange/board');
      await page.waitForTimeout(2000);

      const placeBidBtn = page.getByRole('button', { name: /place bid|bid now/i }).first();
      if (await placeBidBtn.isVisible()) {
        await placeBidBtn.click();

        const bidInput = page.getByPlaceholder(/amount/i).or(page.getByLabel(/bid amount/i));
        if (await bidInput.isVisible()) {
          await bidInput.fill('50000');

          await page.getByRole('button', { name: /submit|confirm|place/i }).click();

          // Should show success message
          await expect(
            page.getByText(/success|placed|submitted/i).or(page.locator('.toast'))
          ).toBeVisible({ timeout: 10000 });
        }
      }
    });
  });

  test.describe('Post Load Flow', () => {
    test.beforeEach(async ({ page }) => {
      await login(page);
    });

    test('should navigate to post load page', async ({ page }) => {
      await page.goto('/exchange/board/post');

      await expect(page).toHaveURL(/\/exchange\/board\/post/);
      await expect(page.getByText(/post.*load|new.*load|create/i).first()).toBeVisible({ timeout: 5000 });
    });

    test('should display load posting form', async ({ page }) => {
      await page.goto('/exchange/board/post');

      // Should show form fields
      await expect(
        page.getByLabel(/origin/i).or(page.getByPlaceholder(/origin/i))
      ).toBeVisible({ timeout: 5000 });

      await expect(
        page.getByLabel(/destination/i).or(page.getByPlaceholder(/destination/i))
      ).toBeVisible({ timeout: 5000 });
    });

    test('should validate required fields', async ({ page }) => {
      await page.goto('/exchange/board/post');

      // Try to submit empty form
      const submitBtn = page.getByRole('button', { name: /post|submit|create/i });
      if (await submitBtn.isVisible()) {
        await submitBtn.click();

        // Should show validation errors
        await expect(page.getByText(/required|fill|enter/i).first()).toBeVisible({ timeout: 5000 });
      }
    });
  });
});
