import { test, expect } from '@playwright/test';

/**
 * Wallet E2E Tests
 * Tests for wallet transactions, balance, and instant pay
 */

test.describe('Wallet', () => {
  // Helper to login
  const login = async (page: any) => {
    await page.goto('/exchange/login');
    await page.getByPlaceholder(/email/i).fill('admin@fr8x.in');
    await page.getByPlaceholder(/password/i).fill('Admin@123');
    await page.getByRole('button', { name: /login|sign in/i }).click();
    await page.waitForURL(/\/exchange\/?$/, { timeout: 15000 });
  };

  test.beforeEach(async ({ page }) => {
    await login(page);
  });

  test.describe('Wallet Page', () => {
    test('should display wallet page', async ({ page }) => {
      await page.goto('/exchange/wallet');

      await expect(page).toHaveURL(/\/exchange\/wallet/);
      await expect(page.getByText(/wallet|balance/i).first()).toBeVisible({ timeout: 10000 });
    });

    test('should display wallet balance', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Should show balance section
      await expect(
        page.getByText(/available.*balance|total.*balance/i).or(page.locator('[data-testid="wallet-balance"]'))
      ).toBeVisible({ timeout: 10000 });
    });

    test('should display transaction history', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Should show transactions section
      await expect(
        page.getByText(/transaction|history|recent/i).first()
      ).toBeVisible({ timeout: 10000 });
    });
  });

  test.describe('Withdrawal Flow', () => {
    test('should open withdrawal modal', async ({ page }) => {
      await page.goto('/exchange/wallet');

      const withdrawBtn = page.getByRole('button', { name: /withdraw|cash out/i });
      if (await withdrawBtn.isVisible({ timeout: 5000 })) {
        await withdrawBtn.click();

        // Should show withdrawal form
        await expect(
          page.getByRole('dialog').or(page.getByPlaceholder(/amount/i))
        ).toBeVisible({ timeout: 5000 });
      }
    });

    test('should validate minimum withdrawal amount', async ({ page }) => {
      await page.goto('/exchange/wallet');

      const withdrawBtn = page.getByRole('button', { name: /withdraw|cash out/i });
      if (await withdrawBtn.isVisible({ timeout: 5000 })) {
        await withdrawBtn.click();

        const amountInput = page.getByPlaceholder(/amount/i).or(page.getByLabel(/amount/i));
        if (await amountInput.isVisible({ timeout: 3000 })) {
          await amountInput.fill('10');

          const submitBtn = page.getByRole('button', { name: /withdraw|submit|confirm/i }).last();
          await submitBtn.click();

          // Should show minimum amount error
          await expect(
            page.getByText(/minimum|at least|too low/i)
          ).toBeVisible({ timeout: 5000 });
        }
      }
    });

    test('should show bank/UPI selection', async ({ page }) => {
      await page.goto('/exchange/wallet');

      const withdrawBtn = page.getByRole('button', { name: /withdraw|cash out/i });
      if (await withdrawBtn.isVisible({ timeout: 5000 })) {
        await withdrawBtn.click();

        // Should show payment method options
        await expect(
          page.getByText(/bank|upi|payment method/i).first()
        ).toBeVisible({ timeout: 5000 });
      }
    });
  });

  test.describe('Instant Pay', () => {
    test('should display instant pay section', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Look for instant pay toggle or section
      const instantPaySection = page.getByText(/instant pay|quick pay/i).first();
      if (await instantPaySection.isVisible({ timeout: 5000 })) {
        await expect(instantPaySection).toBeVisible();
      }
    });

    test('should show instant pay limit', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Look for limit display
      const limitText = page.getByText(/limit|daily.*limit/i).first();
      if (await limitText.isVisible({ timeout: 5000 })) {
        await expect(limitText).toBeVisible();
      }
    });
  });

  test.describe('Transaction Details', () => {
    test('should show transaction list', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Wait for transactions to load
      await page.waitForTimeout(2000);

      // Look for transaction items
      const transactionItem = page.locator('[data-testid="transaction-item"]').or(page.locator('.transaction-item'));
      if (await transactionItem.first().isVisible({ timeout: 5000 })) {
        await expect(transactionItem.first()).toBeVisible();
      }
    });

    test('should filter transactions by type', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Look for filter dropdown
      const filterDropdown = page.getByRole('combobox', { name: /filter|type/i }).or(page.getByLabel(/filter/i));
      if (await filterDropdown.isVisible({ timeout: 5000 })) {
        await filterDropdown.click();

        // Select a filter option
        const creditOption = page.getByRole('option', { name: /credit|earning/i });
        if (await creditOption.isVisible({ timeout: 3000 })) {
          await creditOption.click();
        }
      }
    });

    test('should show transaction date range filter', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Look for date filter
      const dateFilter = page.getByPlaceholder(/date/i).or(page.getByLabel(/date.*range/i));
      if (await dateFilter.isVisible({ timeout: 5000 })) {
        await expect(dateFilter).toBeVisible();
      }
    });
  });

  test.describe('Bank Account Management', () => {
    test('should show linked accounts', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Navigate to settings or accounts section
      const settingsBtn = page.getByRole('button', { name: /settings|accounts|manage/i });
      if (await settingsBtn.isVisible({ timeout: 5000 })) {
        await settingsBtn.click();

        await expect(
          page.getByText(/bank.*account|linked.*account/i).first()
        ).toBeVisible({ timeout: 5000 });
      }
    });

    test('should show add account option', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Look for add account button
      const addAccountBtn = page.getByRole('button', { name: /add.*account|link.*account|add.*bank/i });
      if (await addAccountBtn.isVisible({ timeout: 5000 })) {
        await expect(addAccountBtn).toBeVisible();
      }
    });
  });

  test.describe('Wallet Stats', () => {
    test('should display total earnings', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Look for earnings stat
      await expect(
        page.getByText(/total.*earning|lifetime.*earning/i).or(page.locator('[data-testid="total-earnings"]'))
      ).toBeVisible({ timeout: 10000 });
    });

    test('should display pending balance', async ({ page }) => {
      await page.goto('/exchange/wallet');

      // Look for pending balance
      await expect(
        page.getByText(/pending|processing/i).first()
      ).toBeVisible({ timeout: 10000 });
    });
  });
});
