/**
 * Fr8X Infinite Scroll Hook
 * Provides infinite scroll functionality with intersection observer
 */

import { useCallback, useEffect, useRef, useState } from 'react';

export interface InfiniteScrollOptions {
  /** Threshold for intersection observer (0-1) */
  threshold?: number;
  /** Root margin for intersection observer */
  rootMargin?: string;
  /** Whether to enable infinite scroll */
  enabled?: boolean;
  /** Callback when end is reached */
  onLoadMore?: () => void | Promise<void>;
  /** Whether there are more items to load */
  hasMore?: boolean;
  /** Whether currently loading */
  isLoading?: boolean;
}

export interface InfiniteScrollResult {
  /** Ref to attach to the sentinel element */
  sentinelRef: React.RefObject<HTMLDivElement>;
  /** Whether the sentinel is visible */
  isIntersecting: boolean;
  /** Current page number (1-indexed) */
  page: number;
  /** Reset pagination */
  reset: () => void;
  /** Manually trigger load more */
  loadMore: () => void;
}

/**
 * Hook for implementing infinite scroll with intersection observer
 */
export function useInfiniteScroll(options: InfiniteScrollOptions = {}): InfiniteScrollResult {
  const {
    threshold = 0.1,
    rootMargin = '100px',
    enabled = true,
    onLoadMore,
    hasMore = true,
    isLoading = false,
  } = options;

  const sentinelRef = useRef<HTMLDivElement>(null);
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [page, setPage] = useState(1);
  const loadingRef = useRef(isLoading);
  const hasMoreRef = useRef(hasMore);

  // Keep refs in sync with props
  useEffect(() => {
    loadingRef.current = isLoading;
  }, [isLoading]);

  useEffect(() => {
    hasMoreRef.current = hasMore;
  }, [hasMore]);

  // Load more callback
  const loadMore = useCallback(() => {
    if (loadingRef.current || !hasMoreRef.current) return;

    if (onLoadMore) {
      const result = onLoadMore();
      if (result instanceof Promise) {
        result.then(() => {
          setPage((p) => p + 1);
        });
      } else {
        setPage((p) => p + 1);
      }
    }
  }, [onLoadMore]);

  // Reset pagination
  const reset = useCallback(() => {
    setPage(1);
    setIsIntersecting(false);
  }, []);

  // Set up intersection observer
  useEffect(() => {
    if (!enabled || !sentinelRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        setIsIntersecting(entry.isIntersecting);

        if (entry.isIntersecting && !loadingRef.current && hasMoreRef.current) {
          loadMore();
        }
      },
      {
        threshold,
        rootMargin,
      }
    );

    observer.observe(sentinelRef.current);

    return () => {
      observer.disconnect();
    };
  }, [enabled, threshold, rootMargin, loadMore]);

  return {
    sentinelRef,
    isIntersecting,
    page,
    reset,
    loadMore,
  };
}

/**
 * Hook for cursor-based infinite scroll (more efficient for large datasets)
 */
export interface CursorPaginationOptions<T> {
  /** Initial data */
  initialData?: T[];
  /** Page size */
  pageSize?: number;
  /** Function to get cursor from last item */
  getCursor?: (item: T) => string;
  /** Function to fetch more data */
  fetchMore: (cursor: string | null, limit: number) => Promise<{
    items: T[];
    hasMore: boolean;
    nextCursor: string | null;
  }>;
  /** Whether to enable */
  enabled?: boolean;
}

export interface CursorPaginationResult<T> {
  /** All loaded items */
  items: T[];
  /** Whether loading */
  isLoading: boolean;
  /** Whether there are more items */
  hasMore: boolean;
  /** Current cursor */
  cursor: string | null;
  /** Load more items */
  loadMore: () => Promise<void>;
  /** Reset and refetch */
  reset: () => Promise<void>;
  /** Sentinel ref for intersection observer */
  sentinelRef: React.RefObject<HTMLDivElement>;
}

export function useCursorPagination<T>(
  options: CursorPaginationOptions<T>
): CursorPaginationResult<T> {
  const {
    initialData = [],
    pageSize = 20,
    getCursor,
    fetchMore: fetchMoreFn,
    enabled = true,
  } = options;

  const [items, setItems] = useState<T[]>(initialData);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [cursor, setCursor] = useState<string | null>(null);

  const loadMore = useCallback(async () => {
    if (isLoading || !hasMore || !enabled) return;

    setIsLoading(true);
    try {
      const result = await fetchMoreFn(cursor, pageSize);
      setItems((prev) => [...prev, ...result.items]);
      setHasMore(result.hasMore);
      setCursor(result.nextCursor);
    } catch (error) {
      console.error('Failed to load more items:', error);
    } finally {
      setIsLoading(false);
    }
  }, [cursor, fetchMoreFn, hasMore, isLoading, pageSize, enabled]);

  const reset = useCallback(async () => {
    setItems([]);
    setCursor(null);
    setHasMore(true);
    setIsLoading(true);

    try {
      const result = await fetchMoreFn(null, pageSize);
      setItems(result.items);
      setHasMore(result.hasMore);
      setCursor(result.nextCursor);
    } catch (error) {
      console.error('Failed to reset items:', error);
    } finally {
      setIsLoading(false);
    }
  }, [fetchMoreFn, pageSize]);

  // Use intersection observer for automatic loading
  const { sentinelRef } = useInfiniteScroll({
    enabled,
    hasMore,
    isLoading,
    onLoadMore: loadMore,
  });

  return {
    items,
    isLoading,
    hasMore,
    cursor,
    loadMore,
    reset,
    sentinelRef,
  };
}

/**
 * Hook for offset-based infinite scroll
 */
export interface OffsetPaginationOptions<T> {
  /** Initial data */
  initialData?: T[];
  /** Page size */
  pageSize?: number;
  /** Function to fetch more data */
  fetchMore: (offset: number, limit: number) => Promise<{
    items: T[];
    total: number;
  }>;
  /** Whether to enable */
  enabled?: boolean;
}

export interface OffsetPaginationResult<T> {
  /** All loaded items */
  items: T[];
  /** Whether loading */
  isLoading: boolean;
  /** Whether there are more items */
  hasMore: boolean;
  /** Total count */
  total: number;
  /** Current offset */
  offset: number;
  /** Load more items */
  loadMore: () => Promise<void>;
  /** Reset and refetch */
  reset: () => Promise<void>;
  /** Sentinel ref for intersection observer */
  sentinelRef: React.RefObject<HTMLDivElement>;
}

export function useOffsetPagination<T>(
  options: OffsetPaginationOptions<T>
): OffsetPaginationResult<T> {
  const { initialData = [], pageSize = 20, fetchMore: fetchMoreFn, enabled = true } = options;

  const [items, setItems] = useState<T[]>(initialData);
  const [isLoading, setIsLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(initialData.length);

  const hasMore = offset < total;

  const loadMore = useCallback(async () => {
    if (isLoading || !hasMore || !enabled) return;

    setIsLoading(true);
    try {
      const result = await fetchMoreFn(offset, pageSize);
      setItems((prev) => [...prev, ...result.items]);
      setTotal(result.total);
      setOffset((prev) => prev + result.items.length);
    } catch (error) {
      console.error('Failed to load more items:', error);
    } finally {
      setIsLoading(false);
    }
  }, [offset, fetchMoreFn, hasMore, isLoading, pageSize, enabled]);

  const reset = useCallback(async () => {
    setItems([]);
    setOffset(0);
    setTotal(0);
    setIsLoading(true);

    try {
      const result = await fetchMoreFn(0, pageSize);
      setItems(result.items);
      setTotal(result.total);
      setOffset(result.items.length);
    } catch (error) {
      console.error('Failed to reset items:', error);
    } finally {
      setIsLoading(false);
    }
  }, [fetchMoreFn, pageSize]);

  // Use intersection observer for automatic loading
  const { sentinelRef } = useInfiniteScroll({
    enabled,
    hasMore,
    isLoading,
    onLoadMore: loadMore,
  });

  return {
    items,
    isLoading,
    hasMore,
    total,
    offset,
    loadMore,
    reset,
    sentinelRef,
  };
}

export default useInfiniteScroll;
