/**
 * Apollo-Zustand Sync Hook
 * Syncs Apollo cache updates to Zustand store for real-time UI updates
 * Also handles optimistic updates for mutations
 */

import { useCallback, useEffect } from 'react';
import { useApolloClient, useMutation, type ApolloCache } from '@apollo/client';
import { useExchangeStore, type Load, type Bid } from '@/store/exchange.store';
import {
  PLACE_BID,
  ACCEPT_BID,
  WITHDRAW_BID,
  GET_SPOT_MARKET_LOADS,
  GET_MY_BIDS,
} from '@/lib/graphql/operations';

interface PlaceBidInput {
  loadId: string;
  carrierId: string;
  carrierName: string;
  amount: number;
  transitDays?: number;
  notes?: string;
}

interface BidResult {
  bidId: string;
  status: string;
  message?: string;
}

/**
 * Hook to sync Apollo cache updates to Zustand store
 */
export function useApolloSync() {
  const client = useApolloClient();
  const setLoads = useExchangeStore((state) => state.setLoads);
  const setMyBids = useExchangeStore((state) => state.setMyBids);
  const updateLoad = useExchangeStore((state) => state.updateLoad);
  const addBid = useExchangeStore((state) => state.addBid);
  const updateBid = useExchangeStore((state) => state.updateBid);

  // Watch for cache changes and sync to Zustand
  useEffect(() => {
    const unsubscribe = client.cache.watch({
      query: GET_SPOT_MARKET_LOADS,
      callback: (result) => {
        if (result.result?.spotMarketLoads?.listings) {
          const loads = result.result.spotMarketLoads.listings.map((l: any) => ({
            id: l.id,
            loadNumber: l.referenceNumber,
            origin: { city: l.originCity, state: l.originState, lat: 0, lng: 0 },
            destination: { city: l.destinationCity, state: l.destinationState, lat: 0, lng: 0 },
            vehicleTypes: [l.vehicleType],
            cargoType: l.cargoDescription,
            weightKg: l.weightKg,
            volumeCbm: l.volumeCbm,
            offeredRate: l.maxBudget,
            bestBid: l.lowestBid,
            bidCount: l.bidCount,
            pickupDate: new Date(l.pickupDateFrom),
            urgency: 'NORMAL' as const,
            status: l.status,
            expiresAt: new Date(l.expiresAt),
            shipperId: '',
            shipperName: '',
          }));
          setLoads(loads);
        }
      },
      optimistic: true,
    });

    return () => unsubscribe();
  }, [client, setLoads]);

  return { client };
}

/**
 * Hook for placing bids with optimistic updates
 */
export function usePlaceBidOptimistic() {
  const addBid = useExchangeStore((state) => state.addBid);
  const updateLoad = useExchangeStore((state) => state.updateLoad);
  const addTickerItem = useExchangeStore((state) => state.addTickerItem);

  const [placeBidMutation, { loading, error }] = useMutation<{ placeBid: BidResult }>(PLACE_BID, {
    // Optimistic response for instant UI feedback
    optimisticResponse: ({ input }) => ({
      placeBid: {
        __typename: 'BidResult',
        bidId: `temp-${Date.now()}`,
        status: 'PENDING',
        message: 'Bid placed successfully',
      },
    }),
    // Update cache and store optimistically
    update: (cache, { data }, { variables }) => {
      if (!data?.placeBid || !variables?.input) return;

      const input = variables.input as PlaceBidInput;

      // Update Apollo cache
      try {
        const existingLoads = cache.readQuery<any>({
          query: GET_SPOT_MARKET_LOADS,
        });

        if (existingLoads?.spotMarketLoads?.listings) {
          const updatedListings = existingLoads.spotMarketLoads.listings.map((load: any) => {
            if (load.id === input.loadId) {
              return {
                ...load,
                bidCount: (load.bidCount || 0) + 1,
                lowestBid: load.lowestBid
                  ? Math.min(load.lowestBid, input.amount)
                  : input.amount,
              };
            }
            return load;
          });

          cache.writeQuery({
            query: GET_SPOT_MARKET_LOADS,
            data: {
              ...existingLoads,
              spotMarketLoads: {
                ...existingLoads.spotMarketLoads,
                listings: updatedListings,
              },
            },
          });
        }
      } catch (e) {
        // Cache read may fail if query hasn't been run yet
      }

      // Update Zustand store
      updateLoad(input.loadId, {
        bidCount: 1, // Increment will be handled by store
      });

      // Add bid to store
      const newBid: Bid = {
        id: data.placeBid.bidId,
        loadId: input.loadId,
        carrierId: input.carrierId,
        carrierName: input.carrierName,
        carrierRating: 4.5,
        bidAmount: input.amount,
        status: 'PENDING',
        transitDays: input.transitDays,
        notes: input.notes,
        createdAt: new Date(),
      };
      addBid(newBid);

      // Add ticker item
      addTickerItem({
        id: `ticker-${Date.now()}`,
        type: 'bid_accepted',
        content: `Bid placed: ₹${input.amount.toLocaleString()} on load`,
        timestamp: new Date(),
      });
    },
  });

  const placeBid = useCallback(
    async (input: PlaceBidInput) => {
      try {
        const result = await placeBidMutation({ variables: { input } });
        return result.data?.placeBid;
      } catch (err) {
        console.error('Failed to place bid:', err);
        throw err;
      }
    },
    [placeBidMutation]
  );

  return { placeBid, loading, error };
}

/**
 * Hook for accepting bids with optimistic updates
 */
export function useAcceptBidOptimistic() {
  const updateBid = useExchangeStore((state) => state.updateBid);
  const updateLoad = useExchangeStore((state) => state.updateLoad);
  const addTickerItem = useExchangeStore((state) => state.addTickerItem);

  const [acceptBidMutation, { loading, error }] = useMutation<{ acceptBid: BidResult }>(ACCEPT_BID, {
    optimisticResponse: ({ bidId }) => ({
      acceptBid: {
        __typename: 'BidResult',
        bidId,
        status: 'ACCEPTED',
        message: 'Bid accepted successfully',
      },
    }),
    update: (cache, { data }, { variables }) => {
      if (!data?.acceptBid || !variables) return;

      const { bidId } = variables;

      // Update bid status in Zustand
      updateBid(bidId, { status: 'ACCEPTED' });

      // Add ticker notification
      addTickerItem({
        id: `ticker-${Date.now()}`,
        type: 'match_found',
        content: 'Bid accepted! Carrier assigned to load',
        timestamp: new Date(),
      });
    },
  });

  const acceptBid = useCallback(
    async (bidId: string, shipperId: string) => {
      try {
        const result = await acceptBidMutation({ variables: { bidId, shipperId } });
        return result.data?.acceptBid;
      } catch (err) {
        console.error('Failed to accept bid:', err);
        throw err;
      }
    },
    [acceptBidMutation]
  );

  return { acceptBid, loading, error };
}

/**
 * Hook for withdrawing bids with optimistic updates
 */
export function useWithdrawBidOptimistic() {
  const updateBid = useExchangeStore((state) => state.updateBid);

  const [withdrawBidMutation, { loading, error }] = useMutation<{ withdrawBid: BidResult }>(
    WITHDRAW_BID,
    {
      optimisticResponse: ({ bidId }) => ({
        withdrawBid: {
          __typename: 'BidResult',
          bidId,
          status: 'WITHDRAWN',
          message: 'Bid withdrawn successfully',
        },
      }),
      update: (cache, { data }, { variables }) => {
        if (!data?.withdrawBid || !variables) return;

        const { bidId } = variables;

        // Update bid status in Zustand
        updateBid(bidId, { status: 'WITHDRAWN' });
      },
    }
  );

  const withdrawBid = useCallback(
    async (bidId: string, carrierId: string) => {
      try {
        const result = await withdrawBidMutation({ variables: { bidId, carrierId } });
        return result.data?.withdrawBid;
      } catch (err) {
        console.error('Failed to withdraw bid:', err);
        throw err;
      }
    },
    [withdrawBidMutation]
  );

  return { withdrawBid, loading, error };
}

export default useApolloSync;
