'use client';

/**
 * OAuth Login Buttons
 * Social login with Google, GitHub, and other providers
 */

import { useState } from 'react';
import { Loader2 } from 'lucide-react';

// OAuth Provider configs
const OAUTH_PROVIDERS = {
  google: {
    name: 'Google',
    icon: GoogleIcon,
    bgColor: 'bg-white hover:bg-gray-100',
    textColor: 'text-gray-800',
    borderColor: 'border-gray-300',
  },
  github: {
    name: 'GitHub',
    icon: GithubIcon,
    bgColor: 'bg-[#24292e] hover:bg-[#1b1f23]',
    textColor: 'text-white',
    borderColor: 'border-transparent',
  },
} as const;

type OAuthProvider = keyof typeof OAUTH_PROVIDERS;

interface OAuthButtonsProps {
  onSuccess?: () => void;
  onError?: (error: string) => void;
  disabled?: boolean;
  providers?: OAuthProvider[];
}

export function OAuthButtons({
  onSuccess,
  onError,
  disabled = false,
  providers = ['google', 'github'],
}: OAuthButtonsProps) {
  const [loadingProvider, setLoadingProvider] = useState<OAuthProvider | null>(null);

  const handleOAuthLogin = async (provider: OAuthProvider) => {
    if (disabled || loadingProvider) return;

    setLoadingProvider(provider);

    try {
      // Build OAuth URL
      const backendUrl = process.env.NEXT_PUBLIC_GRAPHQL_URL?.replace('/graphql', '') || 'http://localhost:4050';
      const redirectUri = `${window.location.origin}/exchange/auth/callback`;

      // Redirect to backend OAuth endpoint
      const oauthUrl = new URL(`${backendUrl}/auth/${provider}`);
      oauthUrl.searchParams.set('redirect_uri', redirectUri);
      oauthUrl.searchParams.set('state', generateState());

      // Store state for CSRF protection
      sessionStorage.setItem('oauth_state', oauthUrl.searchParams.get('state') || '');
      sessionStorage.setItem('oauth_provider', provider);

      // Redirect to OAuth provider
      window.location.href = oauthUrl.toString();
    } catch (error) {
      setLoadingProvider(null);
      onError?.(error instanceof Error ? error.message : 'OAuth login failed');
    }
  };

  return (
    <div className="space-y-3">
      {providers.map((provider) => {
        const config = OAUTH_PROVIDERS[provider];
        const Icon = config.icon;
        const isLoading = loadingProvider === provider;

        return (
          <button
            key={provider}
            type="button"
            onClick={() => handleOAuthLogin(provider)}
            disabled={disabled || loadingProvider !== null}
            className={`w-full flex items-center justify-center gap-3 px-4 py-3 rounded-lg border ${config.bgColor} ${config.textColor} ${config.borderColor} font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Icon className="w-5 h-5" />
            )}
            <span>Continue with {config.name}</span>
          </button>
        );
      })}
    </div>
  );
}

// Generate random state for CSRF protection
function generateState(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

// SVG Icons
function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        fill="#4285F4"
      />
      <path
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        fill="#34A853"
      />
      <path
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
        fill="#FBBC05"
      />
      <path
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        fill="#EA4335"
      />
    </svg>
  );
}

function GithubIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.87 8.17 6.84 9.5.5.08.66-.23.66-.5v-1.69c-2.77.6-3.36-1.34-3.36-1.34-.46-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.6.07-.6 1 .07 1.53 1.03 1.53 1.03.87 1.52 2.34 1.07 2.91.83.09-.65.35-1.09.63-1.34-2.22-.25-4.55-1.11-4.55-4.92 0-1.11.38-2 1.03-2.71-.1-.25-.45-1.29.1-2.64 0 0 .84-.27 2.75 1.02.79-.22 1.65-.33 2.5-.33.85 0 1.71.11 2.5.33 1.91-1.29 2.75-1.02 2.75-1.02.55 1.35.2 2.39.1 2.64.65.71 1.03 1.6 1.03 2.71 0 3.82-2.34 4.66-4.57 4.91.36.31.69.92.69 1.85V21c0 .27.16.59.67.5C19.14 20.16 22 16.42 22 12A10 10 0 0012 2z"
      />
    </svg>
  );
}

export default OAuthButtons;
