'use client';

/**
 * Fr8X Infinite Load Board Component
 * Displays load listings with infinite scroll pagination
 */

import { useState, useCallback, useEffect } from 'react';
import { useQuery } from '@apollo/client';
import { useInfiniteScroll } from '@/lib/hooks/useInfiniteScroll';
import { GET_SPOT_MARKET_LOADS } from '@/lib/graphql/operations';
import { SkeletonLoadCard } from '@/components/ui/Skeleton';
import type { SpotMarketFilters, LoadListing } from '@/lib/hooks/useLoadBoard';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

interface InfiniteLoadBoardProps {
  filters?: SpotMarketFilters;
  pageSize?: number;
  onLoadClick?: (load: LoadListing) => void;
  onBidClick?: (load: LoadListing) => void;
  emptyMessage?: string;
  className?: string;
}

interface LoadCardProps {
  load: LoadListing;
  onLoadClick?: (load: LoadListing) => void;
  onBidClick?: (load: LoadListing) => void;
}

// ─────────────────────────────────────────────────────────────────────────────
// Load Card Component
// ─────────────────────────────────────────────────────────────────────────────

function LoadCard({ load, onLoadClick, onBidClick }: LoadCardProps) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'BIDDING':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'ASSIGNED':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'IN_TRANSIT':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'COMPLETED':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  return (
    <div
      className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition-shadow cursor-pointer"
      onClick={() => onLoadClick?.(load)}
    >
      {/* Header */}
      <div className="flex justify-between items-start mb-3">
        <div>
          <span className="text-sm font-mono text-gray-500 dark:text-gray-400">
            {load.referenceNumber}
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(load.status)}`}>
              {load.status}
            </span>
            {load.isHazardous && (
              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                Hazardous
              </span>
            )}
            {load.isFragile && (
              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200">
                Fragile
              </span>
            )}
          </div>
        </div>
        <div className="text-right">
          {load.maxBudget && (
            <div className="text-lg font-semibold text-gray-900 dark:text-white">
              {formatCurrency(load.maxBudget)}
            </div>
          )}
          {load.lowestBid && (
            <div className="text-sm text-green-600 dark:text-green-400">
              Lowest: {formatCurrency(load.lowestBid)}
            </div>
          )}
        </div>
      </div>

      {/* Route */}
      <div className="flex items-center gap-2 mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="font-medium text-gray-900 dark:text-white">
              {load.originCity}
            </span>
            <span className="text-gray-500 dark:text-gray-400 text-sm">
              {load.originState}
            </span>
          </div>
        </div>
        <div className="flex-shrink-0 px-2">
          <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
          </svg>
        </div>
        <div className="flex-1 text-right">
          <div className="flex items-center gap-2 justify-end">
            <span className="font-medium text-gray-900 dark:text-white">
              {load.destinationCity}
            </span>
            <span className="text-gray-500 dark:text-gray-400 text-sm">
              {load.destinationState}
            </span>
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
          </div>
        </div>
      </div>

      {/* Details */}
      <div className="grid grid-cols-4 gap-4 text-sm mb-3">
        <div>
          <span className="text-gray-500 dark:text-gray-400">Weight</span>
          <div className="font-medium text-gray-900 dark:text-white">
            {(load.weightKg / 1000).toFixed(1)} MT
          </div>
        </div>
        <div>
          <span className="text-gray-500 dark:text-gray-400">Vehicle</span>
          <div className="font-medium text-gray-900 dark:text-white">
            {load.vehicleType?.replace(/_/g, ' ') || 'Any'}
          </div>
        </div>
        <div>
          <span className="text-gray-500 dark:text-gray-400">Pickup</span>
          <div className="font-medium text-gray-900 dark:text-white">
            {formatDate(load.pickupDateFrom)}
          </div>
        </div>
        <div>
          <span className="text-gray-500 dark:text-gray-400">Bids</span>
          <div className="font-medium text-gray-900 dark:text-white">
            {load.bidCount}
          </div>
        </div>
      </div>

      {/* Cargo Description */}
      {load.cargoDescription && (
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-3 line-clamp-1">
          {load.cargoDescription}
        </p>
      )}

      {/* Actions */}
      <div className="flex justify-between items-center pt-3 border-t border-gray-100 dark:border-gray-700">
        <span className="text-xs text-gray-500 dark:text-gray-400">
          Expires {formatDate(load.expiresAt)}
        </span>
        {load.status === 'OPEN' && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onBidClick?.(load);
            }}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
          >
            Place Bid
          </button>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Infinite Load Board Component
// ─────────────────────────────────────────────────────────────────────────────

export function InfiniteLoadBoard({
  filters,
  pageSize = 20,
  onLoadClick,
  onBidClick,
  emptyMessage = 'No loads found matching your criteria.',
  className = '',
}: InfiniteLoadBoardProps) {
  const [loads, setLoads] = useState<LoadListing[]>([]);
  const [hasMore, setHasMore] = useState(true);

  // Initial query
  const { data, loading, error, fetchMore } = useQuery(GET_SPOT_MARKET_LOADS, {
    variables: {
      filters: {
        ...filters,
        limit: pageSize,
        offset: 0,
      },
    },
    fetchPolicy: 'cache-and-network',
    onCompleted: (data) => {
      const listings = data?.spotMarketLoads?.listings || [];
      setLoads(listings);
      setHasMore(data?.spotMarketLoads?.hasMore ?? false);
    },
  });

  // Reset when filters change
  useEffect(() => {
    setLoads([]);
    setHasMore(true);
  }, [JSON.stringify(filters)]);

  // Handle load more
  const handleLoadMore = useCallback(async () => {
    if (!hasMore || loading) return;

    try {
      const result = await fetchMore({
        variables: {
          filters: {
            ...filters,
            limit: pageSize,
            offset: loads.length,
          },
        },
      });

      const newListings = result.data?.spotMarketLoads?.listings || [];
      setLoads((prev) => [...prev, ...newListings]);
      setHasMore(result.data?.spotMarketLoads?.hasMore ?? false);
    } catch (err) {
      console.error('Failed to fetch more loads:', err);
    }
  }, [fetchMore, filters, hasMore, loading, loads.length, pageSize]);

  // Infinite scroll hook
  const { sentinelRef, isIntersecting } = useInfiniteScroll({
    enabled: hasMore && !loading,
    hasMore,
    isLoading: loading,
    onLoadMore: handleLoadMore,
    rootMargin: '200px',
  });

  // Error state
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="text-red-500 dark:text-red-400 mb-2">
          <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          Failed to load the board. Please try again.
        </p>
        <button
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
        >
          Retry
        </button>
      </div>
    );
  }

  // Empty state (after loading)
  if (!loading && loads.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="text-gray-400 dark:text-gray-500 mb-4">
          <svg className="w-16 h-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
          </svg>
        </div>
        <p className="text-gray-600 dark:text-gray-400 text-center">
          {emptyMessage}
        </p>
      </div>
    );
  }

  return (
    <div className={className}>
      {/* Load Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loads.map((load) => (
          <LoadCard
            key={load.id}
            load={load}
            onLoadClick={onLoadClick}
            onBidClick={onBidClick}
          />
        ))}

        {/* Loading skeletons */}
        {loading && loads.length === 0 &&
          Array.from({ length: 6 }).map((_, i) => (
            <SkeletonLoadCard key={`skeleton-${i}`} />
          ))}
      </div>

      {/* Sentinel for infinite scroll */}
      <div ref={sentinelRef} className="h-px" />

      {/* Loading more indicator */}
      {loading && loads.length > 0 && (
        <div className="flex justify-center py-6">
          <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
            <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <span>Loading more loads...</span>
          </div>
        </div>
      )}

      {/* End of list */}
      {!hasMore && loads.length > 0 && (
        <div className="text-center py-6 text-gray-500 dark:text-gray-400">
          You've reached the end of the list
        </div>
      )}

      {/* Stats bar */}
      <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-gray-900 dark:bg-gray-700 text-white px-4 py-2 rounded-full text-sm shadow-lg opacity-75">
        Showing {loads.length} of {data?.spotMarketLoads?.total || 0} loads
      </div>
    </div>
  );
}

export default InfiniteLoadBoard;
