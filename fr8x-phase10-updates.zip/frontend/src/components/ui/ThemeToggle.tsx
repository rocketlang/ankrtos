'use client';

/**
 * Theme Toggle Button
 * Switch between dark, light, and system themes
 */

import { useState, useRef, useEffect } from 'react';
import { Sun, Moon, Monitor, ChevronDown } from 'lucide-react';
import { useTheme, type ThemeMode } from '@/lib/theme';
import { cn } from '@/lib/utils';

interface ThemeToggleProps {
  className?: string;
  showLabel?: boolean;
  variant?: 'button' | 'dropdown';
}

export function ThemeToggle({ className, showLabel = false, variant = 'button' }: ThemeToggleProps) {
  const { theme, mode, setMode, toggleTheme, isDark } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const themes: { mode: ThemeMode; label: string; icon: typeof Sun }[] = [
    { mode: 'light', label: 'Light', icon: Sun },
    { mode: 'dark', label: 'Dark', icon: Moon },
    { mode: 'system', label: 'System', icon: Monitor },
  ];

  const currentTheme = themes.find((t) => t.mode === mode) || themes[1];
  const CurrentIcon = isDark ? Moon : Sun;

  if (variant === 'button') {
    return (
      <button
        onClick={toggleTheme}
        className={cn(
          'p-2 rounded-lg bg-surface-800 hover:bg-surface-700 text-gray-400 hover:text-white transition-colors',
          className
        )}
        title={`Switch to ${isDark ? 'light' : 'dark'} mode`}
      >
        <CurrentIcon className="w-5 h-5" />
        {showLabel && (
          <span className="ml-2">{isDark ? 'Dark' : 'Light'}</span>
        )}
      </button>
    );
  }

  return (
    <div ref={dropdownRef} className={cn('relative', className)}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-surface-800 hover:bg-surface-700 text-gray-400 hover:text-white transition-colors"
      >
        <CurrentIcon className="w-4 h-4" />
        <span className="text-sm">{currentTheme.label}</span>
        <ChevronDown className={cn('w-4 h-4 transition-transform', isOpen && 'rotate-180')} />
      </button>

      {isOpen && (
        <div className="absolute top-full mt-2 right-0 w-36 bg-surface-800 border border-white/10 rounded-lg shadow-xl overflow-hidden z-50">
          {themes.map(({ mode: m, label, icon: Icon }) => (
            <button
              key={m}
              onClick={() => {
                setMode(m);
                setIsOpen(false);
              }}
              className={cn(
                'flex items-center gap-2 w-full px-3 py-2 text-left text-sm transition-colors',
                mode === m
                  ? 'bg-primary-500/20 text-primary-400'
                  : 'text-gray-400 hover:bg-surface-700 hover:text-white'
              )}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default ThemeToggle;
