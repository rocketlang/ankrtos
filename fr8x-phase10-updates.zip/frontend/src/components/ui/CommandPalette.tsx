'use client';

/**
 * Fr8X Command Palette (Cmd+K)
 * Quick navigation and action launcher
 */

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface CommandItem {
  id: string;
  title: string;
  description?: string;
  icon?: React.ReactNode;
  shortcut?: string[];
  category: 'navigation' | 'action' | 'search' | 'recent';
  action: () => void | Promise<void>;
  keywords?: string[];
}

interface CommandPaletteProps {
  commands?: CommandItem[];
  placeholder?: string;
  onClose?: () => void;
}

// ─────────────────────────────────────────────────────────────────────────────
// Icons
// ─────────────────────────────────────────────────────────────────────────────

const icons = {
  search: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
  ),
  home: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
  ),
  truck: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" />
    </svg>
  ),
  wallet: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
    </svg>
  ),
  plus: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
  ),
  chart: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
  ),
  users: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
    </svg>
  ),
  settings: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  map: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
    </svg>
  ),
  clock: (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
};

// ─────────────────────────────────────────────────────────────────────────────
// Default Commands
// ─────────────────────────────────────────────────────────────────────────────

function useDefaultCommands(): CommandItem[] {
  const router = useRouter();

  return useMemo(
    () => [
      // Navigation
      {
        id: 'nav-dashboard',
        title: 'Go to Dashboard',
        description: 'View your exchange dashboard',
        icon: icons.home,
        shortcut: ['G', 'D'],
        category: 'navigation',
        action: () => router.push('/exchange'),
        keywords: ['home', 'main', 'overview'],
      },
      {
        id: 'nav-loadboard',
        title: 'Go to Load Board',
        description: 'View available loads',
        icon: icons.truck,
        shortcut: ['G', 'L'],
        category: 'navigation',
        action: () => router.push('/exchange/board'),
        keywords: ['loads', 'freight', 'shipments', 'spot'],
      },
      {
        id: 'nav-wallet',
        title: 'Go to Wallet',
        description: 'View wallet and transactions',
        icon: icons.wallet,
        shortcut: ['G', 'W'],
        category: 'navigation',
        action: () => router.push('/exchange/wallet'),
        keywords: ['money', 'balance', 'payments', 'transactions'],
      },
      {
        id: 'nav-tracking',
        title: 'Go to Tracking',
        description: 'Track active shipments',
        icon: icons.map,
        shortcut: ['G', 'T'],
        category: 'navigation',
        action: () => router.push('/exchange/tracking'),
        keywords: ['track', 'map', 'location', 'gps'],
      },
      {
        id: 'nav-analytics',
        title: 'Go to Analytics',
        description: 'View reports and analytics',
        icon: icons.chart,
        shortcut: ['G', 'A'],
        category: 'navigation',
        action: () => router.push('/exchange/analytics'),
        keywords: ['reports', 'stats', 'metrics', 'charts'],
      },
      {
        id: 'nav-fleet',
        title: 'Go to Fleet',
        description: 'Manage vehicles and drivers',
        icon: icons.truck,
        shortcut: ['G', 'F'],
        category: 'navigation',
        action: () => router.push('/exchange/fleet'),
        keywords: ['vehicles', 'drivers', 'trucks'],
      },
      {
        id: 'nav-settings',
        title: 'Go to Settings',
        description: 'Manage your account settings',
        icon: icons.settings,
        shortcut: ['G', 'S'],
        category: 'navigation',
        action: () => router.push('/exchange/settings'),
        keywords: ['preferences', 'account', 'profile'],
      },
      // Actions
      {
        id: 'action-post-load',
        title: 'Post New Load',
        description: 'Create a new load posting',
        icon: icons.plus,
        shortcut: ['N', 'L'],
        category: 'action',
        action: () => router.push('/exchange/board/post'),
        keywords: ['create', 'new', 'add', 'shipment'],
      },
      {
        id: 'action-add-vehicle',
        title: 'Add Vehicle',
        description: 'Register a new vehicle',
        icon: icons.plus,
        shortcut: ['N', 'V'],
        category: 'action',
        action: () => router.push('/exchange/fleet/vehicles/new'),
        keywords: ['register', 'truck', 'new'],
      },
      {
        id: 'action-add-driver',
        title: 'Add Driver',
        description: 'Register a new driver',
        icon: icons.users,
        shortcut: ['N', 'D'],
        category: 'action',
        action: () => router.push('/exchange/fleet/drivers/new'),
        keywords: ['register', 'new', 'personnel'],
      },
    ],
    [router]
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Command Palette Component
// ─────────────────────────────────────────────────────────────────────────────

export function CommandPalette({ commands: customCommands, placeholder = 'Search commands...', onClose }: CommandPaletteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const defaultCommands = useDefaultCommands();
  const allCommands = useMemo(
    () => [...defaultCommands, ...(customCommands || [])],
    [defaultCommands, customCommands]
  );

  // Filter commands based on search
  const filteredCommands = useMemo(() => {
    if (!search.trim()) return allCommands;

    const query = search.toLowerCase();
    return allCommands.filter((cmd) => {
      const searchText = [
        cmd.title,
        cmd.description,
        ...(cmd.keywords || []),
      ]
        .join(' ')
        .toLowerCase();
      return searchText.includes(query);
    });
  }, [allCommands, search]);

  // Group commands by category
  const groupedCommands = useMemo(() => {
    const groups: Record<string, CommandItem[]> = {
      navigation: [],
      action: [],
      search: [],
      recent: [],
    };

    filteredCommands.forEach((cmd) => {
      if (groups[cmd.category]) {
        groups[cmd.category].push(cmd);
      }
    });

    return groups;
  }, [filteredCommands]);

  // Open/close handlers
  const open = useCallback(() => {
    setIsOpen(true);
    setSearch('');
    setSelectedIndex(0);
  }, []);

  const close = useCallback(() => {
    setIsOpen(false);
    setSearch('');
    setSelectedIndex(0);
    onClose?.();
  }, [onClose]);

  // Execute command
  const executeCommand = useCallback(
    (command: CommandItem) => {
      close();
      command.action();
    },
    [close]
  );

  // Keyboard navigation
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex((i) => Math.min(i + 1, filteredCommands.length - 1));
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex((i) => Math.max(i - 1, 0));
          break;
        case 'Enter':
          e.preventDefault();
          if (filteredCommands[selectedIndex]) {
            executeCommand(filteredCommands[selectedIndex]);
          }
          break;
        case 'Escape':
          e.preventDefault();
          close();
          break;
      }
    },
    [filteredCommands, selectedIndex, executeCommand, close]
  );

  // Global keyboard shortcut (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Cmd+K or Ctrl+K
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) {
          close();
        } else {
          open();
        }
      }

      // Escape to close
      if (e.key === 'Escape' && isOpen) {
        close();
      }
    };

    document.addEventListener('keydown', handleGlobalKeyDown);
    return () => document.removeEventListener('keydown', handleGlobalKeyDown);
  }, [isOpen, open, close]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Scroll selected item into view
  useEffect(() => {
    if (listRef.current) {
      const selected = listRef.current.querySelector('[data-selected="true"]');
      if (selected) {
        selected.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [selectedIndex]);

  if (!isOpen) return null;

  const categoryLabels: Record<string, string> = {
    navigation: 'Navigation',
    action: 'Actions',
    search: 'Search',
    recent: 'Recent',
  };

  return createPortal(
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
        onClick={close}
      />

      {/* Modal */}
      <div className="fixed inset-x-0 top-[20%] mx-auto max-w-xl px-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl ring-1 ring-gray-900/10 dark:ring-white/10 overflow-hidden">
          {/* Search Input */}
          <div className="flex items-center px-4 border-b border-gray-200 dark:border-gray-700">
            <span className="text-gray-400">{icons.search}</span>
            <input
              ref={inputRef}
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setSelectedIndex(0);
              }}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              className="flex-1 px-3 py-4 text-gray-900 dark:text-white placeholder-gray-400 bg-transparent border-0 focus:outline-none focus:ring-0"
            />
            <kbd className="hidden sm:flex items-center gap-1 px-2 py-1 text-xs font-medium text-gray-400 bg-gray-100 dark:bg-gray-700 rounded">
              ESC
            </kbd>
          </div>

          {/* Command List */}
          <div ref={listRef} className="max-h-[60vh] overflow-y-auto p-2">
            {filteredCommands.length === 0 ? (
              <div className="px-4 py-8 text-center text-gray-500 dark:text-gray-400">
                No commands found for "{search}"
              </div>
            ) : (
              Object.entries(groupedCommands).map(([category, commands]) => {
                if (commands.length === 0) return null;

                return (
                  <div key={category} className="mb-2">
                    <div className="px-3 py-2 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      {categoryLabels[category] || category}
                    </div>
                    {commands.map((cmd) => {
                      const globalIndex = filteredCommands.indexOf(cmd);
                      const isSelected = globalIndex === selectedIndex;

                      return (
                        <button
                          key={cmd.id}
                          data-selected={isSelected}
                          onClick={() => executeCommand(cmd)}
                          onMouseEnter={() => setSelectedIndex(globalIndex)}
                          className={`
                            w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors
                            ${isSelected
                              ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-900 dark:text-blue-100'
                              : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/50'
                            }
                          `}
                        >
                          <span className={isSelected ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'}>
                            {cmd.icon}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">{cmd.title}</div>
                            {cmd.description && (
                              <div className="text-sm text-gray-500 dark:text-gray-400 truncate">
                                {cmd.description}
                              </div>
                            )}
                          </div>
                          {cmd.shortcut && (
                            <div className="hidden sm:flex items-center gap-1">
                              {cmd.shortcut.map((key, i) => (
                                <kbd
                                  key={i}
                                  className="px-1.5 py-0.5 text-xs font-medium text-gray-400 bg-gray-100 dark:bg-gray-700 rounded"
                                >
                                  {key}
                                </kbd>
                              ))}
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                );
              })
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between px-4 py-2 border-t border-gray-200 dark:border-gray-700 text-xs text-gray-500 dark:text-gray-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 rounded">↑</kbd>
                <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 rounded">↓</kbd>
                to navigate
              </span>
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 rounded">↵</kbd>
                to select
              </span>
            </div>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 rounded">⌘</kbd>
              <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 rounded">K</kbd>
              to toggle
            </span>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Command Palette Provider
// ─────────────────────────────────────────────────────────────────────────────

export function CommandPaletteProvider({ children }: { children: React.ReactNode }) {
  return (
    <>
      {children}
      <CommandPalette />
    </>
  );
}

export default CommandPalette;
