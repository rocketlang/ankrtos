/**
 * Fr8X Analytics Service
 * Provides dashboard metrics, KPIs, and reporting analytics
 */

import type { PrismaClient } from '../../generated/prisma/index.js';
import { logger } from '../lib/index.js';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface DashboardMetrics {
  overview: OverviewMetrics;
  loadBoard: LoadBoardMetrics;
  fleet: FleetMetrics;
  financial: FinancialMetrics;
  performance: PerformanceMetrics;
}

export interface OverviewMetrics {
  totalShipments: number;
  activeShipments: number;
  completedShipments: number;
  totalRevenue: number;
  activeCarriers: number;
  activeShippers: number;
  avgDeliveryTime: number;
  onTimeDeliveryRate: number;
}

export interface LoadBoardMetrics {
  openLoads: number;
  totalBids: number;
  avgBidsPerLoad: number;
  conversionRate: number;
  avgTimeToBooking: number;
  topLanes: LaneMetric[];
  loadsByStatus: Record<string, number>;
  bidAmountDistribution: { range: string; count: number }[];
}

export interface LaneMetric {
  origin: string;
  destination: string;
  loadCount: number;
  avgRate: number;
  avgTransitDays: number;
}

export interface FleetMetrics {
  totalVehicles: number;
  availableVehicles: number;
  inTransitVehicles: number;
  maintenanceVehicles: number;
  utilizationRate: number;
  totalDrivers: number;
  activeDrivers: number;
  avgDriverRating: number;
  vehiclesByType: Record<string, number>;
}

export interface FinancialMetrics {
  totalGMV: number;
  platformRevenue: number;
  pendingPayments: number;
  completedPayments: number;
  avgTransactionValue: number;
  revenueByMonth: { month: string; revenue: number }[];
  paymentMethodDistribution: Record<string, number>;
  walletBalanceTotal: number;
}

export interface PerformanceMetrics {
  avgResponseTime: number;
  successRate: number;
  errorRate: number;
  activeUsers: number;
  peakHours: { hour: number; requests: number }[];
  topEndpoints: { endpoint: string; calls: number; avgTime: number }[];
}

export interface DateRange {
  startDate: Date;
  endDate: Date;
}

export interface AnalyticsFilter {
  dateRange?: DateRange;
  organizationId?: string;
  carrierId?: string;
  shipperIds?: string[];
  laneCode?: string;
  status?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Analytics Service
// ─────────────────────────────────────────────────────────────────────────────

export class AnalyticsService {
  private prisma: PrismaClient;

  constructor(prisma: PrismaClient) {
    this.prisma = prisma;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Dashboard Metrics
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Get all dashboard metrics
   */
  async getDashboardMetrics(filter?: AnalyticsFilter): Promise<DashboardMetrics> {
    const [overview, loadBoard, fleet, financial, performance] = await Promise.all([
      this.getOverviewMetrics(filter),
      this.getLoadBoardMetrics(filter),
      this.getFleetMetrics(filter),
      this.getFinancialMetrics(filter),
      this.getPerformanceMetrics(filter),
    ]);

    return { overview, loadBoard, fleet, financial, performance };
  }

  /**
   * Get overview metrics
   */
  async getOverviewMetrics(filter?: AnalyticsFilter): Promise<OverviewMetrics> {
    const dateFilter = this.buildDateFilter(filter?.dateRange);

    const [
      totalShipments,
      activeShipments,
      completedShipments,
      revenueData,
      activeCarriers,
      activeShippers,
      deliveryStats,
    ] = await Promise.all([
      this.prisma.shipment.count({
        where: { createdAt: dateFilter },
      }),
      this.prisma.shipment.count({
        where: {
          status: { in: ['IN_TRANSIT', 'PICKED_UP', 'AT_HUB', 'OUT_FOR_DELIVERY'] },
          createdAt: dateFilter,
        },
      }),
      this.prisma.shipment.count({
        where: { status: 'COMPLETED', createdAt: dateFilter },
      }),
      this.prisma.shipment.aggregate({
        where: { status: 'COMPLETED', createdAt: dateFilter },
        _sum: { totalAmount: true },
      }),
      this.prisma.carrier.count({
        where: { status: 'ACTIVE' },
      }),
      this.prisma.organization.count({
        where: { type: 'SHIPPER', verificationStatus: 'VERIFIED' },
      }),
      this.prisma.shipment.aggregate({
        where: { status: 'COMPLETED', createdAt: dateFilter },
        _avg: {
          // Assuming we have these fields or can calculate them
        },
      }),
    ]);

    // Calculate on-time delivery rate
    const onTimeDeliveries = await this.prisma.shipment.count({
      where: {
        status: 'COMPLETED',
        createdAt: dateFilter,
        // deliveredAt: { lte: this.prisma.shipment.fields.deliveryDateTo }
      },
    });

    const onTimeDeliveryRate = completedShipments > 0
      ? (onTimeDeliveries / completedShipments) * 100
      : 0;

    return {
      totalShipments,
      activeShipments,
      completedShipments,
      totalRevenue: revenueData._sum.totalAmount?.toNumber() || 0,
      activeCarriers,
      activeShippers,
      avgDeliveryTime: 2.5, // TODO: Calculate from actual data
      onTimeDeliveryRate,
    };
  }

  /**
   * Get load board metrics
   */
  async getLoadBoardMetrics(filter?: AnalyticsFilter): Promise<LoadBoardMetrics> {
    const dateFilter = this.buildDateFilter(filter?.dateRange);

    const [
      openLoads,
      totalBids,
      loadStatusCounts,
      topLanesData,
    ] = await Promise.all([
      this.prisma.spotMarketLoad.count({
        where: { status: 'OPEN', createdAt: dateFilter },
      }),
      this.prisma.bid.count({
        where: { createdAt: dateFilter },
      }),
      this.prisma.spotMarketLoad.groupBy({
        by: ['status'],
        where: { createdAt: dateFilter },
        _count: true,
      }),
      this.prisma.spotMarketLoad.groupBy({
        by: ['originCity', 'originState', 'destinationCity', 'destinationState'],
        where: { createdAt: dateFilter },
        _count: true,
        _avg: { targetRate: true, lowestBid: true },
        orderBy: { _count: { id: 'desc' } },
        take: 10,
      }),
    ]);

    // Calculate conversion rate
    const bookedLoads = await this.prisma.spotMarketLoad.count({
      where: {
        status: { in: ['ASSIGNED', 'IN_TRANSIT', 'COMPLETED'] },
        createdAt: dateFilter,
      },
    });
    const totalLoads = await this.prisma.spotMarketLoad.count({
      where: { createdAt: dateFilter },
    });

    const loadsByStatus: Record<string, number> = {};
    loadStatusCounts.forEach((item) => {
      loadsByStatus[item.status] = item._count;
    });

    const topLanes: LaneMetric[] = topLanesData.map((lane) => ({
      origin: `${lane.originCity}, ${lane.originState}`,
      destination: `${lane.destinationCity}, ${lane.destinationState}`,
      loadCount: lane._count,
      avgRate: lane._avg.targetRate?.toNumber() || 0,
      avgTransitDays: 2, // TODO: Calculate from actual data
    }));

    return {
      openLoads,
      totalBids,
      avgBidsPerLoad: openLoads > 0 ? totalBids / totalLoads : 0,
      conversionRate: totalLoads > 0 ? (bookedLoads / totalLoads) * 100 : 0,
      avgTimeToBooking: 4.2, // TODO: Calculate from actual data
      topLanes,
      loadsByStatus,
      bidAmountDistribution: [
        { range: '0-25K', count: 0 },
        { range: '25K-50K', count: 0 },
        { range: '50K-100K', count: 0 },
        { range: '100K+', count: 0 },
      ],
    };
  }

  /**
   * Get fleet metrics
   */
  async getFleetMetrics(filter?: AnalyticsFilter): Promise<FleetMetrics> {
    const carrierId = filter?.carrierId;

    const [
      vehicleCounts,
      vehiclesByType,
      driverStats,
    ] = await Promise.all([
      this.prisma.vehicle.groupBy({
        by: ['status'],
        where: carrierId ? { carrierId } : undefined,
        _count: true,
      }),
      this.prisma.vehicle.groupBy({
        by: ['type'],
        where: carrierId ? { carrierId } : undefined,
        _count: true,
      }),
      this.prisma.driver.aggregate({
        where: carrierId ? { carrierId } : undefined,
        _count: true,
        _avg: { averageRating: true },
      }),
    ]);

    const vehicleStatusMap: Record<string, number> = {};
    let totalVehicles = 0;
    vehicleCounts.forEach((item) => {
      vehicleStatusMap[item.status] = item._count;
      totalVehicles += item._count;
    });

    const vehicleTypeMap: Record<string, number> = {};
    vehiclesByType.forEach((item) => {
      vehicleTypeMap[item.type] = item._count;
    });

    const activeDrivers = await this.prisma.driver.count({
      where: {
        status: 'ACTIVE',
        isAvailable: true,
        ...(carrierId ? { carrierId } : {}),
      },
    });

    return {
      totalVehicles,
      availableVehicles: vehicleStatusMap['AVAILABLE'] || 0,
      inTransitVehicles: vehicleStatusMap['IN_TRANSIT'] || 0,
      maintenanceVehicles: vehicleStatusMap['MAINTENANCE'] || 0,
      utilizationRate: totalVehicles > 0
        ? ((totalVehicles - (vehicleStatusMap['AVAILABLE'] || 0)) / totalVehicles) * 100
        : 0,
      totalDrivers: driverStats._count || 0,
      activeDrivers,
      avgDriverRating: driverStats._avg.averageRating || 0,
      vehiclesByType: vehicleTypeMap,
    };
  }

  /**
   * Get financial metrics
   */
  async getFinancialMetrics(filter?: AnalyticsFilter): Promise<FinancialMetrics> {
    const dateFilter = this.buildDateFilter(filter?.dateRange);

    const [
      gmvData,
      paymentStats,
      walletStats,
      monthlyRevenue,
    ] = await Promise.all([
      this.prisma.shipment.aggregate({
        where: { createdAt: dateFilter },
        _sum: { totalAmount: true },
        _avg: { totalAmount: true },
      }),
      this.prisma.shipment.groupBy({
        by: ['paymentStatus'],
        where: { createdAt: dateFilter },
        _sum: { totalAmount: true },
        _count: true,
      }),
      this.prisma.wallet.aggregate({
        _sum: { balance: true },
      }),
      this.getMonthlyRevenue(filter?.dateRange),
    ]);

    const paymentDistribution: Record<string, number> = {};
    let pendingPayments = 0;
    let completedPayments = 0;

    paymentStats.forEach((item) => {
      const amount = item._sum.totalAmount?.toNumber() || 0;
      paymentDistribution[item.paymentStatus] = amount;
      if (['PENDING', 'AUTHORIZED', 'ADVANCE_PAID'].includes(item.paymentStatus)) {
        pendingPayments += amount;
      } else if (['PAID', 'SETTLED'].includes(item.paymentStatus)) {
        completedPayments += amount;
      }
    });

    // Platform revenue (assuming 8% commission)
    const platformRevenue = (completedPayments * 0.08);

    return {
      totalGMV: gmvData._sum.totalAmount?.toNumber() || 0,
      platformRevenue,
      pendingPayments,
      completedPayments,
      avgTransactionValue: gmvData._avg.totalAmount?.toNumber() || 0,
      revenueByMonth: monthlyRevenue,
      paymentMethodDistribution: {},
      walletBalanceTotal: walletStats._sum.balance?.toNumber() || 0,
    };
  }

  /**
   * Get performance metrics (placeholder - would integrate with observability system)
   */
  async getPerformanceMetrics(filter?: AnalyticsFilter): Promise<PerformanceMetrics> {
    // These would typically come from a metrics/observability system like Prometheus
    return {
      avgResponseTime: 150,
      successRate: 99.5,
      errorRate: 0.5,
      activeUsers: 0,
      peakHours: [
        { hour: 9, requests: 1200 },
        { hour: 10, requests: 1500 },
        { hour: 11, requests: 1800 },
        { hour: 14, requests: 1600 },
        { hour: 15, requests: 1400 },
      ],
      topEndpoints: [
        { endpoint: '/graphql', calls: 50000, avgTime: 120 },
        { endpoint: '/health', calls: 10000, avgTime: 5 },
      ],
    };
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Specialized Analytics
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Get carrier performance analytics
   */
  async getCarrierAnalytics(carrierId: string, dateRange?: DateRange) {
    const dateFilter = this.buildDateFilter(dateRange);

    const [
      shipmentStats,
      ratingStats,
      revenueStats,
    ] = await Promise.all([
      this.prisma.shipment.groupBy({
        by: ['status'],
        where: { carrierId, createdAt: dateFilter },
        _count: true,
      }),
      this.prisma.carrier.findUnique({
        where: { id: carrierId },
        select: {
          averageRating: true,
          totalRatings: true,
          onTimeDeliveryRate: true,
          totalTrips: true,
          completedTrips: true,
        },
      }),
      this.prisma.shipment.aggregate({
        where: { carrierId, status: 'COMPLETED', createdAt: dateFilter },
        _sum: { totalAmount: true },
        _count: true,
      }),
    ]);

    return {
      shipmentStats,
      rating: ratingStats,
      revenue: {
        total: revenueStats._sum.totalAmount?.toNumber() || 0,
        completedShipments: revenueStats._count,
      },
    };
  }

  /**
   * Get shipper analytics
   */
  async getShipperAnalytics(organizationId: string, dateRange?: DateRange) {
    const dateFilter = this.buildDateFilter(dateRange);

    const [
      shipmentStats,
      spendStats,
      topCarriers,
    ] = await Promise.all([
      this.prisma.shipment.groupBy({
        by: ['status'],
        where: { shipperOrgId: organizationId, createdAt: dateFilter },
        _count: true,
      }),
      this.prisma.shipment.aggregate({
        where: { shipperOrgId: organizationId, createdAt: dateFilter },
        _sum: { totalAmount: true },
        _avg: { totalAmount: true },
      }),
      this.prisma.shipment.groupBy({
        by: ['carrierId'],
        where: { shipperOrgId: organizationId, createdAt: dateFilter },
        _count: true,
        _sum: { totalAmount: true },
        orderBy: { _count: { id: 'desc' } },
        take: 5,
      }),
    ]);

    return {
      shipmentStats,
      spend: {
        total: spendStats._sum.totalAmount?.toNumber() || 0,
        average: spendStats._avg.totalAmount?.toNumber() || 0,
      },
      topCarriers,
    };
  }

  /**
   * Get lane analytics
   */
  async getLaneAnalytics(originCity: string, destinationCity: string, dateRange?: DateRange) {
    const dateFilter = this.buildDateFilter(dateRange);

    const stats = await this.prisma.spotMarketLoad.aggregate({
      where: {
        originCity,
        destinationCity,
        createdAt: dateFilter,
      },
      _count: true,
      _avg: { targetRate: true, lowestBid: true, bidCount: true },
      _min: { lowestBid: true },
      _max: { targetRate: true },
    });

    return {
      totalLoads: stats._count,
      avgTargetRate: stats._avg.targetRate?.toNumber() || 0,
      avgWinningBid: stats._avg.lowestBid?.toNumber() || 0,
      avgBidsPerLoad: stats._avg.bidCount || 0,
      minBid: stats._min.lowestBid?.toNumber() || 0,
      maxRate: stats._max.targetRate?.toNumber() || 0,
    };
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Private Helpers
  // ─────────────────────────────────────────────────────────────────────────────

  private buildDateFilter(dateRange?: DateRange) {
    if (!dateRange) return undefined;
    return {
      gte: dateRange.startDate,
      lte: dateRange.endDate,
    };
  }

  private async getMonthlyRevenue(dateRange?: DateRange): Promise<{ month: string; revenue: number }[]> {
    // Get last 12 months of revenue
    const months: { month: string; revenue: number }[] = [];
    const now = new Date();

    for (let i = 11; i >= 0; i--) {
      const monthStart = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);

      const revenue = await this.prisma.shipment.aggregate({
        where: {
          status: 'COMPLETED',
          createdAt: {
            gte: monthStart,
            lte: monthEnd,
          },
        },
        _sum: { totalAmount: true },
      });

      months.push({
        month: monthStart.toISOString().substring(0, 7), // YYYY-MM format
        revenue: revenue._sum.totalAmount?.toNumber() || 0,
      });
    }

    return months;
  }
}

export default AnalyticsService;
