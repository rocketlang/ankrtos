/**
 * Fr8X Rate Limiter Service
 * Provides rate limiting for API endpoints and dynamic pricing
 */

import Redis from 'ioredis';
import { logger } from '../lib/index.js';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface RateLimitConfig {
  /** Maximum number of requests */
  limit: number;
  /** Time window in seconds */
  window: number;
  /** Identifier prefix */
  prefix?: string;
}

export interface RateLimitResult {
  /** Whether the request is allowed */
  allowed: boolean;
  /** Number of remaining requests */
  remaining: number;
  /** Total limit */
  limit: number;
  /** Time until reset (seconds) */
  resetIn: number;
  /** Number of requests made */
  current: number;
}

export interface SlidingWindowConfig extends RateLimitConfig {
  /** Number of buckets for sliding window */
  buckets?: number;
}

export interface TokenBucketConfig {
  /** Maximum tokens in bucket */
  capacity: number;
  /** Tokens refilled per second */
  refillRate: number;
  /** Initial tokens */
  initialTokens?: number;
}

export interface DynamicPricingConfig {
  /** Base rate per unit */
  baseRate: number;
  /** Minimum rate multiplier */
  minMultiplier: number;
  /** Maximum rate multiplier */
  maxMultiplier: number;
  /** Demand threshold for price increase */
  highDemandThreshold: number;
  /** Demand threshold for price decrease */
  lowDemandThreshold: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// Rate Limiter Service
// ─────────────────────────────────────────────────────────────────────────────

export class RateLimiterService {
  private redis: Redis;
  private defaultConfig: RateLimitConfig;

  constructor(redisUrl?: string, defaultConfig?: Partial<RateLimitConfig>) {
    this.redis = new Redis(redisUrl || process.env.REDIS_URL || 'redis://localhost:6379');
    this.defaultConfig = {
      limit: 100,
      window: 60,
      prefix: 'rl:',
      ...defaultConfig,
    };
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Fixed Window Rate Limiting
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Check rate limit using fixed window algorithm
   */
  async checkRateLimit(
    identifier: string,
    config?: Partial<RateLimitConfig>
  ): Promise<RateLimitResult> {
    const { limit, window, prefix } = { ...this.defaultConfig, ...config };
    const key = `${prefix}${identifier}`;

    const now = Math.floor(Date.now() / 1000);
    const windowStart = Math.floor(now / window) * window;
    const windowKey = `${key}:${windowStart}`;

    const multi = this.redis.multi();
    multi.incr(windowKey);
    multi.expire(windowKey, window);
    const results = await multi.exec();

    const current = results?.[0]?.[1] as number || 0;
    const resetIn = window - (now - windowStart);

    return {
      allowed: current <= limit,
      remaining: Math.max(0, limit - current),
      limit,
      resetIn,
      current,
    };
  }

  /**
   * Consume a request from rate limit
   */
  async consume(
    identifier: string,
    config?: Partial<RateLimitConfig>
  ): Promise<RateLimitResult> {
    const result = await this.checkRateLimit(identifier, config);

    if (!result.allowed) {
      logger.warn('Rate limit exceeded', {
        identifier,
        current: result.current,
        limit: result.limit,
      });
    }

    return result;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Sliding Window Rate Limiting
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Check rate limit using sliding window algorithm
   * More accurate than fixed window but slightly more expensive
   */
  async checkSlidingWindow(
    identifier: string,
    config?: Partial<SlidingWindowConfig>
  ): Promise<RateLimitResult> {
    const { limit, window, prefix, buckets = 10 } = { ...this.defaultConfig, ...config };
    const key = `${prefix}sw:${identifier}`;

    const now = Date.now();
    const bucketSize = (window * 1000) / buckets;
    const currentBucket = Math.floor(now / bucketSize);

    // Get all buckets in the window
    const pipeline = this.redis.pipeline();
    for (let i = 0; i < buckets; i++) {
      pipeline.get(`${key}:${currentBucket - i}`);
    }
    const results = await pipeline.exec();

    // Sum up requests in window
    let total = 0;
    const weights: number[] = [];
    for (let i = 0; i < buckets; i++) {
      const count = parseInt((results?.[i]?.[1] as string) || '0');
      // Weight by how much of the bucket is in the window
      const weight = i === 0 ? (now % bucketSize) / bucketSize : 1;
      weights.push(weight);
      total += count * weight;
    }

    const current = Math.ceil(total);
    const resetIn = Math.ceil((bucketSize - (now % bucketSize)) / 1000);

    return {
      allowed: current < limit,
      remaining: Math.max(0, limit - current - 1),
      limit,
      resetIn,
      current,
    };
  }

  /**
   * Increment sliding window counter
   */
  async incrementSlidingWindow(
    identifier: string,
    config?: Partial<SlidingWindowConfig>
  ): Promise<RateLimitResult> {
    const { window, prefix, buckets = 10 } = { ...this.defaultConfig, ...config };
    const key = `${prefix}sw:${identifier}`;

    const now = Date.now();
    const bucketSize = (window * 1000) / buckets;
    const currentBucket = Math.floor(now / bucketSize);
    const bucketKey = `${key}:${currentBucket}`;

    await this.redis.multi()
      .incr(bucketKey)
      .expire(bucketKey, window + 1)
      .exec();

    return this.checkSlidingWindow(identifier, config);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Token Bucket Rate Limiting
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Check and consume from token bucket
   * Good for handling bursts while maintaining average rate
   */
  async consumeTokenBucket(
    identifier: string,
    tokens: number = 1,
    config: TokenBucketConfig
  ): Promise<{ allowed: boolean; tokens: number; refillIn: number }> {
    const { capacity, refillRate, initialTokens = capacity } = config;
    const key = `${this.defaultConfig.prefix}tb:${identifier}`;

    const now = Date.now();

    // Lua script for atomic token bucket operation
    const script = `
      local key = KEYS[1]
      local capacity = tonumber(ARGV[1])
      local refillRate = tonumber(ARGV[2])
      local requested = tonumber(ARGV[3])
      local now = tonumber(ARGV[4])
      local initialTokens = tonumber(ARGV[5])

      local data = redis.call('HMGET', key, 'tokens', 'lastRefill')
      local tokens = tonumber(data[1])
      local lastRefill = tonumber(data[2])

      if tokens == nil then
        tokens = initialTokens
        lastRefill = now
      else
        -- Calculate tokens to add based on time elapsed
        local elapsed = (now - lastRefill) / 1000
        local tokensToAdd = elapsed * refillRate
        tokens = math.min(capacity, tokens + tokensToAdd)
        lastRefill = now
      end

      if tokens >= requested then
        tokens = tokens - requested
        redis.call('HMSET', key, 'tokens', tokens, 'lastRefill', lastRefill)
        redis.call('EXPIRE', key, 3600)
        return {1, tokens}
      else
        redis.call('HMSET', key, 'tokens', tokens, 'lastRefill', lastRefill)
        redis.call('EXPIRE', key, 3600)
        return {0, tokens}
      end
    `;

    const result = await this.redis.eval(
      script,
      1,
      key,
      capacity.toString(),
      refillRate.toString(),
      tokens.toString(),
      now.toString(),
      initialTokens.toString()
    ) as [number, number];

    const remainingTokens = result[1];
    const refillIn = tokens <= remainingTokens ? 0 : Math.ceil((tokens - remainingTokens) / refillRate);

    return {
      allowed: result[0] === 1,
      tokens: remainingTokens,
      refillIn,
    };
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Dynamic Pricing
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Calculate dynamic price based on demand
   */
  async calculateDynamicPrice(
    laneCode: string,
    baseRate: number,
    config: DynamicPricingConfig
  ): Promise<{
    rate: number;
    multiplier: number;
    demand: number;
    trend: 'up' | 'down' | 'stable';
  }> {
    const key = `${this.defaultConfig.prefix}dp:${laneCode}`;

    // Get demand data from last hour
    const now = Date.now();
    const oneHourAgo = now - 3600000;

    // Get recent requests and bookings
    const [requests, bookings] = await Promise.all([
      this.redis.zcount(`${key}:requests`, oneHourAgo, now),
      this.redis.zcount(`${key}:bookings`, oneHourAgo, now),
    ]);

    // Calculate demand ratio (bookings / requests)
    const demand = requests > 0 ? bookings / requests : 0.5;

    // Determine multiplier based on demand
    let multiplier = 1;
    let trend: 'up' | 'down' | 'stable' = 'stable';

    if (demand >= config.highDemandThreshold) {
      // High demand - increase price
      const excess = (demand - config.highDemandThreshold) / (1 - config.highDemandThreshold);
      multiplier = 1 + excess * (config.maxMultiplier - 1);
      trend = 'up';
    } else if (demand <= config.lowDemandThreshold) {
      // Low demand - decrease price
      const deficit = (config.lowDemandThreshold - demand) / config.lowDemandThreshold;
      multiplier = 1 - deficit * (1 - config.minMultiplier);
      trend = 'down';
    }

    // Clamp multiplier
    multiplier = Math.max(config.minMultiplier, Math.min(config.maxMultiplier, multiplier));

    const rate = Math.round(baseRate * multiplier);

    logger.debug('Dynamic pricing calculated', {
      laneCode,
      baseRate,
      rate,
      multiplier,
      demand,
      trend,
      requests,
      bookings,
    });

    return { rate, multiplier, demand, trend };
  }

  /**
   * Record a rate request for dynamic pricing
   */
  async recordRateRequest(laneCode: string): Promise<void> {
    const key = `${this.defaultConfig.prefix}dp:${laneCode}:requests`;
    const now = Date.now();
    const twoHoursAgo = now - 7200000;

    await this.redis.multi()
      .zadd(key, now, `${now}`)
      .zremrangebyscore(key, 0, twoHoursAgo)
      .expire(key, 7200)
      .exec();
  }

  /**
   * Record a booking for dynamic pricing
   */
  async recordBooking(laneCode: string): Promise<void> {
    const key = `${this.defaultConfig.prefix}dp:${laneCode}:bookings`;
    const now = Date.now();
    const twoHoursAgo = now - 7200000;

    await this.redis.multi()
      .zadd(key, now, `${now}`)
      .zremrangebyscore(key, 0, twoHoursAgo)
      .expire(key, 7200)
      .exec();
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Utility Methods
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Reset rate limit for an identifier
   */
  async reset(identifier: string): Promise<void> {
    const pattern = `${this.defaultConfig.prefix}*${identifier}*`;
    const keys = await this.redis.keys(pattern);
    if (keys.length > 0) {
      await this.redis.del(...keys);
    }
  }

  /**
   * Get current usage stats
   */
  async getStats(identifier: string): Promise<{
    fixedWindow: number;
    slidingWindow: number;
  }> {
    const { window, prefix } = this.defaultConfig;
    const now = Math.floor(Date.now() / 1000);
    const windowStart = Math.floor(now / window) * window;

    const [fixed, sliding] = await Promise.all([
      this.redis.get(`${prefix}${identifier}:${windowStart}`),
      this.checkSlidingWindow(identifier),
    ]);

    return {
      fixedWindow: parseInt(fixed || '0'),
      slidingWindow: sliding.current,
    };
  }

  /**
   * Close Redis connection
   */
  async close(): Promise<void> {
    await this.redis.quit();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Pre-configured Rate Limiters
// ─────────────────────────────────────────────────────────────────────────────

export const rateLimiters = {
  /** API rate limiter - 100 requests per minute */
  api: { limit: 100, window: 60, prefix: 'rl:api:' },

  /** Auth rate limiter - 5 login attempts per 15 minutes */
  auth: { limit: 5, window: 900, prefix: 'rl:auth:' },

  /** Quote rate limiter - 20 quotes per minute */
  quote: { limit: 20, window: 60, prefix: 'rl:quote:' },

  /** Bid rate limiter - 10 bids per minute */
  bid: { limit: 10, window: 60, prefix: 'rl:bid:' },

  /** Search rate limiter - 30 searches per minute */
  search: { limit: 30, window: 60, prefix: 'rl:search:' },

  /** Webhook rate limiter - 1000 per hour */
  webhook: { limit: 1000, window: 3600, prefix: 'rl:webhook:' },
};

export default RateLimiterService;
