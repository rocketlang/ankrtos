/**
 * Fr8X Token Service
 * Handles JWT access tokens and refresh tokens with "Remember Me" support
 */

import jwt from 'jsonwebtoken';
import { randomBytes, createHash } from 'crypto';
import type { PrismaClient } from '../../generated/prisma/index.js';
import { logger } from '../lib/index.js';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface TokenPayload {
  userId: string;
  email: string;
  role: string;
  organizationId: string | null;
  sessionId: string;
}

export interface AccessTokenPayload extends TokenPayload {
  type: 'access';
}

export interface RefreshTokenPayload {
  userId: string;
  sessionId: string;
  tokenId: string;
  type: 'refresh';
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  refreshExpiresIn: number;
}

export interface TokenConfig {
  accessTokenSecret: string;
  refreshTokenSecret: string;
  accessTokenExpiry: string;
  refreshTokenExpiry: string;
  rememberMeExpiry: string;
}

export interface RefreshTokenRecord {
  id: string;
  userId: string;
  sessionId: string;
  tokenHash: string;
  userAgent?: string;
  ipAddress?: string;
  expiresAt: Date;
  createdAt: Date;
  lastUsedAt: Date;
  isRevoked: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// Token Service
// ─────────────────────────────────────────────────────────────────────────────

export class TokenService {
  private prisma: PrismaClient;
  private config: TokenConfig;

  constructor(prisma: PrismaClient, config?: Partial<TokenConfig>) {
    this.prisma = prisma;
    this.config = {
      accessTokenSecret: config?.accessTokenSecret || process.env.JWT_SECRET || 'fr8x-secret',
      refreshTokenSecret: config?.refreshTokenSecret || process.env.JWT_REFRESH_SECRET || 'fr8x-refresh-secret',
      accessTokenExpiry: config?.accessTokenExpiry || '15m',
      refreshTokenExpiry: config?.refreshTokenExpiry || '7d',
      rememberMeExpiry: config?.rememberMeExpiry || '30d',
    };
  }

  /**
   * Generate a new token pair (access + refresh)
   */
  async generateTokenPair(
    user: { id: string; email: string; role: string; organizationId: string | null },
    options?: {
      rememberMe?: boolean;
      userAgent?: string;
      ipAddress?: string;
    }
  ): Promise<TokenPair> {
    const sessionId = this.generateSessionId();
    const tokenId = this.generateTokenId();

    // Calculate expiry times
    const accessExpiresIn = this.parseExpiry(this.config.accessTokenExpiry);
    const refreshExpiresIn = options?.rememberMe
      ? this.parseExpiry(this.config.rememberMeExpiry)
      : this.parseExpiry(this.config.refreshTokenExpiry);

    // Generate access token
    const accessPayload: AccessTokenPayload = {
      userId: user.id,
      email: user.email,
      role: user.role,
      organizationId: user.organizationId,
      sessionId,
      type: 'access',
    };

    const accessToken = jwt.sign(accessPayload, this.config.accessTokenSecret, {
      expiresIn: this.config.accessTokenExpiry,
      issuer: 'fr8x',
      audience: 'fr8x-api',
    });

    // Generate refresh token
    const refreshPayload: RefreshTokenPayload = {
      userId: user.id,
      sessionId,
      tokenId,
      type: 'refresh',
    };

    const refreshToken = jwt.sign(refreshPayload, this.config.refreshTokenSecret, {
      expiresIn: options?.rememberMe ? this.config.rememberMeExpiry : this.config.refreshTokenExpiry,
      issuer: 'fr8x',
      audience: 'fr8x-refresh',
    });

    // Store refresh token hash in database
    await this.storeRefreshToken({
      id: tokenId,
      userId: user.id,
      sessionId,
      tokenHash: this.hashToken(refreshToken),
      userAgent: options?.userAgent,
      ipAddress: options?.ipAddress,
      expiresAt: new Date(Date.now() + refreshExpiresIn * 1000),
    });

    logger.info('Token pair generated', {
      userId: user.id,
      sessionId,
      rememberMe: options?.rememberMe || false,
    });

    return {
      accessToken,
      refreshToken,
      expiresIn: accessExpiresIn,
      refreshExpiresIn,
    };
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshAccessToken(
    refreshToken: string,
    options?: { userAgent?: string; ipAddress?: string }
  ): Promise<TokenPair | null> {
    try {
      // Verify refresh token
      const payload = jwt.verify(refreshToken, this.config.refreshTokenSecret, {
        issuer: 'fr8x',
        audience: 'fr8x-refresh',
      }) as RefreshTokenPayload;

      if (payload.type !== 'refresh') {
        logger.warn('Invalid token type for refresh');
        return null;
      }

      // Check if token exists and is not revoked
      const storedToken = await this.getStoredRefreshToken(payload.tokenId);
      if (!storedToken || storedToken.isRevoked) {
        logger.warn('Refresh token not found or revoked', { tokenId: payload.tokenId });
        return null;
      }

      // Verify token hash matches
      if (storedToken.tokenHash !== this.hashToken(refreshToken)) {
        logger.warn('Refresh token hash mismatch', { tokenId: payload.tokenId });
        await this.revokeTokenFamily(payload.sessionId); // Revoke all tokens in family
        return null;
      }

      // Check if token is expired
      if (storedToken.expiresAt < new Date()) {
        logger.warn('Refresh token expired', { tokenId: payload.tokenId });
        return null;
      }

      // Get user
      const user = await this.prisma.user.findUnique({
        where: { id: payload.userId },
        select: { id: true, email: true, role: true, organizationId: true },
      });

      if (!user) {
        logger.warn('User not found for refresh', { userId: payload.userId });
        return null;
      }

      // Revoke old refresh token (rotation)
      await this.revokeRefreshToken(payload.tokenId);

      // Generate new token pair with same session
      const newTokenId = this.generateTokenId();
      const accessExpiresIn = this.parseExpiry(this.config.accessTokenExpiry);

      // Calculate remaining time on refresh token
      const remainingRefreshTime = Math.floor((storedToken.expiresAt.getTime() - Date.now()) / 1000);

      const accessPayload: AccessTokenPayload = {
        userId: user.id,
        email: user.email,
        role: user.role,
        organizationId: user.organizationId,
        sessionId: payload.sessionId,
        type: 'access',
      };

      const accessToken = jwt.sign(accessPayload, this.config.accessTokenSecret, {
        expiresIn: this.config.accessTokenExpiry,
        issuer: 'fr8x',
        audience: 'fr8x-api',
      });

      const newRefreshPayload: RefreshTokenPayload = {
        userId: user.id,
        sessionId: payload.sessionId,
        tokenId: newTokenId,
        type: 'refresh',
      };

      const newRefreshToken = jwt.sign(newRefreshPayload, this.config.refreshTokenSecret, {
        expiresIn: remainingRefreshTime,
        issuer: 'fr8x',
        audience: 'fr8x-refresh',
      });

      // Store new refresh token
      await this.storeRefreshToken({
        id: newTokenId,
        userId: user.id,
        sessionId: payload.sessionId,
        tokenHash: this.hashToken(newRefreshToken),
        userAgent: options?.userAgent,
        ipAddress: options?.ipAddress,
        expiresAt: storedToken.expiresAt, // Keep same expiry
      });

      logger.info('Access token refreshed', {
        userId: user.id,
        sessionId: payload.sessionId,
      });

      return {
        accessToken,
        refreshToken: newRefreshToken,
        expiresIn: accessExpiresIn,
        refreshExpiresIn: remainingRefreshTime,
      };
    } catch (error) {
      logger.error('Failed to refresh access token', error as Error);
      return null;
    }
  }

  /**
   * Verify access token
   */
  verifyAccessToken(token: string): AccessTokenPayload | null {
    try {
      const payload = jwt.verify(token, this.config.accessTokenSecret, {
        issuer: 'fr8x',
        audience: 'fr8x-api',
      }) as AccessTokenPayload;

      if (payload.type !== 'access') {
        return null;
      }

      return payload;
    } catch {
      return null;
    }
  }

  /**
   * Revoke all tokens for a session (logout)
   */
  async revokeSession(sessionId: string): Promise<void> {
    await this.revokeTokenFamily(sessionId);
    logger.info('Session revoked', { sessionId });
  }

  /**
   * Revoke all tokens for a user (logout all devices)
   */
  async revokeAllUserTokens(userId: string): Promise<void> {
    await this.prisma.refreshToken.updateMany({
      where: { userId, isRevoked: false },
      data: { isRevoked: true },
    });
    logger.info('All user tokens revoked', { userId });
  }

  /**
   * Get active sessions for a user
   */
  async getActiveSessions(userId: string): Promise<Array<{
    sessionId: string;
    userAgent?: string;
    ipAddress?: string;
    lastUsedAt: Date;
    createdAt: Date;
  }>> {
    const tokens = await this.prisma.refreshToken.findMany({
      where: {
        userId,
        isRevoked: false,
        expiresAt: { gt: new Date() },
      },
      select: {
        sessionId: true,
        userAgent: true,
        ipAddress: true,
        lastUsedAt: true,
        createdAt: true,
      },
      orderBy: { lastUsedAt: 'desc' },
    });

    // Dedupe by sessionId (keep most recent)
    const sessionsMap = new Map<string, typeof tokens[0]>();
    tokens.forEach((t) => {
      if (!sessionsMap.has(t.sessionId)) {
        sessionsMap.set(t.sessionId, t);
      }
    });

    return Array.from(sessionsMap.values());
  }

  /**
   * Clean up expired tokens (run periodically)
   */
  async cleanupExpiredTokens(): Promise<number> {
    const result = await this.prisma.refreshToken.deleteMany({
      where: {
        OR: [
          { expiresAt: { lt: new Date() } },
          { isRevoked: true },
        ],
      },
    });
    logger.info('Cleaned up expired tokens', { count: result.count });
    return result.count;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Private Methods
  // ─────────────────────────────────────────────────────────────────────────────

  private generateSessionId(): string {
    return randomBytes(32).toString('hex');
  }

  private generateTokenId(): string {
    return randomBytes(16).toString('hex');
  }

  private hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  private parseExpiry(expiry: string): number {
    const match = expiry.match(/^(\d+)([smhd])$/);
    if (!match) return 3600; // Default 1 hour

    const [, value, unit] = match;
    const multipliers: Record<string, number> = {
      s: 1,
      m: 60,
      h: 3600,
      d: 86400,
    };

    return parseInt(value) * (multipliers[unit] || 1);
  }

  private async storeRefreshToken(data: Omit<RefreshTokenRecord, 'createdAt' | 'lastUsedAt' | 'isRevoked'>): Promise<void> {
    await this.prisma.refreshToken.create({
      data: {
        ...data,
        isRevoked: false,
        lastUsedAt: new Date(),
      },
    });
  }

  private async getStoredRefreshToken(tokenId: string): Promise<RefreshTokenRecord | null> {
    return this.prisma.refreshToken.findUnique({
      where: { id: tokenId },
    });
  }

  private async revokeRefreshToken(tokenId: string): Promise<void> {
    await this.prisma.refreshToken.update({
      where: { id: tokenId },
      data: { isRevoked: true },
    });
  }

  private async revokeTokenFamily(sessionId: string): Promise<void> {
    await this.prisma.refreshToken.updateMany({
      where: { sessionId, isRevoked: false },
      data: { isRevoked: true },
    });
  }
}

export default TokenService;
