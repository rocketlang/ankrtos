/**
 * Fr8X Auth Hook
 * Handles authentication with Remember Me and refresh token support
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useMutation, useApolloClient } from '@apollo/client';
import { gql } from '@apollo/client';

// ─────────────────────────────────────────────────────────────────────────────
// GraphQL Operations
// ─────────────────────────────────────────────────────────────────────────────

const LOGIN_MUTATION = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      accessToken
      refreshToken
      expiresIn
      refreshExpiresIn
      user {
        id
        email
        firstName
        lastName
        role
        organizationId
      }
    }
  }
`;

const REFRESH_TOKEN_MUTATION = gql`
  mutation RefreshToken($refreshToken: String!) {
    refreshToken(refreshToken: $refreshToken) {
      accessToken
      refreshToken
      expiresIn
      refreshExpiresIn
    }
  }
`;

const LOGOUT_MUTATION = gql`
  mutation Logout {
    logout
  }
`;

const GET_ME_QUERY = gql`
  query GetMe {
    me {
      id
      email
      firstName
      lastName
      role
      organizationId
      organization {
        id
        name
      }
    }
  }
`;

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  organizationId: string | null;
  organization?: {
    id: string;
    name: string;
  } | null;
}

export interface LoginInput {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface AuthActions {
  login: (input: LoginInput) => Promise<boolean>;
  logout: () => Promise<void>;
  refreshSession: () => Promise<boolean>;
}

// ─────────────────────────────────────────────────────────────────────────────
// Token Storage
// ─────────────────────────────────────────────────────────────────────────────

const TOKEN_KEYS = {
  ACCESS: 'fr8x_access_token',
  REFRESH: 'fr8x_refresh_token',
  EXPIRY: 'fr8x_token_expiry',
  REMEMBER_ME: 'fr8x_remember_me',
};

function getStoredTokens() {
  if (typeof window === 'undefined') return null;

  const accessToken = localStorage.getItem(TOKEN_KEYS.ACCESS);
  const refreshToken = localStorage.getItem(TOKEN_KEYS.REFRESH);
  const expiry = localStorage.getItem(TOKEN_KEYS.EXPIRY);
  const rememberMe = localStorage.getItem(TOKEN_KEYS.REMEMBER_ME) === 'true';

  if (!accessToken) return null;

  return {
    accessToken,
    refreshToken,
    expiry: expiry ? parseInt(expiry) : 0,
    rememberMe,
  };
}

function storeTokens(
  accessToken: string,
  refreshToken: string,
  expiresIn: number,
  rememberMe: boolean
) {
  const expiry = Date.now() + expiresIn * 1000;

  if (rememberMe) {
    // Use localStorage for persistent storage
    localStorage.setItem(TOKEN_KEYS.ACCESS, accessToken);
    localStorage.setItem(TOKEN_KEYS.REFRESH, refreshToken);
    localStorage.setItem(TOKEN_KEYS.EXPIRY, expiry.toString());
    localStorage.setItem(TOKEN_KEYS.REMEMBER_ME, 'true');
  } else {
    // Use sessionStorage for session-only storage
    sessionStorage.setItem(TOKEN_KEYS.ACCESS, accessToken);
    sessionStorage.setItem(TOKEN_KEYS.REFRESH, refreshToken);
    sessionStorage.setItem(TOKEN_KEYS.EXPIRY, expiry.toString());
    // Also keep in localStorage for cross-tab access
    localStorage.setItem(TOKEN_KEYS.ACCESS, accessToken);
    localStorage.setItem(TOKEN_KEYS.REFRESH, refreshToken);
    localStorage.setItem(TOKEN_KEYS.EXPIRY, expiry.toString());
    localStorage.removeItem(TOKEN_KEYS.REMEMBER_ME);
  }
}

function clearTokens() {
  localStorage.removeItem(TOKEN_KEYS.ACCESS);
  localStorage.removeItem(TOKEN_KEYS.REFRESH);
  localStorage.removeItem(TOKEN_KEYS.EXPIRY);
  localStorage.removeItem(TOKEN_KEYS.REMEMBER_ME);
  sessionStorage.removeItem(TOKEN_KEYS.ACCESS);
  sessionStorage.removeItem(TOKEN_KEYS.REFRESH);
  sessionStorage.removeItem(TOKEN_KEYS.EXPIRY);
}

function isTokenExpired(expiry: number): boolean {
  // Add 30 second buffer for refresh
  return Date.now() > expiry - 30000;
}

// ─────────────────────────────────────────────────────────────────────────────
// Auth Hook
// ─────────────────────────────────────────────────────────────────────────────

export function useAuth(): AuthState & AuthActions {
  const router = useRouter();
  const apolloClient = useApolloClient();

  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  });

  const refreshTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isRefreshingRef = useRef(false);

  // Mutations
  const [loginMutation] = useMutation(LOGIN_MUTATION);
  const [refreshTokenMutation] = useMutation(REFRESH_TOKEN_MUTATION);
  const [logoutMutation] = useMutation(LOGOUT_MUTATION);

  // Schedule token refresh
  const scheduleRefresh = useCallback((expiresIn: number) => {
    if (refreshTimerRef.current) {
      clearTimeout(refreshTimerRef.current);
    }

    // Refresh 1 minute before expiry
    const refreshIn = Math.max((expiresIn - 60) * 1000, 10000);

    refreshTimerRef.current = setTimeout(() => {
      refreshSession();
    }, refreshIn);
  }, []);

  // Refresh session
  const refreshSession = useCallback(async (): Promise<boolean> => {
    if (isRefreshingRef.current) return false;
    isRefreshingRef.current = true;

    try {
      const tokens = getStoredTokens();
      if (!tokens?.refreshToken) {
        isRefreshingRef.current = false;
        return false;
      }

      const { data } = await refreshTokenMutation({
        variables: { refreshToken: tokens.refreshToken },
      });

      if (data?.refreshToken) {
        storeTokens(
          data.refreshToken.accessToken,
          data.refreshToken.refreshToken,
          data.refreshToken.expiresIn,
          tokens.rememberMe
        );

        scheduleRefresh(data.refreshToken.expiresIn);
        isRefreshingRef.current = false;
        return true;
      }

      isRefreshingRef.current = false;
      return false;
    } catch (error) {
      console.error('Token refresh failed:', error);
      isRefreshingRef.current = false;
      return false;
    }
  }, [refreshTokenMutation, scheduleRefresh]);

  // Login
  const login = useCallback(
    async (input: LoginInput): Promise<boolean> => {
      setState((s) => ({ ...s, isLoading: true, error: null }));

      try {
        const { data } = await loginMutation({
          variables: {
            input: {
              email: input.email,
              password: input.password,
              rememberMe: input.rememberMe || false,
            },
          },
        });

        if (data?.login) {
          storeTokens(
            data.login.accessToken,
            data.login.refreshToken,
            data.login.expiresIn,
            input.rememberMe || false
          );

          setState({
            user: data.login.user,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });

          scheduleRefresh(data.login.expiresIn);
          return true;
        }

        setState((s) => ({
          ...s,
          isLoading: false,
          error: 'Login failed',
        }));
        return false;
      } catch (error: any) {
        const message = error.graphQLErrors?.[0]?.message || 'Login failed';
        setState((s) => ({
          ...s,
          isLoading: false,
          error: message,
        }));
        return false;
      }
    },
    [loginMutation, scheduleRefresh]
  );

  // Logout
  const logout = useCallback(async () => {
    try {
      await logoutMutation();
    } catch {
      // Ignore errors, clear local state anyway
    }

    if (refreshTimerRef.current) {
      clearTimeout(refreshTimerRef.current);
    }

    clearTokens();
    await apolloClient.clearStore();

    setState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
    });

    router.push('/exchange/login');
  }, [logoutMutation, apolloClient, router]);

  // Initialize auth state from stored tokens
  useEffect(() => {
    const initAuth = async () => {
      const tokens = getStoredTokens();

      if (!tokens) {
        setState((s) => ({ ...s, isLoading: false }));
        return;
      }

      // Check if token is expired
      if (tokens.expiry && isTokenExpired(tokens.expiry)) {
        // Try to refresh
        const refreshed = await refreshSession();
        if (!refreshed) {
          clearTokens();
          setState((s) => ({ ...s, isLoading: false }));
          return;
        }
      }

      // Fetch user data
      try {
        const { data } = await apolloClient.query({
          query: GET_ME_QUERY,
          fetchPolicy: 'network-only',
        });

        if (data?.me) {
          setState({
            user: data.me,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });

          // Schedule refresh
          const timeUntilExpiry = tokens.expiry ? (tokens.expiry - Date.now()) / 1000 : 300;
          scheduleRefresh(timeUntilExpiry);
        } else {
          clearTokens();
          setState((s) => ({ ...s, isLoading: false }));
        }
      } catch (error) {
        console.error('Failed to fetch user:', error);
        clearTokens();
        setState((s) => ({ ...s, isLoading: false }));
      }
    };

    initAuth();

    // Cleanup
    return () => {
      if (refreshTimerRef.current) {
        clearTimeout(refreshTimerRef.current);
      }
    };
  }, [apolloClient, refreshSession, scheduleRefresh]);

  // Listen for storage events (cross-tab sync)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === TOKEN_KEYS.ACCESS) {
        if (!e.newValue) {
          // Token cleared in another tab - logout
          setState({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            error: null,
          });
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return {
    ...state,
    login,
    logout,
    refreshSession,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Auth Context (Optional)
// ─────────────────────────────────────────────────────────────────────────────

import { createContext, useContext, type ReactNode } from 'react';

const AuthContext = createContext<(AuthState & AuthActions) | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const auth = useAuth();
  return <AuthContext.Provider value={auth}>{children}</AuthContext.Provider>;
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthContext must be used within AuthProvider');
  }
  return context;
}

export default useAuth;
