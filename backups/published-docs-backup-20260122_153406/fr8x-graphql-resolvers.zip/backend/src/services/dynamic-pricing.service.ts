/**
 * FR8X Dynamic Pricing Service
 * Integrates with @ankr/xchg rate engine for dynamic pricing
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

import { PrismaClient } from '@prisma/client';
import { PubSub } from 'mercurius';
import * as crypto from 'crypto';

// ============================================================================
// TYPES
// ============================================================================

export interface RateResult {
  laneHash: string;
  originPin: string;
  destPin: string;
  vehicleType: string;
  rate: number;
  rateType: 'contract' | 'branch' | 'spot' | 'benchmark' | 'estimated';
  surgeMultiplier?: number;
  customerId?: string;
  validUntil?: Date;
  confidence: number;
  breakdown: {
    baseRate: number;
    tollEstimate: number;
    margin?: number;
    fuelSurcharge?: number;
    handlingCharges?: number;
  };
  currency: string;
}

export interface SurgeInfo {
  demandScore: number;  // 0-100
  supplyScore: number;  // 0-100
  surgeRatio: number;
  multiplier: number;
  level: 'low' | 'below_normal' | 'normal' | 'high' | 'surge' | 'peak';
  description: string;
}

export interface RateTrend {
  date: Date;
  rateType: string;
  minRate: number;
  maxRate: number;
  avgRate: number;
  transactions: number;
}

export interface PricingConfig {
  defaultMarginPercent: number;
  minMarginPercent: number;
  maxMarginPercent: number;
  surgeEnabled: boolean;
  maxSurgeMultiplier: number;
  minSurgeMultiplier: number;
  fuelSurchargePercent: number;
  gstPercent: number;
  roundToNearest: number;
}

// ============================================================================
// DEFAULT CONFIG
// ============================================================================

const DEFAULT_PRICING_CONFIG: PricingConfig = {
  defaultMarginPercent: 15,
  minMarginPercent: 5,
  maxMarginPercent: 30,
  surgeEnabled: true,
  maxSurgeMultiplier: 1.5,
  minSurgeMultiplier: 0.85,
  fuelSurchargePercent: 5,
  gstPercent: 18,
  roundToNearest: 100, // Round to nearest 100
};

// ============================================================================
// VEHICLE RATE MATRIX (Base rate per km)
// ============================================================================

const VEHICLE_RATES: Record<string, { ratePerKm: number; tollMultiplier: number }> = {
  'Tata Ace': { ratePerKm: 18, tollMultiplier: 0.5 },
  'Tata 407': { ratePerKm: 25, tollMultiplier: 0.7 },
  'Eicher 14Ft': { ratePerKm: 35, tollMultiplier: 1.0 },
  'Eicher 17Ft': { ratePerKm: 42, tollMultiplier: 1.0 },
  'Eicher 19Ft': { ratePerKm: 48, tollMultiplier: 1.0 },
  '20Ft Container': { ratePerKm: 45, tollMultiplier: 1.0 },
  '32Ft SXL': { ratePerKm: 52, tollMultiplier: 1.2 },
  '32Ft MXL': { ratePerKm: 55, tollMultiplier: 1.2 },
  '40Ft MXL': { ratePerKm: 65, tollMultiplier: 1.5 },
  '40Ft HQ': { ratePerKm: 70, tollMultiplier: 1.5 },
  'Trailer 40Ft': { ratePerKm: 75, tollMultiplier: 1.8 },
  'ODC': { ratePerKm: 90, tollMultiplier: 2.0 },
};

// ============================================================================
// DYNAMIC PRICING SERVICE
// ============================================================================

export class DynamicPricingService {
  private prisma: PrismaClient;
  private pubsub?: PubSub;
  private config: PricingConfig;
  private rateCache: Map<string, { rate: RateResult; expiresAt: Date }> = new Map();
  private surgeCache: Map<string, { surge: SurgeInfo; expiresAt: Date }> = new Map();

  constructor(
    prisma: PrismaClient,
    pubsub?: PubSub,
    config: Partial<PricingConfig> = {}
  ) {
    this.prisma = prisma;
    this.pubsub = pubsub;
    this.config = { ...DEFAULT_PRICING_CONFIG, ...config };
  }

  // --------------------------------------------------------------------------
  // LANE HASH
  // --------------------------------------------------------------------------

  getLaneHash(origin: string, dest: string, vehicle: string): string {
    return crypto.createHash('md5').update(`${origin}|${dest}|${vehicle}`).digest('hex');
  }

  // --------------------------------------------------------------------------
  // GET RATE (Priority Fallback)
  // --------------------------------------------------------------------------

  async getRate(
    originPin: string,
    destPin: string,
    vehicleType: string,
    customerId?: string,
    branchId?: string,
    distanceKm?: number
  ): Promise<RateResult> {
    const laneHash = this.getLaneHash(originPin, destPin, vehicleType);

    // Check cache first
    const cached = this.rateCache.get(laneHash);
    if (cached && cached.expiresAt > new Date()) {
      return cached.rate;
    }

    // 1. Try CONTRACT rate (customer-specific)
    if (customerId) {
      const contractRate = await this.getContractRate(laneHash, customerId);
      if (contractRate) {
        this.cacheRate(laneHash, contractRate);
        return contractRate;
      }
    }

    // 2. Try BRANCH rate
    if (branchId) {
      const branchRate = await this.getBranchRate(laneHash, branchId);
      if (branchRate) {
        this.cacheRate(laneHash, branchRate);
        return branchRate;
      }
    }

    // 3. Try SPOT rate (with surge)
    const spotRate = await this.getSpotRate(laneHash, originPin, destPin, vehicleType);
    if (spotRate) {
      this.cacheRate(laneHash, spotRate);
      return spotRate;
    }

    // 4. Try BENCHMARK rate (ML-trained)
    const benchmarkRate = await this.getBenchmarkRate(laneHash);
    if (benchmarkRate) {
      this.cacheRate(laneHash, benchmarkRate);
      return benchmarkRate;
    }

    // 5. ESTIMATE fallback
    const estimatedRate = this.estimateRate(
      originPin,
      destPin,
      vehicleType,
      distanceKm || 500
    );
    this.cacheRate(laneHash, estimatedRate);
    return estimatedRate;
  }

  // --------------------------------------------------------------------------
  // CONTRACT RATE
  // --------------------------------------------------------------------------

  private async getContractRate(laneHash: string, customerId: string): Promise<RateResult | null> {
    try {
      const result = await this.prisma.$queryRaw<Array<{
        rate: number;
        toll_included: boolean;
        valid_to: Date;
        origin_pin: string;
        dest_pin: string;
        vehicle_type: string;
      }>>`
        SELECT rate, toll_included, valid_to, origin_pin, dest_pin, vehicle_type
        FROM rates.contracts
        WHERE customer_id = ${customerId}
          AND lane_hash = ${laneHash}
          AND status = 'active'
          AND valid_from <= CURRENT_DATE
          AND valid_to >= CURRENT_DATE
        LIMIT 1
      `;

      if (result.length === 0) return null;

      const contract = result[0];
      return {
        laneHash,
        originPin: contract.origin_pin,
        destPin: contract.dest_pin,
        vehicleType: contract.vehicle_type,
        rate: Number(contract.rate),
        rateType: 'contract',
        customerId,
        validUntil: contract.valid_to,
        confidence: 1.0,
        breakdown: {
          baseRate: Number(contract.rate),
          tollEstimate: contract.toll_included ? 0 : this.estimateToll(500),
        },
        currency: 'INR',
      };
    } catch (error) {
      console.warn('Contract rate lookup failed:', error);
      return null;
    }
  }

  // --------------------------------------------------------------------------
  // BRANCH RATE
  // --------------------------------------------------------------------------

  private async getBranchRate(laneHash: string, branchId: string): Promise<RateResult | null> {
    try {
      const result = await this.prisma.$queryRaw<Array<{
        base_rate: number;
        margin_percent: number;
        final_rate: number;
        origin_pin: string;
        dest_pin: string;
        vehicle_type: string;
      }>>`
        SELECT base_rate, margin_percent, final_rate, origin_pin, dest_pin, vehicle_type
        FROM rates.branch
        WHERE branch_id = ${branchId}
          AND lane_hash = ${laneHash}
          AND status = 'active'
        LIMIT 1
      `;

      if (result.length === 0) return null;

      const branch = result[0];
      const finalRate = Number(branch.final_rate || branch.base_rate);

      return {
        laneHash,
        originPin: branch.origin_pin,
        destPin: branch.dest_pin,
        vehicleType: branch.vehicle_type,
        rate: finalRate,
        rateType: 'branch',
        confidence: 0.9,
        breakdown: {
          baseRate: Number(branch.base_rate),
          tollEstimate: 0,
          margin: Number(branch.margin_percent),
        },
        currency: 'INR',
      };
    } catch (error) {
      console.warn('Branch rate lookup failed:', error);
      return null;
    }
  }

  // --------------------------------------------------------------------------
  // SPOT RATE (with Surge)
  // --------------------------------------------------------------------------

  private async getSpotRate(
    laneHash: string,
    originPin: string,
    destPin: string,
    vehicleType: string
  ): Promise<RateResult | null> {
    try {
      const result = await this.prisma.$queryRaw<Array<{
        base_rate: number;
        surge_multiplier: number;
        final_rate: number;
      }>>`
        SELECT base_rate, surge_multiplier, final_rate
        FROM rates.spot
        WHERE lane_hash = ${laneHash}
      `;

      if (result.length === 0) return null;

      const spot = result[0];
      const surge = await this.calculateSurge(laneHash);

      return {
        laneHash,
        originPin,
        destPin,
        vehicleType,
        rate: Number(spot.final_rate || spot.base_rate * surge.multiplier),
        rateType: 'spot',
        surgeMultiplier: surge.multiplier,
        confidence: 0.8,
        breakdown: {
          baseRate: Number(spot.base_rate),
          tollEstimate: 0,
        },
        currency: 'INR',
      };
    } catch (error) {
      console.warn('Spot rate lookup failed:', error);
      return null;
    }
  }

  // --------------------------------------------------------------------------
  // BENCHMARK RATE
  // --------------------------------------------------------------------------

  private async getBenchmarkRate(laneHash: string): Promise<RateResult | null> {
    try {
      const result = await this.prisma.$queryRaw<Array<{
        avg_rate: number;
        min_rate: number;
        max_rate: number;
        toll_estimate: number;
        confidence: number;
        origin_pin: string;
        dest_pin: string;
        vehicle_type: string;
      }>>`
        SELECT avg_rate, min_rate, max_rate, toll_estimate, confidence,
               origin_pin, dest_pin, vehicle_type
        FROM rates.benchmarks
        WHERE lane_hash = ${laneHash}
      `;

      if (result.length === 0) return null;

      const benchmark = result[0];
      return {
        laneHash,
        originPin: benchmark.origin_pin,
        destPin: benchmark.dest_pin,
        vehicleType: benchmark.vehicle_type,
        rate: Number(benchmark.avg_rate),
        rateType: 'benchmark',
        confidence: Number(benchmark.confidence),
        breakdown: {
          baseRate: Number(benchmark.avg_rate) - Number(benchmark.toll_estimate || 0),
          tollEstimate: Number(benchmark.toll_estimate || 0),
        },
        currency: 'INR',
      };
    } catch (error) {
      console.warn('Benchmark rate lookup failed:', error);
      return null;
    }
  }

  // --------------------------------------------------------------------------
  // ESTIMATE RATE (Fallback)
  // --------------------------------------------------------------------------

  private estimateRate(
    originPin: string,
    destPin: string,
    vehicleType: string,
    distanceKm: number
  ): RateResult {
    const laneHash = this.getLaneHash(originPin, destPin, vehicleType);
    const vehicleConfig = VEHICLE_RATES[vehicleType] || { ratePerKm: 50, tollMultiplier: 1.0 };

    const baseRate = distanceKm * vehicleConfig.ratePerKm;
    const tollEstimate = this.estimateToll(distanceKm) * vehicleConfig.tollMultiplier;
    const fuelSurcharge = baseRate * (this.config.fuelSurchargePercent / 100);
    const subtotal = baseRate + tollEstimate + fuelSurcharge;
    const margin = subtotal * (this.config.defaultMarginPercent / 100);
    const total = this.roundToNearest(subtotal + margin);

    return {
      laneHash,
      originPin,
      destPin,
      vehicleType,
      rate: total,
      rateType: 'estimated',
      confidence: 0.5,
      breakdown: {
        baseRate,
        tollEstimate,
        fuelSurcharge,
        margin,
      },
      currency: 'INR',
    };
  }

  // --------------------------------------------------------------------------
  // CALCULATE SURGE
  // --------------------------------------------------------------------------

  async calculateSurge(laneHash: string): Promise<SurgeInfo> {
    // Check cache
    const cached = this.surgeCache.get(laneHash);
    if (cached && cached.expiresAt > new Date()) {
      return cached.surge;
    }

    try {
      // Get demand (open loads)
      const demandResult = await this.prisma.$queryRaw<Array<{ count: number }>>`
        SELECT COUNT(*)::int as count FROM loads WHERE status = 'BIDDING'
      `.catch(() => [{ count: 10 }]);

      // Get supply (available vehicles)
      const supplyResult = await this.prisma.$queryRaw<Array<{ count: number }>>`
        SELECT COUNT(*)::int as count FROM vehicles WHERE status = 'AVAILABLE'
      `.catch(() => [{ count: 10 }]);

      const demandCount = demandResult[0]?.count || 10;
      const supplyCount = supplyResult[0]?.count || 10;

      const demandScore = Math.min(100, (demandCount / 20) * 100);
      const supplyScore = Math.min(100, (supplyCount / 15) * 100);
      const surgeRatio = supplyScore > 0 ? demandScore / supplyScore : 2;

      let multiplier = 1.0;
      let level: SurgeInfo['level'] = 'normal';
      let description = 'Normal pricing';

      if (surgeRatio < 0.5) {
        multiplier = this.config.minSurgeMultiplier;
        level = 'low';
        description = 'Low demand - discounted rates';
      } else if (surgeRatio < 0.8) {
        multiplier = 0.95;
        level = 'below_normal';
        description = 'Below average demand';
      } else if (surgeRatio <= 1.2) {
        multiplier = 1.0;
        level = 'normal';
        description = 'Normal pricing';
      } else if (surgeRatio <= 1.5) {
        multiplier = 1.15;
        level = 'high';
        description = 'High demand (+15%)';
      } else if (surgeRatio <= 2.0) {
        multiplier = 1.30;
        level = 'surge';
        description = 'Surge pricing (+30%)';
      } else {
        multiplier = this.config.maxSurgeMultiplier;
        level = 'peak';
        description = 'Peak demand (+50%)';
      }

      const surge: SurgeInfo = {
        demandScore,
        supplyScore,
        surgeRatio,
        multiplier,
        level,
        description,
      };

      // Cache for 5 minutes
      this.surgeCache.set(laneHash, {
        surge,
        expiresAt: new Date(Date.now() + 5 * 60 * 1000),
      });

      return surge;
    } catch (error) {
      console.warn('Surge calculation failed:', error);
      return {
        demandScore: 50,
        supplyScore: 50,
        surgeRatio: 1,
        multiplier: 1,
        level: 'normal',
        description: 'Normal pricing',
      };
    }
  }

  // --------------------------------------------------------------------------
  // UPDATE SPOT RATE
  // --------------------------------------------------------------------------

  async updateSpotRate(
    originPin: string,
    destPin: string,
    vehicleType: string,
    baseRate: number
  ): Promise<{ laneHash: string; baseRate: number; surge: SurgeInfo; finalRate: number }> {
    const laneHash = this.getLaneHash(originPin, destPin, vehicleType);
    const surge = await this.calculateSurge(laneHash);
    const finalRate = this.roundToNearest(baseRate * surge.multiplier);

    try {
      await this.prisma.$executeRaw`
        INSERT INTO rates.spot (lane_hash, origin_pin, dest_pin, vehicle_type, base_rate, surge_multiplier, final_rate, demand_score, supply_score, updated_at)
        VALUES (${laneHash}, ${originPin}, ${destPin}, ${vehicleType}, ${baseRate}, ${surge.multiplier}, ${finalRate}, ${surge.demandScore}, ${surge.supplyScore}, NOW())
        ON CONFLICT (lane_hash) DO UPDATE SET
          base_rate = ${baseRate},
          surge_multiplier = ${surge.multiplier},
          final_rate = ${finalRate},
          demand_score = ${surge.demandScore},
          supply_score = ${surge.supplyScore},
          updated_at = NOW()
      `;

      // Invalidate cache
      this.rateCache.delete(laneHash);

      // Publish rate update event
      if (this.pubsub) {
        this.pubsub.publish({
          topic: 'RATE_UPDATED',
          payload: { laneHash, originPin, destPin, vehicleType, baseRate, finalRate, surge },
        });
      }
    } catch (error) {
      console.warn('Spot rate update failed:', error);
    }

    return { laneHash, baseRate, surge, finalRate };
  }

  // --------------------------------------------------------------------------
  // GET RATE TRENDS
  // --------------------------------------------------------------------------

  async getRateTrends(laneHash: string, days = 30): Promise<RateTrend[]> {
    try {
      const result = await this.prisma.$queryRaw<Array<{
        rate_date: Date;
        rate_type: string;
        min_rate: number;
        max_rate: number;
        avg_rate: number;
        transactions: number;
      }>>`
        SELECT rate_date, rate_type, min_rate, max_rate, avg_rate, transactions
        FROM rates.history
        WHERE lane_hash = ${laneHash}
          AND rate_date > NOW() - INTERVAL '${days} days'
        ORDER BY rate_date ASC
      `;

      return result.map((r) => ({
        date: r.rate_date,
        rateType: r.rate_type,
        minRate: Number(r.min_rate),
        maxRate: Number(r.max_rate),
        avgRate: Number(r.avg_rate),
        transactions: r.transactions,
      }));
    } catch (error) {
      console.warn('Rate trends lookup failed:', error);
      return [];
    }
  }

  // --------------------------------------------------------------------------
  // GET PRICING CONFIG
  // --------------------------------------------------------------------------

  getConfig(): PricingConfig {
    return { ...this.config };
  }

  // --------------------------------------------------------------------------
  // UPDATE PRICING CONFIG
  // --------------------------------------------------------------------------

  updateConfig(updates: Partial<PricingConfig>): PricingConfig {
    this.config = { ...this.config, ...updates };
    return this.config;
  }

  // --------------------------------------------------------------------------
  // HELPERS
  // --------------------------------------------------------------------------

  private estimateToll(distanceKm: number): number {
    // Approximate toll: Rs 3 per km on highways
    return distanceKm * 3;
  }

  private roundToNearest(value: number): number {
    return Math.round(value / this.config.roundToNearest) * this.config.roundToNearest;
  }

  private cacheRate(laneHash: string, rate: RateResult): void {
    // Cache for 15 minutes
    this.rateCache.set(laneHash, {
      rate,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
    });
  }
}

// ============================================================================
// SINGLETON EXPORT
// ============================================================================

let pricingServiceInstance: DynamicPricingService | null = null;

export function getDynamicPricingService(
  prisma: PrismaClient,
  pubsub?: PubSub,
  config?: Partial<PricingConfig>
): DynamicPricingService {
  if (!pricingServiceInstance) {
    pricingServiceInstance = new DynamicPricingService(prisma, pubsub, config);
  }
  return pricingServiceInstance;
}

export default DynamicPricingService;
