/**
 * FR8X Flow Service
 * Manages flow state transitions across FreightFlow, DocumentFlow, FinanceFlow, InformationFlow
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

import { PrismaClient } from '@prisma/client';
import { PubSub } from 'mercurius';
import {
  FlowType,
  FlowStage,
  ALL_FLOWS,
  getFlowByType,
  getStageByFlowAndId,
  getNextStages,
  getMilestoneForStage,
  MILESTONES,
} from '../config/fr8x-flows.config';

// ============================================================================
// TYPES
// ============================================================================

export interface FlowState {
  entityId: string;
  entityType: 'LOAD' | 'SHIPMENT' | 'INVOICE' | 'NOTIFICATION';
  flowType: FlowType;
  currentStage: string;
  previousStage?: string;
  stageHistory: StageHistoryEntry[];
  metadata?: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export interface StageHistoryEntry {
  stage: string;
  enteredAt: Date;
  exitedAt?: Date;
  duration?: number; // in seconds
  triggeredBy?: string;
  notes?: string;
}

export interface TransitionResult {
  success: boolean;
  flowState: FlowState;
  milestone?: {
    id: string;
    name: string;
    isComplete: boolean;
  };
  error?: string;
}

export interface EntityFlowSummary {
  entityId: string;
  flows: {
    [key in FlowType]?: {
      currentStage: string;
      stageName: string;
      stageColor: string;
      progress: number; // 0-100
    };
  };
  currentMilestone?: {
    id: string;
    name: string;
    order: number;
  };
  nextMilestone?: {
    id: string;
    name: string;
    order: number;
  };
}

// ============================================================================
// FLOW SERVICE
// ============================================================================

export class FlowService {
  private prisma: PrismaClient;
  private pubsub?: PubSub;
  private flowStates: Map<string, Map<FlowType, FlowState>> = new Map();

  constructor(prisma: PrismaClient, pubsub?: PubSub) {
    this.prisma = prisma;
    this.pubsub = pubsub;
  }

  // --------------------------------------------------------------------------
  // INITIALIZE FLOWS FOR ENTITY
  // --------------------------------------------------------------------------

  async initializeFlows(
    entityId: string,
    entityType: 'LOAD' | 'SHIPMENT' | 'INVOICE' | 'NOTIFICATION',
    flowTypes: FlowType[] = ['FREIGHT', 'DOCUMENT', 'FINANCE', 'INFORMATION']
  ): Promise<Map<FlowType, FlowState>> {
    const flows = new Map<FlowType, FlowState>();

    for (const flowType of flowTypes) {
      const flow = getFlowByType(flowType);
      const initialStage = flow.initialStage;

      const flowState: FlowState = {
        entityId,
        entityType,
        flowType,
        currentStage: initialStage,
        stageHistory: [
          {
            stage: initialStage,
            enteredAt: new Date(),
          },
        ],
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      flows.set(flowType, flowState);
    }

    this.flowStates.set(entityId, flows);

    // Persist to database
    await this.persistFlowStates(entityId, flows);

    // Publish flow initialized event
    if (this.pubsub) {
      this.pubsub.publish({
        topic: 'FLOW_INITIALIZED',
        payload: { entityId, entityType, flows: Object.fromEntries(flows) },
      });
    }

    return flows;
  }

  // --------------------------------------------------------------------------
  // TRANSITION STAGE
  // --------------------------------------------------------------------------

  async transitionStage(
    entityId: string,
    flowType: FlowType,
    toStage: string,
    triggeredBy?: string,
    notes?: string
  ): Promise<TransitionResult> {
    // Get current flow state
    const entityFlows = this.flowStates.get(entityId);
    if (!entityFlows) {
      return {
        success: false,
        flowState: {} as FlowState,
        error: `No flows found for entity ${entityId}`,
      };
    }

    const flowState = entityFlows.get(flowType);
    if (!flowState) {
      return {
        success: false,
        flowState: {} as FlowState,
        error: `Flow ${flowType} not found for entity ${entityId}`,
      };
    }

    // Validate transition
    const flow = getFlowByType(flowType);
    const currentStage = getStageByFlowAndId(flowType, flowState.currentStage);
    const targetStage = getStageByFlowAndId(flowType, toStage);

    if (!targetStage) {
      return {
        success: false,
        flowState,
        error: `Invalid target stage: ${toStage}`,
      };
    }

    if (currentStage?.isTerminal) {
      return {
        success: false,
        flowState,
        error: `Cannot transition from terminal stage: ${flowState.currentStage}`,
      };
    }

    // Update flow state
    const now = new Date();
    const previousStage = flowState.currentStage;

    // Close previous stage history entry
    const lastHistoryEntry = flowState.stageHistory[flowState.stageHistory.length - 1];
    if (lastHistoryEntry) {
      lastHistoryEntry.exitedAt = now;
      lastHistoryEntry.duration = Math.floor(
        (now.getTime() - lastHistoryEntry.enteredAt.getTime()) / 1000
      );
    }

    // Add new stage history entry
    flowState.stageHistory.push({
      stage: toStage,
      enteredAt: now,
      triggeredBy,
      notes,
    });

    flowState.previousStage = previousStage;
    flowState.currentStage = toStage;
    flowState.updatedAt = now;

    // Check for milestone
    const milestone = getMilestoneForStage(flowType, toStage);
    let milestoneResult;

    if (milestone) {
      // Check if milestone is complete (all flow triggers met)
      const allFlowStates: Record<FlowType, string> = {} as Record<FlowType, string>;
      entityFlows.forEach((fs, ft) => {
        allFlowStates[ft] = fs.currentStage;
      });

      const isComplete = milestone.triggers.every((trigger) => {
        const triggerStage = getStageByFlowAndId(trigger.flowType, trigger.stage);
        const currentFlowStage = getStageByFlowAndId(
          trigger.flowType,
          allFlowStates[trigger.flowType]
        );
        return currentFlowStage && triggerStage && currentFlowStage.order >= triggerStage.order;
      });

      milestoneResult = {
        id: milestone.id,
        name: milestone.name,
        isComplete,
      };
    }

    // Persist changes
    await this.persistFlowStates(entityId, entityFlows);

    // Publish transition event
    if (this.pubsub) {
      this.pubsub.publish({
        topic: 'FLOW_TRANSITION',
        payload: {
          entityId,
          flowType,
          fromStage: previousStage,
          toStage,
          milestone: milestoneResult,
        },
      });
    }

    return {
      success: true,
      flowState,
      milestone: milestoneResult,
    };
  }

  // --------------------------------------------------------------------------
  // GET FLOW STATE
  // --------------------------------------------------------------------------

  async getFlowState(entityId: string, flowType: FlowType): Promise<FlowState | null> {
    const entityFlows = this.flowStates.get(entityId);
    if (!entityFlows) {
      // Try to load from database
      const loaded = await this.loadFlowStates(entityId);
      if (!loaded) return null;
      return loaded.get(flowType) || null;
    }
    return entityFlows.get(flowType) || null;
  }

  // --------------------------------------------------------------------------
  // GET ALL FLOW STATES FOR ENTITY
  // --------------------------------------------------------------------------

  async getEntityFlows(entityId: string): Promise<EntityFlowSummary | null> {
    let entityFlows = this.flowStates.get(entityId);
    if (!entityFlows) {
      entityFlows = await this.loadFlowStates(entityId);
      if (!entityFlows) return null;
    }

    const flows: EntityFlowSummary['flows'] = {};

    entityFlows.forEach((flowState, flowType) => {
      const flow = getFlowByType(flowType);
      const stage = getStageByFlowAndId(flowType, flowState.currentStage);
      const totalStages = flow.stages.filter((s) => !s.isTerminal).length;
      const currentOrder = stage?.order || 1;

      flows[flowType] = {
        currentStage: flowState.currentStage,
        stageName: stage?.name || flowState.currentStage,
        stageColor: stage?.color || '#6B7280',
        progress: Math.round((currentOrder / totalStages) * 100),
      };
    });

    // Determine current and next milestone
    const allFlowStates: Record<FlowType, string> = {} as Record<FlowType, string>;
    entityFlows.forEach((fs, ft) => {
      allFlowStates[ft] = fs.currentStage;
    });

    let currentMilestone;
    let nextMilestone;

    for (const milestone of MILESTONES) {
      const isComplete = milestone.triggers.every((trigger) => {
        const triggerStage = getStageByFlowAndId(trigger.flowType, trigger.stage);
        const currentFlowStage = getStageByFlowAndId(
          trigger.flowType,
          allFlowStates[trigger.flowType]
        );
        return currentFlowStage && triggerStage && currentFlowStage.order >= triggerStage.order;
      });

      if (isComplete) {
        currentMilestone = { id: milestone.id, name: milestone.name, order: milestone.order };
      } else if (!nextMilestone) {
        nextMilestone = { id: milestone.id, name: milestone.name, order: milestone.order };
      }
    }

    return {
      entityId,
      flows,
      currentMilestone,
      nextMilestone,
    };
  }

  // --------------------------------------------------------------------------
  // GET STAGE ACTIONS
  // --------------------------------------------------------------------------

  getStageActions(flowType: FlowType, stageId: string) {
    const stage = getStageByFlowAndId(flowType, stageId);
    return stage?.actions || [];
  }

  // --------------------------------------------------------------------------
  // GET NEXT POSSIBLE STAGES
  // --------------------------------------------------------------------------

  getNextPossibleStages(flowType: FlowType, currentStageId: string): FlowStage[] {
    return getNextStages(flowType, currentStageId);
  }

  // --------------------------------------------------------------------------
  // GET FLOW DEFINITION
  // --------------------------------------------------------------------------

  getFlowDefinition(flowType: FlowType) {
    return getFlowByType(flowType);
  }

  // --------------------------------------------------------------------------
  // GET ALL FLOW DEFINITIONS
  // --------------------------------------------------------------------------

  getAllFlowDefinitions() {
    return ALL_FLOWS;
  }

  // --------------------------------------------------------------------------
  // GET MILESTONES
  // --------------------------------------------------------------------------

  getMilestones() {
    return MILESTONES;
  }

  // --------------------------------------------------------------------------
  // PERSISTENCE HELPERS
  // --------------------------------------------------------------------------

  private async persistFlowStates(
    entityId: string,
    flows: Map<FlowType, FlowState>
  ): Promise<void> {
    // Store in database - using a JSON field or separate table
    const flowData = Object.fromEntries(
      Array.from(flows.entries()).map(([type, state]) => [type, state])
    );

    try {
      await this.prisma.$executeRaw`
        INSERT INTO flow_states (entity_id, flows, updated_at)
        VALUES (${entityId}, ${JSON.stringify(flowData)}::jsonb, NOW())
        ON CONFLICT (entity_id) DO UPDATE SET
          flows = ${JSON.stringify(flowData)}::jsonb,
          updated_at = NOW()
      `;
    } catch (error) {
      console.warn('Flow state persistence failed, using in-memory only:', error);
    }
  }

  private async loadFlowStates(entityId: string): Promise<Map<FlowType, FlowState> | null> {
    try {
      const result = await this.prisma.$queryRaw<Array<{ flows: Record<FlowType, FlowState> }>>`
        SELECT flows FROM flow_states WHERE entity_id = ${entityId}
      `;

      if (result.length === 0) return null;

      const flows = new Map<FlowType, FlowState>();
      const flowData = result[0].flows;

      for (const [type, state] of Object.entries(flowData)) {
        flows.set(type as FlowType, state);
      }

      this.flowStates.set(entityId, flows);
      return flows;
    } catch (error) {
      console.warn('Flow state load failed:', error);
      return null;
    }
  }
}

// ============================================================================
// SINGLETON EXPORT
// ============================================================================

let flowServiceInstance: FlowService | null = null;

export function getFlowService(prisma: PrismaClient, pubsub?: PubSub): FlowService {
  if (!flowServiceInstance) {
    flowServiceInstance = new FlowService(prisma, pubsub);
  }
  return flowServiceInstance;
}

export default FlowService;
