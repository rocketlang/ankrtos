/**
 * FR8X Milestone Service
 * Bridges flows and tracks cross-flow milestones
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

import { PrismaClient } from '@prisma/client';
import { PubSub } from 'mercurius';
import {
  FlowType,
  Milestone,
  MILESTONES,
  getStageByFlowAndId,
} from '../config/fr8x-flows.config';
import { FlowService, getFlowService } from './flow.service';

// ============================================================================
// TYPES
// ============================================================================

export interface MilestoneState {
  milestoneId: string;
  entityId: string;
  isComplete: boolean;
  completedAt?: Date;
  flowProgress: {
    [key in FlowType]?: {
      required: string;
      current: string;
      isReached: boolean;
    };
  };
}

export interface MilestoneTimeline {
  entityId: string;
  milestones: MilestoneTimelineEntry[];
  overallProgress: number; // 0-100
  estimatedCompletion?: Date;
}

export interface MilestoneTimelineEntry {
  milestone: Milestone;
  state: MilestoneState;
  estimatedDuration?: number; // seconds
  actualDuration?: number; // seconds
}

export interface MilestoneAlert {
  id: string;
  entityId: string;
  milestoneId: string;
  alertType: 'DELAYED' | 'AT_RISK' | 'BLOCKED' | 'COMPLETED';
  message: string;
  createdAt: Date;
  acknowledgedAt?: Date;
}

// ============================================================================
// MILESTONE SERVICE
// ============================================================================

export class MilestoneService {
  private prisma: PrismaClient;
  private pubsub?: PubSub;
  private flowService: FlowService;
  private milestoneStates: Map<string, Map<string, MilestoneState>> = new Map();

  constructor(prisma: PrismaClient, pubsub?: PubSub) {
    this.prisma = prisma;
    this.pubsub = pubsub;
    this.flowService = getFlowService(prisma, pubsub);
  }

  // --------------------------------------------------------------------------
  // INITIALIZE MILESTONES FOR ENTITY
  // --------------------------------------------------------------------------

  async initializeMilestones(entityId: string): Promise<Map<string, MilestoneState>> {
    const states = new Map<string, MilestoneState>();

    for (const milestone of MILESTONES) {
      const flowProgress: MilestoneState['flowProgress'] = {};

      for (const trigger of milestone.triggers) {
        const flowState = await this.flowService.getFlowState(entityId, trigger.flowType);
        const currentStage = flowState?.currentStage || '';
        const currentStageObj = getStageByFlowAndId(trigger.flowType, currentStage);
        const requiredStageObj = getStageByFlowAndId(trigger.flowType, trigger.stage);

        flowProgress[trigger.flowType] = {
          required: trigger.stage,
          current: currentStage,
          isReached: currentStageObj && requiredStageObj
            ? currentStageObj.order >= requiredStageObj.order
            : false,
        };
      }

      const isComplete = Object.values(flowProgress).every((p) => p?.isReached);

      const state: MilestoneState = {
        milestoneId: milestone.id,
        entityId,
        isComplete,
        completedAt: isComplete ? new Date() : undefined,
        flowProgress,
      };

      states.set(milestone.id, state);
    }

    this.milestoneStates.set(entityId, states);
    return states;
  }

  // --------------------------------------------------------------------------
  // UPDATE MILESTONE FROM FLOW TRANSITION
  // --------------------------------------------------------------------------

  async onFlowTransition(
    entityId: string,
    flowType: FlowType,
    toStage: string
  ): Promise<MilestoneState[]> {
    const updatedMilestones: MilestoneState[] = [];

    let entityMilestones = this.milestoneStates.get(entityId);
    if (!entityMilestones) {
      entityMilestones = await this.initializeMilestones(entityId);
    }

    const toStageObj = getStageByFlowAndId(flowType, toStage);

    for (const [milestoneId, state] of entityMilestones) {
      // Skip already completed milestones
      if (state.isComplete) continue;

      const milestone = MILESTONES.find((m) => m.id === milestoneId);
      if (!milestone) continue;

      // Check if this flow is part of this milestone
      const trigger = milestone.triggers.find((t) => t.flowType === flowType);
      if (!trigger) continue;

      // Update flow progress
      const requiredStageObj = getStageByFlowAndId(flowType, trigger.stage);
      const isReached = toStageObj && requiredStageObj
        ? toStageObj.order >= requiredStageObj.order
        : false;

      state.flowProgress[flowType] = {
        required: trigger.stage,
        current: toStage,
        isReached,
      };

      // Check if all triggers are now met
      const allTriggersComplete = milestone.triggers.every((t) => {
        const progress = state.flowProgress[t.flowType];
        return progress?.isReached;
      });

      if (allTriggersComplete && !state.isComplete) {
        state.isComplete = true;
        state.completedAt = new Date();

        // Publish milestone completed event
        if (this.pubsub) {
          this.pubsub.publish({
            topic: 'MILESTONE_COMPLETED',
            payload: {
              entityId,
              milestoneId: milestone.id,
              milestoneName: milestone.name,
              completedAt: state.completedAt,
            },
          });
        }
      }

      updatedMilestones.push(state);
    }

    return updatedMilestones;
  }

  // --------------------------------------------------------------------------
  // GET MILESTONE STATE
  // --------------------------------------------------------------------------

  async getMilestoneState(entityId: string, milestoneId: string): Promise<MilestoneState | null> {
    const entityMilestones = this.milestoneStates.get(entityId);
    if (!entityMilestones) {
      const initialized = await this.initializeMilestones(entityId);
      return initialized.get(milestoneId) || null;
    }
    return entityMilestones.get(milestoneId) || null;
  }

  // --------------------------------------------------------------------------
  // GET ALL MILESTONES FOR ENTITY
  // --------------------------------------------------------------------------

  async getAllMilestones(entityId: string): Promise<MilestoneState[]> {
    let entityMilestones = this.milestoneStates.get(entityId);
    if (!entityMilestones) {
      entityMilestones = await this.initializeMilestones(entityId);
    }
    return Array.from(entityMilestones.values());
  }

  // --------------------------------------------------------------------------
  // GET MILESTONE TIMELINE
  // --------------------------------------------------------------------------

  async getMilestoneTimeline(entityId: string): Promise<MilestoneTimeline> {
    const milestoneStates = await this.getAllMilestones(entityId);

    const entries: MilestoneTimelineEntry[] = MILESTONES.map((milestone) => {
      const state = milestoneStates.find((s) => s.milestoneId === milestone.id);
      return {
        milestone,
        state: state || {
          milestoneId: milestone.id,
          entityId,
          isComplete: false,
          flowProgress: {},
        },
      };
    });

    // Calculate overall progress
    const completedCount = entries.filter((e) => e.state.isComplete).length;
    const overallProgress = Math.round((completedCount / entries.length) * 100);

    return {
      entityId,
      milestones: entries,
      overallProgress,
    };
  }

  // --------------------------------------------------------------------------
  // GET CURRENT MILESTONE
  // --------------------------------------------------------------------------

  async getCurrentMilestone(entityId: string): Promise<Milestone | null> {
    const milestoneStates = await this.getAllMilestones(entityId);

    // Find the first incomplete milestone
    for (const milestone of MILESTONES) {
      const state = milestoneStates.find((s) => s.milestoneId === milestone.id);
      if (!state?.isComplete) {
        return milestone;
      }
    }

    // All milestones complete
    return null;
  }

  // --------------------------------------------------------------------------
  // GET NEXT MILESTONE
  // --------------------------------------------------------------------------

  async getNextMilestone(entityId: string): Promise<Milestone | null> {
    const current = await this.getCurrentMilestone(entityId);
    if (!current) return null;

    const nextIndex = MILESTONES.findIndex((m) => m.id === current.id) + 1;
    return MILESTONES[nextIndex] || null;
  }

  // --------------------------------------------------------------------------
  // CHECK MILESTONE DELAYS
  // --------------------------------------------------------------------------

  async checkForDelays(
    entityId: string,
    expectedDurations: Record<string, number> // milestoneId -> expected seconds
  ): Promise<MilestoneAlert[]> {
    const alerts: MilestoneAlert[] = [];
    const milestoneStates = await this.getAllMilestones(entityId);

    for (const state of milestoneStates) {
      if (state.isComplete) continue;

      const expectedDuration = expectedDurations[state.milestoneId];
      if (!expectedDuration) continue;

      // Check if milestone is taking too long
      // This would need actual start time tracking
      // For now, we'll check based on flow states

      const flowProgress = state.flowProgress;
      const blockedFlows = Object.entries(flowProgress)
        .filter(([_, progress]) => !progress?.isReached)
        .map(([flowType]) => flowType);

      if (blockedFlows.length > 0) {
        alerts.push({
          id: `alert-${entityId}-${state.milestoneId}`,
          entityId,
          milestoneId: state.milestoneId,
          alertType: 'AT_RISK',
          message: `Milestone "${MILESTONES.find((m) => m.id === state.milestoneId)?.name}" waiting on: ${blockedFlows.join(', ')}`,
          createdAt: new Date(),
        });
      }
    }

    // Publish alerts
    if (this.pubsub && alerts.length > 0) {
      for (const alert of alerts) {
        this.pubsub.publish({
          topic: 'MILESTONE_ALERT',
          payload: alert,
        });
      }
    }

    return alerts;
  }

  // --------------------------------------------------------------------------
  // GET MILESTONE STATISTICS
  // --------------------------------------------------------------------------

  async getMilestoneStats(entityIds: string[]): Promise<{
    totalEntities: number;
    byMilestone: Record<string, { complete: number; pending: number }>;
    averageProgress: number;
  }> {
    const stats: Record<string, { complete: number; pending: number }> = {};

    for (const milestone of MILESTONES) {
      stats[milestone.id] = { complete: 0, pending: 0 };
    }

    let totalProgress = 0;

    for (const entityId of entityIds) {
      const timeline = await this.getMilestoneTimeline(entityId);
      totalProgress += timeline.overallProgress;

      for (const entry of timeline.milestones) {
        if (entry.state.isComplete) {
          stats[entry.milestone.id].complete++;
        } else {
          stats[entry.milestone.id].pending++;
        }
      }
    }

    return {
      totalEntities: entityIds.length,
      byMilestone: stats,
      averageProgress: entityIds.length > 0 ? Math.round(totalProgress / entityIds.length) : 0,
    };
  }

  // --------------------------------------------------------------------------
  // MANUAL MILESTONE TRIGGER
  // --------------------------------------------------------------------------

  async triggerMilestone(
    entityId: string,
    milestoneId: string,
    force = false
  ): Promise<MilestoneState | null> {
    let entityMilestones = this.milestoneStates.get(entityId);
    if (!entityMilestones) {
      entityMilestones = await this.initializeMilestones(entityId);
    }

    const state = entityMilestones.get(milestoneId);
    if (!state) return null;

    if (state.isComplete && !force) {
      return state; // Already complete
    }

    // Force complete all flow progress
    const milestone = MILESTONES.find((m) => m.id === milestoneId);
    if (!milestone) return null;

    for (const trigger of milestone.triggers) {
      state.flowProgress[trigger.flowType] = {
        required: trigger.stage,
        current: trigger.stage,
        isReached: true,
      };
    }

    state.isComplete = true;
    state.completedAt = new Date();

    // Publish event
    if (this.pubsub) {
      this.pubsub.publish({
        topic: 'MILESTONE_COMPLETED',
        payload: {
          entityId,
          milestoneId: milestone.id,
          milestoneName: milestone.name,
          completedAt: state.completedAt,
          forced: force,
        },
      });
    }

    return state;
  }
}

// ============================================================================
// SINGLETON EXPORT
// ============================================================================

let milestoneServiceInstance: MilestoneService | null = null;

export function getMilestoneService(prisma: PrismaClient, pubsub?: PubSub): MilestoneService {
  if (!milestoneServiceInstance) {
    milestoneServiceInstance = new MilestoneService(prisma, pubsub);
  }
  return milestoneServiceInstance;
}

export default MilestoneService;
