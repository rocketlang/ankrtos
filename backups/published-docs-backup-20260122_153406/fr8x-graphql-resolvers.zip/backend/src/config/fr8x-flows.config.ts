/**
 * FR8X Flow Definitions
 * Defines FreightFlow, DocumentFlow, FinanceFlow, InformationFlow
 * with milestone bridges between flows
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

// ============================================================================
// FLOW TYPES
// ============================================================================

export type FlowType = 'FREIGHT' | 'DOCUMENT' | 'FINANCE' | 'INFORMATION';

export interface FlowStage {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  order: number;
  isTerminal?: boolean;
  autoTransitions?: string[]; // Stages that auto-trigger
  requiredFields?: string[];
  actions?: StageAction[];
}

export interface StageAction {
  id: string;
  label: string;
  icon: string;
  type: 'primary' | 'secondary' | 'danger';
  nextStage?: string;
  mutation?: string;
  requiresConfirmation?: boolean;
}

export interface FlowDefinition {
  id: FlowType;
  name: string;
  description: string;
  icon: string;
  color: string;
  stages: FlowStage[];
  initialStage: string;
  terminalStages: string[];
}

export interface Milestone {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  order: number;
  triggers: MilestoneTrigger[];
  isComplete?: boolean;
  completedAt?: Date;
}

export interface MilestoneTrigger {
  flowType: FlowType;
  stage: string;
  condition?: 'ALL' | 'ANY'; // For multi-flow triggers
}

// ============================================================================
// FREIGHT FLOW - Load Lifecycle
// ============================================================================

export const FREIGHT_FLOW: FlowDefinition = {
  id: 'FREIGHT',
  name: 'Freight Flow',
  description: 'Load lifecycle from posting to delivery',
  icon: 'Truck',
  color: '#3B82F6', // Blue
  initialStage: 'LOAD_POSTED',
  terminalStages: ['COMPLETED', 'CANCELLED'],
  stages: [
    {
      id: 'LOAD_POSTED',
      name: 'Load Posted',
      description: 'Load has been posted to the exchange',
      icon: 'Plus',
      color: '#6B7280',
      order: 1,
      actions: [
        { id: 'edit', label: 'Edit Load', icon: 'Edit', type: 'secondary' },
        { id: 'cancel', label: 'Cancel', icon: 'XCircle', type: 'danger', nextStage: 'CANCELLED' },
      ],
    },
    {
      id: 'BIDDING',
      name: 'Bidding',
      description: 'Carriers are placing bids',
      icon: 'MessageSquare',
      color: '#F59E0B',
      order: 2,
      actions: [
        { id: 'view_bids', label: 'View Bids', icon: 'List', type: 'primary' },
        { id: 'extend', label: 'Extend Deadline', icon: 'Clock', type: 'secondary' },
      ],
    },
    {
      id: 'BID_ACCEPTED',
      name: 'Bid Accepted',
      description: 'A bid has been accepted',
      icon: 'CheckCircle',
      color: '#10B981',
      order: 3,
      autoTransitions: ['VEHICLE_ASSIGNED'],
      actions: [
        { id: 'assign_vehicle', label: 'Assign Vehicle', icon: 'Truck', type: 'primary', nextStage: 'VEHICLE_ASSIGNED' },
      ],
    },
    {
      id: 'VEHICLE_ASSIGNED',
      name: 'Vehicle Assigned',
      description: 'Vehicle and driver assigned to the load',
      icon: 'Truck',
      color: '#8B5CF6',
      order: 4,
      requiredFields: ['vehicleId', 'driverId'],
      actions: [
        { id: 'schedule_pickup', label: 'Schedule Pickup', icon: 'Calendar', type: 'primary', nextStage: 'PICKUP_SCHEDULED' },
        { id: 'change_vehicle', label: 'Change Vehicle', icon: 'RefreshCw', type: 'secondary' },
      ],
    },
    {
      id: 'PICKUP_SCHEDULED',
      name: 'Pickup Scheduled',
      description: 'Pickup date and time confirmed',
      icon: 'Calendar',
      color: '#06B6D4',
      order: 5,
      actions: [
        { id: 'start_trip', label: 'Start Trip', icon: 'Navigation', type: 'primary', nextStage: 'IN_TRANSIT' },
        { id: 'reschedule', label: 'Reschedule', icon: 'Clock', type: 'secondary' },
      ],
    },
    {
      id: 'IN_TRANSIT',
      name: 'In Transit',
      description: 'Vehicle is en route to destination',
      icon: 'Navigation',
      color: '#3B82F6',
      order: 6,
      actions: [
        { id: 'track', label: 'Track Live', icon: 'MapPin', type: 'primary' },
        { id: 'update_eta', label: 'Update ETA', icon: 'Clock', type: 'secondary' },
      ],
    },
    {
      id: 'AT_DESTINATION',
      name: 'At Destination',
      description: 'Vehicle has arrived at destination',
      icon: 'MapPin',
      color: '#10B981',
      order: 7,
      actions: [
        { id: 'start_unloading', label: 'Start Unloading', icon: 'PackageOpen', type: 'primary' },
      ],
    },
    {
      id: 'POD_PENDING',
      name: 'POD Pending',
      description: 'Awaiting proof of delivery',
      icon: 'Camera',
      color: '#F59E0B',
      order: 8,
      actions: [
        { id: 'upload_pod', label: 'Upload POD', icon: 'Upload', type: 'primary', nextStage: 'DELIVERED' },
      ],
    },
    {
      id: 'DELIVERED',
      name: 'Delivered',
      description: 'Cargo delivered and POD uploaded',
      icon: 'Check',
      color: '#10B981',
      order: 9,
      autoTransitions: ['COMPLETED'],
      actions: [
        { id: 'complete', label: 'Mark Complete', icon: 'CheckCircle', type: 'primary', nextStage: 'COMPLETED' },
      ],
    },
    {
      id: 'COMPLETED',
      name: 'Completed',
      description: 'Load successfully completed',
      icon: 'Trophy',
      color: '#22C55E',
      order: 10,
      isTerminal: true,
    },
    {
      id: 'CANCELLED',
      name: 'Cancelled',
      description: 'Load has been cancelled',
      icon: 'XCircle',
      color: '#EF4444',
      order: 11,
      isTerminal: true,
    },
  ],
};

// ============================================================================
// DOCUMENT FLOW - Document Lifecycle
// ============================================================================

export const DOCUMENT_FLOW: FlowDefinition = {
  id: 'DOCUMENT',
  name: 'Document Flow',
  description: 'Document generation and verification',
  icon: 'FileText',
  color: '#8B5CF6', // Purple
  initialStage: 'EWAY_PENDING',
  terminalStages: ['ARCHIVED', 'REJECTED'],
  stages: [
    {
      id: 'EWAY_PENDING',
      name: 'E-Way Pending',
      description: 'E-Way Bill generation pending',
      icon: 'FileWarning',
      color: '#F59E0B',
      order: 1,
      actions: [
        { id: 'generate_eway', label: 'Generate E-Way', icon: 'FileText', type: 'primary', nextStage: 'EWAY_GENERATED' },
      ],
    },
    {
      id: 'EWAY_GENERATED',
      name: 'E-Way Generated',
      description: 'E-Way Bill has been generated',
      icon: 'FileCheck',
      color: '#10B981',
      order: 2,
      actions: [
        { id: 'create_lr', label: 'Create LR', icon: 'FileText', type: 'primary', nextStage: 'LR_CREATED' },
      ],
    },
    {
      id: 'LR_CREATED',
      name: 'LR Created',
      description: 'Lorry Receipt has been created',
      icon: 'FileText',
      color: '#3B82F6',
      order: 3,
      actions: [
        { id: 'draft_invoice', label: 'Draft Invoice', icon: 'Receipt', type: 'primary', nextStage: 'INVOICE_DRAFT' },
      ],
    },
    {
      id: 'INVOICE_DRAFT',
      name: 'Invoice Draft',
      description: 'Invoice is in draft state',
      icon: 'Receipt',
      color: '#6B7280',
      order: 4,
      actions: [
        { id: 'send_invoice', label: 'Send Invoice', icon: 'Send', type: 'primary', nextStage: 'INVOICE_SENT' },
        { id: 'edit', label: 'Edit', icon: 'Edit', type: 'secondary' },
      ],
    },
    {
      id: 'INVOICE_SENT',
      name: 'Invoice Sent',
      description: 'Invoice sent to customer',
      icon: 'Send',
      color: '#06B6D4',
      order: 5,
    },
    {
      id: 'POD_UPLOADED',
      name: 'POD Uploaded',
      description: 'Proof of Delivery uploaded',
      icon: 'Upload',
      color: '#8B5CF6',
      order: 6,
      actions: [
        { id: 'generate_einvoice', label: 'Generate E-Invoice', icon: 'FileText', type: 'primary', nextStage: 'EINVOICE_GENERATED' },
      ],
    },
    {
      id: 'EINVOICE_GENERATED',
      name: 'E-Invoice Generated',
      description: 'E-Invoice generated with IRN',
      icon: 'FileCheck',
      color: '#10B981',
      order: 7,
      actions: [
        { id: 'verify_docs', label: 'Verify All Docs', icon: 'CheckCircle', type: 'primary', nextStage: 'DOCS_VERIFIED' },
      ],
    },
    {
      id: 'DOCS_VERIFIED',
      name: 'Docs Verified',
      description: 'All documents verified',
      icon: 'CheckCircle',
      color: '#22C55E',
      order: 8,
      actions: [
        { id: 'archive', label: 'Archive', icon: 'Archive', type: 'primary', nextStage: 'ARCHIVED' },
      ],
    },
    {
      id: 'ARCHIVED',
      name: 'Archived',
      description: 'Documents archived for compliance',
      icon: 'Archive',
      color: '#6B7280',
      order: 9,
      isTerminal: true,
    },
    {
      id: 'REJECTED',
      name: 'Rejected',
      description: 'Documents rejected',
      icon: 'XCircle',
      color: '#EF4444',
      order: 10,
      isTerminal: true,
    },
  ],
};

// ============================================================================
// FINANCE FLOW - Payment Lifecycle
// ============================================================================

export const FINANCE_FLOW: FlowDefinition = {
  id: 'FINANCE',
  name: 'Finance Flow',
  description: 'Billing, payments, and settlements',
  icon: 'DollarSign',
  color: '#22C55E', // Green
  initialStage: 'UNBILLED',
  terminalStages: ['RECONCILED', 'WRITTEN_OFF'],
  stages: [
    {
      id: 'UNBILLED',
      name: 'Unbilled',
      description: 'Trip completed, not yet billed',
      icon: 'FileWarning',
      color: '#6B7280',
      order: 1,
      actions: [
        { id: 'create_invoice', label: 'Create Invoice', icon: 'Receipt', type: 'primary', nextStage: 'INVOICE_CREATED' },
      ],
    },
    {
      id: 'INVOICE_CREATED',
      name: 'Invoice Created',
      description: 'Invoice has been created',
      icon: 'Receipt',
      color: '#3B82F6',
      order: 2,
      actions: [
        { id: 'send', label: 'Send to Customer', icon: 'Send', type: 'primary', nextStage: 'SENT_TO_CUSTOMER' },
      ],
    },
    {
      id: 'SENT_TO_CUSTOMER',
      name: 'Sent to Customer',
      description: 'Invoice sent to customer',
      icon: 'Send',
      color: '#06B6D4',
      order: 3,
    },
    {
      id: 'PAYMENT_PENDING',
      name: 'Payment Pending',
      description: 'Awaiting payment from customer',
      icon: 'Clock',
      color: '#F59E0B',
      order: 4,
      actions: [
        { id: 'send_reminder', label: 'Send Reminder', icon: 'Bell', type: 'secondary' },
        { id: 'record_payment', label: 'Record Payment', icon: 'DollarSign', type: 'primary' },
      ],
    },
    {
      id: 'PARTIAL_PAID',
      name: 'Partial Paid',
      description: 'Partial payment received',
      icon: 'Percent',
      color: '#8B5CF6',
      order: 5,
      actions: [
        { id: 'record_payment', label: 'Record Payment', icon: 'DollarSign', type: 'primary' },
      ],
    },
    {
      id: 'FULLY_PAID',
      name: 'Fully Paid',
      description: 'Full payment received',
      icon: 'CheckCircle',
      color: '#10B981',
      order: 6,
      actions: [
        { id: 'settle', label: 'Settle with Carrier', icon: 'DollarSign', type: 'primary', nextStage: 'SETTLEMENT_PENDING' },
      ],
    },
    {
      id: 'SETTLEMENT_PENDING',
      name: 'Settlement Pending',
      description: 'Pending settlement to carrier',
      icon: 'Loader',
      color: '#F59E0B',
      order: 7,
      actions: [
        { id: 'process_settlement', label: 'Process Settlement', icon: 'DollarSign', type: 'primary', nextStage: 'SETTLED' },
      ],
    },
    {
      id: 'SETTLED',
      name: 'Settled',
      description: 'Carrier has been paid',
      icon: 'Check',
      color: '#22C55E',
      order: 8,
      actions: [
        { id: 'reconcile', label: 'Reconcile', icon: 'FileCheck', type: 'primary', nextStage: 'RECONCILED' },
      ],
    },
    {
      id: 'RECONCILED',
      name: 'Reconciled',
      description: 'Payment fully reconciled',
      icon: 'CheckCircle',
      color: '#22C55E',
      order: 9,
      isTerminal: true,
    },
    {
      id: 'WRITTEN_OFF',
      name: 'Written Off',
      description: 'Bad debt written off',
      icon: 'XCircle',
      color: '#EF4444',
      order: 10,
      isTerminal: true,
    },
  ],
};

// ============================================================================
// INFORMATION FLOW - Notifications & Alerts
// ============================================================================

export const INFORMATION_FLOW: FlowDefinition = {
  id: 'INFORMATION',
  name: 'Information Flow',
  description: 'Notifications, alerts, and updates',
  icon: 'Bell',
  color: '#F59E0B', // Amber
  initialStage: 'EVENT_TRIGGERED',
  terminalStages: ['ACTIONED', 'EXPIRED'],
  stages: [
    {
      id: 'EVENT_TRIGGERED',
      name: 'Event Triggered',
      description: 'An event has occurred',
      icon: 'Zap',
      color: '#F59E0B',
      order: 1,
    },
    {
      id: 'NOTIFICATION_QUEUED',
      name: 'Queued',
      description: 'Notification queued for delivery',
      icon: 'Loader',
      color: '#6B7280',
      order: 2,
    },
    {
      id: 'NOTIFICATION_SENT',
      name: 'Sent',
      description: 'Notification has been sent',
      icon: 'Send',
      color: '#3B82F6',
      order: 3,
    },
    {
      id: 'DELIVERED',
      name: 'Delivered',
      description: 'Notification delivered to recipient',
      icon: 'Check',
      color: '#10B981',
      order: 4,
    },
    {
      id: 'READ',
      name: 'Read',
      description: 'Recipient has read the notification',
      icon: 'Eye',
      color: '#8B5CF6',
      order: 5,
    },
    {
      id: 'ACTIONED',
      name: 'Actioned',
      description: 'Recipient has taken action',
      icon: 'CheckCircle',
      color: '#22C55E',
      order: 6,
      isTerminal: true,
    },
    {
      id: 'EXPIRED',
      name: 'Expired',
      description: 'Notification expired without action',
      icon: 'Clock',
      color: '#EF4444',
      order: 7,
      isTerminal: true,
    },
  ],
};

// ============================================================================
// MILESTONE DEFINITIONS
// ============================================================================

export const MILESTONES: Milestone[] = [
  {
    id: 'M1',
    name: 'Load Confirmed',
    description: 'Bid accepted, LR created, event triggered',
    icon: 'CheckCircle',
    color: '#3B82F6',
    order: 1,
    triggers: [
      { flowType: 'FREIGHT', stage: 'BID_ACCEPTED' },
      { flowType: 'DOCUMENT', stage: 'LR_CREATED' },
      { flowType: 'FINANCE', stage: 'UNBILLED' },
      { flowType: 'INFORMATION', stage: 'EVENT_TRIGGERED' },
    ],
  },
  {
    id: 'M2',
    name: 'In Transit',
    description: 'Vehicle moving, E-Way active, notifications sent',
    icon: 'Navigation',
    color: '#06B6D4',
    order: 2,
    triggers: [
      { flowType: 'FREIGHT', stage: 'IN_TRANSIT' },
      { flowType: 'DOCUMENT', stage: 'EWAY_GENERATED' },
      { flowType: 'INFORMATION', stage: 'NOTIFICATION_SENT' },
    ],
  },
  {
    id: 'M3',
    name: 'Delivered',
    description: 'Cargo delivered, POD uploaded, invoice created',
    icon: 'MapPin',
    color: '#10B981',
    order: 3,
    triggers: [
      { flowType: 'FREIGHT', stage: 'DELIVERED' },
      { flowType: 'DOCUMENT', stage: 'POD_UPLOADED' },
      { flowType: 'FINANCE', stage: 'INVOICE_CREATED' },
      { flowType: 'INFORMATION', stage: 'DELIVERED' },
    ],
  },
  {
    id: 'M4',
    name: 'POD Verified',
    description: 'Trip complete, docs verified, invoice sent',
    icon: 'FileCheck',
    color: '#8B5CF6',
    order: 4,
    triggers: [
      { flowType: 'FREIGHT', stage: 'COMPLETED' },
      { flowType: 'DOCUMENT', stage: 'DOCS_VERIFIED' },
      { flowType: 'FINANCE', stage: 'SENT_TO_CUSTOMER' },
      { flowType: 'INFORMATION', stage: 'ACTIONED' },
    ],
  },
  {
    id: 'M5',
    name: 'Payment Received',
    description: 'Customer has paid in full, docs archived',
    icon: 'DollarSign',
    color: '#22C55E',
    order: 5,
    triggers: [
      { flowType: 'DOCUMENT', stage: 'ARCHIVED' },
      { flowType: 'FINANCE', stage: 'FULLY_PAID' },
    ],
  },
  {
    id: 'M6',
    name: 'Settled',
    description: 'Carrier paid, accounts reconciled',
    icon: 'Trophy',
    color: '#F59E0B',
    order: 6,
    triggers: [
      { flowType: 'FINANCE', stage: 'SETTLED' },
    ],
  },
];

// ============================================================================
// ALL FLOWS
// ============================================================================

export const ALL_FLOWS: Record<FlowType, FlowDefinition> = {
  FREIGHT: FREIGHT_FLOW,
  DOCUMENT: DOCUMENT_FLOW,
  FINANCE: FINANCE_FLOW,
  INFORMATION: INFORMATION_FLOW,
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

export function getFlowByType(type: FlowType): FlowDefinition {
  return ALL_FLOWS[type];
}

export function getStageByFlowAndId(flowType: FlowType, stageId: string): FlowStage | undefined {
  const flow = ALL_FLOWS[flowType];
  return flow?.stages.find(s => s.id === stageId);
}

export function getNextStages(flowType: FlowType, currentStageId: string): FlowStage[] {
  const flow = ALL_FLOWS[flowType];
  const currentStage = flow?.stages.find(s => s.id === currentStageId);
  if (!currentStage || currentStage.isTerminal) return [];

  // Get stages with higher order
  return flow.stages
    .filter(s => s.order > currentStage.order && !s.isTerminal)
    .sort((a, b) => a.order - b.order);
}

export function getMilestoneForStage(flowType: FlowType, stageId: string): Milestone | undefined {
  return MILESTONES.find(m =>
    m.triggers.some(t => t.flowType === flowType && t.stage === stageId)
  );
}

export function checkMilestoneComplete(
  milestone: Milestone,
  flowStates: Record<FlowType, string>
): boolean {
  return milestone.triggers.every(trigger =>
    flowStates[trigger.flowType] === trigger.stage ||
    getStageByFlowAndId(trigger.flowType, flowStates[trigger.flowType])!.order >=
    getStageByFlowAndId(trigger.flowType, trigger.stage)!.order
  );
}

// ============================================================================
// FLOW CANVAS CONFIG (for @ankr/flow-canvas integration)
// ============================================================================

export const FR8X_FLOW_CANVAS_CONFIG = {
  appName: 'FR8X Exchange',
  theme: {
    primary: '#3B82F6',
    secondary: '#8B5CF6',
    success: '#22C55E',
    warning: '#F59E0B',
    danger: '#EF4444',
    background: '#0F172A',
    surface: '#1E293B',
  },
  flows: [
    { ...FREIGHT_FLOW, isDefault: true },
    DOCUMENT_FLOW,
    FINANCE_FLOW,
    INFORMATION_FLOW,
  ],
  milestones: MILESTONES,
  kpis: [
    { id: 'active_loads', label: 'Active Loads', icon: 'Package', color: '#3B82F6' },
    { id: 'in_transit', label: 'In Transit', icon: 'Truck', color: '#06B6D4' },
    { id: 'pending_pod', label: 'Pending POD', icon: 'Camera', color: '#F59E0B' },
    { id: 'unpaid_invoices', label: 'Unpaid', icon: 'DollarSign', color: '#EF4444' },
    { id: 'settled_today', label: 'Settled Today', icon: 'CheckCircle', color: '#22C55E' },
  ],
  roles: {
    SHIPPER: ['FREIGHT', 'DOCUMENT', 'FINANCE'],
    CARRIER: ['FREIGHT', 'DOCUMENT', 'FINANCE'],
    BROKER: ['FREIGHT', 'DOCUMENT', 'FINANCE', 'INFORMATION'],
    DRIVER: ['FREIGHT'],
    ADMIN: ['FREIGHT', 'DOCUMENT', 'FINANCE', 'INFORMATION'],
  },
  voiceCommands: {
    enabled: true,
    language: 'hi-IN', // Hindi default
    commands: [
      { phrase: 'show loads', action: 'navigate', target: '/exchange/board' },
      { phrase: 'my bids', action: 'navigate', target: '/exchange/bids' },
      { phrase: 'track shipment', action: 'navigate', target: '/exchange/tracking' },
      { phrase: 'post load', action: 'navigate', target: '/exchange/board/post' },
    ],
  },
};

export default FR8X_FLOW_CANVAS_CONFIG;
