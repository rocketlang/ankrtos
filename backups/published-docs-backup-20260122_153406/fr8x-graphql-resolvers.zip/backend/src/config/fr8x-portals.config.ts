/**
 * FR8X Portal Configurations
 * Role-based portal definitions for Shipper, Carrier, Broker, Admin, Driver
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export type PortalRole = 'SHIPPER' | 'CARRIER' | 'BROKER' | 'ADMIN' | 'DRIVER' | 'DISPATCHER';

export interface PortalConfig {
  id: PortalRole;
  name: string;
  description: string;
  icon: string;
  theme: PortalTheme;
  navigation: NavigationItem[];
  dashboardWidgets: DashboardWidget[];
  permissions: string[];
  features: PortalFeatures;
}

export interface PortalTheme {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  sidebarColor: string;
  headerColor: string;
  logoUrl?: string;
}

export interface NavigationItem {
  id: string;
  label: string;
  icon: string;
  path: string;
  badge?: string;
  children?: NavigationItem[];
  requiredPermission?: string;
}

export interface DashboardWidget {
  id: string;
  type: 'stat' | 'chart' | 'table' | 'map' | 'timeline' | 'flow';
  title: string;
  icon: string;
  size: 'small' | 'medium' | 'large' | 'full';
  dataSource: string;
  refreshInterval?: number; // seconds
}

export interface PortalFeatures {
  loadPosting: boolean;
  bidding: boolean;
  tracking: boolean;
  wallet: boolean;
  documents: boolean;
  analytics: boolean;
  reports: boolean;
  settings: boolean;
  fleetManagement: boolean;
  driverManagement: boolean;
  invoicing: boolean;
  compliance: boolean;
  notifications: boolean;
  chat: boolean;
  voiceCommands: boolean;
}

// ============================================================================
// SHIPPER PORTAL
// ============================================================================

export const SHIPPER_PORTAL: PortalConfig = {
  id: 'SHIPPER',
  name: 'Shipper Portal',
  description: 'Post loads, track shipments, manage invoices',
  icon: 'Package',
  theme: {
    primaryColor: '#3B82F6',
    secondaryColor: '#1E40AF',
    accentColor: '#60A5FA',
    sidebarColor: '#1E293B',
    headerColor: '#0F172A',
  },
  navigation: [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'LayoutDashboard',
      path: '/exchange/portal/shipper',
    },
    {
      id: 'loads',
      label: 'My Loads',
      icon: 'Package',
      path: '/exchange/portal/shipper/loads',
      children: [
        { id: 'active', label: 'Active Loads', icon: 'Truck', path: '/exchange/portal/shipper/loads/active' },
        { id: 'post', label: 'Post New Load', icon: 'Plus', path: '/exchange/board/post' },
        { id: 'history', label: 'Load History', icon: 'History', path: '/exchange/portal/shipper/loads/history' },
      ],
    },
    {
      id: 'bids',
      label: 'Bids',
      icon: 'MessageSquare',
      path: '/exchange/portal/shipper/bids',
      badge: 'new',
    },
    {
      id: 'tracking',
      label: 'Track Shipments',
      icon: 'MapPin',
      path: '/exchange/tracking',
    },
    {
      id: 'documents',
      label: 'Documents',
      icon: 'FileText',
      path: '/exchange/portal/shipper/documents',
      children: [
        { id: 'invoices', label: 'Invoices', icon: 'Receipt', path: '/exchange/portal/shipper/documents/invoices' },
        { id: 'lr', label: 'Lorry Receipts', icon: 'FileText', path: '/exchange/portal/shipper/documents/lr' },
        { id: 'pod', label: 'POD', icon: 'Camera', path: '/exchange/portal/shipper/documents/pod' },
        { id: 'eway', label: 'E-Way Bills', icon: 'FileCheck', path: '/exchange/portal/shipper/documents/eway' },
      ],
    },
    {
      id: 'payments',
      label: 'Payments',
      icon: 'DollarSign',
      path: '/exchange/wallet',
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: 'BarChart',
      path: '/exchange/portal/shipper/analytics',
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: 'Settings',
      path: '/exchange/portal/shipper/settings',
    },
  ],
  dashboardWidgets: [
    { id: 'active-loads', type: 'stat', title: 'Active Loads', icon: 'Package', size: 'small', dataSource: 'loads.active' },
    { id: 'in-transit', type: 'stat', title: 'In Transit', icon: 'Truck', size: 'small', dataSource: 'loads.inTransit' },
    { id: 'pending-pod', type: 'stat', title: 'Pending POD', icon: 'Camera', size: 'small', dataSource: 'loads.pendingPod' },
    { id: 'unpaid-amount', type: 'stat', title: 'Unpaid Amount', icon: 'DollarSign', size: 'small', dataSource: 'finance.unpaid' },
    { id: 'live-map', type: 'map', title: 'Live Tracking', icon: 'MapPin', size: 'large', dataSource: 'tracking.live', refreshInterval: 30 },
    { id: 'recent-loads', type: 'table', title: 'Recent Loads', icon: 'List', size: 'medium', dataSource: 'loads.recent' },
    { id: 'freight-flow', type: 'flow', title: 'Shipment Flow', icon: 'GitBranch', size: 'full', dataSource: 'flows.freight' },
  ],
  permissions: [
    'load:create', 'load:read', 'load:update', 'load:cancel',
    'bid:read', 'bid:accept', 'bid:reject',
    'tracking:read',
    'document:read', 'document:download',
    'payment:read', 'payment:create',
    'analytics:read',
  ],
  features: {
    loadPosting: true,
    bidding: false, // Shippers accept bids, not place them
    tracking: true,
    wallet: true,
    documents: true,
    analytics: true,
    reports: true,
    settings: true,
    fleetManagement: false,
    driverManagement: false,
    invoicing: true,
    compliance: true,
    notifications: true,
    chat: true,
    voiceCommands: true,
  },
};

// ============================================================================
// CARRIER PORTAL
// ============================================================================

export const CARRIER_PORTAL: PortalConfig = {
  id: 'CARRIER',
  name: 'Carrier Portal',
  description: 'Find loads, manage fleet, track earnings',
  icon: 'Truck',
  theme: {
    primaryColor: '#10B981',
    secondaryColor: '#059669',
    accentColor: '#34D399',
    sidebarColor: '#1E293B',
    headerColor: '#0F172A',
  },
  navigation: [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'LayoutDashboard',
      path: '/exchange/portal/carrier',
    },
    {
      id: 'loadboard',
      label: 'Load Board',
      icon: 'Package',
      path: '/exchange/board',
      badge: 'live',
    },
    {
      id: 'bids',
      label: 'My Bids',
      icon: 'MessageSquare',
      path: '/exchange/bids',
      children: [
        { id: 'active', label: 'Active Bids', icon: 'Clock', path: '/exchange/bids' },
        { id: 'won', label: 'Won Bids', icon: 'Trophy', path: '/exchange/bids?status=won' },
        { id: 'opportunities', label: 'Opportunities', icon: 'Zap', path: '/exchange/bids/opportunities' },
      ],
    },
    {
      id: 'fleet',
      label: 'Fleet',
      icon: 'Truck',
      path: '/exchange/portal/carrier/fleet',
      children: [
        { id: 'vehicles', label: 'Vehicles', icon: 'Truck', path: '/exchange/pool/vehicles' },
        { id: 'drivers', label: 'Drivers', icon: 'Users', path: '/exchange/pool/drivers' },
        { id: 'trips', label: 'Active Trips', icon: 'Navigation', path: '/exchange/portal/carrier/trips' },
      ],
    },
    {
      id: 'backhaul',
      label: 'Backhaul',
      icon: 'RotateCcw',
      path: '/exchange/backhaul',
    },
    {
      id: 'earnings',
      label: 'Earnings',
      icon: 'DollarSign',
      path: '/exchange/wallet',
      children: [
        { id: 'wallet', label: 'Wallet', icon: 'Wallet', path: '/exchange/wallet' },
        { id: 'transactions', label: 'Transactions', icon: 'List', path: '/exchange/wallet/transactions' },
        { id: 'settlements', label: 'Settlements', icon: 'Check', path: '/exchange/portal/carrier/settlements' },
      ],
    },
    {
      id: 'compliance',
      label: 'Compliance',
      icon: 'Shield',
      path: '/exchange/portal/carrier/compliance',
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: 'BarChart',
      path: '/exchange/portal/carrier/analytics',
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: 'Settings',
      path: '/exchange/portal/carrier/settings',
    },
  ],
  dashboardWidgets: [
    { id: 'available-loads', type: 'stat', title: 'Available Loads', icon: 'Package', size: 'small', dataSource: 'loads.available' },
    { id: 'active-bids', type: 'stat', title: 'Active Bids', icon: 'MessageSquare', size: 'small', dataSource: 'bids.active' },
    { id: 'active-trips', type: 'stat', title: 'Active Trips', icon: 'Truck', size: 'small', dataSource: 'trips.active' },
    { id: 'earnings-today', type: 'stat', title: 'Today\'s Earnings', icon: 'DollarSign', size: 'small', dataSource: 'earnings.today' },
    { id: 'fleet-map', type: 'map', title: 'Fleet Location', icon: 'MapPin', size: 'large', dataSource: 'fleet.locations', refreshInterval: 30 },
    { id: 'lane-rates', type: 'chart', title: 'Lane Rate Trends', icon: 'TrendingUp', size: 'medium', dataSource: 'rates.trends' },
    { id: 'earnings-chart', type: 'chart', title: 'Earnings (30 Days)', icon: 'BarChart', size: 'medium', dataSource: 'earnings.history' },
  ],
  permissions: [
    'load:read', 'load:bid',
    'bid:create', 'bid:read', 'bid:update', 'bid:withdraw',
    'vehicle:read', 'vehicle:create', 'vehicle:update',
    'driver:read', 'driver:create', 'driver:update',
    'trip:read', 'trip:update',
    'tracking:read', 'tracking:update',
    'wallet:read', 'wallet:withdraw',
    'document:read', 'document:upload',
    'analytics:read',
  ],
  features: {
    loadPosting: false,
    bidding: true,
    tracking: true,
    wallet: true,
    documents: true,
    analytics: true,
    reports: true,
    settings: true,
    fleetManagement: true,
    driverManagement: true,
    invoicing: false,
    compliance: true,
    notifications: true,
    chat: true,
    voiceCommands: true,
  },
};

// ============================================================================
// BROKER PORTAL
// ============================================================================

export const BROKER_PORTAL: PortalConfig = {
  id: 'BROKER',
  name: 'Broker Portal',
  description: 'Match loads, manage network, earn commissions',
  icon: 'Users',
  theme: {
    primaryColor: '#8B5CF6',
    secondaryColor: '#7C3AED',
    accentColor: '#A78BFA',
    sidebarColor: '#1E293B',
    headerColor: '#0F172A',
  },
  navigation: [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'LayoutDashboard',
      path: '/exchange/portal/broker',
    },
    {
      id: 'matching',
      label: 'Matching',
      icon: 'GitMerge',
      path: '/exchange/portal/broker/matching',
    },
    {
      id: 'shippers',
      label: 'Shippers',
      icon: 'Package',
      path: '/exchange/portal/broker/shippers',
    },
    {
      id: 'carriers',
      label: 'Carriers',
      icon: 'Truck',
      path: '/exchange/pool/carriers',
    },
    {
      id: 'deals',
      label: 'Deals',
      icon: 'Handshake',
      path: '/exchange/portal/broker/deals',
      children: [
        { id: 'active', label: 'Active Deals', icon: 'Clock', path: '/exchange/portal/broker/deals/active' },
        { id: 'closed', label: 'Closed Deals', icon: 'Check', path: '/exchange/portal/broker/deals/closed' },
        { id: 'pipeline', label: 'Pipeline', icon: 'GitBranch', path: '/exchange/portal/broker/deals/pipeline' },
      ],
    },
    {
      id: 'commissions',
      label: 'Commissions',
      icon: 'DollarSign',
      path: '/exchange/portal/broker/commissions',
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: 'BarChart',
      path: '/exchange/portal/broker/analytics',
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: 'Settings',
      path: '/exchange/portal/broker/settings',
    },
  ],
  dashboardWidgets: [
    { id: 'active-deals', type: 'stat', title: 'Active Deals', icon: 'Handshake', size: 'small', dataSource: 'deals.active' },
    { id: 'pending-match', type: 'stat', title: 'Pending Matches', icon: 'GitMerge', size: 'small', dataSource: 'matching.pending' },
    { id: 'commission-mtd', type: 'stat', title: 'MTD Commission', icon: 'DollarSign', size: 'small', dataSource: 'commission.mtd' },
    { id: 'network-size', type: 'stat', title: 'Network Size', icon: 'Users', size: 'small', dataSource: 'network.size' },
    { id: 'deal-pipeline', type: 'timeline', title: 'Deal Pipeline', icon: 'GitBranch', size: 'large', dataSource: 'deals.pipeline' },
    { id: 'commission-chart', type: 'chart', title: 'Commission Trends', icon: 'TrendingUp', size: 'medium', dataSource: 'commission.trends' },
  ],
  permissions: [
    'load:read',
    'shipper:read', 'shipper:manage',
    'carrier:read', 'carrier:manage',
    'deal:create', 'deal:read', 'deal:update',
    'commission:read',
    'analytics:read',
    'network:manage',
  ],
  features: {
    loadPosting: true,
    bidding: true,
    tracking: true,
    wallet: true,
    documents: true,
    analytics: true,
    reports: true,
    settings: true,
    fleetManagement: false,
    driverManagement: false,
    invoicing: true,
    compliance: true,
    notifications: true,
    chat: true,
    voiceCommands: true,
  },
};

// ============================================================================
// ADMIN PORTAL
// ============================================================================

export const ADMIN_PORTAL: PortalConfig = {
  id: 'ADMIN',
  name: 'Admin Portal',
  description: 'System administration, user management, billing',
  icon: 'Shield',
  theme: {
    primaryColor: '#EF4444',
    secondaryColor: '#DC2626',
    accentColor: '#F87171',
    sidebarColor: '#1E293B',
    headerColor: '#0F172A',
  },
  navigation: [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'LayoutDashboard',
      path: '/exchange/portal/admin',
    },
    {
      id: 'users',
      label: 'Users',
      icon: 'Users',
      path: '/exchange/portal/admin/users',
      children: [
        { id: 'all', label: 'All Users', icon: 'Users', path: '/exchange/portal/admin/users' },
        { id: 'shippers', label: 'Shippers', icon: 'Package', path: '/exchange/portal/admin/users/shippers' },
        { id: 'carriers', label: 'Carriers', icon: 'Truck', path: '/exchange/portal/admin/users/carriers' },
        { id: 'drivers', label: 'Drivers', icon: 'User', path: '/exchange/portal/admin/users/drivers' },
        { id: 'kyc', label: 'KYC Pending', icon: 'FileCheck', path: '/exchange/portal/admin/users/kyc' },
      ],
    },
    {
      id: 'operations',
      label: 'Operations',
      icon: 'Activity',
      path: '/exchange/portal/admin/operations',
      children: [
        { id: 'loads', label: 'All Loads', icon: 'Package', path: '/exchange/portal/admin/operations/loads' },
        { id: 'disputes', label: 'Disputes', icon: 'AlertTriangle', path: '/exchange/portal/admin/operations/disputes' },
        { id: 'settlements', label: 'Settlements', icon: 'DollarSign', path: '/exchange/portal/admin/operations/settlements' },
      ],
    },
    {
      id: 'billing',
      label: 'Billing',
      icon: 'CreditCard',
      path: '/exchange/portal/admin/billing',
    },
    {
      id: 'compliance',
      label: 'Compliance',
      icon: 'Shield',
      path: '/exchange/portal/admin/compliance',
    },
    {
      id: 'audit',
      label: 'Audit Logs',
      icon: 'FileText',
      path: '/exchange/portal/admin/audit',
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: 'BarChart',
      path: '/exchange/portal/admin/analytics',
    },
    {
      id: 'system',
      label: 'System',
      icon: 'Settings',
      path: '/exchange/portal/admin/system',
      children: [
        { id: 'config', label: 'Configuration', icon: 'Sliders', path: '/exchange/portal/admin/system/config' },
        { id: 'integrations', label: 'Integrations', icon: 'Plug', path: '/exchange/portal/admin/system/integrations' },
        { id: 'webhooks', label: 'Webhooks', icon: 'Webhook', path: '/exchange/portal/admin/system/webhooks' },
      ],
    },
  ],
  dashboardWidgets: [
    { id: 'total-users', type: 'stat', title: 'Total Users', icon: 'Users', size: 'small', dataSource: 'users.total' },
    { id: 'active-loads', type: 'stat', title: 'Active Loads', icon: 'Package', size: 'small', dataSource: 'loads.active' },
    { id: 'gmv-today', type: 'stat', title: 'GMV Today', icon: 'DollarSign', size: 'small', dataSource: 'finance.gmvToday' },
    { id: 'disputes', type: 'stat', title: 'Open Disputes', icon: 'AlertTriangle', size: 'small', dataSource: 'disputes.open' },
    { id: 'system-health', type: 'chart', title: 'System Health', icon: 'Activity', size: 'medium', dataSource: 'system.health' },
    { id: 'user-growth', type: 'chart', title: 'User Growth', icon: 'TrendingUp', size: 'medium', dataSource: 'users.growth' },
    { id: 'all-flows', type: 'flow', title: 'All Flows', icon: 'GitBranch', size: 'full', dataSource: 'flows.all' },
  ],
  permissions: [
    'admin:*', // Full admin access
    'user:*',
    'load:*',
    'finance:*',
    'system:*',
    'audit:*',
    'compliance:*',
  ],
  features: {
    loadPosting: true,
    bidding: true,
    tracking: true,
    wallet: true,
    documents: true,
    analytics: true,
    reports: true,
    settings: true,
    fleetManagement: true,
    driverManagement: true,
    invoicing: true,
    compliance: true,
    notifications: true,
    chat: true,
    voiceCommands: true,
  },
};

// ============================================================================
// DRIVER PORTAL
// ============================================================================

export const DRIVER_PORTAL: PortalConfig = {
  id: 'DRIVER',
  name: 'Driver Portal',
  description: 'View trips, upload POD, track earnings',
  icon: 'User',
  theme: {
    primaryColor: '#F59E0B',
    secondaryColor: '#D97706',
    accentColor: '#FBBF24',
    sidebarColor: '#1E293B',
    headerColor: '#0F172A',
  },
  navigation: [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'LayoutDashboard',
      path: '/exchange/portal/driver',
    },
    {
      id: 'trips',
      label: 'My Trips',
      icon: 'Navigation',
      path: '/exchange/portal/driver/trips',
      children: [
        { id: 'current', label: 'Current Trip', icon: 'Truck', path: '/exchange/portal/driver/trips/current' },
        { id: 'upcoming', label: 'Upcoming', icon: 'Calendar', path: '/exchange/portal/driver/trips/upcoming' },
        { id: 'history', label: 'Trip History', icon: 'History', path: '/exchange/portal/driver/trips/history' },
      ],
    },
    {
      id: 'pod',
      label: 'Upload POD',
      icon: 'Camera',
      path: '/exchange/portal/driver/pod',
    },
    {
      id: 'earnings',
      label: 'Earnings',
      icon: 'DollarSign',
      path: '/exchange/portal/driver/earnings',
    },
    {
      id: 'documents',
      label: 'Documents',
      icon: 'FileText',
      path: '/exchange/portal/driver/documents',
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: 'User',
      path: '/exchange/portal/driver/profile',
    },
  ],
  dashboardWidgets: [
    { id: 'current-trip', type: 'stat', title: 'Current Trip', icon: 'Truck', size: 'large', dataSource: 'trip.current' },
    { id: 'earnings-today', type: 'stat', title: 'Today\'s Earnings', icon: 'DollarSign', size: 'small', dataSource: 'earnings.today' },
    { id: 'trips-completed', type: 'stat', title: 'Trips Completed', icon: 'Check', size: 'small', dataSource: 'trips.completed' },
    { id: 'rating', type: 'stat', title: 'Rating', icon: 'Star', size: 'small', dataSource: 'profile.rating' },
    { id: 'navigation', type: 'map', title: 'Navigation', icon: 'MapPin', size: 'full', dataSource: 'trip.navigation' },
  ],
  permissions: [
    'trip:read', 'trip:update',
    'pod:upload',
    'earnings:read',
    'document:read', 'document:upload',
    'profile:read', 'profile:update',
  ],
  features: {
    loadPosting: false,
    bidding: false,
    tracking: true,
    wallet: true,
    documents: true,
    analytics: false,
    reports: false,
    settings: true,
    fleetManagement: false,
    driverManagement: false,
    invoicing: false,
    compliance: true,
    notifications: true,
    chat: true,
    voiceCommands: true,
  },
};

// ============================================================================
// ALL PORTALS
// ============================================================================

export const ALL_PORTALS: Record<PortalRole, PortalConfig> = {
  SHIPPER: SHIPPER_PORTAL,
  CARRIER: CARRIER_PORTAL,
  BROKER: BROKER_PORTAL,
  ADMIN: ADMIN_PORTAL,
  DRIVER: DRIVER_PORTAL,
  DISPATCHER: CARRIER_PORTAL, // Dispatcher uses carrier portal with different permissions
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

export function getPortalConfig(role: PortalRole): PortalConfig {
  return ALL_PORTALS[role] || SHIPPER_PORTAL;
}

export function getPortalNavigation(role: PortalRole): NavigationItem[] {
  const portal = getPortalConfig(role);
  return portal.navigation;
}

export function getPortalWidgets(role: PortalRole): DashboardWidget[] {
  const portal = getPortalConfig(role);
  return portal.dashboardWidgets;
}

export function hasPortalFeature(role: PortalRole, feature: keyof PortalFeatures): boolean {
  const portal = getPortalConfig(role);
  return portal.features[feature];
}

export function hasPortalPermission(role: PortalRole, permission: string): boolean {
  const portal = getPortalConfig(role);

  // Check for wildcard permissions
  if (portal.permissions.includes('admin:*')) return true;

  const [resource] = permission.split(':');
  if (portal.permissions.includes(`${resource}:*`)) return true;

  return portal.permissions.includes(permission);
}

export default ALL_PORTALS;
