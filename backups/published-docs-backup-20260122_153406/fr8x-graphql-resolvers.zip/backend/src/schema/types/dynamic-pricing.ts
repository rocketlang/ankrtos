/**
 * FR8X Dynamic Pricing Schema
 * GraphQL types and resolvers for dynamic rate engine with surge pricing
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

import { builder } from '../builder.js';
import { getDynamicPricingService } from '../../services/dynamic-pricing.service.js';
import { fr8xPubSub } from './subscriptions.js';

// ═══════════════════════════════════════════════════════════════════════════════
// ENUMS
// ═══════════════════════════════════════════════════════════════════════════════

const RateTypeEnum = builder.enumType('RateType', {
  values: ['contract', 'branch', 'spot', 'benchmark', 'estimated'] as const,
  description: 'Type of rate source',
});

const SurgeLevelEnum = builder.enumType('SurgeLevel', {
  values: ['low', 'below_normal', 'normal', 'high', 'surge', 'peak'] as const,
  description: 'Level of surge pricing',
});

// ═══════════════════════════════════════════════════════════════════════════════
// INPUT TYPES
// ═══════════════════════════════════════════════════════════════════════════════

const GetRateInput = builder.inputType('GetRateInput', {
  fields: (t) => ({
    originPin: t.string({ required: true }),
    destPin: t.string({ required: true }),
    vehicleType: t.string({ required: true }),
    customerId: t.string(),
    branchId: t.string(),
    distanceKm: t.float(),
  }),
});

const UpdateSpotRateInput = builder.inputType('UpdateSpotRateInput', {
  fields: (t) => ({
    originPin: t.string({ required: true }),
    destPin: t.string({ required: true }),
    vehicleType: t.string({ required: true }),
    baseRate: t.float({ required: true }),
  }),
});

const UpdatePricingConfigInput = builder.inputType('UpdatePricingConfigInput', {
  fields: (t) => ({
    defaultMarginPercent: t.float(),
    minMarginPercent: t.float(),
    maxMarginPercent: t.float(),
    surgeEnabled: t.boolean(),
    maxSurgeMultiplier: t.float(),
    minSurgeMultiplier: t.float(),
    fuelSurchargePercent: t.float(),
    gstPercent: t.float(),
    roundToNearest: t.int(),
  }),
});

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT TYPE INTERFACES
// ═══════════════════════════════════════════════════════════════════════════════

interface RateBreakdownData {
  baseRate: number;
  tollEstimate: number;
  margin: number | null;
  fuelSurcharge: number | null;
  handlingCharges: number | null;
}

interface RateResultData {
  laneHash: string;
  originPin: string;
  destPin: string;
  vehicleType: string;
  rate: number;
  rateType: string;
  surgeMultiplier: number | null;
  customerId: string | null;
  validUntil: Date | null;
  confidence: number;
  breakdown: RateBreakdownData;
  currency: string;
}

interface SurgeInfoData {
  demandScore: number;
  supplyScore: number;
  surgeRatio: number;
  multiplier: number;
  level: string;
  description: string;
}

interface RateTrendData {
  date: Date;
  rateType: string;
  minRate: number;
  maxRate: number;
  avgRate: number;
  transactions: number;
}

interface SpotRateUpdateData {
  laneHash: string;
  baseRate: number;
  finalRate: number;
  surge: SurgeInfoData;
}

interface PricingConfigData {
  defaultMarginPercent: number;
  minMarginPercent: number;
  maxMarginPercent: number;
  surgeEnabled: boolean;
  maxSurgeMultiplier: number;
  minSurgeMultiplier: number;
  fuelSurchargePercent: number;
  gstPercent: number;
  roundToNearest: number;
}

interface VehicleRateData {
  vehicleType: string;
  ratePerKm: number;
  tollMultiplier: number;
}

// ═══════════════════════════════════════════════════════════════════════════════
// OBJECT TYPES
// ═══════════════════════════════════════════════════════════════════════════════

const RateBreakdown = builder.objectRef<RateBreakdownData>('RateBreakdown').implement({
  fields: (t) => ({
    baseRate: t.exposeFloat('baseRate'),
    tollEstimate: t.exposeFloat('tollEstimate'),
    margin: t.exposeFloat('margin', { nullable: true }),
    fuelSurcharge: t.exposeFloat('fuelSurcharge', { nullable: true }),
    handlingCharges: t.exposeFloat('handlingCharges', { nullable: true }),
  }),
});

const RateResult = builder.objectRef<RateResultData>('RateResult').implement({
  fields: (t) => ({
    laneHash: t.exposeString('laneHash'),
    originPin: t.exposeString('originPin'),
    destPin: t.exposeString('destPin'),
    vehicleType: t.exposeString('vehicleType'),
    rate: t.exposeFloat('rate'),
    rateType: t.exposeString('rateType'),
    surgeMultiplier: t.exposeFloat('surgeMultiplier', { nullable: true }),
    customerId: t.exposeString('customerId', { nullable: true }),
    validUntil: t.expose('validUntil', { type: 'DateTime', nullable: true }),
    confidence: t.exposeFloat('confidence'),
    breakdown: t.field({
      type: RateBreakdown,
      resolve: (parent) => parent.breakdown,
    }),
    currency: t.exposeString('currency'),
  }),
});

const SurgeInfo = builder.objectRef<SurgeInfoData>('SurgeInfo').implement({
  fields: (t) => ({
    demandScore: t.exposeFloat('demandScore'),
    supplyScore: t.exposeFloat('supplyScore'),
    surgeRatio: t.exposeFloat('surgeRatio'),
    multiplier: t.exposeFloat('multiplier'),
    level: t.exposeString('level'),
    description: t.exposeString('description'),
  }),
});

const RateTrend = builder.objectRef<RateTrendData>('RateTrend').implement({
  fields: (t) => ({
    date: t.expose('date', { type: 'DateTime' }),
    rateType: t.exposeString('rateType'),
    minRate: t.exposeFloat('minRate'),
    maxRate: t.exposeFloat('maxRate'),
    avgRate: t.exposeFloat('avgRate'),
    transactions: t.exposeInt('transactions'),
  }),
});

const SpotRateUpdate = builder.objectRef<SpotRateUpdateData>('SpotRateUpdate').implement({
  fields: (t) => ({
    laneHash: t.exposeString('laneHash'),
    baseRate: t.exposeFloat('baseRate'),
    finalRate: t.exposeFloat('finalRate'),
    surge: t.field({
      type: SurgeInfo,
      resolve: (parent) => parent.surge,
    }),
  }),
});

const PricingConfig = builder.objectRef<PricingConfigData>('PricingConfig').implement({
  fields: (t) => ({
    defaultMarginPercent: t.exposeFloat('defaultMarginPercent'),
    minMarginPercent: t.exposeFloat('minMarginPercent'),
    maxMarginPercent: t.exposeFloat('maxMarginPercent'),
    surgeEnabled: t.exposeBoolean('surgeEnabled'),
    maxSurgeMultiplier: t.exposeFloat('maxSurgeMultiplier'),
    minSurgeMultiplier: t.exposeFloat('minSurgeMultiplier'),
    fuelSurchargePercent: t.exposeFloat('fuelSurchargePercent'),
    gstPercent: t.exposeFloat('gstPercent'),
    roundToNearest: t.exposeInt('roundToNearest'),
  }),
});

const VehicleRate = builder.objectRef<VehicleRateData>('VehicleRate').implement({
  fields: (t) => ({
    vehicleType: t.exposeString('vehicleType'),
    ratePerKm: t.exposeFloat('ratePerKm'),
    tollMultiplier: t.exposeFloat('tollMultiplier'),
  }),
});

// ═══════════════════════════════════════════════════════════════════════════════
// VEHICLE RATES CONSTANT
// ═══════════════════════════════════════════════════════════════════════════════

const VEHICLE_RATES: VehicleRateData[] = [
  { vehicleType: 'Tata Ace', ratePerKm: 18, tollMultiplier: 0.5 },
  { vehicleType: 'Tata 407', ratePerKm: 25, tollMultiplier: 0.7 },
  { vehicleType: 'Eicher 14Ft', ratePerKm: 35, tollMultiplier: 1.0 },
  { vehicleType: 'Eicher 17Ft', ratePerKm: 42, tollMultiplier: 1.0 },
  { vehicleType: 'Eicher 19Ft', ratePerKm: 48, tollMultiplier: 1.0 },
  { vehicleType: '20Ft Container', ratePerKm: 45, tollMultiplier: 1.0 },
  { vehicleType: '32Ft SXL', ratePerKm: 52, tollMultiplier: 1.2 },
  { vehicleType: '32Ft MXL', ratePerKm: 55, tollMultiplier: 1.2 },
  { vehicleType: '40Ft MXL', ratePerKm: 65, tollMultiplier: 1.5 },
  { vehicleType: '40Ft HQ', ratePerKm: 70, tollMultiplier: 1.5 },
  { vehicleType: 'Trailer 40Ft', ratePerKm: 75, tollMultiplier: 1.8 },
  { vehicleType: 'ODC', ratePerKm: 90, tollMultiplier: 2.0 },
];

// ═══════════════════════════════════════════════════════════════════════════════
// QUERIES
// ═══════════════════════════════════════════════════════════════════════════════

// Get rate for a lane
builder.queryField('getRate', (t) =>
  t.field({
    type: RateResult,
    description: 'Get rate for a lane with priority fallback: Contract > Branch > Spot > Benchmark > Estimate',
    args: {
      input: t.arg({ type: GetRateInput, required: true }),
    },
    resolve: async (_, { input }, ctx) => {
      const pricingService = getDynamicPricingService(ctx.prisma, fr8xPubSub);
      const result = await pricingService.getRate(
        input.originPin,
        input.destPin,
        input.vehicleType,
        input.customerId || undefined,
        input.branchId || undefined,
        input.distanceKm || undefined
      );

      return {
        laneHash: result.laneHash,
        originPin: result.originPin,
        destPin: result.destPin,
        vehicleType: result.vehicleType,
        rate: result.rate,
        rateType: result.rateType,
        surgeMultiplier: result.surgeMultiplier || null,
        customerId: result.customerId || null,
        validUntil: result.validUntil || null,
        confidence: result.confidence,
        breakdown: {
          baseRate: result.breakdown.baseRate,
          tollEstimate: result.breakdown.tollEstimate,
          margin: result.breakdown.margin || null,
          fuelSurcharge: result.breakdown.fuelSurcharge || null,
          handlingCharges: result.breakdown.handlingCharges || null,
        },
        currency: result.currency,
      };
    },
  })
);

// Calculate surge for a lane
builder.queryField('calculateSurge', (t) =>
  t.field({
    type: SurgeInfo,
    description: 'Calculate current surge multiplier for a lane',
    args: {
      originPin: t.arg.string({ required: true }),
      destPin: t.arg.string({ required: true }),
      vehicleType: t.arg.string({ required: true }),
    },
    resolve: async (_, { originPin, destPin, vehicleType }, ctx) => {
      const pricingService = getDynamicPricingService(ctx.prisma, fr8xPubSub);
      const laneHash = pricingService.getLaneHash(originPin, destPin, vehicleType);
      const surge = await pricingService.calculateSurge(laneHash);

      return {
        demandScore: surge.demandScore,
        supplyScore: surge.supplyScore,
        surgeRatio: surge.surgeRatio,
        multiplier: surge.multiplier,
        level: surge.level,
        description: surge.description,
      };
    },
  })
);

// Get rate trends
builder.queryField('rateTrends', (t) =>
  t.field({
    type: [RateTrend],
    description: 'Get historical rate trends for a lane',
    args: {
      originPin: t.arg.string({ required: true }),
      destPin: t.arg.string({ required: true }),
      vehicleType: t.arg.string({ required: true }),
      days: t.arg.int({ defaultValue: 30 }),
    },
    resolve: async (_, { originPin, destPin, vehicleType, days }, ctx) => {
      const pricingService = getDynamicPricingService(ctx.prisma, fr8xPubSub);
      const laneHash = pricingService.getLaneHash(originPin, destPin, vehicleType);
      const trends = await pricingService.getRateTrends(laneHash, days || 30);

      return trends.map((trend) => ({
        date: trend.date,
        rateType: trend.rateType,
        minRate: trend.minRate,
        maxRate: trend.maxRate,
        avgRate: trend.avgRate,
        transactions: trend.transactions,
      }));
    },
  })
);

// Get pricing config
builder.queryField('pricingConfig', (t) =>
  t.field({
    type: PricingConfig,
    description: 'Get current pricing configuration',
    authScopes: { admin: true },
    resolve: (_, __, ctx) => {
      const pricingService = getDynamicPricingService(ctx.prisma, fr8xPubSub);
      return pricingService.getConfig();
    },
  })
);

// Get vehicle rates
builder.queryField('vehicleRates', (t) =>
  t.field({
    type: [VehicleRate],
    description: 'Get base rates per km for all vehicle types',
    resolve: () => VEHICLE_RATES,
  })
);

// Get lane hash
builder.queryField('laneHash', (t) =>
  t.field({
    type: 'String',
    description: 'Generate lane hash for a route',
    args: {
      originPin: t.arg.string({ required: true }),
      destPin: t.arg.string({ required: true }),
      vehicleType: t.arg.string({ required: true }),
    },
    resolve: (_, { originPin, destPin, vehicleType }, ctx) => {
      const pricingService = getDynamicPricingService(ctx.prisma, fr8xPubSub);
      return pricingService.getLaneHash(originPin, destPin, vehicleType);
    },
  })
);

// ═══════════════════════════════════════════════════════════════════════════════
// MUTATIONS
// ═══════════════════════════════════════════════════════════════════════════════

// Update spot rate
builder.mutationField('updateSpotRate', (t) =>
  t.field({
    type: SpotRateUpdate,
    description: 'Update spot rate for a lane (applies surge automatically)',
    args: {
      input: t.arg({ type: UpdateSpotRateInput, required: true }),
    },
    authScopes: { admin: true },
    resolve: async (_, { input }, ctx) => {
      const pricingService = getDynamicPricingService(ctx.prisma, fr8xPubSub);
      const result = await pricingService.updateSpotRate(
        input.originPin,
        input.destPin,
        input.vehicleType,
        input.baseRate
      );

      return {
        laneHash: result.laneHash,
        baseRate: result.baseRate,
        finalRate: result.finalRate,
        surge: {
          demandScore: result.surge.demandScore,
          supplyScore: result.surge.supplyScore,
          surgeRatio: result.surge.surgeRatio,
          multiplier: result.surge.multiplier,
          level: result.surge.level,
          description: result.surge.description,
        },
      };
    },
  })
);

// Update pricing config
builder.mutationField('updatePricingConfig', (t) =>
  t.field({
    type: PricingConfig,
    description: 'Update pricing configuration (admin only)',
    args: {
      input: t.arg({ type: UpdatePricingConfigInput, required: true }),
    },
    authScopes: { admin: true },
    resolve: (_, { input }, ctx) => {
      const pricingService = getDynamicPricingService(ctx.prisma, fr8xPubSub);
      return pricingService.updateConfig({
        defaultMarginPercent: input.defaultMarginPercent ?? undefined,
        minMarginPercent: input.minMarginPercent ?? undefined,
        maxMarginPercent: input.maxMarginPercent ?? undefined,
        surgeEnabled: input.surgeEnabled ?? undefined,
        maxSurgeMultiplier: input.maxSurgeMultiplier ?? undefined,
        minSurgeMultiplier: input.minSurgeMultiplier ?? undefined,
        fuelSurchargePercent: input.fuelSurchargePercent ?? undefined,
        gstPercent: input.gstPercent ?? undefined,
        roundToNearest: input.roundToNearest ?? undefined,
      });
    },
  })
);

// ═══════════════════════════════════════════════════════════════════════════════
// SUBSCRIPTIONS
// ═══════════════════════════════════════════════════════════════════════════════

// Rate update subscription
builder.subscriptionField('rateUpdated', (t) =>
  t.field({
    type: SpotRateUpdate,
    description: 'Subscribe to spot rate updates',
    args: {
      laneHash: t.arg.string(),
    },
    subscribe: (_, { laneHash }) =>
      fr8xPubSub.subscribe('RATE_UPDATED') as AsyncIterable<any>,
    resolve: (payload: any) => {
      return {
        laneHash: payload.laneHash,
        baseRate: payload.baseRate,
        finalRate: payload.finalRate,
        surge: {
          demandScore: payload.surge.demandScore,
          supplyScore: payload.surge.supplyScore,
          surgeRatio: payload.surge.surgeRatio,
          multiplier: payload.surge.multiplier,
          level: payload.surge.level,
          description: payload.surge.description,
        },
      };
    },
  })
);

// ═══════════════════════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════════════════════

export { getDynamicPricingService };
