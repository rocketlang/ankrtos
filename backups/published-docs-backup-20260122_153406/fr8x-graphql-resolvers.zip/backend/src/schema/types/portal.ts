/**
 * FR8X Portal Schema
 * GraphQL types and resolvers for role-based portals
 * Shipper, Carrier, Broker, Admin, Driver portals
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

import { builder } from '../builder.js';
import {
  PortalRole,
  ALL_PORTALS,
  getPortalConfig,
  getPortalNavigation,
  getPortalWidgets,
  hasPortalFeature,
  hasPortalPermission,
} from '../../config/fr8x-portals.config.js';

// ═══════════════════════════════════════════════════════════════════════════════
// ENUMS
// ═══════════════════════════════════════════════════════════════════════════════

const PortalRoleEnum = builder.enumType('PortalRole', {
  values: ['SHIPPER', 'CARRIER', 'BROKER', 'ADMIN', 'DRIVER', 'DISPATCHER'] as const,
  description: 'Role-based portal type',
});

const WidgetTypeEnum = builder.enumType('WidgetType', {
  values: ['stat', 'chart', 'table', 'map', 'timeline', 'flow'] as const,
  description: 'Type of dashboard widget',
});

const WidgetSizeEnum = builder.enumType('WidgetSize', {
  values: ['small', 'medium', 'large', 'full'] as const,
  description: 'Size of dashboard widget',
});

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT TYPE INTERFACES
// ═══════════════════════════════════════════════════════════════════════════════

interface PortalThemeData {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  sidebarColor: string;
  headerColor: string;
  logoUrl: string | null;
}

interface NavigationItemData {
  id: string;
  label: string;
  icon: string;
  path: string;
  badge: string | null;
  requiredPermission: string | null;
  children: NavigationItemData[];
}

interface DashboardWidgetData {
  id: string;
  type: string;
  title: string;
  icon: string;
  size: string;
  dataSource: string;
  refreshInterval: number | null;
}

interface PortalFeaturesData {
  loadPosting: boolean;
  bidding: boolean;
  tracking: boolean;
  wallet: boolean;
  documents: boolean;
  analytics: boolean;
  reports: boolean;
  settings: boolean;
  fleetManagement: boolean;
  driverManagement: boolean;
  invoicing: boolean;
  compliance: boolean;
  notifications: boolean;
  chat: boolean;
  voiceCommands: boolean;
}

interface PortalConfigData {
  id: string;
  name: string;
  description: string;
  icon: string;
  theme: PortalThemeData;
  navigation: NavigationItemData[];
  dashboardWidgets: DashboardWidgetData[];
  permissions: string[];
  features: PortalFeaturesData;
}

interface PortalAccessData {
  hasAccess: boolean;
  portal: PortalConfigData | null;
  reason: string | null;
}

interface PermissionCheckData {
  permission: string;
  hasPermission: boolean;
}

interface FeatureCheckData {
  feature: string;
  enabled: boolean;
}

// ═══════════════════════════════════════════════════════════════════════════════
// OBJECT TYPES
// ═══════════════════════════════════════════════════════════════════════════════

const PortalTheme = builder.objectRef<PortalThemeData>('PortalTheme').implement({
  fields: (t) => ({
    primaryColor: t.exposeString('primaryColor'),
    secondaryColor: t.exposeString('secondaryColor'),
    accentColor: t.exposeString('accentColor'),
    sidebarColor: t.exposeString('sidebarColor'),
    headerColor: t.exposeString('headerColor'),
    logoUrl: t.exposeString('logoUrl', { nullable: true }),
  }),
});

const NavigationItem: any = builder.objectRef<NavigationItemData>('NavigationItem').implement({
  fields: (t) => ({
    id: t.exposeString('id'),
    label: t.exposeString('label'),
    icon: t.exposeString('icon'),
    path: t.exposeString('path'),
    badge: t.exposeString('badge', { nullable: true }),
    requiredPermission: t.exposeString('requiredPermission', { nullable: true }),
    children: t.field({
      type: [NavigationItem],
      resolve: (parent) => parent.children || [],
    }),
  }),
});

const DashboardWidget = builder.objectRef<DashboardWidgetData>('DashboardWidget').implement({
  fields: (t) => ({
    id: t.exposeString('id'),
    type: t.exposeString('type'),
    title: t.exposeString('title'),
    icon: t.exposeString('icon'),
    size: t.exposeString('size'),
    dataSource: t.exposeString('dataSource'),
    refreshInterval: t.exposeInt('refreshInterval', { nullable: true }),
  }),
});

const PortalFeatures = builder.objectRef<PortalFeaturesData>('PortalFeatures').implement({
  fields: (t) => ({
    loadPosting: t.exposeBoolean('loadPosting'),
    bidding: t.exposeBoolean('bidding'),
    tracking: t.exposeBoolean('tracking'),
    wallet: t.exposeBoolean('wallet'),
    documents: t.exposeBoolean('documents'),
    analytics: t.exposeBoolean('analytics'),
    reports: t.exposeBoolean('reports'),
    settings: t.exposeBoolean('settings'),
    fleetManagement: t.exposeBoolean('fleetManagement'),
    driverManagement: t.exposeBoolean('driverManagement'),
    invoicing: t.exposeBoolean('invoicing'),
    compliance: t.exposeBoolean('compliance'),
    notifications: t.exposeBoolean('notifications'),
    chat: t.exposeBoolean('chat'),
    voiceCommands: t.exposeBoolean('voiceCommands'),
  }),
});

const PortalConfig = builder.objectRef<PortalConfigData>('PortalConfig').implement({
  fields: (t) => ({
    id: t.exposeString('id'),
    name: t.exposeString('name'),
    description: t.exposeString('description'),
    icon: t.exposeString('icon'),
    theme: t.field({
      type: PortalTheme,
      resolve: (parent) => parent.theme,
    }),
    navigation: t.field({
      type: [NavigationItem],
      resolve: (parent) => parent.navigation,
    }),
    dashboardWidgets: t.field({
      type: [DashboardWidget],
      resolve: (parent) => parent.dashboardWidgets,
    }),
    permissions: t.exposeStringList('permissions'),
    features: t.field({
      type: PortalFeatures,
      resolve: (parent) => parent.features,
    }),
  }),
});

const PortalAccess = builder.objectRef<PortalAccessData>('PortalAccess').implement({
  fields: (t) => ({
    hasAccess: t.exposeBoolean('hasAccess'),
    portal: t.field({
      type: PortalConfig,
      nullable: true,
      resolve: (parent) => parent.portal,
    }),
    reason: t.exposeString('reason', { nullable: true }),
  }),
});

const PermissionCheck = builder.objectRef<PermissionCheckData>('PermissionCheck').implement({
  fields: (t) => ({
    permission: t.exposeString('permission'),
    hasPermission: t.exposeBoolean('hasPermission'),
  }),
});

const FeatureCheck = builder.objectRef<FeatureCheckData>('FeatureCheck').implement({
  fields: (t) => ({
    feature: t.exposeString('feature'),
    enabled: t.exposeBoolean('enabled'),
  }),
});

// ═══════════════════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function mapNavigationItem(item: any): NavigationItemData {
  return {
    id: item.id,
    label: item.label,
    icon: item.icon,
    path: item.path,
    badge: item.badge || null,
    requiredPermission: item.requiredPermission || null,
    children: (item.children || []).map(mapNavigationItem),
  };
}

function mapPortalConfig(config: any): PortalConfigData {
  return {
    id: config.id,
    name: config.name,
    description: config.description,
    icon: config.icon,
    theme: {
      primaryColor: config.theme.primaryColor,
      secondaryColor: config.theme.secondaryColor,
      accentColor: config.theme.accentColor,
      sidebarColor: config.theme.sidebarColor,
      headerColor: config.theme.headerColor,
      logoUrl: config.theme.logoUrl || null,
    },
    navigation: config.navigation.map(mapNavigationItem),
    dashboardWidgets: config.dashboardWidgets.map((widget: any) => ({
      id: widget.id,
      type: widget.type,
      title: widget.title,
      icon: widget.icon,
      size: widget.size,
      dataSource: widget.dataSource,
      refreshInterval: widget.refreshInterval || null,
    })),
    permissions: config.permissions,
    features: config.features,
  };
}

function getUserPortalRole(userRole: string | undefined): PortalRole | null {
  if (!userRole) return null;

  const roleMap: Record<string, PortalRole> = {
    ADMIN: 'ADMIN',
    SUPER_ADMIN: 'ADMIN',
    USER: 'SHIPPER',
    SHIPPER: 'SHIPPER',
    MANAGER: 'SHIPPER',
    CARRIER: 'CARRIER',
    TRANSPORTER: 'CARRIER',
    DRIVER: 'DRIVER',
    DISPATCHER: 'DISPATCHER',
    BROKER: 'BROKER',
    AGENT: 'BROKER',
  };

  return roleMap[userRole] || null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// QUERIES
// ═══════════════════════════════════════════════════════════════════════════════

// Get all portal configurations
builder.queryField('portals', (t) =>
  t.field({
    type: [PortalConfig],
    description: 'Get all portal configurations',
    authScopes: { admin: true },
    resolve: () => {
      return Object.values(ALL_PORTALS).map(mapPortalConfig);
    },
  })
);

// Get portal configuration by role
builder.queryField('portal', (t) =>
  t.field({
    type: PortalConfig,
    nullable: true,
    description: 'Get portal configuration for a specific role',
    args: {
      role: t.arg({ type: PortalRoleEnum, required: true }),
    },
    resolve: (_, { role }) => {
      const config = getPortalConfig(role);
      return config ? mapPortalConfig(config) : null;
    },
  })
);

// Get current user's portal
builder.queryField('myPortal', (t) =>
  t.field({
    type: PortalAccess,
    description: 'Get portal configuration for the current user based on their role',
    authScopes: { authenticated: true },
    resolve: (_, __, ctx) => {
      const userRole = ctx.user?.role;
      const portalRole = getUserPortalRole(userRole);

      if (!portalRole) {
        return {
          hasAccess: false,
          portal: null,
          reason: `No portal available for role: ${userRole}`,
        };
      }

      const config = getPortalConfig(portalRole);
      return {
        hasAccess: true,
        portal: mapPortalConfig(config),
        reason: null,
      };
    },
  })
);

// Get navigation for a portal
builder.queryField('portalNavigation', (t) =>
  t.field({
    type: [NavigationItem],
    description: 'Get navigation items for a portal',
    args: {
      role: t.arg({ type: PortalRoleEnum, required: true }),
    },
    resolve: (_, { role }) => {
      const navigation = getPortalNavigation(role);
      return navigation.map(mapNavigationItem);
    },
  })
);

// Get dashboard widgets for a portal
builder.queryField('portalWidgets', (t) =>
  t.field({
    type: [DashboardWidget],
    description: 'Get dashboard widgets for a portal',
    args: {
      role: t.arg({ type: PortalRoleEnum, required: true }),
    },
    resolve: (_, { role }) => {
      const widgets = getPortalWidgets(role);
      return widgets.map((widget) => ({
        id: widget.id,
        type: widget.type,
        title: widget.title,
        icon: widget.icon,
        size: widget.size,
        dataSource: widget.dataSource,
        refreshInterval: widget.refreshInterval || null,
      }));
    },
  })
);

// Check if a feature is enabled for a portal
builder.queryField('portalFeatureEnabled', (t) =>
  t.field({
    type: FeatureCheck,
    description: 'Check if a feature is enabled for a portal role',
    args: {
      role: t.arg({ type: PortalRoleEnum, required: true }),
      feature: t.arg.string({ required: true }),
    },
    resolve: (_, { role, feature }) => {
      const enabled = hasPortalFeature(role, feature as any);
      return { feature, enabled };
    },
  })
);

// Check if a permission is granted for a portal
builder.queryField('portalPermissionCheck', (t) =>
  t.field({
    type: PermissionCheck,
    description: 'Check if a permission is granted for a portal role',
    args: {
      role: t.arg({ type: PortalRoleEnum, required: true }),
      permission: t.arg.string({ required: true }),
    },
    resolve: (_, { role, permission }) => {
      const hasPermission = hasPortalPermission(role, permission);
      return { permission, hasPermission };
    },
  })
);

// Check multiple permissions
builder.queryField('portalPermissions', (t) =>
  t.field({
    type: [PermissionCheck],
    description: 'Check multiple permissions for a portal role',
    args: {
      role: t.arg({ type: PortalRoleEnum, required: true }),
      permissions: t.arg.stringList({ required: true }),
    },
    resolve: (_, { role, permissions }) => {
      return permissions.map((permission) => ({
        permission,
        hasPermission: hasPortalPermission(role, permission),
      }));
    },
  })
);

// Get portal for current user with filtered navigation (based on permissions)
builder.queryField('myPortalFiltered', (t) =>
  t.field({
    type: PortalConfig,
    nullable: true,
    description: 'Get portal for current user with navigation filtered by permissions',
    authScopes: { authenticated: true },
    resolve: (_, __, ctx) => {
      const userRole = ctx.user?.role;
      const portalRole = getUserPortalRole(userRole);

      if (!portalRole) return null;

      const config = getPortalConfig(portalRole);
      const mappedConfig = mapPortalConfig(config);

      // Filter navigation based on user permissions
      const filterNavigation = (items: NavigationItemData[]): NavigationItemData[] => {
        return items
          .filter((item) => {
            if (!item.requiredPermission) return true;
            return hasPortalPermission(portalRole, item.requiredPermission);
          })
          .map((item) => ({
            ...item,
            children: filterNavigation(item.children),
          }));
      };

      return {
        ...mappedConfig,
        navigation: filterNavigation(mappedConfig.navigation),
      };
    },
  })
);

// ═══════════════════════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════════════════════

export {
  getPortalConfig,
  getPortalNavigation,
  getPortalWidgets,
  hasPortalFeature,
  hasPortalPermission,
};
