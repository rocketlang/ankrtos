/**
 * FR8X Flow Engine Schema
 * GraphQL types and resolvers for FreightFlow, DocumentFlow, FinanceFlow, InformationFlow
 * with Milestone tracking across flows
 *
 * @author ANKR Labs
 * @version 1.0.0
 */

import { builder } from '../builder.js';
import { getFlowService } from '../../services/flow.service.js';
import { getMilestoneService } from '../../services/milestone.service.js';
import {
  FlowType,
  ALL_FLOWS,
  MILESTONES,
  getFlowByType,
  getStageByFlowAndId,
} from '../../config/fr8x-flows.config.js';
import { fr8xPubSub } from './subscriptions.js';

// ═══════════════════════════════════════════════════════════════════════════════
// ENUMS
// ═══════════════════════════════════════════════════════════════════════════════

const FlowTypeEnum = builder.enumType('FlowType', {
  values: ['FREIGHT', 'DOCUMENT', 'FINANCE', 'INFORMATION'] as const,
  description: 'Type of flow in the FR8X system',
});

const EntityTypeEnum = builder.enumType('FlowEntityType', {
  values: ['LOAD', 'SHIPMENT', 'INVOICE', 'NOTIFICATION'] as const,
  description: 'Type of entity a flow is attached to',
});

// ═══════════════════════════════════════════════════════════════════════════════
// INPUT TYPES
// ═══════════════════════════════════════════════════════════════════════════════

const InitializeFlowsInput = builder.inputType('InitializeFlowsInput', {
  fields: (t) => ({
    entityId: t.string({ required: true }),
    entityType: t.field({ type: EntityTypeEnum, required: true }),
    flowTypes: t.field({ type: [FlowTypeEnum] }),
  }),
});

const TransitionStageInput = builder.inputType('TransitionStageInput', {
  fields: (t) => ({
    entityId: t.string({ required: true }),
    flowType: t.field({ type: FlowTypeEnum, required: true }),
    toStage: t.string({ required: true }),
    triggeredBy: t.string(),
    notes: t.string(),
  }),
});

const TriggerMilestoneInput = builder.inputType('TriggerMilestoneInput', {
  fields: (t) => ({
    entityId: t.string({ required: true }),
    milestoneId: t.string({ required: true }),
    force: t.boolean({ defaultValue: false }),
  }),
});

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT TYPE INTERFACES
// ═══════════════════════════════════════════════════════════════════════════════

interface StageActionData {
  id: string;
  label: string;
  icon: string;
  type: string;
  nextStage: string | null;
  mutation: string | null;
  requiresConfirmation: boolean;
}

interface FlowStageData {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  order: number;
  isTerminal: boolean;
  alertCount: number;
  count: number;
  actions: StageActionData[];
}

interface FlowDefinitionData {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  initialStage: string;
  terminalStages: string[];
  stages: FlowStageData[];
}

interface StageHistoryEntryData {
  stage: string;
  stageName: string;
  enteredAt: Date;
  exitedAt: Date | null;
  duration: number | null;
  triggeredBy: string | null;
  notes: string | null;
}

interface FlowStateData {
  entityId: string;
  entityType: string;
  flowType: string;
  currentStage: string;
  currentStageName: string;
  currentStageColor: string;
  previousStage: string | null;
  progress: number;
  stageHistory: StageHistoryEntryData[];
  createdAt: Date;
  updatedAt: Date;
}

interface FlowProgressData {
  flowType: string;
  required: string;
  current: string;
  isReached: boolean;
}

interface MilestoneData {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  order: number;
}

interface MilestoneStateData {
  milestoneId: string;
  entityId: string;
  isComplete: boolean;
  completedAt: Date | null;
  flowProgress: FlowProgressData[];
}

interface MilestoneTimelineEntryData {
  milestone: MilestoneData;
  state: MilestoneStateData;
}

interface MilestoneTimelineData {
  entityId: string;
  milestones: MilestoneTimelineEntryData[];
  overallProgress: number;
  currentMilestone: MilestoneData | null;
  nextMilestone: MilestoneData | null;
}

interface TransitionResultData {
  success: boolean;
  flowState: FlowStateData | null;
  milestone: MilestoneData | null;
  milestoneComplete: boolean;
  error: string | null;
}

interface EntityFlowSummaryData {
  entityId: string;
  flows: FlowSummaryItemData[];
  currentMilestone: MilestoneData | null;
  nextMilestone: MilestoneData | null;
  overallProgress: number;
}

interface FlowSummaryItemData {
  flowType: string;
  currentStage: string;
  stageName: string;
  stageColor: string;
  progress: number;
}

// ═══════════════════════════════════════════════════════════════════════════════
// OBJECT TYPES
// ═══════════════════════════════════════════════════════════════════════════════

const StageAction = builder.objectRef<StageActionData>('StageAction').implement({
  fields: (t) => ({
    id: t.exposeString('id'),
    label: t.exposeString('label'),
    icon: t.exposeString('icon'),
    type: t.exposeString('type'),
    nextStage: t.exposeString('nextStage', { nullable: true }),
    mutation: t.exposeString('mutation', { nullable: true }),
    requiresConfirmation: t.exposeBoolean('requiresConfirmation'),
  }),
});

const FlowStage = builder.objectRef<FlowStageData>('FlowStage').implement({
  fields: (t) => ({
    id: t.exposeString('id'),
    name: t.exposeString('name'),
    description: t.exposeString('description'),
    icon: t.exposeString('icon'),
    color: t.exposeString('color'),
    order: t.exposeInt('order'),
    isTerminal: t.exposeBoolean('isTerminal'),
    alertCount: t.exposeInt('alertCount'),
    count: t.exposeInt('count'),
    actions: t.field({
      type: [StageAction],
      resolve: (parent) => parent.actions,
    }),
  }),
});

const FlowDefinition = builder.objectRef<FlowDefinitionData>('FlowDefinition').implement({
  fields: (t) => ({
    id: t.exposeString('id'),
    name: t.exposeString('name'),
    description: t.exposeString('description'),
    icon: t.exposeString('icon'),
    color: t.exposeString('color'),
    initialStage: t.exposeString('initialStage'),
    terminalStages: t.exposeStringList('terminalStages'),
    stages: t.field({
      type: [FlowStage],
      resolve: (parent) => parent.stages,
    }),
  }),
});

const StageHistoryEntry = builder.objectRef<StageHistoryEntryData>('StageHistoryEntry').implement({
  fields: (t) => ({
    stage: t.exposeString('stage'),
    stageName: t.exposeString('stageName'),
    enteredAt: t.expose('enteredAt', { type: 'DateTime' }),
    exitedAt: t.expose('exitedAt', { type: 'DateTime', nullable: true }),
    duration: t.exposeInt('duration', { nullable: true }),
    triggeredBy: t.exposeString('triggeredBy', { nullable: true }),
    notes: t.exposeString('notes', { nullable: true }),
  }),
});

const FlowState = builder.objectRef<FlowStateData>('FlowState').implement({
  fields: (t) => ({
    entityId: t.exposeString('entityId'),
    entityType: t.exposeString('entityType'),
    flowType: t.exposeString('flowType'),
    currentStage: t.exposeString('currentStage'),
    currentStageName: t.exposeString('currentStageName'),
    currentStageColor: t.exposeString('currentStageColor'),
    previousStage: t.exposeString('previousStage', { nullable: true }),
    progress: t.exposeInt('progress'),
    stageHistory: t.field({
      type: [StageHistoryEntry],
      resolve: (parent) => parent.stageHistory,
    }),
    createdAt: t.expose('createdAt', { type: 'DateTime' }),
    updatedAt: t.expose('updatedAt', { type: 'DateTime' }),
  }),
});

const FlowProgress = builder.objectRef<FlowProgressData>('FlowProgress').implement({
  fields: (t) => ({
    flowType: t.exposeString('flowType'),
    required: t.exposeString('required'),
    current: t.exposeString('current'),
    isReached: t.exposeBoolean('isReached'),
  }),
});

const Milestone = builder.objectRef<MilestoneData>('Milestone').implement({
  fields: (t) => ({
    id: t.exposeString('id'),
    name: t.exposeString('name'),
    description: t.exposeString('description'),
    icon: t.exposeString('icon'),
    color: t.exposeString('color'),
    order: t.exposeInt('order'),
  }),
});

const MilestoneState = builder.objectRef<MilestoneStateData>('MilestoneState').implement({
  fields: (t) => ({
    milestoneId: t.exposeString('milestoneId'),
    entityId: t.exposeString('entityId'),
    isComplete: t.exposeBoolean('isComplete'),
    completedAt: t.expose('completedAt', { type: 'DateTime', nullable: true }),
    flowProgress: t.field({
      type: [FlowProgress],
      resolve: (parent) => parent.flowProgress,
    }),
  }),
});

const MilestoneTimelineEntry = builder.objectRef<MilestoneTimelineEntryData>('MilestoneTimelineEntry').implement({
  fields: (t) => ({
    milestone: t.field({
      type: Milestone,
      resolve: (parent) => parent.milestone,
    }),
    state: t.field({
      type: MilestoneState,
      resolve: (parent) => parent.state,
    }),
  }),
});

const MilestoneTimeline = builder.objectRef<MilestoneTimelineData>('MilestoneTimeline').implement({
  fields: (t) => ({
    entityId: t.exposeString('entityId'),
    milestones: t.field({
      type: [MilestoneTimelineEntry],
      resolve: (parent) => parent.milestones,
    }),
    overallProgress: t.exposeInt('overallProgress'),
    currentMilestone: t.field({
      type: Milestone,
      nullable: true,
      resolve: (parent) => parent.currentMilestone,
    }),
    nextMilestone: t.field({
      type: Milestone,
      nullable: true,
      resolve: (parent) => parent.nextMilestone,
    }),
  }),
});

const TransitionResult = builder.objectRef<TransitionResultData>('TransitionResult').implement({
  fields: (t) => ({
    success: t.exposeBoolean('success'),
    flowState: t.field({
      type: FlowState,
      nullable: true,
      resolve: (parent) => parent.flowState,
    }),
    milestone: t.field({
      type: Milestone,
      nullable: true,
      resolve: (parent) => parent.milestone,
    }),
    milestoneComplete: t.exposeBoolean('milestoneComplete'),
    error: t.exposeString('error', { nullable: true }),
  }),
});

const FlowSummaryItem = builder.objectRef<FlowSummaryItemData>('FlowSummaryItem').implement({
  fields: (t) => ({
    flowType: t.exposeString('flowType'),
    currentStage: t.exposeString('currentStage'),
    stageName: t.exposeString('stageName'),
    stageColor: t.exposeString('stageColor'),
    progress: t.exposeInt('progress'),
  }),
});

const EntityFlowSummary = builder.objectRef<EntityFlowSummaryData>('EntityFlowSummary').implement({
  fields: (t) => ({
    entityId: t.exposeString('entityId'),
    flows: t.field({
      type: [FlowSummaryItem],
      resolve: (parent) => parent.flows,
    }),
    currentMilestone: t.field({
      type: Milestone,
      nullable: true,
      resolve: (parent) => parent.currentMilestone,
    }),
    nextMilestone: t.field({
      type: Milestone,
      nullable: true,
      resolve: (parent) => parent.nextMilestone,
    }),
    overallProgress: t.exposeInt('overallProgress'),
  }),
});

// ═══════════════════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function mapFlowDefinition(flow: typeof ALL_FLOWS['FREIGHT']): FlowDefinitionData {
  return {
    id: flow.id,
    name: flow.name,
    description: flow.description,
    icon: flow.icon,
    color: flow.color,
    initialStage: flow.initialStage,
    terminalStages: flow.terminalStages,
    stages: flow.stages.map((stage) => ({
      id: stage.id,
      name: stage.name,
      description: stage.description,
      icon: stage.icon,
      color: stage.color,
      order: stage.order,
      isTerminal: stage.isTerminal || false,
      alertCount: 0, // Will be populated from actual data
      count: 0, // Will be populated from actual data
      actions: (stage.actions || []).map((action) => ({
        id: action.id,
        label: action.label,
        icon: action.icon,
        type: action.type,
        nextStage: action.nextStage || null,
        mutation: action.mutation || null,
        requiresConfirmation: action.requiresConfirmation || false,
      })),
    })),
  };
}

function mapMilestone(milestone: typeof MILESTONES[0]): MilestoneData {
  return {
    id: milestone.id,
    name: milestone.name,
    description: milestone.description,
    icon: milestone.icon,
    color: milestone.color,
    order: milestone.order,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// QUERIES
// ═══════════════════════════════════════════════════════════════════════════════

// Get all flow definitions
builder.queryField('flowDefinitions', (t) =>
  t.field({
    type: [FlowDefinition],
    description: 'Get all flow definitions (Freight, Document, Finance, Information)',
    resolve: () => {
      return Object.values(ALL_FLOWS).map(mapFlowDefinition);
    },
  })
);

// Get a specific flow definition
builder.queryField('flowDefinition', (t) =>
  t.field({
    type: FlowDefinition,
    nullable: true,
    description: 'Get a specific flow definition by type',
    args: {
      flowType: t.arg({ type: FlowTypeEnum, required: true }),
    },
    resolve: (_, { flowType }) => {
      const flow = getFlowByType(flowType);
      return flow ? mapFlowDefinition(flow) : null;
    },
  })
);

// Get flow state for an entity
builder.queryField('flowState', (t) =>
  t.field({
    type: FlowState,
    nullable: true,
    description: 'Get current flow state for an entity',
    args: {
      entityId: t.arg.string({ required: true }),
      flowType: t.arg({ type: FlowTypeEnum, required: true }),
    },
    resolve: async (_, { entityId, flowType }, ctx) => {
      const flowService = getFlowService(ctx.prisma, fr8xPubSub);
      const state = await flowService.getFlowState(entityId, flowType);
      if (!state) return null;

      const stage = getStageByFlowAndId(flowType, state.currentStage);
      const flow = getFlowByType(flowType);
      const totalStages = flow.stages.filter((s) => !s.isTerminal).length;
      const progress = Math.round(((stage?.order || 1) / totalStages) * 100);

      return {
        entityId: state.entityId,
        entityType: state.entityType,
        flowType: state.flowType,
        currentStage: state.currentStage,
        currentStageName: stage?.name || state.currentStage,
        currentStageColor: stage?.color || '#6B7280',
        previousStage: state.previousStage || null,
        progress,
        stageHistory: state.stageHistory.map((entry) => ({
          stage: entry.stage,
          stageName: getStageByFlowAndId(flowType, entry.stage)?.name || entry.stage,
          enteredAt: entry.enteredAt,
          exitedAt: entry.exitedAt || null,
          duration: entry.duration || null,
          triggeredBy: entry.triggeredBy || null,
          notes: entry.notes || null,
        })),
        createdAt: state.createdAt,
        updatedAt: state.updatedAt,
      };
    },
  })
);

// Get all flow states for an entity
builder.queryField('entityFlows', (t) =>
  t.field({
    type: EntityFlowSummary,
    nullable: true,
    description: 'Get summary of all flows for an entity',
    args: {
      entityId: t.arg.string({ required: true }),
    },
    resolve: async (_, { entityId }, ctx) => {
      const flowService = getFlowService(ctx.prisma, fr8xPubSub);
      const milestoneService = getMilestoneService(ctx.prisma, fr8xPubSub);

      const summary = await flowService.getEntityFlows(entityId);
      if (!summary) return null;

      const timeline = await milestoneService.getMilestoneTimeline(entityId);

      const flows: FlowSummaryItemData[] = Object.entries(summary.flows).map(([flowType, data]) => ({
        flowType,
        currentStage: data!.currentStage,
        stageName: data!.stageName,
        stageColor: data!.stageColor,
        progress: data!.progress,
      }));

      return {
        entityId,
        flows,
        currentMilestone: summary.currentMilestone
          ? mapMilestone(MILESTONES.find((m) => m.id === summary.currentMilestone!.id)!)
          : null,
        nextMilestone: summary.nextMilestone
          ? mapMilestone(MILESTONES.find((m) => m.id === summary.nextMilestone!.id)!)
          : null,
        overallProgress: timeline.overallProgress,
      };
    },
  })
);

// Get all milestones
builder.queryField('milestones', (t) =>
  t.field({
    type: [Milestone],
    description: 'Get all milestone definitions',
    resolve: () => {
      return MILESTONES.map(mapMilestone);
    },
  })
);

// Get milestone timeline for an entity
builder.queryField('milestoneTimeline', (t) =>
  t.field({
    type: MilestoneTimeline,
    nullable: true,
    description: 'Get milestone timeline for an entity',
    args: {
      entityId: t.arg.string({ required: true }),
    },
    resolve: async (_, { entityId }, ctx) => {
      const milestoneService = getMilestoneService(ctx.prisma, fr8xPubSub);
      const timeline = await milestoneService.getMilestoneTimeline(entityId);

      const currentMilestone = await milestoneService.getCurrentMilestone(entityId);
      const nextMilestone = await milestoneService.getNextMilestone(entityId);

      return {
        entityId,
        milestones: timeline.milestones.map((entry) => ({
          milestone: mapMilestone(entry.milestone),
          state: {
            milestoneId: entry.state.milestoneId,
            entityId: entry.state.entityId,
            isComplete: entry.state.isComplete,
            completedAt: entry.state.completedAt || null,
            flowProgress: Object.entries(entry.state.flowProgress).map(([flowType, progress]) => ({
              flowType,
              required: progress!.required,
              current: progress!.current,
              isReached: progress!.isReached,
            })),
          },
        })),
        overallProgress: timeline.overallProgress,
        currentMilestone: currentMilestone ? mapMilestone(currentMilestone) : null,
        nextMilestone: nextMilestone ? mapMilestone(nextMilestone) : null,
      };
    },
  })
);

// Get milestone state for an entity
builder.queryField('milestoneState', (t) =>
  t.field({
    type: MilestoneState,
    nullable: true,
    description: 'Get state of a specific milestone for an entity',
    args: {
      entityId: t.arg.string({ required: true }),
      milestoneId: t.arg.string({ required: true }),
    },
    resolve: async (_, { entityId, milestoneId }, ctx) => {
      const milestoneService = getMilestoneService(ctx.prisma, fr8xPubSub);
      const state = await milestoneService.getMilestoneState(entityId, milestoneId);
      if (!state) return null;

      return {
        milestoneId: state.milestoneId,
        entityId: state.entityId,
        isComplete: state.isComplete,
        completedAt: state.completedAt || null,
        flowProgress: Object.entries(state.flowProgress).map(([flowType, progress]) => ({
          flowType,
          required: progress!.required,
          current: progress!.current,
          isReached: progress!.isReached,
        })),
      };
    },
  })
);

// ═══════════════════════════════════════════════════════════════════════════════
// MUTATIONS
// ═══════════════════════════════════════════════════════════════════════════════

// Initialize flows for an entity
builder.mutationField('initializeFlows', (t) =>
  t.field({
    type: EntityFlowSummary,
    description: 'Initialize all flows for an entity (e.g., when a load is created)',
    args: {
      input: t.arg({ type: InitializeFlowsInput, required: true }),
    },
    resolve: async (_, { input }, ctx) => {
      const flowService = getFlowService(ctx.prisma, fr8xPubSub);
      const milestoneService = getMilestoneService(ctx.prisma, fr8xPubSub);

      const flowTypes = (input.flowTypes as FlowType[]) || ['FREIGHT', 'DOCUMENT', 'FINANCE', 'INFORMATION'];
      await flowService.initializeFlows(input.entityId, input.entityType as any, flowTypes);
      await milestoneService.initializeMilestones(input.entityId);

      const summary = await flowService.getEntityFlows(input.entityId);
      const timeline = await milestoneService.getMilestoneTimeline(input.entityId);

      const flows: FlowSummaryItemData[] = Object.entries(summary!.flows).map(([flowType, data]) => ({
        flowType,
        currentStage: data!.currentStage,
        stageName: data!.stageName,
        stageColor: data!.stageColor,
        progress: data!.progress,
      }));

      return {
        entityId: input.entityId,
        flows,
        currentMilestone: summary!.currentMilestone
          ? mapMilestone(MILESTONES.find((m) => m.id === summary!.currentMilestone!.id)!)
          : null,
        nextMilestone: summary!.nextMilestone
          ? mapMilestone(MILESTONES.find((m) => m.id === summary!.nextMilestone!.id)!)
          : null,
        overallProgress: timeline.overallProgress,
      };
    },
  })
);

// Transition flow stage
builder.mutationField('transitionFlowStage', (t) =>
  t.field({
    type: TransitionResult,
    description: 'Transition an entity to a new stage in a flow',
    args: {
      input: t.arg({ type: TransitionStageInput, required: true }),
    },
    resolve: async (_, { input }, ctx) => {
      const flowService = getFlowService(ctx.prisma, fr8xPubSub);
      const milestoneService = getMilestoneService(ctx.prisma, fr8xPubSub);

      const result = await flowService.transitionStage(
        input.entityId,
        input.flowType as FlowType,
        input.toStage,
        input.triggeredBy || undefined,
        input.notes || undefined
      );

      if (!result.success) {
        return {
          success: false,
          flowState: null,
          milestone: null,
          milestoneComplete: false,
          error: result.error || 'Transition failed',
        };
      }

      // Update milestones
      await milestoneService.onFlowTransition(
        input.entityId,
        input.flowType as FlowType,
        input.toStage
      );

      const stage = getStageByFlowAndId(input.flowType as FlowType, result.flowState.currentStage);
      const flow = getFlowByType(input.flowType as FlowType);
      const totalStages = flow.stages.filter((s) => !s.isTerminal).length;
      const progress = Math.round(((stage?.order || 1) / totalStages) * 100);

      return {
        success: true,
        flowState: {
          entityId: result.flowState.entityId,
          entityType: result.flowState.entityType,
          flowType: result.flowState.flowType,
          currentStage: result.flowState.currentStage,
          currentStageName: stage?.name || result.flowState.currentStage,
          currentStageColor: stage?.color || '#6B7280',
          previousStage: result.flowState.previousStage || null,
          progress,
          stageHistory: result.flowState.stageHistory.map((entry) => ({
            stage: entry.stage,
            stageName: getStageByFlowAndId(input.flowType as FlowType, entry.stage)?.name || entry.stage,
            enteredAt: entry.enteredAt,
            exitedAt: entry.exitedAt || null,
            duration: entry.duration || null,
            triggeredBy: entry.triggeredBy || null,
            notes: entry.notes || null,
          })),
          createdAt: result.flowState.createdAt,
          updatedAt: result.flowState.updatedAt,
        },
        milestone: result.milestone
          ? mapMilestone(MILESTONES.find((m) => m.id === result.milestone!.id)!)
          : null,
        milestoneComplete: result.milestone?.isComplete || false,
        error: null,
      };
    },
  })
);

// Trigger milestone manually
builder.mutationField('triggerMilestone', (t) =>
  t.field({
    type: MilestoneState,
    nullable: true,
    description: 'Manually trigger a milestone (admin only)',
    args: {
      input: t.arg({ type: TriggerMilestoneInput, required: true }),
    },
    authScopes: { admin: true },
    resolve: async (_, { input }, ctx) => {
      const milestoneService = getMilestoneService(ctx.prisma, fr8xPubSub);
      const state = await milestoneService.triggerMilestone(
        input.entityId,
        input.milestoneId,
        input.force || false
      );

      if (!state) return null;

      return {
        milestoneId: state.milestoneId,
        entityId: state.entityId,
        isComplete: state.isComplete,
        completedAt: state.completedAt || null,
        flowProgress: Object.entries(state.flowProgress).map(([flowType, progress]) => ({
          flowType,
          required: progress!.required,
          current: progress!.current,
          isReached: progress!.isReached,
        })),
      };
    },
  })
);

// ═══════════════════════════════════════════════════════════════════════════════
// SUBSCRIPTIONS
// ═══════════════════════════════════════════════════════════════════════════════

// Flow transition subscription
builder.subscriptionField('flowTransition', (t) =>
  t.field({
    type: TransitionResult,
    description: 'Subscribe to flow stage transitions',
    args: {
      entityId: t.arg.string(),
    },
    subscribe: (_, { entityId }) =>
      fr8xPubSub.subscribe('FLOW_TRANSITION') as AsyncIterable<any>,
    resolve: (payload: any) => {
      return {
        success: true,
        flowState: payload.flowState || null,
        milestone: payload.milestone || null,
        milestoneComplete: payload.milestone?.isComplete || false,
        error: null,
      };
    },
  })
);

// Milestone completed subscription
builder.subscriptionField('milestoneCompleted', (t) =>
  t.field({
    type: MilestoneState,
    description: 'Subscribe to milestone completions',
    args: {
      entityId: t.arg.string(),
    },
    subscribe: (_, { entityId }) =>
      fr8xPubSub.subscribe('MILESTONE_COMPLETED') as AsyncIterable<any>,
    resolve: (payload: any) => {
      return {
        milestoneId: payload.milestoneId,
        entityId: payload.entityId,
        isComplete: true,
        completedAt: payload.completedAt,
        flowProgress: [],
      };
    },
  })
);

// ═══════════════════════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════════════════════

export { getFlowService, getMilestoneService };
