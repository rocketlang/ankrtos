/**
 * Fr8X GraphQL Schema
 * Combines all type definitions and resolvers
 *
 * Integrated with @ankr packages:
 * - @ankr/oauth - Authentication (Email, OTP, OAuth, MagicLink, WebAuthn)
 * - @ankr/iam - MFA, RBAC, ABAC, Session Recording
 * - @ankr/wire - Event bus, Service discovery
 * - @ankr/alerts - SOS, Recalls, Broadcasts, Incidents
 *
 * 🙏 Jai Guru Ji | © 2026 ANKR Labs
 */

import { builder } from './builder.js';

// ─────────────────────────────────────────────────────────────────────────────
// Import all schema modules
// ─────────────────────────────────────────────────────────────────────────────

// Core entities
import './types/organization.js';
import './types/user.js';
import './types/address.js';

// Auth & RBAC (integrated with @ankr/oauth and @ankr/iam)
import './types/auth.js';

// Alerts & Notifications (integrated with @ankr/alerts and @ankr/wire)
import './types/alerts.js';

// Real-time Subscriptions
import './types/subscriptions.js';

// SaaS Subscription & Device Management
import './types/subscription-management.js';

// Resource Pool - Passive Service Provider Tracking
import './types/resource-pool.js';

// ─────────────────────────────────────────────────────────────────────────────
// FR8X Tools Suite - Game-Changing Features
// ─────────────────────────────────────────────────────────────────────────────

// Universal Wallet - Instant pay for all vendor types
import './types/wallet.js';

// Backhaul Optimizer - Return load matching
import './types/backhaul.js';

// AI Bots - LLM assistants for every profile
import './types/bot.js';

// DocScan AI - OCR and document verification
import './types/docscan.js';

// Workflow Engine & Wizards - Automated processes and guided flows
import './types/workflow.js';

// Freight operations
import './types/carrier.js';
import './types/vehicle.js';
import './types/driver.js';
import './types/shipment.js';
import './types/quote.js';
import './types/trip.js';
import './types/tracking.js';
import './types/loadboard.js';

// Financial
import './types/payment.js';
import './types/razorpay.js';

// Documents
import './types/document.js';

// Routing
import './types/lane.js';

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 11 - Compliance & Ocean Tracking (integrating @ankr packages)
// ─────────────────────────────────────────────────────────────────────────────

// GST Compliance - E-way Bill, E-invoice (integrated with @ankr/compliance-gst)
import './types/compliance.js';

// Ocean Container Tracking (integrated with @ankr/ocean-tracker)
import './types/ocean-tracking.js';

// GPS Fleet Tracking - Real-time vehicle location
import './types/gps-tracking.js';

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 14 & 15 - AI/ML & Advanced Services
// ─────────────────────────────────────────────────────────────────────────────

// Route Optimization - AI-powered multi-stop optimization
import './types/route-optimizer.js';

// Predictive Pricing - ML-based rate prediction
import './types/predictive-pricing.js';

// Carbon Tracking - Emissions and sustainability
import './types/carbon-tracking.js';

// Multi-Tenant - Organization isolation and plans
import './types/multi-tenant.js';

// Offline Sync - Driver app offline-first sync
import './types/offline-sync.js';

// Push Notifications - FCM, APNs, Web Push
import './types/push-notification.js';

// ERP Integration - Tally, SAP, Oracle, Zoho
import './types/erp-integration.js';

// Insurance - Quotes, policies, claims
import './types/insurance.js';

// Realtime Analytics - Dashboard metrics
import './types/realtime-analytics.js';

// i18n - Multi-language support
import './types/i18n.js';

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 16 - Ecosystem Integration (Admin, CRM, HRMS, ERP)
// ─────────────────────────────────────────────────────────────────────────────

// Admin Console - Platform administration (@ankr/iam integration)
import './types/admin.js';

// CRM - Lead, Contact, Deal management (@ankr/crm-core integration)
import './types/crm.js';

// HRMS - Employee, Attendance, Payroll (@ankr/hrms integration)
import './types/hrms.js';

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 17 - AI Services (Brain, Translate, Voice, OCR)
// ─────────────────────────────────────────────────────────────────────────────

// AI Services - Swayam Bot, Translation, OCR, Voice (@ankr/brain integration)
import './types/ai-services.js';

// Lead Scraper - Website and WhatsApp lead scraping (@ankr/lead-scraper, @ankr/wa-scraper)
import './types/lead-scraper.js';

// Dev Tools - Testing, mock data generation, code scaffolding (@ankr/test-tool, @ankr/mcp-tools)
import './types/dev-tools.js';

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 18 - Flow Engine, Dynamic Pricing & Portals
// ─────────────────────────────────────────────────────────────────────────────

// Flow Engine - FreightFlow, DocumentFlow, FinanceFlow, InformationFlow with Milestones
import './types/flow-engine.js';

// Dynamic Pricing - Contract > Branch > Spot > Benchmark with Surge pricing
import './types/dynamic-pricing.js';

// Role-Based Portals - Shipper, Carrier, Broker, Admin, Driver
import './types/portal.js';

// ─────────────────────────────────────────────────────────────────────────────
// Build and export schema
// ─────────────────────────────────────────────────────────────────────────────
export const schema = builder.toSchema();

// Export IAM services for use in other modules
export {
  iamService,
  mfaService,
  jitAccessService,
  sessionRecorder
} from './types/auth.js';

// Export notification service and topics for use in other modules
export {
  notificationService,
  FR8X_TOPICS,
  ALERT_TOPICS
} from './types/alerts.js';

// Export PubSub for WebSocket server integration
export { fr8xPubSub } from './types/subscriptions.js';

// Export subscription service for SaaS management
export { subscriptionService, PLAN_LIMITS } from '../services/subscription.service.js';

// Export resource pool service for passive tracking
export { createResourcePoolService } from './types/resource-pool.js';

// ─────────────────────────────────────────────────────────────────────────────
// Fr8X Tools Suite Exports
// ─────────────────────────────────────────────────────────────────────────────

// Wallet service for instant pay, advances, settlements
export { createWalletService } from './types/wallet.js';

// Backhaul optimizer for return load matching
export { createBackhaulOptimizerService } from './types/backhaul.js';

// Bot service for AI assistants
export { createBotService } from './types/bot.js';

// Workflow Engine - Automated workflow execution
export { getWorkflowEngineService } from './types/workflow.js';

// Wizard Service - Step-by-step guided processes
export { getWizardService } from './types/workflow.js';

// Razorpay Payment Gateway - Checkout, escrow, refunds, payouts
export { createRazorpayService } from './types/razorpay.js';

// Shipment Service - Core shipment lifecycle with escrow integration
export { createShipmentService } from './types/shipment.js';

// ─────────────────────────────────────────────────────────────────────────────
// Phase 11 - Compliance & Ocean Tracking Exports
// ─────────────────────────────────────────────────────────────────────────────

// Compliance Service - GST, E-way Bill, E-invoice
export { complianceService, FREIGHT_GST_RATES, FREIGHT_HSN_CODES, STATE_CODES } from '../services/compliance.service.js';

// Ocean Tracking Service - Container, Vessel, Freight Rates
export { oceanTrackingService, SUPPORTED_CARRIERS, INDIAN_PORTS } from '../services/ocean-tracking.service.js';

// GPS Tracking Service - Real-time vehicle location and fleet management
export { gpsTrackingService } from '../services/gps-tracking.service.js';

// Loadboard - Spot market and load matching (resolvers are in loadboard.ts)

// ─────────────────────────────────────────────────────────────────────────────
// Phase 17 - AI Services & Lead Scraping Exports
// ─────────────────────────────────────────────────────────────────────────────

// Lead Scraper Service - Website and WhatsApp lead capture
export { leadScraperService } from './types/lead-scraper.js';

// DocScan Service - AI-powered document scanning
export { docScanService } from '../services/docscan.service.js';

// Swayam Bot Service - Universal AI assistant
export { swayamBotService } from '../services/swayam-bot.service.js';

// Dev Tools Service - Testing, mock data, code generation
export { devToolsService } from './types/dev-tools.js';

// ─────────────────────────────────────────────────────────────────────────────
// Phase 18 - Flow Engine, Dynamic Pricing & Portal Exports
// ─────────────────────────────────────────────────────────────────────────────

// Flow Engine - FreightFlow, DocumentFlow, FinanceFlow, InformationFlow
export { getFlowService, getMilestoneService } from './types/flow-engine.js';

// Dynamic Pricing - Surge pricing, Rate trends, Vehicle rates
export { getDynamicPricingService } from './types/dynamic-pricing.js';

// Portals - Role-based portal configurations
export {
  getPortalConfig,
  getPortalNavigation,
  getPortalWidgets,
  hasPortalFeature,
  hasPortalPermission,
} from './types/portal.js';
