# Vibecoding Tools - TODO

## Overview
Transform @ankr/vibecoding-tools from a basic 10-tool package to an enterprise-grade 35-tool suite fully integrated with the ANKR ecosystem.

---

## Phase 1: ANKR Integration (Priority: P0)

### Week 1 Tasks

- [ ] **Add ankr5 to PATH**
  - Create symlink: `ln -s /root/ankr-labs-nx/.ankr/cli/bin/ankr5 /usr/local/bin/ankr5`
  - Verify: `which ankr5`

- [ ] **Create `src/integrations/ankr5.ts`**
  ```typescript
  export async function getServicePort(service: string): Promise<number>
  export async function getServiceUrl(service: string): Promise<string>
  export async function checkGatewayStatus(): Promise<Record<string, boolean>>
  ```

- [ ] **Create `src/integrations/config.ts`**
  ```typescript
  import { PORTS, getBackendUrl } from '@ankr/config';
  export function getPortConfig(service: string): number
  export function getUrl(service: string, path?: string): string
  ```

- [ ] **Update `package.json`**
  - Add `@ankr/config` to dependencies
  - Add peer dependencies for `@ankr/ai-router`, `@ankr/eon`

- [ ] **Fix hardcoded port in `scaffold.ts:277`**
  - Replace `port: 3000` with dynamic port lookup
  - Use `getServicePort(projectName)` with fallback

---

## Phase 2: AI-Powered Generation (Priority: P1)

### Week 2 Tasks

- [ ] **Create `src/integrations/rag.ts`**
  - `buildCodeContext(query, cwd)` - Use ankr5 context build
  - `findSimilarPatterns(code)` - Search codebase for patterns

- [ ] **Create `src/integrations/eon.ts`**
  - `rememberGeneration(input, output)` - Store generation history
  - `recallSimilarGenerations(context)` - Retrieve past generations

- [ ] **Create `src/tools/smart-generate.ts`**
  - `smart_scaffold` - AI-powered scaffolding with RAG
  - `smart_component` - Context-aware component generation
  - `smart_api` - Pattern-learning API generation
  - `smart_refactor` - Codebase-aware refactoring

---

## Phase 3: Enterprise Templates (Priority: P1)

### Week 3 Tasks

- [ ] **Create enterprise project templates**
  | Template | Features |
  |----------|----------|
  | `enterprise-api` | Auth, RBAC, logging, metrics, OpenAPI |
  | `enterprise-frontend` | Auth flow, error boundaries, i18n |
  | `enterprise-fullstack` | Shared types, monorepo structure |
  | `microservice` | Docker, K8s, service mesh |

- [ ] **Add 8 new enterprise tools**
  - `generate_auth_flow`
  - `generate_api_docs`
  - `generate_docker`
  - `generate_ci_pipeline`
  - `generate_k8s_manifests`
  - `generate_error_handling`
  - `generate_logging`
  - `generate_tests`

- [ ] **Integrate @ankr/oauth**
  - Support 9 OAuth providers
  - RBAC templates
  - MFA configuration

- [ ] **Integrate @ankr/pulse**
  - Metrics endpoints
  - Health check templates
  - Tracing setup

---

## Phase 4: Validation & Quality (Priority: P2)

### Week 4 Tasks

- [ ] **Create `src/validation/` module**
  - `typescript.ts` - tsc --noEmit validation
  - `eslint.ts` - ESLint check
  - `security.ts` - Basic security scan
  - `imports.ts` - Import resolution check

- [ ] **Create `src/tools/generate-tests.ts`**
  - Auto-generate unit tests for components
  - Auto-generate integration tests for APIs

- [ ] **Add quality metrics tracking**
  ```typescript
  interface GenerationMetrics {
    syntaxValid: boolean;
    typesValid: boolean;
    testsPass: boolean;
    securityIssues: number;
    codeQualityScore: number;
  }
  ```

---

## Phase 5: MCP Orchestration (Priority: P2)

### Week 5 Tasks

- [ ] **Create MCP orchestration layer**
  - Call multiple MCP tools in sequence
  - Aggregate results for complex generations

- [ ] **Add domain-specific generators**
  | Domain | Tools |
  |--------|-------|
  | Logistics | `generate_shipment_ui`, `generate_tracking_api` |
  | Compliance | `generate_gst_form`, `generate_invoice_template` |
  | CRM | `generate_lead_form`, `generate_contact_ui` |
  | ERP | `generate_inventory_ui`, `generate_order_flow` |

- [ ] **Integrate with 255+ existing MCP tools**
  - Use `ankr5 mcp call` for tool invocation
  - Build context from tool results

---

## Quick Wins (Do Now)

1. **Add ankr5 to PATH** (5 min)
   ```bash
   ln -s /root/ankr-labs-nx/.ankr/cli/bin/ankr5 /usr/local/bin/ankr5
   ```

2. **Fix hardcoded port** (10 min)
   - Edit `scaffold.ts:277`
   - Replace `3000` with dynamic lookup

3. **Update package.json** (5 min)
   - Add @ankr/config dependency

---

## Progress Tracker

| Phase | Status | Tools | Completion |
|-------|--------|-------|------------|
| Current State | Done | 10 | 100% |
| Phase 1 - ANKR Integration | Not Started | +2 | 0% |
| Phase 2 - AI-Powered | Not Started | +4 | 0% |
| Phase 3 - Enterprise | Not Started | +8 | 0% |
| Phase 4 - Validation | Not Started | +3 | 0% |
| Phase 5 - MCP | Not Started | +8 | 0% |
| **Total** | | **35** | **29%** |

---

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| @ankr/config | workspace:* | Port configuration |
| @ankr/ai-router | >=2.0.0 | AI completions |
| @ankr/eon | >=3.0.0 | Memory system |
| @modelcontextprotocol/sdk | ^1.0.0 | MCP protocol |

---

## Testing Checklist

- [ ] `pnpm build` succeeds
- [ ] `ankr5 doctor` shows all services healthy
- [ ] `scaffold_project` uses dynamic ports
- [ ] Generated code passes TypeScript check
- [ ] Generated tests pass

---

## Related Documents

- [ENTERPRISE-UPGRADE-PLAN.md](./ENTERPRISE-UPGRADE-PLAN.md) - Full upgrade plan
- [ANKR5-INTEGRATION-GAPS.md](./ANKR5-INTEGRATION-GAPS.md) - Gap analysis
- [ANKRCODE-ECOSYSTEM.md](/root/ankrcode-project/ANKRCODE-ECOSYSTEM.md) - Ecosystem overview

---

*Created: 2026-01-17*
*Owner: ANKR Labs*
*Status: Active*
