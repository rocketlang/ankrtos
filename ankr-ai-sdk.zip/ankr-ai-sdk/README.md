# @ankr/ai-sdk

Universal AI SDK for all ANKR products - WowTruck, FreightBox, CompliMtrx, Bani, Saathi, SWAYAM.

## Features

- 🤖 **Auto Skills Injection** - AI automatically knows ANKR patterns (Fastify, Prisma, Zustand)
- 🆓 **Cost Optimized** - Uses free providers first (Groq, Cerebras)
- 🔌 **Universal** - Works with any ANKR product
- 📊 **GraphQL Support** - Full GraphQL API access
- 🧠 **Memory Integration** - Optional EON memory context

## Installation

```bash
pnpm add @ankr/ai-sdk
```

## Quick Start

```typescript
import { AnkrAI } from '@ankr/ai-sdk';

// Create instance for your product
const ai = new AnkrAI({ product: 'wowtruck' });

// Generate code - AI knows to use Fastify + Prisma!
const response = await ai.complete('Create a carrier rating API');

console.log(response.content);
// Output: Fastify routes with Prisma queries (not Express/Mongoose!)
```

## Product-Specific Instances

```typescript
import { 
  createWowTruckAI,
  createFreightBoxAI,
  createBaniAI,
  createSaathiAI 
} from '@ankr/ai-sdk';

// Pre-configured instances
const wowtruckAI = createWowTruckAI();
const freightboxAI = createFreightBoxAI();
const baniAI = createBaniAI();
const saathiAI = createSaathiAI();
```

## API Reference

### Constructor

```typescript
const ai = new AnkrAI({
  product: 'wowtruck',           // Required: which product
  baseUrl: 'http://ai.ankr.in',  // Optional: AI proxy URL
  strategy: 'free_first',        // Optional: provider selection
  userId: 'user-123',            // Optional: for context injection
  injectContext: true,           // Optional: enable memory
  timeout: 30000,                // Optional: request timeout
});
```

### Methods

#### `ai.complete(prompt, options?)`

Generate AI completion with ANKR skills automatically injected.

```typescript
const response = await ai.complete('Create GraphQL resolvers for shipment CRUD', {
  persona: 'CODE_EXPERT',
  maxTokens: 2000,
  temperature: 0.7,
});

console.log(response.content);    // Generated code
console.log(response.provider);   // 'cerebras'
console.log(response.cost);       // 0 (free!)
console.log(response.latencyMs);  // 650
```

#### `ai.chat(messages, options?)`

OpenAI-compatible chat format.

```typescript
const response = await ai.chat([
  { role: 'system', content: 'You are a logistics expert.' },
  { role: 'user', content: 'How to optimize fleet routing?' },
]);
```

#### `ai.embed(text)`

Generate embeddings for RAG/search.

```typescript
const { embedding } = await ai.embed('shipment tracking system');
// embedding: number[1536]
```

#### `ai.graphql(query, variables?)`

Execute GraphQL queries against ai-proxy.

```typescript
const data = await ai.graphql(`
  query GetStats {
    stats {
      requests
      completions
      totalCost
    }
  }
`);
```

#### `ai.health()`

Check AI proxy health.

```typescript
const health = await ai.health();
// { status: 'ok', providers: 17, memory: 'ready' }
```

#### `ai.providers()`

Get available AI providers.

```typescript
const { providers } = await ai.providers();
// ['groq', 'cerebras', 'deepseek', ...]
```

#### `ai.feedback(requestId, helpful, feedback?)`

Submit feedback for improving AI responses.

```typescript
await ai.feedback(response.requestId, true, 'Great code!');
```

## Environment Variables

```bash
# AI Proxy URL (defaults to localhost:4444)
ANKR_AI_URL=http://ai.ankr.in

# Or per-product
WOWTRUCK_AI_URL=http://ai.ankr.in
```

## Usage in Products

### WowTruck Backend

```typescript
// apps/wowtruck/backend/src/services/ai.service.ts
import { createWowTruckAI } from '@ankr/ai-sdk';

const ai = createWowTruckAI({
  baseUrl: process.env.AI_PROXY_URL,
});

export async function generateShipmentSummary(shipmentId: string) {
  const shipment = await prisma.shipment.findUnique({ where: { id: shipmentId } });
  
  const response = await ai.complete(
    `Generate a customer-friendly summary for this shipment: ${JSON.stringify(shipment)}`,
    { persona: 'LOGISTICS_EXPERT' }
  );
  
  return response.content;
}
```

### WowTruck Frontend

```typescript
// apps/wowtruck/frontend/src/hooks/useAI.ts
import { createWowTruckAI } from '@ankr/ai-sdk';
import { useState } from 'react';

const ai = createWowTruckAI({
  baseUrl: import.meta.env.VITE_AI_URL,
});

export function useAIChat() {
  const [loading, setLoading] = useState(false);

  const ask = async (question: string) => {
    setLoading(true);
    try {
      const response = await ai.complete(question);
      return response.content;
    } finally {
      setLoading(false);
    }
  };

  return { ask, loading };
}
```

### Bani (AI Assistant)

```typescript
// apps/bani/src/agent.ts
import { createBaniAI } from '@ankr/ai-sdk';

const ai = createBaniAI({
  injectContext: true,  // Enable memory
  userId: 'bani-agent',
});

export async function processUserQuery(query: string) {
  // AI automatically has access to all ANKR knowledge + user memory
  const response = await ai.complete(query, {
    persona: 'ASSISTANT',
  });
  
  return response.content;
}
```

## Skills Auto-Injection

When you call `ai.complete()`, the SDK automatically:

1. Detects your product (`wowtruck`, `bani`, etc.)
2. Loads relevant skills from `.claude/skills/`
3. Injects ANKR patterns into the AI context
4. AI generates code following YOUR stack:
   - ✅ Fastify (not Express)
   - ✅ Prisma (not Mongoose)
   - ✅ Mercurius (not Apollo Server)
   - ✅ Zustand (not Redux)
   - ✅ Lucide (not Heroicons)

## Cost

| Provider | Cost |
|----------|------|
| Groq | **FREE** |
| Cerebras | **FREE** |
| DeepSeek | ~$0.001/request |
| OpenAI | ~$0.01/request |

Default strategy `free_first` always uses free providers when available.

---

🙏 Jai Guru Ji | © 2025 ANKR Labs
