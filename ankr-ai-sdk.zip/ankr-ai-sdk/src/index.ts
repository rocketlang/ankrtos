/**
 * ═══════════════════════════════════════════════════════════════════════════
 * @ankr/ai-sdk - Universal AI SDK for all ANKR Products
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Usage:
 *   import { AnkrAI } from '@ankr/ai-sdk';
 *   const ai = new AnkrAI({ product: 'wowtruck' });
 *   const response = await ai.complete('Create a shipment tracking API');
 * 
 * 🙏 Jai Guru Ji | © 2025 ANKR Labs
 */

export type AnkrProduct = 
  | 'wowtruck' 
  | 'freightbox' 
  | 'complimtrx' 
  | 'bani' 
  | 'swayam' 
  | 'saathi' 
  | 'sunosunao'
  | 'ankr-internal';

export type AIStrategy = 
  | 'free_first'    // Use free providers first (Groq, Cerebras)
  | 'cheapest'      // Cheapest available
  | 'fastest'       // Lowest latency
  | 'quality';      // Best quality (may cost more)

export interface AnkrAIConfig {
  /** Which ANKR product is using this SDK */
  product: AnkrProduct;
  
  /** AI Proxy URL - defaults to localhost:4444 */
  baseUrl?: string;
  
  /** Provider selection strategy */
  strategy?: AIStrategy;
  
  /** User ID for context injection */
  userId?: string;
  
  /** Enable memory/context injection */
  injectContext?: boolean;
  
  /** Request timeout in ms */
  timeout?: number;
}

export interface CompletionOptions {
  /** Override default strategy for this request */
  strategy?: AIStrategy;
  
  /** System prompt override */
  systemPrompt?: string;
  
  /** Max tokens to generate */
  maxTokens?: number;
  
  /** Temperature (0-1) */
  temperature?: number;
  
  /** Specific skills to load (auto-detected if not provided) */
  skills?: string[];
  
  /** Persona to use */
  persona?: string;
}

export interface CompletionResponse {
  id: string;
  requestId: string;
  content: string;
  provider: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  cost: number;
  latencyMs: number;
  persona: string;
  skillsUsed?: string[];
}

export interface EmbeddingResponse {
  embedding: number[];
  provider: string;
  model: string;
  dimensions: number;
}

export interface HealthResponse {
  status: string;
  version: string;
  uptime: string;
  providers: number;
  memory: string;
  graphql: boolean;
  deepcode: boolean;
}

/**
 * Universal AI SDK for all ANKR Products
 */
export class AnkrAI {
  private config: Required<AnkrAIConfig>;

  constructor(config: AnkrAIConfig) {
    this.config = {
      product: config.product,
      baseUrl: config.baseUrl || process.env.ANKR_AI_URL || 'http://localhost:4444',
      strategy: config.strategy || 'free_first',
      userId: config.userId || '',
      injectContext: config.injectContext ?? false,
      timeout: config.timeout || 30000,
    };
  }

  /**
   * Generate AI completion with ANKR skills automatically injected
   */
  async complete(prompt: string, options?: CompletionOptions): Promise<CompletionResponse> {
    const response = await this.fetch('/api/ai/complete', {
      method: 'POST',
      body: JSON.stringify({
        prompt,
        product: this.config.product,
        strategy: options?.strategy || this.config.strategy,
        systemPrompt: options?.systemPrompt,
        maxTokens: options?.maxTokens,
        temperature: options?.temperature,
        skills: options?.skills,
        persona: options?.persona || 'GENERAL',
        userId: this.config.userId,
        injectContext: this.config.injectContext,
      }),
    });

    return response.json();
  }

  /**
   * Generate embeddings for text
   */
  async embed(text: string): Promise<EmbeddingResponse> {
    const response = await this.fetch('/api/ai/embeddings', {
      method: 'POST',
      body: JSON.stringify({ text }),
    });

    return response.json();
  }

  /**
   * Chat completion (OpenAI-compatible format)
   */
  async chat(messages: Array<{ role: string; content: string }>, options?: CompletionOptions): Promise<CompletionResponse> {
    const response = await this.fetch('/v1/chat/completions', {
      method: 'POST',
      body: JSON.stringify({
        messages,
        product: this.config.product,
        max_tokens: options?.maxTokens,
        temperature: options?.temperature,
      }),
    });

    const data = await response.json();
    
    return {
      id: data.id,
      requestId: data._ankr?.requestId || data.id,
      content: data.choices[0]?.message?.content || '',
      provider: data._ankr?.provider || 'unknown',
      model: data.model,
      inputTokens: data.usage?.prompt_tokens || 0,
      outputTokens: data.usage?.completion_tokens || 0,
      totalTokens: data.usage?.total_tokens || 0,
      cost: data._ankr?.cost?.total_cost || 0,
      latencyMs: data._ankr?.latency_ms || 0,
      persona: 'GENERAL',
    };
  }

  /**
   * GraphQL query to ai-proxy
   */
  async graphql<T = any>(query: string, variables?: Record<string, any>): Promise<T> {
    const response = await this.fetch('/graphql', {
      method: 'POST',
      body: JSON.stringify({ query, variables }),
    });

    const data = await response.json();
    
    if (data.errors) {
      throw new Error(data.errors[0]?.message || 'GraphQL error');
    }

    return data.data;
  }

  /**
   * Check AI proxy health
   */
  async health(): Promise<HealthResponse> {
    const response = await this.fetch('/health');
    return response.json();
  }

  /**
   * Get available providers
   */
  async providers(): Promise<{ providers: string[]; count: number }> {
    const response = await this.fetch('/api/ai/providers');
    return response.json();
  }

  /**
   * Get available personas
   */
  async personas(): Promise<Array<{ id: string; name: string; icon: string }>> {
    const response = await this.fetch('/api/ai/personas');
    return response.json();
  }

  /**
   * Submit feedback for a completion
   */
  async feedback(requestId: string, helpful: boolean, feedback?: string): Promise<void> {
    await this.fetch('/api/ai/feedback', {
      method: 'POST',
      body: JSON.stringify({ requestId, helpful, feedback }),
    });
  }

  /**
   * Internal fetch helper
   */
  private async fetch(path: string, options?: RequestInit): Promise<Response> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const response = await fetch(`${this.config.baseUrl}${path}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'X-ANKR-Product': this.config.product,
          ...options?.headers,
        },
        signal: controller.signal,
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`AI Proxy error: ${response.status} - ${error}`);
      }

      return response;
    } finally {
      clearTimeout(timeoutId);
    }
  }

  /**
   * Update configuration
   */
  setConfig(config: Partial<AnkrAIConfig>): void {
    Object.assign(this.config, config);
  }

  /**
   * Get current product
   */
  getProduct(): AnkrProduct {
    return this.config.product;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CONVENIENCE FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Create a pre-configured AI instance for WowTruck
 */
export function createWowTruckAI(config?: Partial<Omit<AnkrAIConfig, 'product'>>): AnkrAI {
  return new AnkrAI({ ...config, product: 'wowtruck' });
}

/**
 * Create a pre-configured AI instance for FreightBox
 */
export function createFreightBoxAI(config?: Partial<Omit<AnkrAIConfig, 'product'>>): AnkrAI {
  return new AnkrAI({ ...config, product: 'freightbox' });
}

/**
 * Create a pre-configured AI instance for CompliMtrx
 */
export function createCompliMtrxAI(config?: Partial<Omit<AnkrAIConfig, 'product'>>): AnkrAI {
  return new AnkrAI({ ...config, product: 'complimtrx' });
}

/**
 * Create a pre-configured AI instance for Bani
 */
export function createBaniAI(config?: Partial<Omit<AnkrAIConfig, 'product'>>): AnkrAI {
  return new AnkrAI({ ...config, product: 'bani' });
}

/**
 * Create a pre-configured AI instance for Saathi
 */
export function createSaathiAI(config?: Partial<Omit<AnkrAIConfig, 'product'>>): AnkrAI {
  return new AnkrAI({ ...config, product: 'saathi' });
}

/**
 * Create a pre-configured AI instance for SWAYAM
 */
export function createSwayamAI(config?: Partial<Omit<AnkrAIConfig, 'product'>>): AnkrAI {
  return new AnkrAI({ ...config, product: 'swayam' });
}

// Default export
export default AnkrAI;
