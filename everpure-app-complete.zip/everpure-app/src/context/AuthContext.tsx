import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { sendOTP as apiSendOTP, verifyOTP as apiVerifyOTP, Customer } from '../services/api';

// Cross-platform storage
const storage = {
  async getItem(key: string): Promise<string | null> {
    try {
      if (Platform.OS === 'web') return localStorage.getItem(key);
      return await SecureStore.getItemAsync(key);
    } catch (e) {
      console.error('Storage GET error:', e);
      return null;
    }
  },
  async setItem(key: string, value: string): Promise<void> {
    try {
      if (Platform.OS === 'web') {
        localStorage.setItem(key, value);
        return;
      }
      await SecureStore.setItemAsync(key, value);
    } catch (e) {
      console.error('Storage SET error:', e);
    }
  },
  async removeItem(key: string): Promise<void> {
    try {
      if (Platform.OS === 'web') {
        localStorage.removeItem(key);
        return;
      }
      await SecureStore.deleteItemAsync(key);
    } catch (e) {
      console.error('Storage REMOVE error:', e);
    }
  },
};

export interface User {
  id: number;
  name?: string;
  phone: string;
  email?: string;
  loyaltyPoints: number;
  totalOrders: number;
  totalSpent: number;
  isAdmin?: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isLoggedIn: boolean;
  sendOTP: (phone: string) => Promise<{ success: boolean; message: string }>;
  verifyOTP: (phone: string, otp: string) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<void>;
  updateUser: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_PHONES = ['9711121512', '9876543210', '+919711121512', '+919876543210'];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStoredUser();
  }, []);

  const loadStoredUser = async () => {
    try {
      const stored = await storage.getItem('everpure_user');
      if (stored) {
        const parsedUser = JSON.parse(stored);
        // Check admin status
        parsedUser.isAdmin = ADMIN_PHONES.some(p => 
          parsedUser.phone?.includes(p.replace('+91', ''))
        );
        setUser(parsedUser);
      }
    } catch (e) {
      console.error('Failed to load user:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const sendOTP = async (phone: string): Promise<{ success: boolean; message: string }> => {
    try {
      // Format phone - ensure it has +91 prefix
      const formattedPhone = phone.startsWith('+91') ? phone : `+91${phone.replace(/\D/g, '')}`;
      
      const result = await apiSendOTP(formattedPhone);
      return { success: result.success, message: result.message };
    } catch (error: any) {
      console.error('Send OTP error:', error);
      return { success: false, message: error.message || 'Failed to send OTP' };
    }
  };

  const verifyOTP = async (phone: string, otp: string): Promise<{ success: boolean; message: string }> => {
    try {
      const formattedPhone = phone.startsWith('+91') ? phone : `+91${phone.replace(/\D/g, '')}`;
      
      const result = await apiVerifyOTP(formattedPhone, otp);
      
      if (result.success && result.customer) {
        const newUser: User = {
          id: result.customer.id,
          name: result.customer.name,
          phone: result.customer.phone,
          email: result.customer.email,
          loyaltyPoints: result.customer.loyaltyPoints,
          totalOrders: result.customer.totalOrders,
          totalSpent: result.customer.totalSpent,
          isAdmin: ADMIN_PHONES.some(p => formattedPhone.includes(p.replace('+91', ''))),
        };
        
        setUser(newUser);
        await storage.setItem('everpure_user', JSON.stringify(newUser));
        
        if (result.token) {
          await storage.setItem('everpure_token', result.token);
        }
        
        return { success: true, message: 'Login successful!' };
      }
      
      return { success: false, message: result.message || 'Invalid OTP' };
    } catch (error: any) {
      console.error('Verify OTP error:', error);
      return { success: false, message: error.message || 'Verification failed' };
    }
  };

  const logout = async () => {
    setUser(null);
    await storage.removeItem('everpure_user');
    await storage.removeItem('everpure_token');
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      storage.setItem('everpure_user', JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isLoggedIn: !!user,
        sendOTP,
        verifyOTP,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
