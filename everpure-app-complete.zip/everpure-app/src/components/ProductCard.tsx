import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Product, getImageUrl } from '../services/api';

interface Props {
  product: Product;
  onAddToCart: (product: Product) => void;
  onPress?: (product: Product) => void;
  cartQuantity?: number;
}

export default function ProductCard({ product, onAddToCart, onPress, cartQuantity = 0 }: Props) {
  const discount = product.mrp > product.price 
    ? Math.round(((product.mrp - product.price) / product.mrp) * 100) 
    : 0;
  
  const isOutOfStock = product.stock === 0;
  const isComingSoon = product.badge === 'coming_soon';
  const isLowStock = product.stock > 0 && product.stock <= 5;
  const canBuy = !isOutOfStock && !isComingSoon && product.isActive !== false;

  const handleAdd = () => {
    if (!canBuy) {
      Alert.alert(
        isOutOfStock ? 'Out of Stock' : 'Coming Soon',
        'Would you like to be notified when available?',
        [
          { text: 'No' },
          { text: 'Notify Me', onPress: () => Alert.alert('Done!', 'We\'ll notify you when available.') }
        ]
      );
      return;
    }
    onAddToCart(product);
  };

  return (
    <TouchableOpacity 
      style={styles.card} 
      onPress={() => onPress?.(product)} 
      activeOpacity={0.8}
    >
      {/* Discount Badge */}
      {discount > 0 && canBuy && (
        <View style={styles.discountBadge}>
          <Text style={styles.discountText}>{discount}% OFF</Text>
        </View>
      )}
      
      {/* Out of Stock / Coming Soon Overlay */}
      {!canBuy && (
        <View style={styles.overlay}>
          <View style={[styles.statusBadge, isComingSoon && styles.comingSoonBadge]}>
            <Ionicons 
              name={isOutOfStock ? 'alert-circle' : 'time'} 
              size={16} 
              color="#fff" 
            />
            <Text style={styles.statusText}>
              {isOutOfStock ? 'Sold Out' : 'Coming Soon'}
            </Text>
          </View>
        </View>
      )}

      {/* Product Image */}
      <View style={[styles.imageBox, !canBuy && styles.imageDimmed]}>
        <Image 
          source={{ uri: getImageUrl(product.imageUrl) }} 
          style={styles.image} 
          resizeMode="contain" 
        />
      </View>

      {/* Product Info */}
      <View style={styles.info}>
        {product.category && (
          <Text style={styles.category}>{product.category.toUpperCase()}</Text>
        )}
        <Text style={styles.name} numberOfLines={2}>{product.nameEn}</Text>
        
        {product.weight && (
          <Text style={styles.weight}>{product.weight}</Text>
        )}
        
        <View style={styles.priceRow}>
          <Text style={styles.price}>₹{product.price}</Text>
          {product.mrp > product.price && (
            <Text style={styles.mrp}>₹{product.mrp}</Text>
          )}
        </View>
        
        {/* Low Stock Warning */}
        {isLowStock && (
          <View style={styles.lowStock}>
            <Ionicons name="warning" size={12} color="#F59E0B" />
            <Text style={styles.lowStockText}>Only {product.stock} left!</Text>
          </View>
        )}
        
        {/* Add to Cart Button */}
        {cartQuantity > 0 ? (
          <View style={styles.quantityControl}>
            <TouchableOpacity 
              style={styles.qtyBtn} 
              onPress={() => onAddToCart({ ...product, stock: -1 } as any)}
            >
              <Ionicons name="remove" size={18} color="#059669" />
            </TouchableOpacity>
            <Text style={styles.qtyText}>{cartQuantity}</Text>
            <TouchableOpacity style={styles.qtyBtn} onPress={handleAdd}>
              <Ionicons name="add" size={18} color="#059669" />
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity 
            style={[styles.addBtn, !canBuy && styles.notifyBtn]} 
            onPress={handleAdd}
          >
            <Ionicons 
              name={canBuy ? 'add' : 'notifications-outline'} 
              size={18} 
              color={canBuy ? '#fff' : '#F59E0B'} 
            />
            <Text style={[styles.addText, !canBuy && styles.notifyText]}>
              {canBuy ? 'Add' : 'Notify Me'}
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
    marginHorizontal: 6,
    flex: 1,
    maxWidth: '47%',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  discountBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#EF4444',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    zIndex: 10,
  },
  discountText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    zIndex: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EF4444',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  comingSoonBadge: {
    backgroundColor: '#F59E0B',
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  imageBox: {
    aspectRatio: 1,
    backgroundColor: '#F9FAFB',
    padding: 10,
  },
  imageDimmed: {
    opacity: 0.5,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  info: {
    padding: 10,
  },
  category: {
    fontSize: 9,
    color: '#059669',
    fontWeight: '600',
    marginBottom: 2,
  },
  name: {
    fontSize: 13,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
    lineHeight: 17,
  },
  weight: {
    fontSize: 11,
    color: '#6B7280',
    marginBottom: 4,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  price: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
  },
  mrp: {
    fontSize: 12,
    color: '#9CA3AF',
    textDecorationLine: 'line-through',
  },
  lowStock: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 4,
    marginBottom: 6,
    gap: 4,
    alignSelf: 'flex-start',
  },
  lowStockText: {
    fontSize: 9,
    color: '#F59E0B',
    fontWeight: '600',
  },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#059669',
    paddingVertical: 8,
    borderRadius: 8,
    gap: 4,
  },
  notifyBtn: {
    backgroundColor: '#FEF3C7',
    borderWidth: 1,
    borderColor: '#F59E0B',
  },
  addText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '600',
  },
  notifyText: {
    color: '#F59E0B',
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f0fdf4',
    borderRadius: 8,
    borderWidth: 1.5,
    borderColor: '#059669',
  },
  qtyBtn: {
    padding: 8,
  },
  qtyText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#059669',
    paddingHorizontal: 12,
  },
});
