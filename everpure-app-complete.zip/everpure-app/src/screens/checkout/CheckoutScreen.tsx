import React, { useState, useEffect } from 'react';
import { 
  View, Text, ScrollView, TextInput, TouchableOpacity, 
  StyleSheet, Alert, ActivityIndicator, Platform, 
  KeyboardAvoidingView, Linking 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { createOrder, OrderItem } from '../../services/api';
import * as SecureStore from 'expo-secure-store';

const RAZORPAY_KEY = 'rzp_test_RuzFF9lkbGVxwK';
const ADMIN_WHATSAPP = '919711121512';

// Cross-platform storage
const storage = {
  async getItem(key: string): Promise<string | null> {
    try {
      if (Platform.OS === 'web') return localStorage.getItem(key);
      return await SecureStore.getItemAsync(key);
    } catch (e) {
      return null;
    }
  },
  async setItem(key: string, value: string): Promise<void> {
    try {
      if (Platform.OS === 'web') {
        localStorage.setItem(key, value);
        return;
      }
      await SecureStore.setItemAsync(key, value);
    } catch (e) {
      console.error('Storage error:', e);
    }
  },
};

interface SavedAddress {
  id: string;
  name: string;
  phone: string;
  address: string;
  pincode: string;
  city: string;
  state: string;
}

export default function CheckoutScreen({ navigation }: any) {
  const { items, totalAmount, clearCart } = useCart();
  const { user } = useAuth();
  
  // Form state
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  
  // UI state
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'online'>('cod');
  const [savedAddresses, setSavedAddresses] = useState<SavedAddress[]>([]);
  const [showSaved, setShowSaved] = useState(false);
  const [addressSaved, setAddressSaved] = useState(false);
  const [discountCode, setDiscountCode] = useState('');

  const delivery = totalAmount >= 500 ? 0 : 50;
  const total = totalAmount + delivery;

  useEffect(() => {
    loadSavedData();
  }, []);

  const loadSavedData = async () => {
    try {
      // Load saved addresses
      const saved = await storage.getItem('everpure_addresses');
      if (saved) {
        const addresses = JSON.parse(saved);
        setSavedAddresses(addresses);
        
        // Auto-fill with most recent address
        if (addresses.length > 0) {
          const recent = addresses[0];
          setName(recent.name || '');
          setPhone(recent.phone || '');
          setAddress(recent.address || '');
          setPincode(recent.pincode || '');
          setCity(recent.city || '');
          setState(recent.state || '');
          setAddressSaved(true);
        }
      }
      
      // Fill from user profile if no saved address
      if (!name && user?.name) setName(user.name);
      if (!phone && user?.phone) setPhone(user.phone.replace('+91', ''));
      if (!email && user?.email) setEmail(user.email);
    } catch (e) {
      console.error('Load error:', e);
      if (user?.name) setName(user.name);
      if (user?.phone) setPhone(user.phone.replace('+91', ''));
    }
  };

  const saveAddress = async () => {
    if (!name.trim() || !address.trim() || !pincode.trim() || !city.trim()) {
      Alert.alert('Incomplete', 'Please fill Name, Address, Pincode and City to save');
      return;
    }
    
    const newAddr: SavedAddress = {
      id: Date.now().toString(),
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      pincode: pincode.trim(),
      city: city.trim(),
      state: state.trim(),
    };
    
    // Remove duplicates
    const filtered = savedAddresses.filter(a => 
      !(a.address.toLowerCase() === address.toLowerCase().trim() && a.pincode === pincode.trim())
    );
    
    const updated = [newAddr, ...filtered].slice(0, 5);
    await storage.setItem('everpure_addresses', JSON.stringify(updated));
    setSavedAddresses(updated);
    setAddressSaved(true);
    Alert.alert('✓ Saved!', 'Address saved for future orders');
  };

  const selectSavedAddress = (addr: SavedAddress) => {
    setName(addr.name);
    setPhone(addr.phone);
    setAddress(addr.address);
    setPincode(addr.pincode);
    setCity(addr.city);
    setState(addr.state);
    setShowSaved(false);
    setAddressSaved(true);
  };

  const deleteSavedAddress = async (id: string) => {
    const updated = savedAddresses.filter(a => a.id !== id);
    await storage.setItem('everpure_addresses', JSON.stringify(updated));
    setSavedAddresses(updated);
    Alert.alert('Deleted', 'Address removed');
  };

  const validateForm = (): boolean => {
    if (!name.trim()) {
      Alert.alert('Required', 'Please enter your name');
      return false;
    }
    if (!phone.trim() || phone.replace(/\D/g, '').length < 10) {
      Alert.alert('Required', 'Please enter valid 10-digit phone');
      return false;
    }
    if (!address.trim()) {
      Alert.alert('Required', 'Please enter your address');
      return false;
    }
    if (!pincode.trim() || pincode.length !== 6) {
      Alert.alert('Required', 'Please enter valid 6-digit pincode');
      return false;
    }
    if (!city.trim()) {
      Alert.alert('Required', 'Please enter your city');
      return false;
    }
    return true;
  };

  const formatOrderForWhatsApp = (orderId?: string) => {
    const itemsList = items.map(i => 
      `${i.product.nameEn} x${i.quantity} = ₹${i.product.price * i.quantity}`
    ).join('\n');
    
    const payStatus = paymentMethod === 'cod' ? 'Cash on Delivery' : 'PAID Online';
    const fullAddress = `${address}\n${city}${state ? ', ' + state : ''} - ${pincode}`;
    
    return `🌿 *Ever Pure Order${orderId ? ' #' + orderId : ''}*

${itemsList}

📍 *Delivery:*
${name}
${fullAddress}
📞 ${phone}

💰 Subtotal: ₹${totalAmount}
🚚 Delivery: ${delivery === 0 ? 'FREE' : '₹' + delivery}
*Total: ₹${total}*
💳 ${payStatus}`;
  };

  const sendWhatsAppOrder = (orderId?: string) => {
    const msg = formatOrderForWhatsApp(orderId);
    const url = `https://wa.me/${ADMIN_WHATSAPP}?text=${encodeURIComponent(msg)}`;
    Platform.OS === 'web' ? window.open(url, '_blank') : Linking.openURL(url);
  };

  const handleRazorpayPayment = async (dbOrder: any) => {
    if (Platform.OS === 'web') {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.async = true;
      document.body.appendChild(script);
      
      script.onload = () => {
        const options = {
          key: RAZORPAY_KEY,
          amount: total * 100,
          currency: 'INR',
          name: 'Ever Pure',
          description: `Order #${dbOrder.orderId}`,
          order_id: dbOrder.razorpayOrderId, // If backend creates Razorpay order
          handler: async (response: any) => {
            try {
              // Confirm payment in backend
              // await confirmPayment(dbOrder.orderId, response.razorpay_payment_id, response.razorpay_signature);
              
              clearCart();
              sendWhatsAppOrder(dbOrder.orderId);
              Alert.alert('Success! ✅', `Order #${dbOrder.orderId}\nPayment ID: ${response.razorpay_payment_id}`, [
                { text: 'OK', onPress: () => navigation.reset({ index: 0, routes: [{ name: 'Main' }] }) }
              ]);
            } catch (e) {
              console.error('Payment confirmation error:', e);
              Alert.alert('Payment Received', 'Order placed successfully!', [
                { text: 'OK', onPress: () => navigation.reset({ index: 0, routes: [{ name: 'Main' }] }) }
              ]);
            }
          },
          prefill: {
            name,
            email: email || 'customer@everpure.in',
            contact: '+91' + phone.replace(/\D/g, ''),
          },
          theme: { color: '#059669' },
          modal: { ondismiss: () => setLoading(false) },
        };
        
        const rzp = new (window as any).Razorpay(options);
        rzp.on('payment.failed', (r: any) => {
          Alert.alert('Payment Failed', r.error.description || 'Please try again');
          setLoading(false);
        });
        rzp.open();
      };
      
      script.onerror = () => {
        Alert.alert('Error', 'Failed to load payment gateway');
        setLoading(false);
      };
    } else {
      // Mobile - use Razorpay native SDK
      try {
        const RazorpayCheckout = require('react-native-razorpay').default;
        const data = await RazorpayCheckout.open({
          key: RAZORPAY_KEY,
          amount: total * 100,
          currency: 'INR',
          name: 'Ever Pure',
          description: `Order #${dbOrder.orderId}`,
          prefill: {
            name,
            email: email || 'customer@everpure.in',
            contact: '+91' + phone.replace(/\D/g, ''),
          },
          theme: { color: '#059669' },
        });
        
        clearCart();
        sendWhatsAppOrder(dbOrder.orderId);
        Alert.alert('Success!', `Order #${dbOrder.orderId} placed!`, [
          { text: 'OK', onPress: () => navigation.reset({ index: 0, routes: [{ name: 'Main' }] }) }
        ]);
      } catch (e: any) {
        Alert.alert('Payment Failed', e.description || 'Please try again');
        setLoading(false);
      }
    }
  };

  const placeOrder = async () => {
    if (!validateForm()) return;
    
    setLoading(true);
    
    try {
      // Prepare order items for backend
      const orderItems: OrderItem[] = items.map(item => ({
        productId: item.product.id,
        name: item.product.nameEn,
        price: item.product.price,
        quantity: item.quantity,
        total: item.product.price * item.quantity,
      }));
      
      const fullAddress = `${address}, ${city}${state ? ', ' + state : ''} - ${pincode}`;
      
      // Create order in database
      const dbOrder = await createOrder({
        customerName: name.trim(),
        customerPhone: '+91' + phone.replace(/\D/g, ''),
        customerEmail: email || undefined,
        customerAddress: fullAddress,
        items: orderItems,
        paymentMethod: paymentMethod === 'cod' ? 'COD' : 'ONLINE',
      });
      
      console.log('Order created in database:', dbOrder);
      
      // Save address for future use
      if (name && address && pincode && city) {
        const newAddr: SavedAddress = { id: Date.now().toString(), name, phone, address, pincode, city, state };
        const filtered = savedAddresses.filter(a => !(a.address === address && a.pincode === pincode));
        const updated = [newAddr, ...filtered].slice(0, 5);
        await storage.setItem('everpure_addresses', JSON.stringify(updated));
      }
      
      if (paymentMethod === 'online') {
        // Handle online payment
        handleRazorpayPayment(dbOrder);
      } else {
        // COD - complete order
        sendWhatsAppOrder(dbOrder.orderId);
        clearCart();
        Alert.alert(
          'Order Placed! 🎉',
          `Order #${dbOrder.orderId}\nCheck WhatsApp for confirmation`,
          [{ text: 'OK', onPress: () => navigation.reset({ index: 0, routes: [{ name: 'Main' }] }) }]
        );
        setLoading(false);
      }
    } catch (error: any) {
      console.error('Order creation error:', error);
      Alert.alert('Error', error.message || 'Failed to place order. Please try again.');
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <View style={s.empty}>
        <Ionicons name="cart-outline" size={80} color="#ccc" />
        <Text style={s.emptyTxt}>Cart is empty</Text>
        <TouchableOpacity 
          style={s.shopBtn} 
          onPress={() => navigation.reset({ index: 0, routes: [{ name: 'Main' }] })}
        >
          <Text style={s.shopBtnTxt}>Shop Now</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const canSave = name.trim() && address.trim() && pincode.trim() && city.trim();

  return (
    <KeyboardAvoidingView 
      style={s.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#111" />
        </TouchableOpacity>
        <Text style={s.title}>Checkout</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={s.content} keyboardShouldPersistTaps="handled">
        {/* Order Summary */}
        <View style={s.section}>
          <Text style={s.secTitle}>🛒 Order Summary</Text>
          {items.map(i => (
            <View key={i.product.id} style={s.row}>
              <Text style={s.itemName}>{i.product.nameEn} x{i.quantity}</Text>
              <Text style={s.itemPrice}>₹{i.product.price * i.quantity}</Text>
            </View>
          ))}
          <View style={s.divider} />
          <View style={s.row}>
            <Text>Subtotal</Text>
            <Text>₹{totalAmount}</Text>
          </View>
          <View style={s.row}>
            <Text>Delivery</Text>
            <Text style={delivery === 0 ? s.free : undefined}>
              {delivery === 0 ? 'FREE' : '₹' + delivery}
            </Text>
          </View>
          {totalAmount < 500 && (
            <Text style={s.hint}>Add ₹{500 - totalAmount} more for FREE delivery</Text>
          )}
          <View style={s.divider} />
          <View style={s.row}>
            <Text style={s.totalLbl}>Total</Text>
            <Text style={s.totalVal}>₹{total}</Text>
          </View>
        </View>

        {/* Shipping Address */}
        <View style={s.section}>
          <View style={s.secHeader}>
            <Text style={s.secTitle}>📍 Shipping Address</Text>
            {savedAddresses.length > 0 && (
              <TouchableOpacity style={s.savedBtn} onPress={() => setShowSaved(!showSaved)}>
                <Ionicons name="bookmark" size={16} color="#059669" />
                <Text style={s.savedBtnTxt}>{savedAddresses.length} Saved</Text>
                <Ionicons name={showSaved ? 'chevron-up' : 'chevron-down'} size={16} color="#059669" />
              </TouchableOpacity>
            )}
          </View>

          {/* Saved Addresses Dropdown */}
          {showSaved && (
            <View style={s.savedList}>
              <Text style={s.savedListTitle}>Tap to use:</Text>
              {savedAddresses.map(addr => (
                <TouchableOpacity 
                  key={addr.id} 
                  style={s.savedItem} 
                  onPress={() => selectSavedAddress(addr)}
                >
                  <View style={s.savedInfo}>
                    <Text style={s.savedName}>{addr.name}</Text>
                    <Text style={s.savedAddr}>{addr.address}</Text>
                    <Text style={s.savedCity}>{addr.city} - {addr.pincode}</Text>
                  </View>
                  <TouchableOpacity 
                    onPress={() => deleteSavedAddress(addr.id)} 
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Ionicons name="close-circle" size={22} color="#EF4444" />
                  </TouchableOpacity>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Address Form */}
          <TextInput 
            style={s.input} 
            placeholder="Full Name *" 
            value={name} 
            onChangeText={(t) => { setName(t); setAddressSaved(false); }} 
            placeholderTextColor="#999" 
          />
          <TextInput 
            style={s.input} 
            placeholder="Phone (10 digits) *" 
            value={phone} 
            onChangeText={(t) => { setPhone(t); setAddressSaved(false); }} 
            keyboardType="phone-pad" 
            maxLength={10} 
            placeholderTextColor="#999" 
          />
          <TextInput 
            style={s.input} 
            placeholder="Email (optional)" 
            value={email} 
            onChangeText={setEmail} 
            keyboardType="email-address" 
            autoCapitalize="none" 
            placeholderTextColor="#999" 
          />
          <TextInput 
            style={[s.input, s.textArea]} 
            placeholder="Full Address (House No, Street, Area) *" 
            value={address} 
            onChangeText={(t) => { setAddress(t); setAddressSaved(false); }} 
            multiline 
            placeholderTextColor="#999" 
          />
          <View style={s.rowInput}>
            <TextInput 
              style={[s.input, { flex: 1, marginRight: 10 }]} 
              placeholder="Pincode *" 
              value={pincode} 
              onChangeText={(t) => { setPincode(t); setAddressSaved(false); }} 
              keyboardType="number-pad" 
              maxLength={6} 
              placeholderTextColor="#999" 
            />
            <TextInput 
              style={[s.input, { flex: 1 }]} 
              placeholder="City *" 
              value={city} 
              onChangeText={(t) => { setCity(t); setAddressSaved(false); }} 
              placeholderTextColor="#999" 
            />
          </View>
          <TextInput 
            style={s.input} 
            placeholder="State (optional)" 
            value={state} 
            onChangeText={setState} 
            placeholderTextColor="#999" 
          />
          
          {/* Save Address Button */}
          {canSave && (
            <TouchableOpacity 
              style={[s.saveAddrBtn, addressSaved && s.saveAddrBtnSaved]} 
              onPress={addressSaved ? undefined : saveAddress}
              disabled={addressSaved}
            >
              <Ionicons 
                name={addressSaved ? 'checkmark-circle' : 'bookmark-outline'} 
                size={20} 
                color={addressSaved ? '#fff' : '#059669'} 
              />
              <Text style={[s.saveAddrTxt, addressSaved && s.saveAddrTxtSaved]}>
                {addressSaved ? 'Address Saved ✓' : 'Save this Address'}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Payment Method */}
        <View style={s.section}>
          <Text style={s.secTitle}>💳 Payment Method</Text>
          
          <TouchableOpacity 
            style={[s.payOpt, paymentMethod === 'cod' && s.payOptActive]} 
            onPress={() => setPaymentMethod('cod')}
          >
            <Ionicons 
              name={paymentMethod === 'cod' ? 'radio-button-on' : 'radio-button-off'} 
              size={24} 
              color={paymentMethod === 'cod' ? '#059669' : '#999'} 
            />
            <View style={s.payInfo}>
              <Text style={s.payTxt}>Cash on Delivery</Text>
              <Text style={s.payDesc}>Pay when you receive</Text>
            </View>
            <Text style={s.payIcon}>💵</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[s.payOpt, paymentMethod === 'online' && s.payOptActive]} 
            onPress={() => setPaymentMethod('online')}
          >
            <Ionicons 
              name={paymentMethod === 'online' ? 'radio-button-on' : 'radio-button-off'} 
              size={24} 
              color={paymentMethod === 'online' ? '#059669' : '#999'} 
            />
            <View style={s.payInfo}>
              <Text style={s.payTxt}>Pay Online</Text>
              <Text style={s.payDesc}>UPI, Card, Net Banking</Text>
            </View>
            <Text style={s.payIcon}>💳</Text>
          </TouchableOpacity>
        </View>
        
        <View style={{ height: 120 }} />
      </ScrollView>

      {/* Footer */}
      <View style={s.footer}>
        <View>
          <Text style={s.footerLbl}>Total</Text>
          <Text style={s.footerVal}>₹{total}</Text>
        </View>
        <TouchableOpacity 
          style={[s.placeBtn, loading && s.placeBtnDisabled]} 
          onPress={placeOrder} 
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Ionicons 
                name={paymentMethod === 'online' ? 'card' : 'checkmark-circle'} 
                size={20} 
                color="#fff" 
              />
              <Text style={s.placeTxt}>
                {paymentMethod === 'online' ? `Pay ₹${total}` : 'Place Order'}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f3f4f6' },
  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    padding: 16, 
    paddingTop: 50, 
    backgroundColor: '#fff', 
    borderBottomWidth: 1, 
    borderBottomColor: '#e5e7eb' 
  },
  title: { fontSize: 18, fontWeight: 'bold', color: '#111' },
  content: { flex: 1 },
  section: { 
    backgroundColor: '#fff', 
    margin: 12, 
    marginBottom: 0, 
    padding: 16, 
    borderRadius: 12 
  },
  secHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: 12 
  },
  secTitle: { fontSize: 16, fontWeight: 'bold', color: '#111' },
  savedBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#f0fdf4', 
    paddingHorizontal: 10, 
    paddingVertical: 6, 
    borderRadius: 20, 
    gap: 4 
  },
  savedBtnTxt: { color: '#059669', fontSize: 13, fontWeight: '600' },
  savedList: { 
    backgroundColor: '#f0fdf4', 
    borderRadius: 10, 
    padding: 12, 
    marginBottom: 16, 
    borderWidth: 1, 
    borderColor: '#d1fae5' 
  },
  savedListTitle: { fontSize: 12, color: '#059669', fontWeight: '600', marginBottom: 8 },
  savedItem: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#fff', 
    padding: 12, 
    borderRadius: 8, 
    marginBottom: 8, 
    borderWidth: 1, 
    borderColor: '#e5e7eb' 
  },
  savedInfo: { flex: 1 },
  savedName: { fontSize: 14, fontWeight: '700', color: '#111' },
  savedAddr: { fontSize: 13, color: '#374151', marginTop: 2 },
  savedCity: { fontSize: 12, color: '#6b7280', marginTop: 2 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  itemName: { fontSize: 14, color: '#374151', flex: 1 },
  itemPrice: { fontSize: 14, fontWeight: '600', color: '#111' },
  divider: { height: 1, backgroundColor: '#e5e7eb', marginVertical: 12 },
  free: { color: '#059669', fontWeight: '700' },
  hint: { fontSize: 12, color: '#f59e0b', marginTop: 4 },
  totalLbl: { fontSize: 16, fontWeight: 'bold', color: '#111' },
  totalVal: { fontSize: 20, fontWeight: 'bold', color: '#059669' },
  input: { 
    backgroundColor: '#f9fafb', 
    borderWidth: 1, 
    borderColor: '#e5e7eb', 
    borderRadius: 10, 
    padding: 14, 
    fontSize: 16, 
    color: '#111', 
    marginBottom: 12 
  },
  textArea: { height: 80, textAlignVertical: 'top' },
  rowInput: { flexDirection: 'row' },
  saveAddrBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    padding: 14, 
    borderWidth: 2, 
    borderColor: '#059669', 
    borderRadius: 10, 
    gap: 8 
  },
  saveAddrBtnSaved: { backgroundColor: '#059669', borderColor: '#059669' },
  saveAddrTxt: { color: '#059669', fontSize: 15, fontWeight: '700' },
  saveAddrTxtSaved: { color: '#fff' },
  payOpt: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    padding: 14, 
    borderWidth: 2, 
    borderColor: '#e5e7eb', 
    borderRadius: 12, 
    marginBottom: 10 
  },
  payOptActive: { borderColor: '#059669', backgroundColor: '#f0fdf4' },
  payInfo: { flex: 1, marginLeft: 12 },
  payTxt: { fontSize: 16, color: '#111', fontWeight: '600' },
  payDesc: { fontSize: 12, color: '#6b7280', marginTop: 2 },
  payIcon: { fontSize: 24 },
  footer: { 
    backgroundColor: '#fff', 
    padding: 16, 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    borderTopWidth: 1, 
    borderTopColor: '#e5e7eb' 
  },
  footerLbl: { fontSize: 12, color: '#6b7280' },
  footerVal: { fontSize: 22, fontWeight: 'bold', color: '#059669' },
  placeBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#059669', 
    paddingHorizontal: 28, 
    paddingVertical: 14, 
    borderRadius: 12, 
    gap: 8 
  },
  placeBtnDisabled: { opacity: 0.6 },
  placeTxt: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  emptyTxt: { fontSize: 18, color: '#6b7280', marginTop: 16 },
  shopBtn: { 
    marginTop: 20, 
    backgroundColor: '#059669', 
    paddingHorizontal: 32, 
    paddingVertical: 14, 
    borderRadius: 10 
  },
  shopBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
