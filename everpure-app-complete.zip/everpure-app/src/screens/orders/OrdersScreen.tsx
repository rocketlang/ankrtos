import React, { useState, useEffect } from 'react';
import { 
  View, Text, ScrollView, TouchableOpacity, 
  StyleSheet, ActivityIndicator, RefreshControl, TextInput, Alert 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getCustomerOrders, trackOrder, Order } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

const STATUS_COLORS: Record<string, { bg: string; text: string; icon: string }> = {
  pending: { bg: '#FEF3C7', text: '#F59E0B', icon: 'time' },
  confirmed: { bg: '#DBEAFE', text: '#3B82F6', icon: 'checkmark-circle' },
  processing: { bg: '#E0E7FF', text: '#6366F1', icon: 'sync' },
  shipped: { bg: '#D1FAE5', text: '#059669', icon: 'airplane' },
  delivered: { bg: '#D1FAE5', text: '#059669', icon: 'checkmark-done-circle' },
  cancelled: { bg: '#FEE2E2', text: '#EF4444', icon: 'close-circle' },
};

export default function OrdersScreen({ navigation }: any) {
  const { user, isLoggedIn } = useAuth();
  
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  
  const [trackPhone, setTrackPhone] = useState('');
  const [trackOrderId, setTrackOrderId] = useState('');
  const [tracking, setTracking] = useState(false);
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (isLoggedIn && user?.phone) {
      loadOrders();
    } else {
      setLoading(false);
    }
  }, [isLoggedIn, user?.phone]);

  const loadOrders = async () => {
    if (!user?.phone) return;
    try {
      setLoading(true);
      const data = await getCustomerOrders(user.phone);
      setOrders(data);
    } catch (e: any) {
      console.error('Load orders error:', e);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrders();
    setRefreshing(false);
  };

  const handleTrackOrder = async () => {
    if (!trackPhone.trim() || !trackOrderId.trim()) {
      Alert.alert('Required', 'Please enter both phone number and order ID');
      return;
    }
    try {
      setTracking(true);
      const formattedPhone = trackPhone.startsWith('+91') ? trackPhone : `+91${trackPhone.replace(/\D/g, '')}`;
      const order = await trackOrder(trackOrderId.trim(), formattedPhone);
      if (order) {
        setTrackedOrder(order);
      } else {
        Alert.alert('Not Found', 'No order found with this ID and phone number');
      }
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to track order');
    } finally {
      setTracking(false);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const getStatusStyle = (status: string) => STATUS_COLORS[status.toLowerCase()] || STATUS_COLORS.pending;

  const renderOrder = (order: Order) => {
    const statusStyle = getStatusStyle(order.orderStatus);
    const items = typeof order.items === 'string' ? JSON.parse(order.items) : order.items;
    
    return (
      <View key={order.id} style={styles.orderCard}>
        <View style={styles.orderHeader}>
          <View>
            <Text style={styles.orderId}>#{order.orderId}</Text>
            <Text style={styles.orderDate}>{formatDate(order.createdAt)}</Text>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: statusStyle.bg }]}>
            <Ionicons name={statusStyle.icon as any} size={14} color={statusStyle.text} />
            <Text style={[styles.statusText, { color: statusStyle.text }]}>{order.orderStatus}</Text>
          </View>
        </View>
        
        <View style={styles.divider} />
        
        <View style={styles.itemsList}>
          {Array.isArray(items) && items.slice(0, 3).map((item: any, idx: number) => (
            <Text key={idx} style={styles.itemText}>• {item.name} x{item.quantity}</Text>
          ))}
          {Array.isArray(items) && items.length > 3 && (
            <Text style={styles.moreItems}>+{items.length - 3} more items</Text>
          )}
        </View>
        
        <View style={styles.divider} />
        
        <View style={styles.orderFooter}>
          <View>
            <Text style={styles.paymentMethod}>{order.paymentMethod === 'COD' ? '💵 COD' : '💳 Paid'}</Text>
            <Text style={styles.paymentStatus}>{order.paymentStatus === 'paid' ? '✓ Paid' : 'Pending'}</Text>
          </View>
          <Text style={styles.orderTotal}>₹{order.total}</Text>
        </View>
        
        {order.trackingId && (
          <View style={styles.trackingInfo}>
            <Ionicons name="locate" size={16} color="#059669" />
            <Text style={styles.trackingText}>Tracking: {order.trackingId}</Text>
          </View>
        )}
      </View>
    );
  };

  if (!isLoggedIn) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#111" /></TouchableOpacity>
          <Text style={styles.title}>Track Order</Text>
          <View style={{ width: 24 }} />
        </View>
        
        <ScrollView style={styles.content} contentContainerStyle={styles.trackContainer}>
          <View style={styles.trackIcon}><Ionicons name="location" size={64} color="#059669" /></View>
          <Text style={styles.trackTitle}>Track Your Order</Text>
          <Text style={styles.trackDesc}>Enter your phone number and order ID to track your order</Text>
          
          <TextInput style={styles.input} placeholder="Phone Number" value={trackPhone} onChangeText={setTrackPhone} keyboardType="phone-pad" maxLength={10} placeholderTextColor="#9CA3AF" />
          <TextInput style={styles.input} placeholder="Order ID (e.g., EP-12345)" value={trackOrderId} onChangeText={setTrackOrderId} autoCapitalize="characters" placeholderTextColor="#9CA3AF" />
          
          <TouchableOpacity style={[styles.trackBtn, tracking && styles.trackBtnDisabled]} onPress={handleTrackOrder} disabled={tracking}>
            {tracking ? <ActivityIndicator color="#fff" /> : (<><Ionicons name="search" size={20} color="#fff" /><Text style={styles.trackBtnText}>Track Order</Text></>)}
          </TouchableOpacity>
          
          {trackedOrder && renderOrder(trackedOrder)}
          
          <View style={styles.loginPrompt}>
            <Text style={styles.loginText}>Want to see all your orders?</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}><Text style={styles.loginLink}>Login to your account</Text></TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.header}><TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#111" /></TouchableOpacity><Text style={styles.title}>My Orders</Text><View style={{ width: 24 }} /></View>
        <View style={styles.loadingContainer}><ActivityIndicator size="large" color="#059669" /><Text style={styles.loadingText}>Loading orders...</Text></View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="arrow-back" size={24} color="#111" /></TouchableOpacity>
        <Text style={styles.title}>My Orders</Text>
        <TouchableOpacity onPress={onRefresh}><Ionicons name="refresh" size={24} color="#059669" /></TouchableOpacity>
      </View>
      
      <ScrollView style={styles.content} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#059669']} />}>
        {orders.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="receipt-outline" size={80} color="#D1D5DB" />
            <Text style={styles.emptyTitle}>No orders yet</Text>
            <Text style={styles.emptyDesc}>Your order history will appear here</Text>
            <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Home')}><Text style={styles.shopBtnText}>Start Shopping</Text></TouchableOpacity>
          </View>
        ) : orders.map(renderOrder)}
        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 50, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  title: { fontSize: 18, fontWeight: 'bold', color: '#111' },
  content: { flex: 1, padding: 16 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { marginTop: 12, fontSize: 16, color: '#6B7280' },
  orderCard: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 16, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  orderId: { fontSize: 16, fontWeight: 'bold', color: '#111' },
  orderDate: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  statusBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, gap: 4 },
  statusText: { fontSize: 12, fontWeight: '600', textTransform: 'capitalize' },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 12 },
  itemsList: { gap: 4 },
  itemText: { fontSize: 14, color: '#374151' },
  moreItems: { fontSize: 12, color: '#6B7280', fontStyle: 'italic', marginTop: 4 },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  paymentMethod: { fontSize: 14, color: '#374151' },
  paymentStatus: { fontSize: 12, color: '#059669', marginTop: 2 },
  orderTotal: { fontSize: 20, fontWeight: 'bold', color: '#059669' },
  trackingInfo: { flexDirection: 'row', alignItems: 'center', marginTop: 12, padding: 10, backgroundColor: '#F0FDF4', borderRadius: 8, gap: 8 },
  trackingText: { fontSize: 14, color: '#059669', flex: 1 },
  trackContainer: { alignItems: 'center', padding: 20 },
  trackIcon: { marginVertical: 20 },
  trackTitle: { fontSize: 24, fontWeight: 'bold', color: '#111', marginBottom: 8 },
  trackDesc: { fontSize: 14, color: '#6B7280', textAlign: 'center', marginBottom: 24 },
  input: { width: '100%', backgroundColor: '#fff', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, padding: 14, fontSize: 16, marginBottom: 12, color: '#111' },
  trackBtn: { width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#059669', padding: 16, borderRadius: 10, marginTop: 8, gap: 8 },
  trackBtnDisabled: { opacity: 0.6 },
  trackBtnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  loginPrompt: { alignItems: 'center', marginTop: 40 },
  loginText: { fontSize: 14, color: '#6B7280' },
  loginLink: { fontSize: 14, color: '#059669', fontWeight: '600', marginTop: 4 },
  emptyContainer: { alignItems: 'center', paddingVertical: 60 },
  emptyTitle: { fontSize: 20, fontWeight: 'bold', color: '#374151', marginTop: 16 },
  emptyDesc: { fontSize: 14, color: '#6B7280', marginTop: 4 },
  shopBtn: { marginTop: 20, backgroundColor: '#059669', paddingHorizontal: 32, paddingVertical: 14, borderRadius: 10 },
  shopBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
