import React from 'react';
import { 
  View, Text, ScrollView, Image, TouchableOpacity, 
  StyleSheet, Alert 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../../context/CartContext';
import { getImageUrl } from '../../services/api';

export default function CartScreen({ navigation }: any) {
  const { items, totalAmount, updateQuantity, removeFromCart, clearCart } = useCart();

  const delivery = totalAmount >= 500 ? 0 : 50;
  const total = totalAmount + delivery;

  const handleClearCart = () => {
    Alert.alert(
      'Clear Cart',
      'Are you sure you want to remove all items?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Clear', style: 'destructive', onPress: clearCart }
      ]
    );
  };

  if (items.length === 0) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#111" />
          </TouchableOpacity>
          <Text style={styles.title}>Cart</Text>
          <View style={{ width: 24 }} />
        </View>
        
        <View style={styles.emptyContainer}>
          <Ionicons name="cart-outline" size={100} color="#D1D5DB" />
          <Text style={styles.emptyTitle}>Your cart is empty</Text>
          <Text style={styles.emptyDesc}>Add some organic products to get started</Text>
          <TouchableOpacity 
            style={styles.shopBtn}
            onPress={() => navigation.navigate('Home')}
          >
            <Ionicons name="leaf" size={20} color="#fff" />
            <Text style={styles.shopBtnText}>Start Shopping</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#111" />
        </TouchableOpacity>
        <Text style={styles.title}>Cart ({items.length} items)</Text>
        <TouchableOpacity onPress={handleClearCart}>
          <Ionicons name="trash-outline" size={24} color="#EF4444" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        {/* Cart Items */}
        {items.map(item => (
          <View key={item.product.id} style={styles.cartItem}>
            <Image 
              source={{ uri: getImageUrl(item.product.imageUrl) }} 
              style={styles.itemImage} 
              resizeMode="contain"
            />
            
            <View style={styles.itemInfo}>
              <Text style={styles.itemName} numberOfLines={2}>{item.product.nameEn}</Text>
              {item.product.weight && (
                <Text style={styles.itemWeight}>{item.product.weight}</Text>
              )}
              <View style={styles.priceRow}>
                <Text style={styles.itemPrice}>₹{item.product.price}</Text>
                {item.product.mrp > item.product.price && (
                  <Text style={styles.itemMrp}>₹{item.product.mrp}</Text>
                )}
              </View>
            </View>
            
            <View style={styles.quantityContainer}>
              <TouchableOpacity 
                style={styles.qtyBtn}
                onPress={() => updateQuantity(item.product.id, item.quantity - 1)}
              >
                <Ionicons 
                  name={item.quantity === 1 ? "trash-outline" : "remove"} 
                  size={18} 
                  color={item.quantity === 1 ? "#EF4444" : "#059669"} 
                />
              </TouchableOpacity>
              
              <Text style={styles.qtyText}>{item.quantity}</Text>
              
              <TouchableOpacity 
                style={styles.qtyBtn}
                onPress={() => updateQuantity(item.product.id, item.quantity + 1)}
              >
                <Ionicons name="add" size={18} color="#059669" />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.itemTotal}>₹{item.product.price * item.quantity}</Text>
          </View>
        ))}

        {/* Order Summary */}
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Order Summary</Text>
          
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Subtotal</Text>
            <Text style={styles.summaryValue}>₹{totalAmount}</Text>
          </View>
          
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Delivery</Text>
            <Text style={[styles.summaryValue, delivery === 0 && styles.freeDelivery]}>
              {delivery === 0 ? 'FREE' : `₹${delivery}`}
            </Text>
          </View>
          
          {totalAmount < 500 && (
            <View style={styles.freeDeliveryHint}>
              <Ionicons name="information-circle" size={16} color="#F59E0B" />
              <Text style={styles.hintText}>
                Add ₹{500 - totalAmount} more for FREE delivery!
              </Text>
            </View>
          )}
          
          <View style={styles.divider} />
          
          <View style={styles.summaryRow}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>₹{total}</Text>
          </View>
        </View>

        <View style={{ height: 120 }} />
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <View>
          <Text style={styles.footerLabel}>Total</Text>
          <Text style={styles.footerTotal}>₹{total}</Text>
        </View>
        <TouchableOpacity 
          style={styles.checkoutBtn}
          onPress={() => navigation.navigate('Checkout')}
        >
          <Text style={styles.checkoutText}>Checkout</Text>
          <Ionicons name="arrow-forward" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    padding: 16, 
    paddingTop: 50, 
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: { fontSize: 18, fontWeight: 'bold', color: '#111' },
  content: { flex: 1 },
  
  // Empty state
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  emptyTitle: { fontSize: 22, fontWeight: 'bold', color: '#374151', marginTop: 20 },
  emptyDesc: { fontSize: 14, color: '#6B7280', marginTop: 8, textAlign: 'center' },
  shopBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#059669', 
    paddingHorizontal: 32, 
    paddingVertical: 14, 
    borderRadius: 12,
    marginTop: 24,
    gap: 8,
  },
  shopBtnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  
  // Cart item
  cartItem: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#fff', 
    marginHorizontal: 12, 
    marginTop: 12, 
    padding: 12, 
    borderRadius: 12,
  },
  itemImage: { width: 60, height: 60, borderRadius: 8, backgroundColor: '#F9FAFB' },
  itemInfo: { flex: 1, marginLeft: 12 },
  itemName: { fontSize: 14, fontWeight: '600', color: '#111' },
  itemWeight: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4, gap: 6 },
  itemPrice: { fontSize: 14, fontWeight: 'bold', color: '#059669' },
  itemMrp: { fontSize: 12, color: '#9CA3AF', textDecorationLine: 'line-through' },
  quantityContainer: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#F3F4F6', 
    borderRadius: 8,
    marginHorizontal: 8,
  },
  qtyBtn: { padding: 8 },
  qtyText: { fontSize: 14, fontWeight: 'bold', color: '#111', paddingHorizontal: 8 },
  itemTotal: { fontSize: 14, fontWeight: 'bold', color: '#111', minWidth: 50, textAlign: 'right' },
  
  // Summary
  summaryCard: { 
    backgroundColor: '#fff', 
    margin: 12, 
    padding: 16, 
    borderRadius: 12,
  },
  summaryTitle: { fontSize: 16, fontWeight: 'bold', color: '#111', marginBottom: 12 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryLabel: { fontSize: 14, color: '#6B7280' },
  summaryValue: { fontSize: 14, color: '#111' },
  freeDelivery: { color: '#059669', fontWeight: '600' },
  freeDeliveryHint: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#FEF3C7', 
    padding: 10, 
    borderRadius: 8, 
    marginVertical: 8,
    gap: 8,
  },
  hintText: { fontSize: 12, color: '#F59E0B', flex: 1 },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 12 },
  totalLabel: { fontSize: 16, fontWeight: 'bold', color: '#111' },
  totalValue: { fontSize: 20, fontWeight: 'bold', color: '#059669' },
  
  // Footer
  footer: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    backgroundColor: '#fff', 
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  footerLabel: { fontSize: 12, color: '#6B7280' },
  footerTotal: { fontSize: 22, fontWeight: 'bold', color: '#059669' },
  checkoutBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#059669', 
    paddingHorizontal: 28, 
    paddingVertical: 14, 
    borderRadius: 12,
    gap: 8,
  },
  checkoutText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
