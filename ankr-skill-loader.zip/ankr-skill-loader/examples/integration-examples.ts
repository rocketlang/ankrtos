/**
 * ANKR Skill Integration Examples
 * 
 * Shows how to integrate skills with your existing AI Proxy (17 providers)
 */

// ============================================================================
// EXAMPLE 1: Basic Integration with AI Proxy
// ============================================================================

import { createSkillAwareProxy, chatWithSkills } from '@ankr/skill-loader';
import { AIProxy } from '@ankr/ai-proxy';  // Your existing proxy

// Initialize your existing AI Proxy
const aiProxy = new AIProxy({
  providers: ['groq', 'ollama', 'longcat', 'deepseek', 'openrouter', /* ... 17 total */],
  defaultProvider: 'groq',
  fallbackChain: ['groq', 'ollama', 'deepseek'],
  preferFreeTier: true,
});

// Wrap with skill awareness
const skillProxy = createSkillAwareProxy(aiProxy, {
  skillsPath: '.claude/skills',  // Where skills are stored
  maxTokens: 8000,
  cache: true,
});

// Use it!
async function example1() {
  // Auto-detects relevant skills based on query
  const response = await skillProxy.chat(
    'Create a driver-management module with CRUD operations'
  );
  
  console.log('Response:', response.content);
  console.log('Provider used:', response.provider);  // e.g., 'groq'
  console.log('Cost:', response.cost);  // e.g., 0 (free tier)
}


// ============================================================================
// EXAMPLE 2: Specify Skills Manually
// ============================================================================

async function example2() {
  // Force specific skills
  const response = await skillProxy.chat(
    'How do I record an episode in the memory system?',
    {
      skills: ['ankr-eon-memory'],  // Only use memory skill
      provider: 'deepseek',  // Force DeepSeek
    }
  );
  
  console.log(response.content);
}


// ============================================================================
// EXAMPLE 3: Hindi Voice Query
// ============================================================================

async function example3() {
  const response = await skillProxy.chat(
    'मुझे मुंबई के delayed shipments बताओ',  // "Tell me about Mumbai's delayed shipments"
    {
      autoDetect: true,  // Will detect: logistics-rag, voice-hindi
      language: 'hi',    // Routes to LongCat (best for Hindi)
    }
  );
  
  console.log(response.content);
  console.log('Provider:', response.provider);  // 'longcat'
}


// ============================================================================
// EXAMPLE 4: NestJS Integration
// ============================================================================

import { Controller, Post, Body, Inject } from '@nestjs/common';
import { SkillService, createSkillModule } from '@ankr/skill-loader/middleware';

// In your app.module.ts
// imports: [createSkillModule(aiProxy, '.claude/skills')]

@Controller('ai')
class AIController {
  constructor(
    @Inject('SKILL_SERVICE') private skills: SkillService
  ) {}

  @Post('query')
  async query(@Body() body: { query: string; language?: string }) {
    const response = await this.skills.chat(body.query, {
      autoDetect: true,
      language: body.language,
    });
    
    return {
      answer: response.content,
      provider: response.provider,
      cost: response.cost,
    };
  }

  @Post('code')
  async generateCode(@Body() body: { description: string }) {
    // Force TMS dev skill for code generation
    const response = await this.skills.chat(body.description, {
      skills: ['ankr-tms-dev'],
      provider: 'deepseek',  // Best for coding
    });
    
    return { code: response.content };
  }
}


// ============================================================================
// EXAMPLE 5: Express REST API
// ============================================================================

import express from 'express';
import { skillMiddleware } from '@ankr/skill-loader/middleware';

const app = express();
app.use(express.json());

// Add skill middleware
app.use(skillMiddleware({
  aiProxy,
  skillsPath: '.claude/skills',
  autoDetect: true,
}));

// Now every route has access to req.chatWithSkills
app.post('/api/chat', async (req, res) => {
  const { query, skills, language } = req.body;
  
  const response = await req.chatWithSkills(query, skills);
  
  res.json({
    answer: response.content,
    provider: response.provider,
  });
});

// Specific endpoint for logistics queries
app.post('/api/logistics/query', async (req, res) => {
  const response = await req.skillProxy.chat(req.body.query, {
    skills: ['ankr-logistics-rag', 'ankr-tms-dev'],
  });
  
  res.json(response);
});


// ============================================================================
// EXAMPLE 6: Voice Integration (SUNOKAHOBOLO)
// ============================================================================

import { createVoiceSkillHandler } from '@ankr/skill-loader/voice';

const voiceHandler = createVoiceSkillHandler({
  aiProxy,
  sttProvider: whisperClient,      // Your STT provider
  ttsProvider: chatterboxClient,   // Your TTS provider
  skillsPath: '.claude/skills',
  defaultLanguage: 'hi',
});

// Handle voice request
app.post('/api/voice', async (req, res) => {
  const response = await voiceHandler.handle({
    audio: req.body.audio,
    language: req.body.language || 'hi',
    userId: req.body.userId,
    sessionId: req.body.sessionId,
  });
  
  res.json({
    text: response.text,
    audio: response.audio?.toString('base64'),
    language: response.language,
    skillsUsed: response.skillsUsed,
    processingTime: response.processingTime,
  });
});

// Driver voice commands
app.post('/api/voice/driver', async (req, res) => {
  const { command, language, driverId } = req.body;
  
  const response = await voiceHandler.handleDriverCommand(
    command,
    language,
    driverId
  );
  
  res.json({ response });
});


// ============================================================================
// EXAMPLE 7: Streaming Response
// ============================================================================

app.get('/api/chat/stream', async (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  
  const stream = skillProxy.chatStream(req.query.q as string, {
    autoDetect: true,
  });
  
  for await (const chunk of stream) {
    res.write(`data: ${JSON.stringify({ text: chunk })}\n\n`);
  }
  
  res.write('data: [DONE]\n\n');
  res.end();
});


// ============================================================================
// EXAMPLE 8: Customer Care Bot
// ============================================================================

class CustomerCareBot {
  constructor(private proxy: typeof skillProxy) {}

  async handleQuery(
    message: string,
    customerId: string,
    language: string = 'en'
  ) {
    // Use customer care agent + RAG skill
    const response = await this.proxy.chat(message, {
      skills: ['ankr-logistics-rag'],
      language,
    });

    // Log to ankr-eon for learning
    await this.logInteraction(message, response.content, customerId);

    return response.content;
  }

  async handleComplaint(
    complaint: string,
    shipmentId: string,
    language: string
  ) {
    const query = `
      Customer complaint about shipment ${shipmentId}:
      "${complaint}"
      
      Provide empathetic response and resolution steps.
    `;

    return this.proxy.chat(query, {
      skills: ['ankr-logistics-rag', 'ankr-voice-hindi'],
      language,
    });
  }

  private async logInteraction(query: string, response: string, customerId: string) {
    // Log to ankr-eon memory system
    // This helps the system learn from interactions
  }
}


// ============================================================================
// EXAMPLE 9: Cost Monitoring
// ============================================================================

class CostMonitor {
  private dailyCost = 0;
  private maxDailyCost = 1.0;  // $1/day limit
  
  async chat(query: string, options?: any) {
    if (this.dailyCost >= this.maxDailyCost) {
      // Force free providers only
      options = { ...options, provider: 'groq' };
    }
    
    const response = await skillProxy.chat(query, options);
    
    this.dailyCost += response.cost;
    
    if (this.dailyCost > this.maxDailyCost * 0.8) {
      console.warn('⚠️ Approaching daily cost limit');
    }
    
    return response;
  }
  
  getStats() {
    return {
      dailyCost: this.dailyCost,
      remaining: this.maxDailyCost - this.dailyCost,
      percentUsed: (this.dailyCost / this.maxDailyCost) * 100,
    };
  }
}


// ============================================================================
// EXAMPLE 10: Hybrid Usage (Claude Code + AI Proxy)
// ============================================================================

/**
 * HYBRID APPROACH SUMMARY
 * 
 * Complex Tasks → Claude Code + Max Subscription
 * - Architecture decisions
 * - Complex refactoring
 * - Multi-file code generation
 * - Debugging sessions
 * 
 * Simple Tasks → AI Proxy + Skills
 * - API queries
 * - Voice commands
 * - Customer support
 * - Quick lookups
 * - Document search
 * 
 * Both read from same .claude/skills/ directory!
 */

// For simple tasks (cost: ~$0)
async function simpleQuery() {
  return skillProxy.chat('What carriers are available in Mumbai?', {
    skills: ['ankr-logistics-rag'],
    provider: 'groq',  // Free
  });
}

// For complex tasks, use Claude Code in terminal:
// $ cd ~/ankr-labs-nx
// $ claude
// > "Refactor the shipment module to use the new carrier rating system"
// (Uses Max subscription - no extra cost)
