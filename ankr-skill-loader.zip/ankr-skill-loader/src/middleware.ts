/**
 * @ankr/skill-loader/middleware
 * 
 * Express/Fastify middleware for skill-enhanced API endpoints
 */

import { SkillLoader, SkillAwareProxy } from './index';

// ============================================================================
// EXPRESS MIDDLEWARE
// ============================================================================

export interface SkillMiddlewareOptions {
  aiProxy: any;
  skillsPath?: string;
  defaultSkills?: string[];
  autoDetect?: boolean;
}

/**
 * Express middleware that adds skill-aware proxy to request
 */
export function skillMiddleware(options: SkillMiddlewareOptions) {
  const { aiProxy, skillsPath, defaultSkills, autoDetect = true } = options;
  
  const proxy = new SkillAwareProxy(aiProxy, { skillsPath });

  return (req: any, res: any, next: any) => {
    // Attach skill-aware proxy to request
    req.skillProxy = proxy;
    req.skillLoader = proxy.getSkillLoader();
    
    // Add helper method
    req.chatWithSkills = async (query: string, skills?: string[]) => {
      return proxy.chat(query, {
        skills: skills || defaultSkills,
        autoDetect
      });
    };

    next();
  };
}

// ============================================================================
// FASTIFY PLUGIN
// ============================================================================

/**
 * Fastify plugin for skill-aware AI proxy
 */
export async function skillPlugin(fastify: any, options: SkillMiddlewareOptions) {
  const { aiProxy, skillsPath, defaultSkills, autoDetect = true } = options;
  
  const proxy = new SkillAwareProxy(aiProxy, { skillsPath });

  // Decorate fastify instance
  fastify.decorate('skillProxy', proxy);
  fastify.decorate('skillLoader', proxy.getSkillLoader());

  // Decorate request
  fastify.decorateRequest('chatWithSkills', null);

  fastify.addHook('preHandler', async (request: any) => {
    request.chatWithSkills = async (query: string, skills?: string[]) => {
      return proxy.chat(query, {
        skills: skills || defaultSkills,
        autoDetect
      });
    };
  });
}

// ============================================================================
// NESTJS INTEGRATION
// ============================================================================

/**
 * NestJS Injectable Service
 */
export class SkillService {
  private proxy: SkillAwareProxy;
  private loader: SkillLoader;

  constructor(aiProxy: any, skillsPath?: string) {
    this.loader = new SkillLoader({ skillsPath });
    this.proxy = new SkillAwareProxy(aiProxy, { skillsPath });
  }

  async chat(query: string, options?: {
    skills?: string[];
    autoDetect?: boolean;
    provider?: string;
    language?: string;
  }) {
    return this.proxy.chat(query, options);
  }

  async chatWithHistory(
    messages: Array<{ role: string; content: string }>,
    options?: {
      skills?: string[];
      autoDetect?: boolean;
      provider?: string;
    }
  ) {
    return this.proxy.chatWithHistory(messages, options);
  }

  loadSkill(name: string) {
    return this.loader.load(name);
  }

  loadSkills(names: string[]) {
    return this.loader.loadMultiple(names);
  }

  detectSkills(query: string) {
    return this.loader.autoDetect(query);
  }

  listSkills() {
    return this.loader.listSkills();
  }
}

/**
 * NestJS Module factory
 */
export function createSkillModule(aiProxy: any, skillsPath?: string) {
  return {
    module: class SkillModule {},
    providers: [
      {
        provide: 'SKILL_SERVICE',
        useFactory: () => new SkillService(aiProxy, skillsPath)
      }
    ],
    exports: ['SKILL_SERVICE']
  };
}
