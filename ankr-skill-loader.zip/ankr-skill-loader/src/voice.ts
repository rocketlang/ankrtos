/**
 * @ankr/skill-loader/voice
 * 
 * Voice integration for skill-enhanced AI
 * Works with SUNOKAHOBOLO gateway
 */

import { SkillAwareProxy } from './index';

// ============================================================================
// TYPES
// ============================================================================

export interface VoiceRequest {
  audio?: Buffer;
  text?: string;  // Pre-transcribed text
  language: string;
  userId: string;
  sessionId: string;
  context?: Record<string, unknown>;
}

export interface VoiceResponse {
  text: string;
  audio?: Buffer;
  language: string;
  skillsUsed: string[];
  provider: string;
  processingTime: number;
}

export interface VoiceSkillsOptions {
  aiProxy: any;
  sttProvider?: any;  // Speech-to-text provider
  ttsProvider?: any;  // Text-to-speech provider
  skillsPath?: string;
  defaultLanguage?: string;
}

// ============================================================================
// VOICE HANDLER
// ============================================================================

export class VoiceSkillHandler {
  private proxy: SkillAwareProxy;
  private stt: any;
  private tts: any;
  private defaultLanguage: string;

  // Voice command patterns per language
  private static VOICE_PATTERNS: Record<string, Record<string, string>> = {
    hi: {
      'शिपमेंट कहां है': 'track_shipment',
      'आज का रूट': 'get_route',
      'कितनी दूर': 'get_distance',
      'पहुंच गया': 'mark_arrived',
      'मदद चाहिए': 'request_help',
      'गाड़ी खराब': 'report_breakdown',
    },
    ta: {
      'ஷிப்மென்ட் எங்கே': 'track_shipment',
      'இன்றைய ரூட்': 'get_route',
      'எவ்வளவு தூரம்': 'get_distance',
      'வந்துட்டேன்': 'mark_arrived',
    },
    te: {
      'షిప్మెంట్ ఎక్కడ': 'track_shipment',
      'ఈ రోజు రూట్': 'get_route',
      'ఎంత దూరం': 'get_distance',
      'చేరుకున్నాను': 'mark_arrived',
    }
  };

  constructor(options: VoiceSkillsOptions) {
    this.proxy = new SkillAwareProxy(options.aiProxy, {
      skillsPath: options.skillsPath
    });
    this.stt = options.sttProvider;
    this.tts = options.ttsProvider;
    this.defaultLanguage = options.defaultLanguage || 'en';
  }

  /**
   * Handle voice request with skill injection
   */
  async handle(request: VoiceRequest): Promise<VoiceResponse> {
    const startTime = Date.now();
    
    // Get text (transcribe if needed)
    let text = request.text;
    if (!text && request.audio && this.stt) {
      text = await this.stt.transcribe(request.audio, request.language);
    }

    if (!text) {
      throw new Error('No text or audio provided');
    }

    // Detect intent from voice pattern
    const intent = this.detectIntent(text, request.language);

    // Determine skills based on intent
    const skills = this.getSkillsForIntent(intent);

    // Call AI with skills
    const response = await this.proxy.chat(text, {
      skills,
      language: request.language,
      autoDetect: skills.length === 0
    });

    // Generate audio response if TTS available
    let audioResponse: Buffer | undefined;
    if (this.tts) {
      audioResponse = await this.tts.synthesize(
        response.content,
        request.language
      );
    }

    return {
      text: response.content,
      audio: audioResponse,
      language: request.language,
      skillsUsed: skills,
      provider: response.provider,
      processingTime: Date.now() - startTime
    };
  }

  /**
   * Handle streaming voice response
   */
  async *handleStream(request: VoiceRequest): AsyncGenerator<{
    type: 'text' | 'audio';
    data: string | Buffer;
  }> {
    let text = request.text;
    if (!text && request.audio && this.stt) {
      text = await this.stt.transcribe(request.audio, request.language);
    }

    if (!text) {
      throw new Error('No text or audio provided');
    }

    const intent = this.detectIntent(text, request.language);
    const skills = this.getSkillsForIntent(intent);

    // Stream text response
    const stream = this.proxy.chatStream(text, {
      skills,
      language: request.language
    });

    let fullText = '';
    for await (const chunk of stream) {
      fullText += chunk;
      yield { type: 'text', data: chunk };
    }

    // Generate audio at the end
    if (this.tts) {
      const audio = await this.tts.synthesize(fullText, request.language);
      yield { type: 'audio', data: audio };
    }
  }

  /**
   * Quick response for common driver commands
   */
  async handleDriverCommand(
    command: string,
    language: string,
    driverId: string
  ): Promise<string> {
    const intent = this.detectIntent(command, language);

    // Use voice skill for driver commands
    const response = await this.proxy.chat(command, {
      skills: ['ankr-voice-hindi', 'ankr-tms-dev'],
      language
    });

    return response.content;
  }

  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------

  private detectIntent(text: string, language: string): string {
    const patterns = VoiceSkillHandler.VOICE_PATTERNS[language] || {};
    
    for (const [pattern, intent] of Object.entries(patterns)) {
      if (text.includes(pattern)) {
        return intent;
      }
    }

    // Fuzzy match for partial matches
    const textLower = text.toLowerCase();
    
    if (/track|where|status|कहां|எங்கே|ఎక్కడ/.test(textLower)) {
      return 'track_shipment';
    }
    if (/route|रूट|ரூட்|రూట్/.test(textLower)) {
      return 'get_route';
    }
    if (/help|मदद|உதவி|సహాయం/.test(textLower)) {
      return 'request_help';
    }

    return 'general_query';
  }

  private getSkillsForIntent(intent: string): string[] {
    const intentSkillMap: Record<string, string[]> = {
      'track_shipment': ['ankr-tms-dev', 'ankr-logistics-rag'],
      'get_route': ['ankr-tms-dev'],
      'get_distance': ['ankr-tms-dev'],
      'mark_arrived': ['ankr-tms-dev', 'ankr-eon-memory'],
      'request_help': ['ankr-voice-hindi'],
      'report_breakdown': ['ankr-voice-hindi', 'ankr-tms-dev'],
      'general_query': ['ankr-logistics-rag']
    };

    return intentSkillMap[intent] || [];
  }
}

// ============================================================================
// FACTORY
// ============================================================================

export function createVoiceSkillHandler(options: VoiceSkillsOptions): VoiceSkillHandler {
  return new VoiceSkillHandler(options);
}
