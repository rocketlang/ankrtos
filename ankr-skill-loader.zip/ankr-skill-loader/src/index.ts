/**
 * @ankr/skill-loader
 * 
 * Skill integration for AI Proxy - enables all 17 providers to use ANKR skills
 * 
 * Part of the Hybrid Approach:
 * - Claude Code + Max: Complex tasks (coding, architecture)
 * - AI Proxy + Skills: Simple tasks (queries, voice, customer care)
 */

import { readFileSync, readdirSync, existsSync } from 'fs';
import { join } from 'path';
import { createHash } from 'crypto';

// ============================================================================
// TYPES
// ============================================================================

export interface Skill {
  name: string;
  description: string;
  content: string;
  tokens: number;  // Approximate token count
  triggers: string[];  // Keywords that activate this skill
}

export interface SkillLoaderOptions {
  skillsPath?: string;
  maxTokens?: number;  // Max tokens for combined skills
  cache?: boolean;
  autoCompress?: boolean;  // Compress skills if over token limit
}

export interface ChatWithSkillsOptions {
  skills?: string[];  // Specific skills to use
  autoDetect?: boolean;  // Auto-detect skills from query
  provider?: string;  // Force specific provider
  maxCost?: number;  // Max cost for this request
  language?: string;  // For voice/multilingual routing
}

export interface AIProxyRequest {
  messages: Array<{ role: string; content: string }>;
  provider?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
}

export interface AIProxyResponse {
  content: string;
  provider: string;
  model: string;
  cost: number;
  tokens: { input: number; output: number; total: number };
  cached: boolean;
}

// ============================================================================
// SKILL LOADER CLASS
// ============================================================================

export class SkillLoader {
  private skillsPath: string;
  private cache: Map<string, Skill> = new Map();
  private options: SkillLoaderOptions;

  // Skill trigger patterns for auto-detection
  private static SKILL_TRIGGERS: Record<string, string[]> = {
    'ankr-tms-dev': [
      'module', 'service', 'controller', 'nestjs', 'prisma', 'dto',
      'crud', 'api', 'endpoint', 'swagger', 'zod', 'validation',
      'shipment', 'carrier', 'route', 'driver', 'vehicle', 'tms', 'wms', 'oms'
    ],
    'ankr-eon-memory': [
      'memory', 'episode', 'semantic', 'pattern', 'learn', 'remember',
      'pgvector', 'embedding', 'consolidation', 'cross-module', 'eon'
    ],
    'ankr-voice-hindi': [
      'voice', 'hindi', 'tamil', 'telugu', 'speak', 'audio', 'stt', 'tts',
      'sunokahobolo', 'driver command', 'multilingual', 'भाषा', 'आवाज'
    ],
    'ankr-llmbox': [
      'llm', 'provider', 'groq', 'deepseek', 'ollama', 'longcat',
      'cost', 'free tier', 'fallback', 'routing', 'cascade'
    ],
    'ankr-logistics-rag': [
      'search', 'rag', 'retrieve', 'document', 'query', 'semantic search',
      'hybrid search', 'vector', 'knowledge', 'context'
    ]
  };

  constructor(options: SkillLoaderOptions = {}) {
    this.skillsPath = options.skillsPath || '.claude/skills';
    this.options = {
      maxTokens: 8000,  // Default max tokens for skills
      cache: true,
      autoCompress: true,
      ...options
    };
  }

  /**
   * Load a single skill by name
   */
  load(skillName: string): Skill | null {
    // Check cache
    if (this.options.cache && this.cache.has(skillName)) {
      return this.cache.get(skillName)!;
    }

    const skillPath = join(this.skillsPath, skillName, 'SKILL.md');
    
    if (!existsSync(skillPath)) {
      console.warn(`Skill not found: ${skillName}`);
      return null;
    }

    const content = readFileSync(skillPath, 'utf-8');
    const { name, description } = this.parseSkillMetadata(content);

    const skill: Skill = {
      name: name || skillName,
      description: description || '',
      content,
      tokens: this.estimateTokens(content),
      triggers: SkillLoader.SKILL_TRIGGERS[skillName] || []
    };

    if (this.options.cache) {
      this.cache.set(skillName, skill);
    }

    return skill;
  }

  /**
   * Load multiple skills and combine them
   */
  loadMultiple(skillNames: string[]): string {
    const skills = skillNames
      .map(name => this.load(name))
      .filter((s): s is Skill => s !== null);

    if (skills.length === 0) {
      return '';
    }

    // Check total tokens
    const totalTokens = skills.reduce((sum, s) => sum + s.tokens, 0);

    if (this.options.autoCompress && totalTokens > this.options.maxTokens!) {
      return this.compressSkills(skills, this.options.maxTokens!);
    }

    return skills.map(s => s.content).join('\n\n---\n\n');
  }

  /**
   * Auto-detect relevant skills based on query
   */
  autoDetect(query: string): string[] {
    const queryLower = query.toLowerCase();
    const scores: Record<string, number> = {};

    // Score each skill based on trigger matches
    for (const [skillName, triggers] of Object.entries(SkillLoader.SKILL_TRIGGERS)) {
      scores[skillName] = 0;
      for (const trigger of triggers) {
        if (queryLower.includes(trigger.toLowerCase())) {
          scores[skillName]++;
        }
      }
    }

    // Sort by score and filter skills with score > 0
    const detected = Object.entries(scores)
      .filter(([_, score]) => score > 0)
      .sort((a, b) => b[1] - a[1])
      .map(([name]) => name);

    // Always return at least one skill
    return detected.length > 0 ? detected : ['ankr-tms-dev'];
  }

  /**
   * List all available skills
   */
  listSkills(): string[] {
    if (!existsSync(this.skillsPath)) {
      return [];
    }

    return readdirSync(this.skillsPath, { withFileTypes: true })
      .filter(dirent => dirent.isDirectory())
      .filter(dirent => existsSync(join(this.skillsPath, dirent.name, 'SKILL.md')))
      .map(dirent => dirent.name);
  }

  /**
   * Get skill info without loading full content
   */
  getSkillInfo(skillName: string): { name: string; description: string } | null {
    const skill = this.load(skillName);
    if (!skill) return null;
    return { name: skill.name, description: skill.description };
  }

  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------

  private parseSkillMetadata(content: string): { name?: string; description?: string } {
    const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
    if (!frontmatterMatch) return {};

    const frontmatter = frontmatterMatch[1];
    const nameMatch = frontmatter.match(/name:\s*(.+)/);
    const descMatch = frontmatter.match(/description:\s*["']?([^"'\n]+)["']?/);

    return {
      name: nameMatch?.[1]?.trim(),
      description: descMatch?.[1]?.trim()
    };
  }

  private estimateTokens(text: string): number {
    // Rough estimation: ~4 chars per token
    return Math.ceil(text.length / 4);
  }

  private compressSkills(skills: Skill[], maxTokens: number): string {
    // Prioritize skills by relevance (first ones are most relevant)
    const compressed: string[] = [];
    let currentTokens = 0;

    for (const skill of skills) {
      if (currentTokens + skill.tokens <= maxTokens) {
        compressed.push(skill.content);
        currentTokens += skill.tokens;
      } else {
        // Extract only the essential sections
        const essential = this.extractEssentials(skill.content);
        const essentialTokens = this.estimateTokens(essential);
        
        if (currentTokens + essentialTokens <= maxTokens) {
          compressed.push(essential);
          currentTokens += essentialTokens;
        }
      }
    }

    return compressed.join('\n\n---\n\n');
  }

  private extractEssentials(content: string): string {
    // Keep frontmatter, overview, and key sections
    const sections = content.split(/\n##\s+/);
    const essential = [sections[0]]; // Keep intro

    const prioritySections = ['overview', 'when to use', 'usage', 'example'];
    
    for (const section of sections.slice(1)) {
      const sectionLower = section.toLowerCase();
      if (prioritySections.some(p => sectionLower.startsWith(p))) {
        essential.push('## ' + section);
      }
    }

    return essential.join('\n\n');
  }
}

// ============================================================================
// SKILL-AWARE AI PROXY WRAPPER
// ============================================================================

export class SkillAwareProxy {
  private loader: SkillLoader;
  private aiProxy: any;  // Your existing AI proxy instance
  private responseCache: Map<string, AIProxyResponse> = new Map();

  constructor(aiProxy: any, loaderOptions?: SkillLoaderOptions) {
    this.aiProxy = aiProxy;
    this.loader = new SkillLoader(loaderOptions);
  }

  /**
   * Chat with automatic skill injection
   */
  async chat(
    query: string,
    options: ChatWithSkillsOptions = {}
  ): Promise<AIProxyResponse> {
    const {
      skills,
      autoDetect = true,
      provider,
      maxCost,
      language
    } = options;

    // Determine which skills to use
    let skillNames: string[];
    if (skills && skills.length > 0) {
      skillNames = skills;
    } else if (autoDetect) {
      skillNames = this.loader.autoDetect(query);
    } else {
      skillNames = [];
    }

    // Load and combine skills
    const skillContent = skillNames.length > 0
      ? this.loader.loadMultiple(skillNames)
      : '';

    // Build system prompt
    const systemPrompt = this.buildSystemPrompt(skillContent, language);

    // Check cache
    const cacheKey = this.getCacheKey(query, skillNames, provider);
    if (this.responseCache.has(cacheKey)) {
      const cached = this.responseCache.get(cacheKey)!;
      return { ...cached, cached: true };
    }

    // Call AI Proxy
    const response = await this.aiProxy.chat({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: query }
      ],
      provider: provider || this.selectProvider(query, language, maxCost),
      maxCost
    });

    // Cache response
    this.responseCache.set(cacheKey, { ...response, cached: false });

    return response;
  }

  /**
   * Chat with conversation history
   */
  async chatWithHistory(
    messages: Array<{ role: string; content: string }>,
    options: ChatWithSkillsOptions = {}
  ): Promise<AIProxyResponse> {
    const { skills, autoDetect = true, provider, maxCost, language } = options;

    // Get query from last user message
    const lastUserMessage = messages.filter(m => m.role === 'user').pop();
    const query = lastUserMessage?.content || '';

    // Determine skills
    let skillNames: string[];
    if (skills && skills.length > 0) {
      skillNames = skills;
    } else if (autoDetect) {
      skillNames = this.loader.autoDetect(query);
    } else {
      skillNames = [];
    }

    const skillContent = skillNames.length > 0
      ? this.loader.loadMultiple(skillNames)
      : '';

    const systemPrompt = this.buildSystemPrompt(skillContent, language);

    return this.aiProxy.chat({
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages
      ],
      provider: provider || this.selectProvider(query, language, maxCost),
      maxCost
    });
  }

  /**
   * Stream chat with skills
   */
  async *chatStream(
    query: string,
    options: ChatWithSkillsOptions = {}
  ): AsyncGenerator<string> {
    const { skills, autoDetect = true, provider, language } = options;

    let skillNames: string[];
    if (skills && skills.length > 0) {
      skillNames = skills;
    } else if (autoDetect) {
      skillNames = this.loader.autoDetect(query);
    } else {
      skillNames = [];
    }

    const skillContent = skillNames.length > 0
      ? this.loader.loadMultiple(skillNames)
      : '';

    const systemPrompt = this.buildSystemPrompt(skillContent, language);

    const stream = await this.aiProxy.chatStream({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: query }
      ],
      provider: provider || this.selectProvider(query, language),
      stream: true
    });

    for await (const chunk of stream) {
      yield chunk;
    }
  }

  /**
   * Get loaded skill info
   */
  getSkillLoader(): SkillLoader {
    return this.loader;
  }

  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------

  private buildSystemPrompt(skillContent: string, language?: string): string {
    let prompt = '';

    if (skillContent) {
      prompt += skillContent + '\n\n';
    }

    // Add language instruction if specified
    if (language && language !== 'en') {
      const langNames: Record<string, string> = {
        hi: 'Hindi',
        ta: 'Tamil',
        te: 'Telugu',
        bn: 'Bengali'
      };
      prompt += `\nRespond in ${langNames[language] || language} when appropriate.\n`;
    }

    // Add ANKR context
    prompt += `
You are an AI assistant for ANKR Labs, a logistics technology company.
Follow the patterns and guidelines from the skills above.
Be concise, practical, and cost-conscious in your responses.
`;

    return prompt.trim();
  }

  private selectProvider(query: string, language?: string, maxCost?: number): string {
    // Language-based routing
    if (language && ['hi', 'ta', 'te', 'bn'].includes(language)) {
      return 'longcat';  // Best for Indic languages
    }

    // Cost-based routing
    if (maxCost !== undefined && maxCost < 0.001) {
      return 'groq';  // Free tier
    }

    // Query-based routing
    const queryLower = query.toLowerCase();
    
    if (/code|function|class|implement/i.test(queryLower)) {
      return 'deepseek';  // Good for coding
    }

    // Default to fast free provider
    return 'groq';
  }

  private getCacheKey(query: string, skills: string[], provider?: string): string {
    const data = JSON.stringify({ query, skills, provider });
    return createHash('md5').update(data).digest('hex');
  }
}

// ============================================================================
// FACTORY FUNCTION
// ============================================================================

/**
 * Create a skill-aware AI proxy wrapper
 */
export function createSkillAwareProxy(
  aiProxy: any,
  options?: SkillLoaderOptions
): SkillAwareProxy {
  return new SkillAwareProxy(aiProxy, options);
}

/**
 * Quick helper for one-off skill-enhanced queries
 */
export async function chatWithSkills(
  aiProxy: any,
  query: string,
  options?: ChatWithSkillsOptions & SkillLoaderOptions
): Promise<AIProxyResponse> {
  const proxy = new SkillAwareProxy(aiProxy, options);
  return proxy.chat(query, options);
}

// ============================================================================
// EXPORTS
// ============================================================================

export default {
  SkillLoader,
  SkillAwareProxy,
  createSkillAwareProxy,
  chatWithSkills
};
