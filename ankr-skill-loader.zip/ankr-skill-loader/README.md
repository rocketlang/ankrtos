# @ankr/skill-loader

Skill integration for AI Proxy - enables all 17 providers to use ANKR skills.

## The Hybrid Approach

```
┌─────────────────────────────────────────────────────────────────┐
│                    HYBRID SKILL USAGE                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  COMPLEX TASKS (coding, architecture)                           │
│    → Claude Code + Max subscription                             │
│    → Skills auto-loaded from .claude/skills/                    │
│    → Zero extra cost (uses Max quota)                           │
│                                                                  │
│  SIMPLE TASKS (queries, voice, support)                         │
│    → AI Proxy + Skill injection                                 │
│    → Routes to Groq/DeepSeek/LongCat                           │
│    → Near-zero cost ($0.00 - $0.01)                            │
│                                                                  │
│  SAME SKILLS, TWO RUNTIMES                                      │
│    → .claude/skills/ is the single source of truth             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Installation

```bash
pnpm add @ankr/skill-loader
```

## Quick Start

```typescript
import { createSkillAwareProxy } from '@ankr/skill-loader';
import { AIProxy } from '@ankr/ai-proxy';

// Your existing 17-provider proxy
const aiProxy = new AIProxy({ /* your config */ });

// Wrap with skill awareness
const skillProxy = createSkillAwareProxy(aiProxy, {
  skillsPath: '.claude/skills',
});

// Auto-detects and injects relevant skills
const response = await skillProxy.chat(
  'Create a shipment tracking module'
);

console.log(response.content);   // Generated code
console.log(response.provider);  // 'groq' (free)
console.log(response.cost);      // 0
```

## Features

### 🎯 Auto-Detection
Automatically detects which skills are relevant based on query content.

```typescript
const response = await skillProxy.chat(
  'How do I record memory episodes?'
);
// Auto-detects: ['ankr-eon-memory']
```

### 🌐 Language Routing
Routes to best provider based on language.

```typescript
const response = await skillProxy.chat(
  'मुझे शिपमेंट की जानकारी दो',  // Hindi
  { language: 'hi' }
);
// Routes to: LongCat (best for Indic languages)
```

### 💰 Cost Control
Enforce cost limits per request.

```typescript
const response = await skillProxy.chat(query, {
  maxCost: 0.001,  // Max $0.001
});
// Automatically uses free-tier providers
```

### 🔊 Voice Integration
Works with SUNOKAHOBOLO for voice-first interfaces.

```typescript
import { createVoiceSkillHandler } from '@ankr/skill-loader/voice';

const voice = createVoiceSkillHandler({
  aiProxy,
  sttProvider: whisper,
  ttsProvider: chatterbox,
});

const response = await voice.handle({
  audio: audioBuffer,
  language: 'hi',
  userId: 'driver-123',
});
```

## Middleware

### Express

```typescript
import { skillMiddleware } from '@ankr/skill-loader/middleware';

app.use(skillMiddleware({ aiProxy }));

app.post('/chat', async (req, res) => {
  const response = await req.chatWithSkills(req.body.query);
  res.json(response);
});
```

### NestJS

```typescript
import { createSkillModule, SkillService } from '@ankr/skill-loader/middleware';

@Module({
  imports: [createSkillModule(aiProxy)],
})
export class AppModule {}

@Controller('ai')
export class AIController {
  constructor(@Inject('SKILL_SERVICE') private skills: SkillService) {}

  @Post('query')
  async query(@Body() body: { query: string }) {
    return this.skills.chat(body.query);
  }
}
```

### Fastify

```typescript
import { skillPlugin } from '@ankr/skill-loader/middleware';

fastify.register(skillPlugin, { aiProxy });

fastify.post('/chat', async (req) => {
  return req.chatWithSkills(req.body.query);
});
```

## Available Skills

| Skill | Auto-Triggers |
|-------|---------------|
| `ankr-tms-dev` | module, service, controller, nestjs, prisma |
| `ankr-eon-memory` | memory, episode, pattern, learn |
| `ankr-voice-hindi` | voice, hindi, tamil, telugu, speak |
| `ankr-llmbox` | llm, provider, cost, routing |
| `ankr-logistics-rag` | search, rag, retrieve, document |

## Provider Routing

| Condition | Provider |
|-----------|----------|
| Hindi/Tamil/Telugu | LongCat |
| Code generation | DeepSeek |
| maxCost < $0.001 | Groq |
| Default | Groq (free) |

## Cost Comparison

| Task Type | Method | Cost |
|-----------|--------|------|
| Complex coding | Claude Code + Max | $0 (Max quota) |
| Simple query | AI Proxy + Groq | $0 (free tier) |
| Hindi voice | AI Proxy + LongCat | $0 (free tier) |
| Heavy usage | AI Proxy + DeepSeek | ~$0.001/query |

## API Reference

### SkillLoader

```typescript
const loader = new SkillLoader({
  skillsPath: '.claude/skills',
  maxTokens: 8000,
  cache: true,
  autoCompress: true,
});

loader.load('ankr-tms-dev');           // Load single skill
loader.loadMultiple(['skill1', 'skill2']); // Load multiple
loader.autoDetect('query text');       // Detect relevant skills
loader.listSkills();                   // List all available
```

### SkillAwareProxy

```typescript
const proxy = createSkillAwareProxy(aiProxy, options);

proxy.chat(query, {
  skills: ['skill1'],     // Specific skills
  autoDetect: true,       // Or auto-detect
  provider: 'groq',       // Force provider
  maxCost: 0.01,          // Cost limit
  language: 'hi',         // Language routing
});

proxy.chatWithHistory(messages, options);  // With conversation
proxy.chatStream(query, options);          // Streaming
```

### VoiceSkillHandler

```typescript
const voice = createVoiceSkillHandler({
  aiProxy,
  sttProvider,
  ttsProvider,
  skillsPath: '.claude/skills',
});

voice.handle({ audio, language, userId, sessionId });
voice.handleStream({ audio, language, userId, sessionId });
voice.handleDriverCommand(command, language, driverId);
```

## License

MIT - ANKR Labs
